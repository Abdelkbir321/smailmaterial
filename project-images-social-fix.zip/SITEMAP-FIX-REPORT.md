# تقرير تشخيص وإصلاح مشكل Google Search Console "Couldn't fetch" لـ sitemap.xml

## التشخيص الفعلي للموقع المنشور

تم فحص الموقع المنشور على `https://ismailmaterial.netlify.app/sitemap.xml` مباشرة:

### الاختبارات المنجزة:

| الاختبار | النتيجة |
|---|---|
| GET /sitemap.xml | HTTP 200 ✅ (XML صالح يحتوي 25 URL) |
| HEAD /sitemap.xml | HTTP 200 ✅ |
| Googlebot user-agent | HTTP 200 ✅ |
| Accept: application/xml | HTTP 200 ✅ |
| XML validity | صالح ✅ |
| UTF-8 encoding | ✅ |

### المشاكل المكتشفة في الاستجابة الفعلية:

**1. Content-Type ناقص charset:**
```
الفعلي:     content-type: application/xml
المتوقع:    content-type: application/xml; charset=utf-8
```
ملف `netlify.toml` كان يضبط `application/xml; charset=utf-8` لكن `@netlify/plugin-nextjs` كان يتجاوزه ويزيل `charset=utf-8`.

**2. Cache-Control يمنع التخزين المؤقت:**
```
الفعلي:     cache-control: public,max-age=0,must-revalidate
المتوقع:    cache-control: public, max-age=3600, s-maxage=3600
```
`max-age=0` + `must-revaluate` يجبر Google على إعادة التحقق من كل طلب، مما يسبب فشل متقطع في الجلب.

**3. Vary header يحتوي رؤوس Next.js داخلية:**
```
vary: rsc, next-router-state-tree, next-router-prefetch, next-router-segment-prefetch, Accept-Encoding
```
Googlebot لا يرسل هذه الرؤوس، ووجودها في `Vary` يجعل Google يعتقد أن الاستجابة تختلف بناءً على رؤوس لا يفهمها.

**4. netlify-vary يحتوي cookie-based variation:**
```
netlify-vary: ...cookie=__prerender_bypass|__next_preview_data...
```
هذا يعني أن Netlify قد يخدم استجابات مختلفة بناءً على cookies. إذا كان لدى Google أي cookies، قد يحصل على استجابة مختلفة.

## السبب الجذري

**`@netlify/plugin-nextjs` يضيف رؤوس Next.js داخلية (Vary, netlify-vary, Cache-Control) إلى جميع المسارات بما فيها `/sitemap.xml` و `/robots.txt`. هذه الرؤوس مصممة لتطبيقات Next.js الديناميكية وليست مناسبة لملفات sitemap التي يحتاج Google لجلبها بشكل موثوق.**

ملف `netlify.toml` كان يحاول ضبط الرؤوس الصحيحة، لكن `@netlify/plugin-nextjs` يتجاوزها لأنه يعالج المسار بعد `netlify.toml`.

## الإصلاح المطبق

### 1. تحويل sitemap.ts إلى Route Handler صريح
- **قبل:** `src/app/sitemap.ts` (Next.js metadata convention — يولد `/sitemap.xml` تلقائياً مع رؤوس Next.js)
- **بعد:** `src/app/sitemap.xml/route.ts` (Route Handler صريح يتحكم في الرؤوس)

الـ Route Handler يضبط:
- `Content-Type: application/xml; charset=utf-8`
- `Cache-Control: public, max-age=3600, s-maxage=3600`
- `X-Content-Type-Options: nosniff`

### 2. تحويل robots.ts إلى Route Handler صريح
- **قبل:** `src/app/robots.ts`
- **بعد:** `src/app/robots.txt/route.ts`

نفس المعالجة — يضبط `Content-Type: text/plain; charset=utf-8` و `Cache-Control: public, max-age=60, s-maxage=60`.

### 3. إضافة ملف `public/_headers`
ملف `_headers` يتم معالجته بواسطة Netlify **بعد** `@netlify/plugin-nextjs`، لذلك يتجاوز الرؤوس التي يضيفها الـ plugin.

المحتوى:
```
/sitemap.xml
  Content-Type: application/xml; charset=utf-8
  Cache-Control: public, max-age=3600, s-maxage=3600
  X-Content-Type-Options: nosniff
  Vary: Accept-Encoding

/robots.txt
  Content-Type: text/plain; charset=utf-8
  Cache-Control: public, max-age=60, s-maxage=60
  X-Content-Type-Options: nosniff
  Vary: Accept-Encoding
```

هذا يضمن أن:
- `Vary` يحتوي فقط `Accept-Encoding` (وليس رؤوس Next.js الداخلية)
- `Content-Type` يحتوي `charset=utf-8`
- `Cache-Control` يسمح بالتخزين المؤقت لمدة ساعة

### 4. تحديث `netlify.toml`
تم إزالة رؤوس `/sitemap.xml` و `/robots.txt` من `netlify.toml` (لأن `public/_headers` يتولاها الآن بعد الـ plugin).

## الملفات المعدلة

| الملف | التغيير |
|---|---|
| `src/app/sitemap.ts` | تم حذفه (استبدل بـ Route Handler) |
| `src/app/sitemap.xml/route.ts` | **جديد** — Route Handler يولد XML برؤوس نظيفة |
| `src/app/robots.ts` | تم حذفه (استبدل بـ Route Handler) |
| `src/app/robots.txt/route.ts` | **جديد** — Route Handler يولد robots.txt برؤوس نظيفة |
| `public/_headers` | **جديد** — يتجاوز رؤوس Netlify plugin لـ sitemap و robots |
| `netlify.toml` | إزالة رؤوس sitemap/robots المكررة |

## نتائج الاختبارات المحلية

```
✓ Build:              Compiled successfully in 16.1s (Turbopack)
✓ sitemap.xml route:  Exists in .next/server/app/sitemap.xml/route.js
✓ robots.txt route:   Exists in .next/server/app/robots.txt/route.js
✓ GET /sitemap.xml:   HTTP 200, Content-Type: application/xml; charset=utf-8
✓ GET /robots.txt:    HTTP 200, Content-Type: text/plain; charset=utf-8
✓ Cache-Control:      public, max-age=3600, s-maxage=3600 (sitemap)
✓ Cache-Control:      public, max-age=60, s-maxage=60 (robots)
✓ XML body:           صالح، يحتوي 25 URL
✓ Googlebot test:     HTTP 200
✓ HEAD request:       HTTP 200
✓ All pages:          HTTP 200 (/, /produits, /cart, /checkout, /admin/login)
```

### مقارنة قبل/بعد:

| الرأس | قبل (مباشر) | بعد (محلي) |
|---|---|---|
| Content-Type | `application/xml` | `application/xml; charset=utf-8` ✅ |
| Cache-Control | `public,max-age=0,must-revalidate` | `public, max-age=3600, s-maxage=3600` ✅ |
| Vary | `rsc, next-router-*, Accept-Encoding` | `Accept-Encoding` (عبر _headers) ✅ |

## ما لم يتم اختباره

- **النسخة المنشورة على Netlify:** لم أتمكن من نشر النسخة الجديدة على Netlify للتأكد من أن `public/_headers` يتجاوز فعلاً رؤوس `@netlify/plugin-nextjs`. هذا يتطلب نشر فعلي.

- **اختبار Googlebot الحقيقي:** لا أملك وصولاً إلى Google Search Console للتأكد من أن المشكل حل.

## الخطوات التالية المطلوبة

1. **انشر النسخة الجديدة على Netlify** (الـ ZIP جاهز)
2. **بعد النشر، اختبر الرؤوس الفعلية:**
   ```bash
   curl -sI https://ismailmaterial.netlify.app/sitemap.xml
   ```
   يجب أن ترى:
   - `content-type: application/xml; charset=utf-8`
   - `cache-control: public, max-age=3600, s-maxage=3600`
   - `vary: Accept-Encoding` (وليس `rsc, next-router-*`)

3. **في Google Search Console:**
   - اذهب إلى Sitemaps
   - احذف الـ sitemap القديم
   - أعد إضافته: `https://ismailmaterial.netlify.app/sitemap.xml`
   - انتظر 24-48 ساعة

4. **إذا استمر المشكل بعد النشر:**
   - تحقق من أن `public/_headers` تم نسخه إلى مجلد النشر
   - جرب إضافة `force = true` في `netlify.toml` للرؤوس
   - استعمل أداة Google's "Inspect URL" للتشخيص الدقيق

## ما تم الحفاظ عليه
- ✅ جميع المنتجات والطلبات والبيانات
- ✅ DATABASE_URL, AUTH_SECRET, Cloudinary — بدون تغيير
- ✅ نظام SEO (metadata, canonical, JSON-LD)
- ✅ التصميم والوظائف الحالية
- ✅ قاعدة بيانات Neon — بدون reset
