import { db } from '../src/lib/db'

/**
 * Seed default order fields (idempotent). Run with:
 *   unset DATABASE_URL && bun run prisma/seed-order-fields.ts
 */
const DEFAULTS = [
  { key: 'full_name', type: 'text' as const, labelAr: 'الاسم الكامل', labelFr: 'Nom complet', labelEn: 'Full name', required: true, sortOrder: 1, width: 'full' },
  { key: 'phone', type: 'phone' as const, labelAr: 'الهاتف', labelFr: 'Téléphone', labelEn: 'Phone', required: true, sortOrder: 2, width: 'half' },
  { key: 'email', type: 'email' as const, labelAr: 'البريد الإلكتروني', labelFr: 'Email', labelEn: 'Email', required: false, sortOrder: 3, width: 'half' },
  { key: 'country', type: 'select' as const, labelAr: 'الدولة', labelFr: 'Pays', labelEn: 'Country', required: true, sortOrder: 4, width: 'half' },
  { key: 'city', type: 'text' as const, labelAr: 'المدينة', labelFr: 'Ville', labelEn: 'City', required: true, sortOrder: 5, width: 'half' },
  { key: 'address', type: 'textarea' as const, labelAr: 'العنوان الكامل', labelFr: 'Adresse complète', labelEn: 'Full address', required: true, sortOrder: 6, width: 'full' },
  { key: 'postal_code', type: 'text' as const, labelAr: 'الرمز البريدي', labelFr: 'Code postal', labelEn: 'Postal code', required: false, sortOrder: 7, width: 'half' },
  { key: 'notes', type: 'textarea' as const, labelAr: 'ملاحظات', labelFr: 'Notes', labelEn: 'Notes', required: false, sortOrder: 8, width: 'full' },
]

async function main() {
  for (const f of DEFAULTS) {
    await db.orderField.upsert({
      where: { key: f.key },
      create: f,
      update: { type: f.type, labelAr: f.labelAr, labelFr: f.labelFr, labelEn: f.labelEn, required: f.required, sortOrder: f.sortOrder, width: f.width },
    })
    console.log(`  ✓ order field: ${f.key}`)
  }
  console.log(`✅ Seeded ${DEFAULTS.length} order fields`)
}

main()
  .catch((e) => { console.error(e); process.exit(1) })
  .finally(() => db.$disconnect())
