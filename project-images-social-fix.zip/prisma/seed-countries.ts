/**
 * Seed all world countries + currencies into the Neon database.
 * Run with: npx tsx prisma/seed-countries.ts
 *
 * - Uses ISO 3166-1 alpha-2 country codes
 * - Uses ISO 4217 currency codes
 * - Preserves existing countries (upsert by code)
 * - Morocco (MA) is set as default + enabled + sortOrder 0
 * - All other countries are disabled by default (admin enables them)
 */

import { PrismaClient } from '@prisma/client'

const db = new PrismaClient()

// Comprehensive list of countries with their currencies
// Format: [code, name, nameAr, currencyCode, currencySymbol, phonePrefix]
const COUNTRIES: Array<[string, string, string, string, string, string]> = [
  // North Africa
  ['MA', 'Morocco', 'المغرب', 'MAD', 'DH', '+212'],
  ['DZ', 'Algeria', 'الجزائر', 'DZD', 'DA', '+213'],
  ['TN', 'Tunisia', 'تونس', 'TND', 'DT', '+216'],
  ['LY', 'Libya', 'ليبيا', 'LYD', 'LD', '+218'],
  ['EG', 'Egypt', 'مصر', 'EGP', 'E£', '+20'],
  ['SD', 'Sudan', 'السودان', 'SDG', 'SDG', '+249'],

  // Middle East
  ['SA', 'Saudi Arabia', 'السعودية', 'SAR', 'SR', '+966'],
  ['AE', 'United Arab Emirates', 'الإمارات', 'AED', 'AED', '+971'],
  ['QA', 'Qatar', 'قطر', 'QAR', 'QR', '+974'],
  ['KW', 'Kuwait', 'الكويت', 'KWD', 'KD', '+965'],
  ['BH', 'Bahrain', 'البحرين', 'BHD', 'BD', '+973'],
  ['OM', 'Oman', 'عمان', 'OMR', 'OMR', '+968'],
  ['JO', 'Jordan', 'الأردن', 'JOD', 'JD', '+962'],
  ['LB', 'Lebanon', 'لبنان', 'LBP', 'LBP', '+961'],
  ['SY', 'Syria', 'سوريا', 'SYP', 'SYP', '+963'],
  ['IQ', 'Iraq', 'العراق', 'IQD', 'IQD', '+964'],
  ['YE', 'Yemen', 'اليمن', 'YER', 'YER', '+967'],
  ['PS', 'Palestine', 'فلسطين', 'ILS', '₪', '+970'],
  ['IL', 'Israel', 'إسرائيل', 'ILS', '₪', '+972'],
  ['IR', 'Iran', 'إيران', 'IRR', 'IRR', '+98'],

  // Europe
  ['FR', 'France', 'فرنسا', 'EUR', '€', '+33'],
  ['DE', 'Germany', 'ألمانيا', 'EUR', '€', '+49'],
  ['IT', 'Italy', 'إيطاليا', 'EUR', '€', '+39'],
  ['ES', 'Spain', 'إسبانيا', 'EUR', '€', '+34'],
  ['PT', 'Portugal', 'البرتغال', 'EUR', '€', '+351'],
  ['NL', 'Netherlands', 'هولندا', 'EUR', '€', '+31'],
  ['BE', 'Belgium', 'بلجيكا', 'EUR', '€', '+32'],
  ['LU', 'Luxembourg', 'لوكسمبورغ', 'EUR', '€', '+352'],
  ['IE', 'Ireland', 'أيرلندا', 'EUR', '€', '+353'],
  ['AT', 'Austria', 'النمسا', 'EUR', '€', '+43'],
  ['GR', 'Greece', 'اليونان', 'EUR', '€', '+30'],
  ['CY', 'Cyprus', 'قبرص', 'EUR', '€', '+357'],
  ['MT', 'Malta', 'مالطا', 'EUR', '€', '+356'],
  ['FI', 'Finland', 'فنلندا', 'EUR', '€', '+358'],
  ['SK', 'Slovakia', 'سلوفاكيا', 'EUR', '€', '+421'],
  ['SI', 'Slovenia', 'سلوفينيا', 'EUR', '€', '+386'],
  ['EE', 'Estonia', 'إستونيا', 'EUR', '€', '+372'],
  ['LV', 'Latvia', 'لاتفيا', 'EUR', '€', '+371'],
  ['LT', 'Lithuania', 'ليتوانيا', 'EUR', '€', '+370'],
  ['HR', 'Croatia', 'كرواتيا', 'EUR', '€', '+385'],

  ['GB', 'United Kingdom', 'المملكة المتحدة', 'GBP', '£', '+44'],
  ['CH', 'Switzerland', 'سويسرا', 'CHF', 'CHF', '+41'],
  ['NO', 'Norway', 'النرويج', 'NOK', 'kr', '+47'],
  ['SE', 'Sweden', 'السويد', 'SEK', 'kr', '+46'],
  ['DK', 'Denmark', 'الدنمارك', 'DKK', 'kr', '+45'],
  ['IS', 'Iceland', 'أيسلندا', 'ISK', 'kr', '+354'],
  ['PL', 'Poland', 'بولندا', 'PLN', 'zł', '+48'],
  ['CZ', 'Czech Republic', 'التشيك', 'CZK', 'Kč', '+420'],
  ['HU', 'Hungary', 'المجر', 'HUF', 'Ft', '+36'],
  ['RO', 'Romania', 'رومانيا', 'RON', 'lei', '+40'],
  ['BG', 'Bulgaria', 'بلغاريا', 'BGN', 'lv', '+359'],
  ['RS', 'Serbia', 'صربيا', 'RSD', 'din', '+381'],
  ['BA', 'Bosnia and Herzegovina', 'البوسنة', 'BAM', 'KM', '+387'],
  ['AL', 'Albania', 'ألبانيا', 'ALL', 'L', '+355'],
  ['MK', 'North Macedonia', 'مقدونيا الشمالية', 'MKD', 'den', '+389'],
  ['ME', 'Montenegro', 'الجبل الأسود', 'EUR', '€', '+382'],
  ['MD', 'Moldova', 'مولدوفا', 'MDL', 'L', '+373'],
  ['UA', 'Ukraine', 'أوكرانيا', 'UAH', '₴', '+380'],
  ['BY', 'Belarus', 'بيلاروس', 'BYN', 'Br', '+375'],
  ['RU', 'Russia', 'روسيا', 'RUB', '₽', '+7'],

  // Americas
  ['US', 'United States', 'الولايات المتحدة', 'USD', '$', '+1'],
  ['CA', 'Canada', 'كندا', 'CAD', 'C$', '+1'],
  ['MX', 'Mexico', 'المكسيك', 'MXN', '$', '+52'],
  ['BR', 'Brazil', 'البرازيل', 'BRL', 'R$', '+55'],
  ['AR', 'Argentina', 'الأرجنتين', 'ARS', '$', '+54'],
  ['CL', 'Chile', 'تشيلي', 'CLP', '$', '+56'],
  ['CO', 'Colombia', 'كولومبيا', 'COP', '$', '+57'],
  ['PE', 'Peru', 'البيرو', 'PEN', 'S/', '+51'],
  ['VE', 'Venezuela', 'فنزويلا', 'VES', 'Bs', '+58'],
  ['EC', 'Ecuador', 'الإكوادور', 'USD', '$', '+593'],
  ['BO', 'Bolivia', 'بوليفيا', 'BOB', 'Bs', '+591'],
  ['PY', 'Paraguay', 'باراغواي', 'PYG', '₲', '+595'],
  ['UY', 'Uruguay', 'الأوروغواي', 'UYU', '$U', '+598'],
  ['CR', 'Costa Rica', 'كوستاريكا', 'CRC', '₡', '+506'],
  ['PA', 'Panama', 'بنما', 'USD', 'B/', '+507'],
  ['DO', 'Dominican Republic', 'الدومينيكان', 'DOP', 'RD$', '+809'],
  ['GT', 'Guatemala', 'غواتيمالا', 'GTQ', 'Q', '+502'],
  ['HN', 'Honduras', 'هندوراس', 'HNL', 'L', '+504'],
  ['SV', 'El Salvador', 'السلفادور', 'USD', '$', '+503'],
  ['NI', 'Nicaragua', 'نيكاراغوا', 'NIO', 'C$', '+505'],
  ['CU', 'Cuba', 'كوبا', 'CUP', '$', '+53'],
  ['JM', 'Jamaica', 'جامايكا', 'JMD', 'J$', '+876'],
  ['TT', 'Trinidad and Tobago', 'ترينيداد', 'TTD', 'TT$', '+868'],
  ['BB', 'Barbados', 'بربادوس', 'BBD', 'Bds$', '+1246'],
  ['BS', 'Bahamas', 'الباهاما', 'BSD', 'B$', '+1242'],

  // Asia
  ['CN', 'China', 'الصين', 'CNY', '¥', '+86'],
  ['JP', 'Japan', 'اليابان', 'JPY', '¥', '+81'],
  ['KR', 'South Korea', 'كوريا الجنوبية', 'KRW', '₩', '+82'],
  ['KP', 'North Korea', 'كوريا الشمالية', 'KPW', '₩', '+850'],
  ['IN', 'India', 'الهند', 'INR', '₹', '+91'],
  ['PK', 'Pakistan', 'باكستان', 'PKR', '₨', '+92'],
  ['BD', 'Bangladesh', 'بنغلاديش', 'BDT', '৳', '+880'],
  ['LK', 'Sri Lanka', 'سريلانكا', 'LKR', 'Rs', '+94'],
  ['NP', 'Nepal', 'نيبال', 'NPR', 'Rs', '+977'],
  ['AF', 'Afghanistan', 'أفغانستان', 'AFN', '؋', '+93'],
  ['TH', 'Thailand', 'تايلاند', 'THB', '฿', '+66'],
  ['VN', 'Vietnam', 'فيتنام', 'VND', '₫', '+84'],
  ['MY', 'Malaysia', 'ماليزيا', 'MYR', 'RM', '+60'],
  ['SG', 'Singapore', 'سنغافورة', 'SGD', 'S$', '+65'],
  ['ID', 'Indonesia', 'إندونيسيا', 'IDR', 'Rp', '+62'],
  ['PH', 'Philippines', 'الفلبين', 'PHP', '₱', '+63'],
  ['MM', 'Myanmar', 'ميانمار', 'MMK', 'K', '+95'],
  ['KH', 'Cambodia', 'كمبوديا', 'KHR', '៛', '+855'],
  ['LA', 'Laos', 'لاوس', 'LAK', '₭', '+856'],
  ['BN', 'Brunei', 'بروناي', 'BND', 'B$', '+673'],
  ['TL', 'Timor-Leste', 'تيمور الشرقية', 'USD', '$', '+670'],
  ['TW', 'Taiwan', 'تايوان', 'TWD', 'NT$', '+886'],
  ['HK', 'Hong Kong', 'هونغ كونغ', 'HKD', 'HK$', '+852'],
  ['MO', 'Macao', 'ماكاو', 'MOP', 'MOP', '+853'],
  ['KZ', 'Kazakhstan', 'كازاخستان', 'KZT', '₸', '+7'],
  ['UZ', 'Uzbekistan', 'أوزبكستان', 'UZS', 'so\'m', '+998'],
  ['KG', 'Kyrgyzstan', 'قيرغيزستان', 'KGS', 'som', '+996'],
  ['TJ', 'Tajikistan', 'طاجيكستان', 'TJS', 'somoni', '+992'],
  ['TM', 'Turkmenistan', 'تركمانستان', 'TMT', 'm', '+993'],
  ['AZ', 'Azerbaijan', 'أذربيجان', 'AZN', 'manat', '+994'],
  ['AM', 'Armenia', 'أرمينيا', 'AMD', 'dram', '+374'],
  ['GE', 'Georgia', 'جورجيا', 'GEL', '₾', '+995'],
  ['TR', 'Turkey', 'تركيا', 'TRY', '₺', '+90'],
  ['MN', 'Mongolia', 'منغوليا', 'MNT', '₮', '+976'],

  // Sub-Saharan Africa
  ['NG', 'Nigeria', 'نيجيريا', 'NGN', '₦', '+234'],
  ['GH', 'Ghana', 'غانا', 'GHS', '₵', '+233'],
  ['KE', 'Kenya', 'كينيا', 'KES', 'KSh', '+254'],
  ['ET', 'Ethiopia', 'إثيوبيا', 'ETB', 'Br', '+251'],
  ['TZ', 'Tanzania', 'تنزانيا', 'TZS', 'TSh', '+255'],
  ['UG', 'Uganda', 'أوغندا', 'UGX', 'USh', '+256'],
  ['RW', 'Rwanda', 'رواندا', 'RWF', 'RF', '+250'],
  ['BI', 'Burundi', 'بوروندي', 'BIF', 'FBu', '+257'],
  ['SO', 'Somalia', 'الصومال', 'SOS', 'Sh', '+252'],
  ['DJ', 'Djibouti', 'جيبوتي', 'DJF', 'Fdj', '+253'],
  ['ER', 'Eritrea', 'إريتريا', 'ERN', 'Nfk', '+291'],
  ['SS', 'South Sudan', 'جنوب السودان', 'SSP', 'SSP', '+211'],
  ['CF', 'Central African Republic', 'أفريقيا الوسطى', 'XAF', 'FCFA', '+236'],
  ['TD', 'Chad', 'تشاد', 'XAF', 'FCFA', '+235'],
  ['CM', 'Cameroon', 'الكاميرون', 'XAF', 'FCFA', '+237'],
  ['CG', 'Congo', 'الكونغو', 'XAF', 'FCFA', '+242'],
  ['CD', 'DR Congo', 'الكونغو الديمقراطية', 'CDF', 'FC', '+243'],
  ['GA', 'Gabon', 'الغابون', 'XAF', 'FCFA', '+241'],
  ['GQ', 'Equatorial Guinea', 'غينيا الاستوائية', 'XAF', 'FCFA', '+240'],
  ['ST', 'São Tomé and Príncipe', 'ساو تومي', 'STN', 'Db', '+239'],
  ['AO', 'Angola', 'أنغولا', 'AOA', 'Kz', '+244'],
  ['ZM', 'Zambia', 'زامبيا', 'ZMW', 'ZK', '+260'],
  ['ZW', 'Zimbabwe', 'زيمبابوي', 'ZWL', 'Z$', '+263'],
  ['MW', 'Malawi', 'مالاوي', 'MWK', 'MK', '+265'],
  ['MZ', 'Mozambique', 'موزمبيق', 'MZN', 'MT', '+258'],
  ['BW', 'Botswana', 'بوتسوانا', 'BWP', 'P', '+267'],
  ['NA', 'Namibia', 'ناميبيا', 'NAD', 'N$', '+264'],
  ['LS', 'Lesotho', 'ليسوتو', 'LSL', 'L', '+266'],
  ['SZ', 'Eswatini', 'إسواتيني', 'SZL', 'E', '+268'],
  ['MG', 'Madagascar', 'مدغشقر', 'MGA', 'Ar', '+261'],
  ['MU', 'Mauritius', 'موريشيوس', 'MUR', 'Rs', '+230'],
  ['SC', 'Seychelles', 'سيشل', 'SCR', 'SR', '+248'],
  ['CV', 'Cape Verde', 'الرأس الأخضر', 'CVE', '$', '+238'],
  ['GW', 'Guinea-Bissau', 'غينيا بيساو', 'XOF', 'CFA', '+245'],
  ['GN', 'Guinea', 'غينيا', 'GNF', 'FG', '+224'],
  ['SL', 'Sierra Leone', 'سيراليون', 'SLL', 'Le', '+232'],
  ['LR', 'Liberia', 'ليبيريا', 'LRD', 'L$', '+231'],
  ['CI', 'Ivory Coast', 'ساحل العاج', 'XOF', 'CFA', '+225'],
  ['BF', 'Burkina Faso', 'بوركينا فاسو', 'XOF', 'CFA', '+226'],
  ['ML', 'Mali', 'مالي', 'XOF', 'CFA', '+223'],
  ['SN', 'Senegal', 'السنغال', 'XOF', 'CFA', '+221'],
  ['NE', 'Niger', 'النيجر', 'XOF', 'CFA', '+227'],
  ['TG', 'Togo', 'توغو', 'XOF', 'CFA', '+228'],
  ['BJ', 'Benin', 'بنين', 'XOF', 'CFA', '+229'],
  ['MR', 'Mauritania', 'موريتانيا', 'MRU', 'UM', '+222'],
  ['KM', 'Comoros', 'جزر القمر', 'KMF', 'CF', '+269'],

  // Oceania
  ['AU', 'Australia', 'أستراليا', 'AUD', 'A$', '+61'],
  ['NZ', 'New Zealand', 'نيوزيلندا', 'NZD', 'NZ$', '+64'],
  ['FJ', 'Fiji', 'فيجي', 'FJD', 'FJ$', '+679'],
  ['PG', 'Papua New Guinea', 'بابوا غينيا', 'PGK', 'K', '+675'],
  ['WS', 'Samoa', 'ساموا', 'WST', 'T', '+685'],
  ['TO', 'Tonga', 'تونغا', 'TOP', 'T$', '+676'],
  ['VU', 'Vanuatu', 'فانواتو', 'VUV', 'Vt', '+678'],
  ['SB', 'Solomon Islands', 'جزر سليمان', 'SBD', 'SI$', '+677'],
  ['KI', 'Kiribati', 'كيريباتي', 'AUD', 'A$', '+686'],
  ['TV', 'Tuvalu', 'توفالو', 'AUD', 'A$', '+688'],
  ['NR', 'Nauru', 'ناورو', 'AUD', 'A$', '+674'],
  ['PW', 'Palau', 'بالاو', 'USD', '$', '+680'],
  ['MH', 'Marshall Islands', 'جزر مارشال', 'USD', '$', '+692'],
  ['FM', 'Micronesia', 'ميكرونيزيا', 'USD', '$', '+691'],

  // Other
  ['VA', 'Vatican City', 'الفاتيكان', 'EUR', '€', '+379'],
  ['MC', 'Monaco', 'موناكو', 'EUR', '€', '+377'],
  ['AD', 'Andorra', 'أندورا', 'EUR', '€', '+376'],
  ['SM', 'San Marino', 'سان مارينو', 'EUR', '€', '+378'],
  ['LI', 'Liechtenstein', 'ليختنشتاين', 'CHF', 'CHF', '+423'],
]

async function main() {
  console.log(`Seeding ${COUNTRIES.length} countries...`)

  let created = 0
  let updated = 0

  for (let i = 0; i < COUNTRIES.length; i++) {
    const [code, name, nameAr, currencyCode, currencySymbol, phonePrefix] = COUNTRIES[i]
    const isDefault = code === 'MA'
    const isEnabled = code === 'MA' // Only Morocco enabled by default
    const sortOrder = i

    const result = await db.country.upsert({
      where: { code },
      create: {
        code,
        name,
        nameAr,
        currencyCode,
        currencySymbol,
        phonePrefix,
        locale: 'fr',
        isEnabled,
        isDefault,
        sortOrder,
        shippingBase: 0,
        shippingPerKg: 0,
        taxRate: 0,
      },
      update: {
        // Only update fields that should be refreshed
        // Preserve isEnabled, isDefault, shippingBase, taxRate if already set
        name,
        nameAr,
        currencyCode,
        currencySymbol,
        phonePrefix,
        sortOrder,
      },
    })

    if (result.createdAt) {
      created++
    } else {
      updated++
    }
  }

  // Ensure only Morocco is default
  await db.country.updateMany({
    where: { code: { not: 'MA' } },
    data: { isDefault: false },
  })

  console.log(`Done! Created: ${created}, Updated: ${updated}, Total: ${COUNTRIES.length}`)
}

main()
  .catch((e) => {
    console.error('Seed failed:', e)
    process.exit(1)
  })
  .finally(async () => {
    await db.$disconnect()
  })
