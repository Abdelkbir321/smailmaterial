import { db } from '../src/lib/db'
import { hashPassword } from '../src/lib/password'
import { PERMISSION_SECTIONS, ROLE_PERMISSIONS, superAdminPermissions } from '../src/lib/permissions'
import type { PermissionAction } from '../src/lib/permissions'

/**
 * Re-seed roles with the full RBAC permission model (21 sections × actions),
 * + ensure the super-admin exists. Idempotent — safe to re-run.
 * Run:  unset DATABASE_URL && bun run prisma/seed-roles.ts
 */

const ROLES = [
  { name: 'Super Admin', slug: 'super-admin', description: 'كل الصلاحيات، بما فيها إدارة المسؤولين والصلاحيات والأمان.', permissions: superAdminPermissions() },
  { name: 'Store Manager', slug: 'store-manager', description: 'العمليات اليومية: منتجات، مخزون، طلبات، زبناء.', permissions: ROLE_PERMISSIONS['store-manager'] || {} },
  { name: 'Products Manager', slug: 'products-manager', description: 'المنتجات والصور والتصنيفات والمخزون.', permissions: ROLE_PERMISSIONS['products-manager'] || {} },
  { name: 'Orders Manager', slug: 'orders-manager', description: 'الطلبات وتحديث الحالة والزبناء.', permissions: ROLE_PERMISSIONS['orders-manager'] || {} },
  { name: 'Content & SEO Manager', slug: 'content-seo-manager', description: 'المحتوى والصفحات وSEO والهوية البصرية.', permissions: ROLE_PERMISSIONS['content-seo-manager'] || {} },
  { name: 'Support Agent', slug: 'support-agent', description: 'خدمة الزبناء: عرض الطلبات والزبناء.', permissions: ROLE_PERMISSIONS['support-agent'] || {} },
]

async function main() {
  for (const r of ROLES) {
    await db.role.upsert({
      where: { slug: r.slug },
      create: { slug: r.slug, name: r.name, description: r.description, permissions: r.permissions as any },
      update: { name: r.name, description: r.description, permissions: r.permissions as any },
    })
    console.log(`  ✓ role: ${r.slug}`)
  }
  // Ensure super-admin user exists
  const superRole = await db.role.findUnique({ where: { slug: 'super-admin' } })
  if (superRole) {
    const existing = await db.adminUser.findUnique({ where: { email: 'admin@ismailmaterial.ma' } })
    if (!existing) {
      const pwHash = await hashPassword('admin12345')
      await db.adminUser.create({
        data: { email: 'admin@ismailmaterial.ma', fullName: 'Ismail Material Super Admin', passwordHash: pwHash, roleId: superRole.id, status: 'ACTIVE' },
      })
      console.log('  ✓ super-admin user created (admin@ismailmaterial.ma / admin12345)')
    } else {
      await db.adminUser.update({ where: { id: existing.id }, data: { roleId: superRole.id } })
      console.log('  ✓ super-admin user exists, role ensured')
    }
  }
  console.log(`\n✅ Seeded ${ROLES.length} roles with RBAC permissions`)
  console.log(`   Sections: ${PERMISSION_SECTIONS.length}, Actions: view|create|edit|delete|publish|manage_settings`)
}

main()
  .catch((e) => { console.error(e); process.exit(1) })
  .finally(() => db.$disconnect())
