# تطوير لوحة التحكم: الفئات والطلبات — تقرير التنفيذ

## ما تم تنفيذه

### 1. تحكم كامل في الفئات Categories

#### API جديد:
- **`/api/admin/categories/[id]`** (جديد كلياً):
  - `GET` — جلب فئة واحدة مع عدد المنتجات
  - `PUT` — تعديل (اسم، slug، وصف، صورة، ظاهرة، ترتيب، SEO)
  - `DELETE` — حذف مع خيارات:
    - نقل المنتجات لفئة أخرى (`productAction: 'move'` + `targetCategoryId`)
    - إلغاء العملية (`productAction: 'cancel'`)
  - منع المرجعية الدائرية (لا يمكن تعيين فئة كأب لنفسها)
  - التحقق من uniqueness الـ slug
  - `revalidateTag('catalog')` + `revalidateTag('sitemap')` بعد كل تغيير
  - حماية بـ `requirePermission('categories', 'edit'/'delete')`

- **`/api/admin/categories/bulk`** (جديد كلياً):
  - `POST` — عمليات جماعية:
    - `delete` — حذف عدة فئات (مع نقل المنتجات)
    - `show` — إظهار عدة فئات
    - `hide` — إخفاء عدة فئات
  - Transaction آمن: ينقل المنتجات، يحدّث الأبناء، يحذف الفئات
  - منع نقل المنتجات لفئة سيتم حذفها

#### واجهة الإدارة (categories page):
- ✅ جدول كامل مع: صورة، اسم، slug، عدد المنتجات، حالة الظهور، التاريخ
- ✅ بحث فوري (debounce 300ms)
- ✅ إضافة فئة (Dialog مع: اسم، slug، اسم عربي، وصف، صورة، ظاهرة، ترتيب)
- ✅ تعديل فئة (Dialog بنفس الحقول)
- ✅ حذف فئة مع نافذة تأكيد
- ✅ حذف فئة بمنتجات: اختيار نقل المنتجات لفئة أخرى أو إلغاء
- ✅ إظهار/إخفاء فردي (inline toggle)
- ✅ تحديد عدة فئات (checkbox)
- ✅ "تحديد الكل" / "إلغاء التحديد"
- ✅ حذف جماعي مع تأكيد
- ✅ إظهار/إخفاء جماعي
- ✅ عداد المحدد
- ✅ عرض بطاقات على الهاتف (responsive)
- ✅ عرض جدول على الكمبيوتر

### 2. إدارة الطلبات Orders

#### API جديد:
- **`/api/admin/orders/bulk`** (جديد كلياً):
  - `POST` — عمليات جماعية:
    - `delete` — حذف نهائي من قاعدة البيانات (مع OrderItem + OrderStatusHistory تلقائياً عبر Cascade)
    - `status` — تغيير حالة عدة طلبات (يستخدم `updateOrderStatus` لكتابة سجل الحالة)
  - حماية بـ `requirePermission('orders', 'delete'/'edit')`
  - Audit log لكل عملية
  - `revalidateTag('catalog')` بعد الحذف

#### واجهة الإدارة (orders page):
- ✅ جدول كامل: رقم، عميل، هاتف، حالة، دفع، عناصر، إجمالي، دولة، تاريخ
- ✅ بحث (رقم، اسم، هاتف) — debounce 350ms
- ✅ فلترة بالحالة (9 حالات بما فيها RETURNED)
- ✅ تحديد عدة طلبات (checkbox)
- ✅ "تحديد الكل في الصفحة"
- ✅ عداد المحدد
- ✅ حذف جماعي مع تأكيد ("واش متأكد أنك باغي تحذف X طلب؟")
- ✅ تغيير حالة جماعي (Dialog لاختيار الحالة)
- ✅ عرض بطاقات على الهاتف/التابليت
- ✅ عرض جدول على الكمبيوتر (lg:block)
- ✅ pagination
- ✅ تحديث مباشر بعد العمليات (لا حاجة لإعادة تحميل)

### 3. تصميم لوحة التحكم

- ✅ Sidebar موجودة (`AdminShell` بـ shadcn/ui Sidebar، RTL، `collapsible="icon"`)
- ✅ Header منظم (`PageHeader` مع breadcrumb + actions)
- ✅ توحيد الأحجام (أزرار `size="sm"`, حقول `h-9`, text-xs/text-sm متناسق)
- ✅ Responsive:
  - الهاتف: بطاقات مرتبة عمودياً
  - التابليت: بطاقات
  - الكمبيوتر: جداول كاملة
- ✅ حالات واضحة: loading (Spinner), empty (EmptyState), error (toast)
- ✅ ألوان متناسقة: rose للحذف، emerald للنجاح، amber للتحذير
- ✅ RTL كامل (dir="rtl", side="right")
- ✅ Toaster (sonner) للحصول على إشعارات

### 4. الأمان وقاعدة البيانات

- ✅ `requireAdmin()` على كل API
- ✅ `requirePermission(section, action)` على عمليات التعديل/الحذف
- ✅ Transactions للعمليات متعددة الجداول
- ✅ Audit log لكل عملية
- ✅ لا حذف للمنتجات عند حذف فئة (نقل فقط)
- ✅ لا حذف للعملاء (Order.customer relation: `SetNull` آمن)
- ✅ لا reset لقاعدة البيانات
- ✅ DATABASE_URL, AUTH_SECRET, Cloudinary — بدون تغيير
- ✅ منع HTML/JS injection (Zod validation)

### 5. التوافق مع الموقع العام

- ✅ `revalidateTag('catalog')` يحدّث الكاش فوراً
- ✅ `revalidateTag('sitemap')` يحدّث sitemap
- ✅ الفئات المحذوفة تختفي من الصفحة الرئيسية، قائمة الفئات، الفلاتر
- ✅ لا تأثير على checkout أو السلة أو الطلبات

## الملفات الجديدة

| الملف | الوصف |
|---|---|
| `src/app/api/admin/categories/[id]/route.ts` | GET/PUT/DELETE لفئة واحدة |
| `src/app/api/admin/categories/bulk/route.ts` | عمليات جماعية (حذف، إظهار، إخفاء) |
| `src/app/api/admin/orders/bulk/route.ts` | عمليات جماعية (حذف، تغيير حالة) |

## الملفات المعدلة

| الملف | التغيير |
|---|---|
| `src/app/admin/(dashboard)/categories/page.tsx` | إعادة كتابة كاملة: بحث، تعديل، حذف، bulk actions، responsive |
| `src/app/admin/(dashboard)/orders/page.tsx` | إعادة كتابة كاملة: bulk select، bulk delete، bulk status، responsive |

## نتائج الاختبارات

```
✓ Build:              Compiled successfully in 15.5s (Turbopack)
✓ Homepage:           HTTP 200 ✅
✓ Products:           HTTP 200 ✅
✓ Cart:               HTTP 200 ✅
✓ Checkout:           HTTP 200 ✅
✓ Admin login:        HTTP 200 ✅
✓ Admin categories:   HTTP 307 (redirect to login = correct auth) ✅
✓ Admin orders:       HTTP 307 (redirect to login = correct auth) ✅
✓ GET /api/admin/categories: HTTP 401 (auth required) ✅
✓ GET /api/admin/orders: HTTP 401 (auth required) ✅
✓ POST /api/admin/categories/bulk: HTTP 401 (auth required) ✅
✓ POST /api/admin/orders/bulk: HTTP 401 (auth required) ✅
✓ Database:           ok ✅
```

## الميزات المضافة

### الفئات:
1. ✅ عرض مع صورة، اسم، slug، عدد المنتجات، حالة، تاريخ
2. ✅ إضافة فئة (مع صورة، وصف، SEO)
3. ✅ تعديل فئة
4. ✅ حذف فئة مع تأكيد
5. ✅ حذف فئة بمنتجات: نقل لفئة أخرى
6. ✅ إظهار/إخفاء فردي
7. ✅ بحث
8. ✅ تحديد متعدد + حذف جماعي
9. ✅ تحديد متعدد + إظهار/إخفاء جماعي
10. ✅ Responsive (بطاقات على الهاتف)

### الطلبات:
1. ✅ عرض جدول كامل
2. ✅ بحث (رقم، اسم، هاتف)
3. ✅ فلترة بالحالة (9 حالات)
4. ✅ تحديد متعدد (checkbox)
5. ✅ تحديد الكل في الصفحة
6. ✅ عداد المحدد
7. ✅ حذف جماعي مع تأكيد ("حذف X طلب")
8. ✅ تغيير حالة جماعي
9. ✅ حذف نهائي من قاعدة البيانات (Cascade)
10. ✅ Responsive (بطاقات على الهاتف/التابليت)
11. ✅ تحديث مباشر بعد العمليات

## خطوات النشر

1. فك الـ ZIP
2. `npm install`
3. اضبط env vars على Netlify (DATABASE_URL, AUTH_SECRET, NEXT_PUBLIC_SITE_URL)
4. Deploy
5. سجّل كـ admin → جرّب صفحات الفئات والطلبات الجديدة
