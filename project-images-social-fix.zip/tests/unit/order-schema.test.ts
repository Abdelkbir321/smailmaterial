/**
 * Focused test for the dynamic baseSchema logic in /api/orders/route.ts.
 *
 * Run with: bun test tests/unit/order-schema.test.ts
 *
 * Verifies the FIX for the "المرجو تصحيح الحقول المشار إليها بالأحمر." bug
 * where deactivated OrderFields still blocked checkout.
 *
 * We extract the schema-building logic from the route handler so it can be
 * tested without a DB. The route handler now uses this same logic (refactored
 * into src/lib/order-schema.ts).
 */

import { describe, it, expect } from 'bun:test'
import { z } from 'zod'
import type { OrderField } from '@prisma/client'
import { buildOrderSchemaFromFields } from '@/lib/order-schema'

const baseRow = (key: string, overrides: Partial<OrderField> = {}): OrderField => ({
  id: `id_${key}`,
  key,
  type: 'text',
  labelAr: key,
  labelFr: key,
  labelEn: key,
  placeholderAr: null,
  placeholderFr: null,
  placeholderEn: null,
  helpTextAr: null,
  helpTextFr: null,
  helpTextEn: null,
  options: [],
  required: true,
  isActive: true,
  sortOrder: 0,
  defaultValue: null,
  width: 'full',
  minLength: null,
  maxLength: null,
  countryCodes: [],
  createdAt: new Date(),
  updatedAt: new Date(),
  ...overrides,
})

describe('buildOrderSchemaFromFields — dynamic checkout schema', () => {
  it('accepts a complete valid order with all default fields active', async () => {
    const fields: OrderField[] = [
      baseRow('full_name', { type: 'text', required: true }),
      baseRow('phone', { type: 'phone', required: true }),
      baseRow('email', { type: 'email', required: false }),
      baseRow('country', { type: 'select', required: true }),
      baseRow('city', { type: 'text', required: true }),
      baseRow('address', { type: 'textarea', required: true }),
      baseRow('postal_code', { type: 'text', required: false }),
      baseRow('notes', { type: 'textarea', required: false }),
    ]
    const schema = buildOrderSchemaFromFields(fields)
    const result = schema.safeParse({
      customerFullName: 'محمد العامل',
      customerPhone: '+212 6 12 34 56 78',
      customerEmail: '',
      countryId: 'country-1',
      shippingCity: 'الدار البيضاء',
      shippingAddress: 'حي المعاريف، شارع الحسن الثاني، رقم 45',
      shippingPostalCode: '',
      notes: '',
      items: [{ productId: 'p1', variantId: null, quantity: 1 }],
    })
    expect(result.success).toBe(true)
  })

  it('accepts order with optional fields empty (email, postal_code, notes)', async () => {
    const fields: OrderField[] = [
      baseRow('full_name', { required: true }),
      baseRow('phone', { type: 'phone', required: true }),
      baseRow('email', { type: 'email', required: false }),
      baseRow('country', { required: true }),
      baseRow('city', { required: true }),
      baseRow('address', { required: true }),
      baseRow('postal_code', { required: false }),
      baseRow('notes', { required: false }),
    ]
    const schema = buildOrderSchemaFromFields(fields)
    const result = schema.safeParse({
      customerFullName: 'Said',
      customerPhone: '0612345678',
      customerEmail: '',
      countryId: 'c1',
      shippingCity: 'Rabat',
      shippingAddress: 'Hassan, Rabat, Morocco',
      shippingPostalCode: '',
      notes: '',
      items: [{ productId: 'p1', variantId: null, quantity: 2 }],
    })
    expect(result.success).toBe(true)
  })

  it('FIX: accepts order when structured field is DEACTIVATED (isActive=false)', async () => {
    // User deactivated `phone` and `email` from the admin panel.
    // Form doesn't render them → user can't fill them → server must NOT
    // require them. This was the original "Veuillez corriger..." bug.
    const fields: OrderField[] = [
      baseRow('full_name', { required: true }),
      baseRow('phone', { type: 'phone', required: true, isActive: false }),
      baseRow('email', { type: 'email', required: false, isActive: false }),
      baseRow('country', { required: true }),
      baseRow('city', { required: true }),
      baseRow('address', { required: true }),
      baseRow('postal_code', { required: false }),
      baseRow('notes', { required: false }),
    ]
    const schema = buildOrderSchemaFromFields(fields)
    const result = schema.safeParse({
      customerFullName: 'Youssef',
      customerPhone: '',            // phone field deactivated — not in form
      customerEmail: '',            // email field deactivated
      countryId: 'c1',
      shippingCity: 'Marrakech',
      shippingAddress: 'Gueliz, Marrakech',
      shippingPostalCode: '',
      notes: '',
      items: [{ productId: 'p1', variantId: null, quantity: 1 }],
    })
    expect(result.success).toBe(true)
  })

  it('FIX: accepts order when structured field is ACTIVE but required=false (admin made it optional)', async () => {
    // Admin set `phone` to required=false (still showing it in the form,
    // but not requiring it).
    const fields: OrderField[] = [
      baseRow('full_name', { required: true }),
      baseRow('phone', { type: 'phone', required: false }),
      baseRow('country', { required: true }),
      baseRow('city', { required: true }),
      baseRow('address', { required: true }),
    ]
    const schema = buildOrderSchemaFromFields(fields)
    const result = schema.safeParse({
      customerFullName: 'Karim',
      customerPhone: '',            // empty — should be accepted because required=false
      countryId: 'c1',
      shippingCity: 'Fès',
      shippingAddress: 'Medina, Fès',
      items: [{ productId: 'p1', variantId: null, quantity: 1 }],
    })
    expect(result.success).toBe(true)
  })

  it('rejects order when REQUIRED structured field is empty (still enforced)', async () => {
    const fields: OrderField[] = [
      baseRow('full_name', { required: true }),
      baseRow('phone', { type: 'phone', required: true }),
      baseRow('country', { required: true }),
      baseRow('city', { required: true }),
      baseRow('address', { required: true }),
    ]
    const schema = buildOrderSchemaFromFields(fields)
    const result = schema.safeParse({
      customerFullName: '',         // ← missing required full_name
      customerPhone: '+212600000000',
      countryId: 'c1',
      shippingCity: 'Tanger',
      shippingAddress: 'Route de Rabat',
      items: [{ productId: 'p1', variantId: null, quantity: 1 }],
    })
    expect(result.success).toBe(false)
    if (!result.success) {
      const issueKeys = result.error.issues.map((i) => i.path.join('.'))
      expect(issueKeys).toContain('customerFullName')
    }
  })

  it('rejects malformed phone when required and field is active', async () => {
    const fields: OrderField[] = [
      baseRow('phone', { type: 'phone', required: true }),
    ]
    const schema = buildOrderSchemaFromFields(fields)
    const result = schema.safeParse({
      customerPhone: 'abc-not-a-phone',
      items: [{ productId: 'p1', variantId: null, quantity: 1 }],
    })
    expect(result.success).toBe(false)
  })

  it('rejects empty cart', async () => {
    const fields: OrderField[] = []
    const schema = buildOrderSchemaFromFields(fields)
    const result = schema.safeParse({
      customerFullName: 'Test',
      customerPhone: '',
      countryId: 'c1',
      shippingCity: 'Test',
      shippingAddress: 'Test Address 12345',
      items: [],                    // ← empty cart
    })
    expect(result.success).toBe(false)
  })

  it('accepts order with custom (admin-defined) field outside the structured set', async () => {
    const fields: OrderField[] = [
      baseRow('full_name', { required: true }),
      baseRow('phone', { type: 'phone', required: true }),
      baseRow('country', { required: true }),
      baseRow('city', { required: true }),
      baseRow('address', { required: true }),
      baseRow('preferred_delivery_time', { type: 'text', required: false }),
    ]
    const schema = buildOrderSchemaFromFields(fields)
    const result = schema.safeParse({
      customerFullName: 'Hassan',
      customerPhone: '+212666666666',
      countryId: 'c1',
      shippingCity: 'Agadir',
      shippingAddress: 'Quartier residentiel',
      customFields: { preferred_delivery_time: 'morning' },
      items: [{ productId: 'p1', variantId: null, quantity: 1 }],
    })
    expect(result.success).toBe(true)
  })

  // ─── Alias tests ────────────────────────────────────────────────────
  // These cover the production scenario where the admin created fields
  // with non-canonical keys: `name` (instead of `full_name`) and
  // `adress` (typo, instead of `address`). The schema must still enforce
  // `required` and length bounds on the corresponding structured column
  // (customerFullName / shippingAddress).

  it('ALIAS FIX: enforces required on customerFullName when only `name` field row exists', async () => {
    // The DB has `name` (alias), not `full_name`. The schema must still
    // require customerFullName because the `name` row has required=true.
    const fields: OrderField[] = [
      baseRow('name', { type: 'text', required: true }),
      baseRow('phone', { type: 'phone', required: true }),
      baseRow('city', { required: true }),
      baseRow('adress', { type: 'text', required: true }), // alias + typo
    ]
    const schema = buildOrderSchemaFromFields(fields)

    // Missing customerFullName → must fail (because `name` is required)
    const bad = schema.safeParse({
      customerFullName: '',
      customerPhone: '+212612345678',
      countryId: 'c1',
      shippingCity: 'Rabat',
      shippingAddress: '123 Main St',
      items: [{ productId: 'p1', variantId: null, quantity: 1 }],
    })
    expect(bad.success).toBe(false)
    if (!bad.success) {
      const issueKeys = bad.error.issues.map((i) => i.path.join('.'))
      expect(issueKeys).toContain('customerFullName')
    }

    // With customerFullName filled → must pass
    const good = schema.safeParse({
      customerFullName: 'Karim',
      customerPhone: '+212612345678',
      countryId: 'c1',
      shippingCity: 'Rabat',
      shippingAddress: '123 Main St',
      items: [{ productId: 'p1', variantId: null, quantity: 1 }],
    })
    expect(good.success).toBe(true)
  })

  it('ALIAS FIX: enforces required on shippingAddress when only `adress` (typo) field row exists', async () => {
    const fields: OrderField[] = [
      baseRow('name', { required: true }),
      baseRow('phone', { type: 'phone', required: true }),
      baseRow('city', { required: true }),
      baseRow('adress', { type: 'text', required: true }),
    ]
    const schema = buildOrderSchemaFromFields(fields)

    const bad = schema.safeParse({
      customerFullName: 'Karim',
      customerPhone: '+212612345678',
      countryId: 'c1',
      shippingCity: 'Rabat',
      shippingAddress: '', // missing
      items: [{ productId: 'p1', variantId: null, quantity: 1 }],
    })
    expect(bad.success).toBe(false)
    if (!bad.success) {
      const issueKeys = bad.error.issues.map((i) => i.path.join('.'))
      expect(issueKeys).toContain('shippingAddress')
    }
  })

  it('ALIAS FIX: prefers canonical key over alias when both exist', async () => {
    // If both `full_name` and `name` rows exist in the DB (admin created
    // the canonical one later), the canonical row wins. This test makes
    // the canonical required=false and the alias required=true; the
    // schema should follow the canonical (accept empty).
    const fields: OrderField[] = [
      baseRow('full_name', { required: false }),
      baseRow('name', { required: true }), // alias — should be ignored
    ]
    const schema = buildOrderSchemaFromFields(fields)
    const result = schema.safeParse({
      customerFullName: '',
      items: [{ productId: 'p1', variantId: null, quantity: 1 }],
    })
    expect(result.success).toBe(true)
  })

  it('ALIAS FIX: respects minLength / maxLength set on an alias row', async () => {
    const fields: OrderField[] = [
      baseRow('name', { type: 'text', required: true, minLength: 3, maxLength: 10 }),
    ]
    const schema = buildOrderSchemaFromFields(fields)

    // Too short
    const tooShort = schema.safeParse({
      customerFullName: 'ab',
      items: [{ productId: 'p1', variantId: null, quantity: 1 }],
    })
    expect(tooShort.success).toBe(false)

    // Too long
    const tooLong = schema.safeParse({
      customerFullName: 'this is a very long name',
      items: [{ productId: 'p1', variantId: null, quantity: 1 }],
    })
    expect(tooLong.success).toBe(false)

    // Just right
    const ok = schema.safeParse({
      customerFullName: 'Karim',
      items: [{ productId: 'p1', variantId: null, quantity: 1 }],
    })
    expect(ok.success).toBe(true)
  })
})
