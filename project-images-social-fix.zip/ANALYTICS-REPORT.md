# نظام Analytics الإحترافي + نظام الصلاحيات — تقرير التنفيذ

## ما تم تنفيذه

### 1. نظام تتبع الزيارات (Analytics Tracking)

#### قاعدة البيانات:
- ✅ نموذج جديد `AnalyticsEvent` في Prisma schema
- ✅ حقول: `sessionId`, `eventName`, `pageUrl`, `pagePath`, `referrer`, UTM params, `trafficSource`, `device`, `browser`, `os`, `country`, `eventData`, `createdAt`
- ✅ فهارس على: `sessionId`, `eventName`, `createdAt`, `trafficSource`, `pagePath`
- ✅ `prisma db push` — تم إنشاء الجدول بدون reset

#### API التتبع: `/api/track`
- ✅ نقطة نهاية عامة (public) لجمع الأحداث
- ✅ فلترة البوتات (30+ نمط bot/crawler/spider)
- ✅ استثناء مسارات Admin من التتبع
- ✅ إدارة الجلسات (session cookie، 30 دقيقة idle timeout)
- ✅ منع التكرار (dedup: نفس session+event+path خلال 2 ثانية = تجاهل)
- ✅ استخراج UTM params من URL
- ✅ كشف مصدر الزيارة (direct/organic_search/paid_search/organic_social/paid_social/referral/email)
- ✅ كشف الجهاز (desktop/mobile/tablet) والمتصفح ونظام التشغيل
- ✅ لا تخزين IP الكامل (فقط country من headers)
- ✅ لا fingerprinting

#### الأحداث المتتبعة:
- ✅ `page_view` — تلقائي عند كل صفحة (AnalyticsTracker component)
- ✅ `session_start` — تلقائي عند أول زيارة
- ✅ `view_item` — عند مشاهدة صفحة منتج (ViewItemTracker)
- ✅ `add_to_cart` — عند الإضافة للسلة (AddToCartSection)
- ✅ `begin_checkout` — عند بدء الدفع (checkout page)
- ✅ `purchase` — عند إنشاء طلب بنجاح (checkout page)
- ✅ `search` — عند البحث (recherche page)

### 2. لوحة الإحصائيات (Analytics Dashboard)

#### API الاستعلام: `/api/admin/analytics`
- ✅ محمي بـ `requirePermission('reports', 'view')`
- ✅ دعم الفترات: today, yesterday, 7d, 14d, 30d, 90d, this_month, last_month, 12m
- ✅ دعم الفترة المخصصة (from/to)
- ✅ مقارنة بالفترة السابقة المماثلة
- ✅ KPIs: page views, unique visitors, sessions, orders, revenue, conversion rate, add_to_cart, begin_checkout, searches
- ✅ Funnel: view_item → add_to_cart → begin_checkout → purchase → confirmed
- ✅ مصادر الزيارات (8 فئات)
- ✅ توزيع الأجهزة والمتصفحات وأنظمة التشغيل
- ✅ أكثر 20 صفحة زيارة
- ✅ أكثر 20 منتج مشاهدة
- ✅ Time series يومي للرسوم البيانية
- ✅ توقيت Africa/Casablanca (UTC+1)

#### صفحة Analytics:
- ✅ شريط اختيار الفترة (9 خيارات + فترة مخصصة)
- ✅ بطاقات KPI مع نسبة التغيير ومؤشر صعود/هبوط
- ✅ رسوم بيانية (recharts):
  - Area chart للزيارات والزوار عبر الوقت
  - Bar chart لقمع الشراء (horizontal funnel)
  - Pie chart لمصادر الزيارات
  - Progress bars للأجهزة والمتصفحات وأنظمة التشغيل
- ✅ جداول: أكثر الصفحات والمنتجات زيارة
- ✅ حالات: loading (spinner), empty (بدأ جمع البيانات), error (toast)
- ✅ Responsive: بطاقات على الهاتف، جداول على الكمبيوتر
- ✅ RTL كامل

### 3. نظام الصلاحيات

- ✅ نظام RBAC موجود بالفعل (21 قسم × 6 إجراءات)
- ✅ `requirePermission()` مطبق على جميع APIs الجديدة
- ✅ قسم `reports` جديد للتحليلات
- ✅ صفحة Analytics محمية بـ `requirePermission('reports', 'view')`
- ✅ الأدوار الافتراضية تشمل `reports: ['view']`
- ✅ Super-admin يرى كل شيء تلقائياً

### 4. سجل العمليات (Audit Logs) — محسّن

#### API محسّن: `/api/admin/audit-logs`
- ✅ فلترة بالكيان (product, order, category, etc.)
- ✅ بحث في العملية/المعرّف/اسم المسؤول
- ✅ Pagination (25 per page)
- ✅ إرجاع `total` للـ pagination

#### صفحة Audit Logs محسّنة:
- ✅ بحث (debounce 350ms)
- ✅ فلترة بالكيان
- ✅ Pagination
- ✅ تصدير CSV
- ✅ Responsive (بطاقات على الهاتف)
- ✅ عرض البيانات الوصفية (JSON)

### 5. Sidebar Navigation

- ✅ إضافة "التحليلات" كثاني عنصر في القائمة
- ✅ أيقونة BarChart3
- ✅ section: 'reports' (يظهر فقط لمن لديه صلاحية)

## الملفات الجديدة

| الملف | الوصف |
|---|---|
| `src/lib/analytics.ts` | أدوات: bot detection, device/browser/OS parsing, traffic source detection, session management |
| `src/lib/track.ts` | دالة `trackEvent()` من جانب العميل |
| `src/app/api/track/route.ts` | API عام لجمع الأحداث |
| `src/app/api/admin/analytics/route.ts` | API محمي لاستعلام الإحصائيات |
| `src/components/storefront/analytics-tracker.tsx` | مكون يطلق page_view تلقائياً |
| `src/components/storefront/view-item-tracker.tsx` | مكون يطلق view_item على صفحة المنتج |
| `src/app/admin/(dashboard)/analytics/page.tsx` | صفحة لوحة التحليلات |

## الملفات المعدلة

| الملف | التغيير |
|---|---|
| `prisma/schema.prisma` | إضافة `AnalyticsEvent` model |
| `src/components/admin/admin-shell.tsx` | إضافة "التحليلات" للـ sidebar |
| `src/app/(storefront)/layout.tsx` | إضافة `<AnalyticsTracker />` |
| `src/app/(storefront)/produits/[slug]/page.tsx` | إضافة `<ViewItemTracker />` |
| `src/components/storefront/add-to-cart-section.tsx` | تتبع `add_to_cart` |
| `src/app/(storefront)/checkout/page.tsx` | تتبع `begin_checkout` و `purchase` |
| `src/app/(storefront)/recherche/page.tsx` | تتبع `search` |
| `src/app/admin/(dashboard)/audit-logs/page.tsx` | إعادة كتابة: بحث، فلترة، pagination، CSV |
| `src/app/api/admin/audit-logs/route.ts` | إضافة فلترة، بحث، pagination |

## نتائج الاختبارات

```
✓ Build:              Compiled successfully in 16.4s (Turbopack)
✓ Prisma:             AnalyticsEvent table created
✓ Homepage:           HTTP 200 ✅
✓ Products:           HTTP 200 ✅
✓ Cart:               HTTP 200 ✅
✓ Checkout:           HTTP 200 ✅
✓ Admin login:        HTTP 200 ✅
✓ Admin analytics:    HTTP 307 (redirect to login = correct auth) ✅
✓ Admin audit-logs:   HTTP 307 (redirect to login = correct auth) ✅

Tracking tests:
✓ page_view event:    Stored successfully (desktop, direct) ✅
✓ session_start:      Auto-created on first page_view ✅
✓ view_item event:    Stored successfully (desktop, direct) ✅
✓ add_to_cart event:  Stored successfully (mobile, direct) ✅
✓ Bot filtering:      curl/bot requests rejected ✅
✓ Dedup:              Duplicate events within 2s ignored ✅
✓ Device detection:   Desktop/mobile correctly identified ✅
✓ Traffic source:     Direct/organic/social correctly detected ✅

API tests:
✓ /api/track:         Public (no auth) ✅
✓ /api/admin/analytics: HTTP 401 without auth ✅
✓ /api/admin/audit-logs: HTTP 401 without auth ✅
```

## ما يعمل مباشرة بعد النشر

1. ✅ **تتبع الزيارات**: سيبدأ فوراً بعد النشر — كل زائر سيتم تتبعه تلقائياً
2. ✅ **لوحة التحليلات**: ستظهر في sidebar المسؤولين
3. ✅ **الصلاحيات**: نظام RBAC كامل يعمل
4. ✅ **سجل العمليات**: محسّن مع بحث وفلترة

## ما يحتاج وقت

- **البيانات التاريخية**: لا يمكن استرجاعها — البيانات تبدأ من النشر فقط
- **ظهور البيانات في لوحة التحكم**: قد تأخذ دقائق بعد أول زيارة
- **Google Search Console**: لا يحتاج إعداد (النظام مخصص، لا يعتمد GA4)

## ما لا يحتاج إعداد خارجي

- ❌ لا يحتاج Google Analytics 4
- ❌ لا يحتاج Umami أو Plausible
- ❌ لا يحتاج متغيرات بيئة جديدة
- ✅ النظام مخصص بالكامل، يعمل على Netlify + Neon

## الخصوصية

- ✅ لا تخزين IP الكامل
- ✅ لا fingerprinting
- ✅ لا cookies تدقيق (فقط session ID عشوائي)
- ✅ لا بيانات شخصية حساسة
- ✅ مسارات Admin مستثناة من التتبع

## خطوات النشر

1. فك الـ ZIP و `npm install`
2. `npx prisma db push` (لإنشاء جدول `analytics_events`)
3. اضبط env vars على Netlify
4. Deploy
5. سجّل كـ admin → اذهب إلى "التحليلات" في sidebar
6. البيانات ستبدأ في الظهور بعد أول زيارة للموقع
