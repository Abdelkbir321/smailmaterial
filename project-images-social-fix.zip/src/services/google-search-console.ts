/**
 * Google Search Console (GSC) integration service.
 *
 * ==========================================================================
 * STATUS: Infrastructure ready — requires credentials to activate.
 * --------------------------------------------------------------------------
 *
 * This service provides the SERVER-SIDE functions to query the Google Search
 * Console API. It uses a Google Service Account (not OAuth) so it can run
 * unattended in a serverless function.
 *
 * SETUP (one-time, by the site owner):
 *   1. Go to https://console.cloud.google.com/
 *      → Create a project (or use existing)
 *      → Enable the "Google Search Console API"
 *      → IAM & Admin → Service Accounts → Create service account
 *      → Download the JSON key file
 *   2. Go to https://search.google.com/search-console
 *      → Add your property (your site URL)
 *      → Verify ownership (HTML tag, DNS, or Google Analytics)
 *      → Settings → Users and permissions → Add user
 *      → Add the service account email (xxx@yyy.iam.gserviceaccount.com)
 *        with "Restricted" or "Full" permission
 *   3. In Netlify site settings → Environment variables, add:
 *      - GOOGLE_SERVICE_ACCOUNT_EMAIL = "xxx@yyy.iam.gserviceaccount.com"
 *      - GOOGLE_SERVICE_ACCOUNT_PRIVATE_KEY = "-----BEGIN PRIVATE KEY-----\n..."
 *        (the full key, with \n escaped as literal backslash-n)
 *      - GSC_SITE_URL = "https://ismailmaterial.ma" (the URL of your property)
 *   4. Redeploy — the /admin/seo/performance page will start showing real data.
 *
 * ==========================================================================
 * WHAT THIS SERVICE RETURNS WHEN NOT CONFIGURED
 * --------------------------------------------------------------------------
 * Every function returns `{ connected: false, error: 'not_configured' }`
 * when the credentials are missing. The admin UI shows a clear "needs setup"
 * message with the steps above — NEVER fake data.
 *
 * ==========================================================================
 * PRIVACY
 * --------------------------------------------------------------------------
 * The service account credentials are read from env vars on the SERVER.
 * They are NEVER sent to the browser. The admin UI only sees the
 * aggregated metrics (clicks, impressions, queries) — never the raw
 * credentials.
 */

export interface GscCredentials {
  clientEmail: string
  privateKey: string
  siteUrl: string
}

export function getGscCredentials(): GscCredentials | null {
  const clientEmail = process.env.GOOGLE_SERVICE_ACCOUNT_EMAIL
  const privateKey = process.env.GOOGLE_SERVICE_ACCOUNT_PRIVATE_KEY
  const siteUrl = process.env.GSC_SITE_URL
  if (!clientEmail || !privateKey || !siteUrl) return null
  return { clientEmail, privateKey, siteUrl }
}

export function isGscConfigured(): boolean {
  return getGscCredentials() !== null
}

/**
 * Create a signed JWT for the Google Service Account.
 * This is the OAuth2 flow for server-to-server authentication.
 *
 * We build the JWT manually (no googleapis dependency) to keep the bundle
 * small. The JWT is exchanged for an access token at Google's OAuth2 endpoint.
 */
async function getGoogleAccessToken(scope: string): Promise<string | null> {
  const creds = getGscCredentials()
  if (!creds) return null

  // The JWT header + payload
  const now = Math.floor(Date.now() / 1000)
  const header = { alg: 'RS256', typ: 'JWT' }
  const payload = {
    iss: creds.clientEmail,
    scope,
    aud: 'https://oauth2.googleapis.com/token',
    exp: now + 3600,
    iat: now,
  }

  // Base64url encode
  const b64url = (obj: unknown) => {
    const json = JSON.stringify(obj)
    return Buffer.from(json).toString('base64')
      .replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '')
  }

  const unsigned = `${b64url(header)}.${b64url(payload)}`

  // Sign with the private key using Web Crypto API (available in Node 18+)
  // The private key from the JSON file has literal "\n" — convert them back.
  const pemKey = creds.privateKey.replace(/\\n/g, '\n')
  try {
    const { createSign } = await import('node:crypto')
    const sign = createSign('RSA-SHA256')
    sign.update(unsigned)
    const signature = sign.sign(pemKey, 'base64url')
    const jwt = `${unsigned}.${signature}`

    // Exchange the JWT for an access token
    const tokenRes = await fetch('https://oauth2.googleapis.com/token', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        grant_type: 'urn:ietf:params:oauth:grant-type:jwt-bearer',
        assertion: jwt,
      }),
    })
    if (!tokenRes.ok) return null
    const tokenData = await tokenRes.json() as { access_token?: string }
    return tokenData.access_token || null
  } catch {
    return null
  }
}

const GSC_SCOPE = 'https://www.googleapis.com/auth/webmasters.readonly'

export interface GscQueryResult {
  clicks: number
  impressions: number
  ctr: number
  position: number
  rows: Array<{
    keys: string[]
    clicks: number
    impressions: number
    ctr: number
    position: number
  }>
}

/**
 * Query the Search Console API for search analytics.
 *
 * @param dimension - 'query' (top keywords), 'page' (top pages),
 *                    'country' (top countries), 'device'
 * @param startDate - ISO date string (YYYY-MM-DD)
 * @param endDate   - ISO date string (YYYY-MM-DD)
 *
 * Returns null when not configured. Returns the raw API response on success.
 */
export async function querySearchAnalytics(
  dimension: 'query' | 'page' | 'country' | 'device',
  startDate: string,
  endDate: string,
): Promise<{ connected: boolean; data?: GscQueryResult; error?: string }> {
  const creds = getGscCredentials()
  if (!creds) return { connected: false, error: 'not_configured' }

  const token = await getGoogleAccessToken(GSC_SCOPE)
  if (!token) return { connected: true, error: 'auth_failed' }

  try {
    const res = await fetch(
      `https://www.googleapis.com/webmasters/v3/sites/${encodeURIComponent(creds.siteUrl)}/searchAnalytics/query`,
      {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          startDate,
          endDate,
          dimensions: [dimension],
          rowLimit: 50,
        }),
      },
    )
    if (!res.ok) {
      const errBody = await res.text()
      return { connected: true, error: `api_error_${res.status}: ${errBody.slice(0, 200)}` }
    }
    const data = await res.json() as {
      rows?: Array<{
        keys: string[]
        clicks: number
        impressions: number
        ctr: number
        position: number
      }>
    }
    const rows = data.rows || []
    const totals = rows.reduce(
      (acc, r) => ({
        clicks: acc.clicks + r.clicks,
        impressions: acc.impressions + r.impressions,
      }),
      { clicks: 0, impressions: 0 },
    )
    return {
      connected: true,
      data: {
        clicks: totals.clicks,
        impressions: totals.impressions,
        ctr: totals.impressions > 0 ? Number((totals.clicks / totals.impressions * 100).toFixed(2)) : 0,
        position: rows.length > 0 ? Number((rows.reduce((s, r) => s + r.position, 0) / rows.length).toFixed(1)) : 0,
        rows,
      },
    }
  } catch (e) {
    return { connected: true, error: `fetch_failed: ${e instanceof Error ? e.message : 'unknown'}` }
  }
}

/**
 * List the sitemaps submitted to GSC for this property.
 * Returns the sitemap URLs + their last submission + processing status.
 */
export async function listSitemaps(): Promise<{
  connected: boolean
  data?: Array<{ path: string; lastSubmitted?: string; status?: string; errors?: number }>
  error?: string
}> {
  const creds = getGscCredentials()
  if (!creds) return { connected: false, error: 'not_configured' }

  const token = await getGoogleAccessToken(GSC_SCOPE)
  if (!token) return { connected: true, error: 'auth_failed' }

  try {
    const res = await fetch(
      `https://www.googleapis.com/webmasters/v3/sites/${encodeURIComponent(creds.siteUrl)}/sitemaps`,
      { headers: { 'Authorization': `Bearer ${token}` } },
    )
    if (!res.ok) return { connected: true, error: `api_error_${res.status}` }
    const data = await res.json() as {
      sitemap?: Array<{
        path: string
        lastSubmitted?: string
        lastDownloaded?: string
        errors?: string
        warnings?: string
        contents?: Array<{ type: string; submitted: string; indexed: string }>
        isPending?: boolean
        isSitemapsIndex?: boolean
      }>
    }
    return {
      connected: true,
      data: (data.sitemap || []).map((s) => ({
        path: s.path,
        lastSubmitted: s.lastSubmitted,
        status: s.isPending ? 'pending' : 'processed',
        errors: s.errors ? Number(s.errors) : 0,
      })),
    }
  } catch (e) {
    return { connected: true, error: `fetch_failed: ${e instanceof Error ? e.message : 'unknown'}` }
  }
}
