/**
 * Comprehensive Site Settings Service
 * ===================================
 *
 * This module provides typed getters for all customizable site settings:
 * - Social links (CRUD via SocialLink table)
 * - Checkout texts (multilingual)
 * - Typography (fonts, sizes, weights)
 * - Design settings (colors, border radius, button size, layout)
 * - Header/footer texts
 *
 * All settings are cached via unstable_cache with tag 'settings' and
 * invalidated via revalidateTag('settings') after admin writes.
 */

import { db } from '@/lib/db'
import { unstable_cache } from 'next/cache'
import { getSetting } from '@/services/settings'

// =========================================================================
// SOCIAL LINKS
// =========================================================================

export interface SocialLinkRow {
  id: string
  platform: string
  label: string | null
  url: string
  iconKey: string
  order: number
  isEnabled: boolean
  showInHeader: boolean
  showInFooter: boolean
  showInContact: boolean
}

export const getSocialLinks = unstable_cache(
  async (placement?: 'header' | 'footer' | 'contact'): Promise<SocialLinkRow[]> => {
    const where: Record<string, unknown> = { isEnabled: true }
    if (placement === 'header') where.showInHeader = true
    if (placement === 'footer') where.showInFooter = true
    if (placement === 'contact') where.showInContact = true
    const rows = await db.socialLink.findMany({
      where,
      orderBy: { order: 'asc' },
    })
    return rows.map((r) => ({
      id: r.id,
      platform: r.platform,
      label: r.label,
      url: r.url,
      iconKey: r.iconKey || r.platform,
      order: r.order,
      isEnabled: r.isEnabled,
      showInHeader: r.showInHeader,
      showInFooter: r.showInFooter,
      showInContact: r.showInContact,
    }))
  },
  ['social-links'],
  { revalidate: 60, tags: ['settings', 'social-links'] },
)

export async function getAllSocialLinksAdmin(): Promise<SocialLinkRow[]> {
  const rows = await db.socialLink.findMany({ orderBy: { order: 'asc' } })
  return rows.map((r) => ({
    id: r.id,
    platform: r.platform,
    label: r.label,
    url: r.url,
    iconKey: r.iconKey || r.platform,
    order: r.order,
    isEnabled: r.isEnabled,
    showInHeader: r.showInHeader,
    showInFooter: r.showInFooter,
    showInContact: r.showInContact,
  }))
}

// =========================================================================
// CHECKOUT TEXTS (multilingual: fr, ar, en)
// =========================================================================

export interface CheckoutTexts {
  // Section: buyer info
  buyerInfoTitle: { fr: string; ar: string; en: string }
  buyerInfoHelper: { fr: string; ar: string; en: string }
  // Section: payment
  paymentTitle: { fr: string; ar: string; en: string }
  paymentDescription: { fr: string; ar: string; en: string }
  // Button
  submitButton: { fr: string; ar: string; en: string }
  submitHelper: { fr: string; ar: string; en: string }
  // Cart sidebar
  cartTitle: { fr: string; ar: string; en: string }
  subtotalLabel: { fr: string; ar: string; en: string }
  shippingLabel: { fr: string; ar: string; en: string }
  totalLabel: { fr: string; ar: string; en: string }
  freeShippingLabel: { fr: string; ar: string; en: string }
  // Trust badges
  trustCod: { fr: string; ar: string; en: string }
  trustShipping: { fr: string; ar: string; en: string }
  trustPrivacy: { fr: string; ar: string; en: string }
  // Page header
  pageTitle: { fr: string; ar: string; en: string }
  pageSubtitle: { fr: string; ar: string; en: string }
  // Toasts
  successMessage: { fr: string; ar: string; en: string }
  errorMessage: { fr: string; ar: string; en: string }
  processingMessage: { fr: string; ar: string; en: string }
}

export const DEFAULT_CHECKOUT_TEXTS: CheckoutTexts = {
  buyerInfoTitle: {
    fr: 'Vos informations',
    ar: 'معلوماتك',
    en: 'Your information',
  },
  buyerInfoHelper: {
    fr: 'Tous les champs marqués * sont requis',
    ar: 'جميع الحقول المعلّمة بـ * مطلوبة',
    en: 'All fields marked * are required',
  },
  paymentTitle: {
    fr: 'Paiement à la livraison',
    ar: 'الدفع عند الاستلام',
    en: 'Cash on delivery',
  },
  paymentDescription: {
    fr: 'Payez en espèces à la réception du colis',
    ar: 'خلّص ملي توصلك السلعة',
    en: 'Pay in cash upon delivery',
  },
  submitButton: {
    fr: 'Confirmer la commande',
    ar: 'تأكيد الطلب',
    en: 'Confirm order',
  },
  submitHelper: {
    fr: 'Cliquez une seule fois — aucune commande en double ne sera créée',
    ar: 'اضغط مرة واحدة فقط — لن يتم إنشاء طلب مكرر',
    en: 'Click only once — no duplicate order will be created',
  },
  cartTitle: {
    fr: 'Votre commande',
    ar: 'طلبك',
    en: 'Your order',
  },
  subtotalLabel: {
    fr: 'Sous-total',
    ar: 'المجموع الفرعي',
    en: 'Subtotal',
  },
  shippingLabel: {
    fr: 'Livraison',
    ar: 'التوصيل',
    en: 'Shipping',
  },
  totalLabel: {
    fr: 'Total',
    ar: 'المجموع',
    en: 'Total',
  },
  freeShippingLabel: {
    fr: 'Gratuite',
    ar: 'مجاني',
    en: 'Free',
  },
  trustCod: {
    fr: 'Paiement à la livraison (COD)',
    ar: 'الدفع عند الاستلام',
    en: 'Cash on delivery (COD)',
  },
  trustShipping: {
    fr: 'Livraison 24–72h',
    ar: 'توصيل 24–72 ساعة',
    en: '24–72h delivery',
  },
  trustPrivacy: {
    fr: 'Vos données restent privées',
    ar: 'بياناتك تبقى خاصة',
    en: 'Your data stays private',
  },
  pageTitle: {
    fr: 'Finaliser la commande',
    ar: 'إتمام الطلب',
    en: 'Checkout',
  },
  pageSubtitle: {
    fr: 'Paiement à la livraison · Sans création de compte',
    ar: 'الدفع عند الاستلام · بدون إنشاء حساب',
    en: 'Cash on delivery · No account required',
  },
  successMessage: {
    fr: 'Votre commande a été reçue avec succès !',
    ar: 'تم استلام طلبك بنجاح!',
    en: 'Your order has been received successfully!',
  },
  errorMessage: {
    fr: 'Impossible de finaliser la commande. Réessayez.',
    ar: 'تعذّر إتمام الطلب. حاول مرة أخرى.',
    en: 'Could not complete the order. Try again.',
  },
  processingMessage: {
    fr: 'Traitement en cours…',
    ar: 'جاري المعالجة…',
    en: 'Processing…',
  },
}

export async function getCheckoutTexts(): Promise<CheckoutTexts> {
  try {
    const raw = await getSetting('checkout_texts')
    if (!raw) return DEFAULT_CHECKOUT_TEXTS
    const parsed = JSON.parse(raw)
    // Deep merge with defaults so missing keys fall back
    return deepMerge(DEFAULT_CHECKOUT_TEXTS, parsed)
  } catch {
    return DEFAULT_CHECKOUT_TEXTS
  }
}

// =========================================================================
// TYPOGRAPHY
// =========================================================================

export interface TypographySettings {
  // Font families
  bodyFontLatin: string // CSS font-family for Latin text
  bodyFontArabic: string // CSS font-family for Arabic text
  headingFont: string // CSS font-family for headings
  buttonFont: string // CSS font-family for buttons
  // Font loading
  googleFontsUrl: string // Google Fonts URL to import (empty = use system fonts)
  // Sizes (rem)
  bodyFontSize: number
  headingFontSize: number // h2 base size
  smallTextSize: number
  // Weight
  bodyFontWeight: number
  headingFontWeight: number
  // Line height
  bodyLineHeight: number
  headingLineHeight: number
  // Letter spacing
  bodyLetterSpacing: number // em
  headingLetterSpacing: number // em
}

export const DEFAULT_TYPOGRAPHY: TypographySettings = {
  bodyFontLatin: 'Geist, ui-sans-serif, system-ui, sans-serif',
  bodyFontArabic: "'Noto Sans Arabic', 'Cairo', sans-serif",
  headingFont: "'Bricolage Grotesque', 'Geist', sans-serif",
  buttonFont: 'Geist, ui-sans-serif, system-ui, sans-serif',
  googleFontsUrl: '',
  bodyFontSize: 1,
  headingFontSize: 2,
  smallTextSize: 0.875,
  bodyFontWeight: 400,
  headingFontWeight: 700,
  bodyLineHeight: 1.6,
  headingLineHeight: 1.2,
  bodyLetterSpacing: 0,
  headingLetterSpacing: -0.02,
}

/** Available Arabic fonts for the admin picker */
export const ARABIC_FONTS = [
  { value: "'Cairo', sans-serif", label: 'Cairo', google: 'Cairo:wght@400;500;600;700' },
  { value: "'Tajawal', sans-serif", label: 'Tajawal', google: 'Tajawal:wght@400;500;700' },
  { value: "'IBM Plex Sans Arabic', sans-serif", label: 'IBM Plex Sans Arabic', google: 'IBM+Plex+Sans+Arabic:wght@400;500;600;700' },
  { value: "'Noto Sans Arabic', sans-serif", label: 'Noto Sans Arabic', google: 'Noto+Sans+Arabic:wght@400;500;600;700' },
  { value: "'Alexandria', sans-serif", label: 'Alexandria', google: 'Alexandria:wght@400;500;600;700' },
] as const

/** Available Latin fonts for the admin picker */
export const LATIN_FONTS = [
  { value: "'Inter', sans-serif", label: 'Inter', google: 'Inter:wght@400;500;600;700' },
  { value: "'Roboto', sans-serif", label: 'Roboto', google: 'Roboto:wght@400;500;700' },
  { value: "'Manrope', sans-serif", label: 'Manrope', google: 'Manrope:wght@400;500;600;700' },
  { value: "'Plus Jakarta Sans', sans-serif", label: 'Plus Jakarta Sans', google: 'Plus+Jakarta+Sans:wght@400;500;600;700' },
  { value: "'Montserrat', sans-serif", label: 'Montserrat', google: 'Montserrat:wght@400;500;600;700' },
  { value: 'Geist, ui-sans-serif, system-ui, sans-serif', label: 'Geist (default)', google: '' },
] as const

/** Available heading fonts */
export const HEADING_FONTS = [
  { value: "'Bricolage Grotesque', sans-serif", label: 'Bricolage Grotesque (default)', google: 'Bricolage+Grotesque:wght@400;500;600;700;800' },
  { value: "'Inter', sans-serif", label: 'Inter', google: 'Inter:wght@400;500;600;700' },
  { value: "'Manrope', sans-serif", label: 'Manrope', google: 'Manrope:wght@400;500;600;700;800' },
  { value: "'Plus Jakarta Sans', sans-serif", label: 'Plus Jakarta Sans', google: 'Plus+Jakarta+Sans:wght@400;500;600;700;800' },
  { value: "'Montserrat', sans-serif", label: 'Montserrat', google: 'Montserrat:wght@400;500;600;700;800' },
  { value: "'Poppins', sans-serif", label: 'Poppins', google: 'Poppins:wght@400;500;600;700;800' },
] as const

export async function getTypography(): Promise<TypographySettings> {
  try {
    const raw = await getSetting('typography')
    if (!raw) return DEFAULT_TYPOGRAPHY
    const parsed = JSON.parse(raw)
    return { ...DEFAULT_TYPOGRAPHY, ...parsed }
  } catch {
    return DEFAULT_TYPOGRAPHY
  }
}

// =========================================================================
// DESIGN SETTINGS (colors, borders, layout)
// =========================================================================

export interface DesignSettings {
  // Colors (override CSS variables)
  primaryColor: string
  primaryHoverColor: string
  accentColor: string
  backgroundColor: string
  backgroundSubtleColor: string
  textColor: string
  cardColor: string
  borderColor: string
  // Corner radius
  borderRadius: number // px
  // Button size
  buttonPaddingY: number // px
  buttonPaddingX: number // px
  buttonFontSize: number // rem
  // Layout
  contentMaxWidth: number // px
  sectionSpacing: number // px
  // Product card style
  productCardStyle: 'classic' | 'compact' | 'minimal'
  // Visibility toggles
  showAnnouncementBar: boolean
  showHeroSection: boolean
  showFeaturedProducts: boolean
  showBestSellers: boolean
  showNewArrivals: boolean
  showBrandsSection: boolean
  showFaqSection: boolean
}

export const DEFAULT_DESIGN: DesignSettings = {
  primaryColor: '#B23A0E',
  primaryHoverColor: '#8E2D0A',
  accentColor: '#9A6A1E',
  backgroundColor: '#F4EFE6',
  backgroundSubtleColor: '#EFE9DD',
  textColor: '#1A1410',
  cardColor: '#FFFFFF',
  borderColor: '#DDD2BD',
  borderRadius: 8,
  buttonPaddingY: 8,
  buttonPaddingX: 16,
  buttonFontSize: 0.875,
  contentMaxWidth: 1280,
  sectionSpacing: 64,
  productCardStyle: 'classic',
  showAnnouncementBar: true,
  showHeroSection: true,
  showFeaturedProducts: true,
  showBestSellers: true,
  showNewArrivals: true,
  showBrandsSection: true,
  showFaqSection: true,
}

export async function getDesignSettings(): Promise<DesignSettings> {
  try {
    const raw = await getSetting('design_settings')
    if (!raw) return DEFAULT_DESIGN
    const parsed = JSON.parse(raw)
    return { ...DEFAULT_DESIGN, ...parsed }
  } catch {
    return DEFAULT_DESIGN
  }
}

// =========================================================================
// HEADER TEXTS
// =========================================================================

export interface HeaderTexts {
  announcementText: { fr: string; ar: string; en: string }
  logoSubtitle: { fr: string; ar: string; en: string }
  searchPlaceholder: { fr: string; ar: string; en: string }
  catalogueButton: { fr: string; ar: string; en: string }
  navHome: { fr: string; ar: string; en: string }
  navProducts: { fr: string; ar: string; en: string }
  navAllCategories: { fr: string; ar: string; en: string }
}

export const DEFAULT_HEADER_TEXTS: HeaderTexts = {
  announcementText: {
    fr: 'Livraison 24–72h partout au Maroc · Paiement à la livraison',
    ar: 'توصيل 24–72 ساعة لجميع مدن المغرب · الدفع عند الاستلام',
    en: '24–72h delivery across Morocco · Cash on delivery',
  },
  logoSubtitle: {
    fr: 'Outillage · Maroc',
    ar: 'عُدّة · المغرب',
    en: 'Tools · Morocco',
  },
  searchPlaceholder: {
    fr: 'Rechercher un outil, une marque, une référence…',
    ar: 'ابحث عن أداة، علامة، مرجع…',
    en: 'Search for a tool, brand, reference…',
  },
  catalogueButton: {
    fr: 'Catalogue',
    ar: 'الكتالوج',
    en: 'Catalog',
  },
  navHome: { fr: 'Accueil', ar: 'الرئيسية', en: 'Home' },
  navProducts: { fr: 'Produits', ar: 'المنتجات', en: 'Products' },
  navAllCategories: { fr: 'Tout voir →', ar: 'عرض الكل ←', en: 'View all →' },
}

export async function getHeaderTexts(): Promise<HeaderTexts> {
  try {
    const raw = await getSetting('header_texts')
    if (!raw) return DEFAULT_HEADER_TEXTS
    const parsed = JSON.parse(raw)
    return deepMerge(DEFAULT_HEADER_TEXTS, parsed)
  } catch {
    return DEFAULT_HEADER_TEXTS
  }
}

// =========================================================================
// FOOTER TEXTS
// =========================================================================

export interface FooterTexts {
  aboutTitle: { fr: string; ar: string; en: string }
  shippingTitle: { fr: string; ar: string; en: string }
  shippingDesc: { fr: string; ar: string; en: string }
  paymentTitle: { fr: string; ar: string; en: string }
  paymentDesc: { fr: string; ar: string; en: string }
  supportTitle: { fr: string; ar: string; en: string }
  supportDesc: { fr: string; ar: string; en: string }
  workingHours: { fr: string; ar: string; en: string }
  catalogTitle: { fr: string; ar: string; en: string }
  allProducts: { fr: string; ar: string; en: string }
  categoriesTitle: { fr: string; ar: string; en: string }
  featuredProducts: { fr: string; ar: string; en: string }
  bestSellers: { fr: string; ar: string; en: string }
  newArrivals: { fr: string; ar: string; en: string }
  helpTitle: { fr: string; ar: string; en: string }
  helpCenter: { fr: string; ar: string; en: string }
  contactUs: { fr: string; ar: string; en: string }
  faq: { fr: string; ar: string; en: string }
  shippingReturns: { fr: string; ar: string; en: string }
  terms: { fr: string; ar: string; en: string }
  brandsTitle: { fr: string; ar: string; en: string }
  brandsList: { fr: string; ar: string; en: string }
  copyright: { fr: string; ar: string; en: string }
  codBadge: { fr: string; ar: string; en: string }
  shippingBadge: { fr: string; ar: string; en: string }
}

export const DEFAULT_FOOTER_TEXTS: FooterTexts = {
  aboutTitle: { fr: 'Ismail Material', ar: 'إسماعيل ماتيريال', en: 'Ismail Material' },
  shippingTitle: { fr: 'Livraison rapide', ar: 'توصيل سريع', en: 'Fast delivery' },
  shippingDesc: { fr: 'Expédition 24–72h partout au Maroc', ar: 'شحن 24–72 ساعة لجميع مدن المغرب', en: '24–72h shipping across Morocco' },
  paymentTitle: { fr: 'Paiement à la livraison', ar: 'الدفع عند الاستلام', en: 'Cash on delivery' },
  paymentDesc: { fr: 'Payez en espèces à la réception du colis', ar: 'خلّص نقداً عند استلام الطرد', en: 'Pay in cash upon delivery' },
  supportTitle: { fr: 'Support expert', ar: 'دعم احترافي', en: 'Expert support' },
  supportDesc: { fr: 'Contactez notre équipe technique', ar: 'تواصل مع فريقنا التقني', en: 'Contact our technical team' },
  workingHours: { fr: 'Du lundi au samedi', ar: 'من الإثنين إلى السبت', en: 'Monday to Saturday' },
  catalogTitle: { fr: 'Catalogue', ar: 'الكتالوج', en: 'Catalog' },
  allProducts: { fr: 'Tous les produits', ar: 'جميع المنتجات', en: 'All products' },
  categoriesTitle: { fr: 'Catégories', ar: 'الفئات', en: 'Categories' },
  featuredProducts: { fr: 'Produits en vedette', ar: 'منتجات مميزة', en: 'Featured products' },
  bestSellers: { fr: 'Meilleures ventes', ar: 'الأكثر مبيعاً', en: 'Best sellers' },
  newArrivals: { fr: 'Nouveautés', ar: 'وصل حديثاً', en: 'New arrivals' },
  helpTitle: { fr: 'Aide', ar: 'مساعدة', en: 'Help' },
  helpCenter: { fr: "Centre d'aide", ar: 'مركز المساعدة', en: 'Help center' },
  contactUs: { fr: 'Contact', ar: 'اتصل بنا', en: 'Contact' },
  faq: { fr: 'FAQ', ar: 'الأسئلة الشائعة', en: 'FAQ' },
  shippingReturns: { fr: 'Livraison & retours', ar: 'التوصيل والإرجاع', en: 'Shipping & returns' },
  terms: { fr: 'Conditions générales', ar: 'الشروط والأحكام', en: 'Terms & conditions' },
  brandsTitle: { fr: 'Marques professionnelles', ar: 'علامات احترافية', en: 'Professional brands' },
  brandsList: { fr: '· INGCO · Total · Crown · Würth', ar: '· INGCO · Total · Crown · Würth', en: '· INGCO · Total · Crown · Würth' },
  copyright: { fr: 'Tous droits réservés.', ar: 'جميع الحقوق محفوظة.', en: 'All rights reserved.' },
  codBadge: { fr: 'Paiement à la livraison', ar: 'الدفع عند الاستلام', en: 'Cash on delivery' },
  shippingBadge: { fr: 'Livraison Maroc', ar: 'توصيل المغرب', en: 'Morocco delivery' },
}

export async function getFooterTexts(): Promise<FooterTexts> {
  try {
    const raw = await getSetting('footer_texts')
    if (!raw) return DEFAULT_FOOTER_TEXTS
    const parsed = JSON.parse(raw)
    return deepMerge(DEFAULT_FOOTER_TEXTS, parsed)
  } catch {
    return DEFAULT_FOOTER_TEXTS
  }
}

// =========================================================================
// SHIPPING & RETURN POLICY SETTINGS
// =========================================================================
//
// These power the Product Schema's `shippingDetails` and
// `hasMerchantReturnPolicy` fields (Google rich results). The values MUST
// match what's published on /page/livraison-retours — we use these same
// settings to render the policy page, so there's a single source of truth.
//
// When the admin updates these via /admin/settings (checkout tab), the
// structured data on every product page updates automatically.
//
// All amounts are in the store's default currency (MAD). The shipping rate
// is a flat lower-bound — the actual rate may be higher for remote areas.
// We expose it in structured data because Google accepts a single flat
// rate per Offer.

export interface ShippingReturnSettings {
  /** Flat shipping rate (lower bound) in the store currency. 0 = free. */
  shippingRate: number
  /** Currency code (MAD, DZD, ...) — matches the default country's currency. */
  shippingCurrency: string
  /** Free-shipping threshold (cart total above which shipping is free). 0 = no free shipping. */
  freeShippingThreshold: number
  /** Min delivery time in business days. */
  deliveryTimeMinDays: number
  /** Max delivery time in business days. */
  deliveryTimeMaxDays: number
  /** Number of days the customer has to return a product. 0 = no returns. */
  returnPolicyDays: number
  /** Whether returns are allowed at all. */
  returnsEnabled: boolean
  /** Return shipping fees amount (what the customer pays to ship a return). 0 = free returns. */
  returnShippingFeesAmount: number
  /** Currency for the return shipping fees (usually same as shippingCurrency). */
  returnShippingFeesCurrency: string
  /** Whether reviews are enabled site-wide. */
  reviewsEnabled: boolean
  /** Whether reviews require admin approval before publishing. */
  reviewsRequireApproval: boolean
  /** Whether to show the "Verified Purchase" badge (requires order phone match). */
  reviewsShowVerifiedBadge: boolean
  /** Whether to use the store name as a fallback brand for products without a brand.
   *  This helps with Google's "Missing brand" warning — the store name is a
   *  legitimate brand identifier (the retailer), not a fabricated manufacturer. */
  useStoreNameAsFallbackBrand: boolean
}

export const DEFAULT_SHIPPING_RETURN: ShippingReturnSettings = {
  shippingRate: 30,
  shippingCurrency: 'MAD',
  freeShippingThreshold: 500,
  deliveryTimeMinDays: 1,
  deliveryTimeMaxDays: 5,
  returnPolicyDays: 7,
  returnsEnabled: true,
  // Default: customer pays return shipping (standard for Moroccan e-commerce).
  // The admin can set this to 0 for free returns.
  returnShippingFeesAmount: 30,
  returnShippingFeesCurrency: 'MAD',
  reviewsEnabled: true,
  reviewsRequireApproval: true,
  reviewsShowVerifiedBadge: true,
  // Default: use store name as fallback brand — helps with Google's
  // "Missing brand" warning without fabricating a manufacturer brand.
  useStoreNameAsFallbackBrand: true,
}

export async function getShippingReturnSettings(): Promise<ShippingReturnSettings> {
  try {
    const raw = await getSetting('shipping_return_settings')
    if (!raw) return DEFAULT_SHIPPING_RETURN
    const parsed = JSON.parse(raw)
    return { ...DEFAULT_SHIPPING_RETURN, ...parsed }
  } catch {
    return DEFAULT_SHIPPING_RETURN
  }
}

/**
 * Convenience: returns the shipping info in the format expected by
 * buildProductSchema's `shippingInfo` parameter. Returns `null` only
 * when shippingRate is negative (invalid) — otherwise returns the
 * structured data, even when the rate is 0 (free shipping).
 */
export async function getShippingInfoForSchema(): Promise<{
  rate: number
  currency: string
  deliveryTimeMinDays: number
  deliveryTimeMaxDays: number
} | null> {
  const s = await getShippingReturnSettings()
  if (s.shippingRate < 0) return null
  return {
    rate: s.shippingRate,
    currency: s.shippingCurrency,
    deliveryTimeMinDays: s.deliveryTimeMinDays,
    deliveryTimeMaxDays: s.deliveryTimeMaxDays,
  }
}

/**
 * Convenience: returns the return policy in the format expected by
 * buildProductSchema's `returnPolicy` parameter. Returns `null` when
 * returns are disabled.
 *
 * Includes `returnShippingFeesAmount` + `returnShippingFeesCurrency` —
 * Google now REQUIRES this field when `returnFees` is set to
 * `https://schema.org/ReturnShippingFees` (i.e. the customer pays for
 * return shipping). Without it, GSC shows the "Missing field
 * returnShippingFeesAmount" warning.
 */
export async function getReturnPolicyForSchema(): Promise<{
  days: number
  returnShippingFeesAmount: number
  returnShippingFeesCurrency: string
} | null> {
  const s = await getShippingReturnSettings()
  if (!s.returnsEnabled || s.returnPolicyDays <= 0) return null
  return {
    days: s.returnPolicyDays,
    returnShippingFeesAmount: s.returnShippingFeesAmount,
    returnShippingFeesCurrency: s.returnShippingFeesCurrency || s.shippingCurrency,
  }
}

/**
 * Convenience: returns the full shipping return settings — used by the
 * product page to decide whether to use the store name as a fallback brand.
 */
export async function getFallbackBrandSetting(): Promise<boolean> {
  const s = await getShippingReturnSettings()
  return s.useStoreNameAsFallbackBrand
}

// =========================================================================
// HELPERS
// =========================================================================

function deepMerge<T>(defaults: T, override: Partial<T>): T {
  if (typeof defaults !== 'object' || defaults === null) return defaults
  if (typeof override !== 'object' || override === null) return defaults
  const result: Record<string, unknown> = { ...(defaults as Record<string, unknown>) }
  for (const key of Object.keys(override as Record<string, unknown>)) {
    const defVal = (defaults as Record<string, unknown>)[key]
    const overVal = (override as Record<string, unknown>)[key]
    if (defVal && typeof defVal === 'object' && !Array.isArray(defVal) && overVal && typeof overVal === 'object' && !Array.isArray(overVal)) {
      result[key] = deepMerge(defVal, overVal)
    } else if (overVal !== undefined && overVal !== null) {
      result[key] = overVal
    }
  }
  return result as T
}
