/**
 * Google PageSpeed Insights API integration.
 *
 * ==========================================================================
 * STATUS: Infrastructure ready — requires API key to activate.
 * --------------------------------------------------------------------------
 *
 * The PageSpeed Insights API is PUBLIC (no OAuth needed) but requires an
 * API key for reasonable rate limits. Without a key, you get 1 request/min
 * which is too low for a dashboard.
 *
 * SETUP:
 *   1. Go to https://console.cloud.google.com/
 *      → Enable "PageSpeed Insights API"
 *      → APIs & Services → Credentials → Create API key
 *      → Restrict the key to the PageSpeed Insights API
 *   2. In Netlify site settings → Environment variables:
 *      - PAGESPEED_API_KEY = "AIza..."
 *   3. Redeploy — the /admin/diagnostics page will show real PageSpeed scores.
 *
 * ==========================================================================
 * WHAT THE API RETURNS
 * --------------------------------------------------------------------------
 * - Performance score (0-100) for mobile + desktop
 * - Core Web Vitals: LCP, INP, CLS (from CrUX — real user data)
 * - Lab data: FCP, LCP, TBT, CLS, Speed Index (from Lighthouse)
 * - Opportunities + diagnostics (specific optimization suggestions)
 *
 * We store the latest result per URL so the dashboard can show "last checked"
 * without re-querying the API on every page load.
 */

export interface PageSpeedResult {
  url: string
  strategy: 'mobile' | 'desktop'
  performanceScore: number | null
  // Core Web Vitals (from CrUX — real user data, may be null for low-traffic sites)
  lcp: number | null // Largest Contentful Paint (ms)
  inp: number | null // Interaction to Next Paint (ms)
  cls: number | null // Cumulative Layout Shift (unitless)
  // Lab data (from Lighthouse — always present)
  fcp: number | null // First Contentful Paint (ms)
  tbt: number | null // Total Blocking Time (ms)
  speedIndex: number | null
  // Opportunities (specific suggestions)
  opportunities: Array<{
    id: string
    title: string
    description: string
    savingsMs: number
  }>
  // Timestamps
  fetchedAt: string
  loadingExperience?: {
    metric: string
    category: string
  } | null
}

export function isPageSpeedConfigured(): boolean {
  return !!process.env.PAGESPEED_API_KEY
}

/**
 * Fetch PageSpeed Insights for a URL.
 *
 * @param url - The full URL to test (e.g. "https://ismailmaterial.ma/")
 * @param strategy - 'mobile' or 'desktop'
 *
 * Returns null when not configured. Returns the parsed result on success.
 */
export async function fetchPageSpeed(
  url: string,
  strategy: 'mobile' | 'desktop',
): Promise<{ connected: boolean; data?: PageSpeedResult; error?: string }> {
  const apiKey = process.env.PAGESPEED_API_KEY
  if (!apiKey) return { connected: false, error: 'not_configured' }

  const apiUrl = new URL('https://www.googleapis.com/pagespeedonline/v5/runPagespeed')
  apiUrl.searchParams.set('url', url)
  apiUrl.searchParams.set('strategy', strategy)
  apiUrl.searchParams.set('key', apiKey)
  // Request the categories we need
  apiUrl.searchParams.set('category', 'performance')

  try {
    const res = await fetch(apiUrl.toString(), {
      // PageSpeed API can take 10-30 seconds — give it room
      signal: AbortSignal.timeout(45000),
    })
    if (!res.ok) {
      const errBody = await res.text()
      return { connected: true, error: `api_error_${res.status}: ${errBody.slice(0, 200)}` }
    }
    const data = await res.json() as Record<string, unknown>

    // The API response is deeply nested. We extract the key metrics.
    const lighthouse = (data.lighthouseResult as Record<string, unknown> | undefined) || {}
    const categories = (lighthouse.categories as Record<string, { score?: number }> | undefined) || {}
    const audits = (lighthouse.audits as Record<string, { numericValue?: number; title?: string; description?: string; score?: number; details?: Record<string, unknown> }> | undefined) || {}

    const performanceScore = categories['performance']?.score != null
      ? Math.round(categories['performance'].score * 100)
      : null

    // CrUX (real user data) — loadingExperience
    const loadingExp = (data.loadingExperience as Record<string, unknown> | undefined) || {}
    const loadingMetrics = (loadingExp.metrics as Record<string, { percentile?: number; category?: string }> | undefined) || {}

    const result: PageSpeedResult = {
      url,
      strategy,
      performanceScore,
      // CrUX real-user metrics
      lcp: loadingMetrics['LARGEST_CONTENTFUL_PAINT']?.percentile ?? null,
      inp: loadingMetrics['INTERACTION_TO_NEXT_PAINT']?.percentile ?? null,
      cls: loadingMetrics['CUMULATIVE_LAYOUT_SHIFT_SCORE']?.percentile != null
        ? Number((loadingMetrics['CUMULATIVE_LAYOUT_SHIFT_SCORE'].percentile! / 100).toFixed(3))
        : null,
      // Lighthouse lab metrics
      fcp: audits['first-contentful-paint']?.numericValue ?? null,
      tbt: audits['total-blocking-time']?.numericValue ?? null,
      speedIndex: audits['speed-index']?.numericValue ?? null,
      opportunities: [],
      fetchedAt: new Date().toISOString(),
      loadingExperience: loadingMetrics['LARGEST_CONTENTFUL_PAINT']?.category
        ? { metric: 'LCP', category: loadingMetrics['LARGEST_CONTENTFUL_PAINT'].category! }
        : null,
    }

    // Extract top opportunities (suggestions with the biggest time savings)
    const opportunities: PageSpeedResult['opportunities'] = []
    for (const [id, audit] of Object.entries(audits)) {
      if (!audit || typeof audit !== 'object') continue
      const details = audit.details as { overallSavingsMs?: number } | undefined
      if (details?.overallSavingsMs && details.overallSavingsMs > 100) {
        opportunities.push({
          id,
          title: audit.title || id,
          description: audit.description || '',
          savingsMs: details.overallSavingsMs,
        })
      }
    }
    opportunities.sort((a, b) => b.savingsMs - a.savingsMs)
    result.opportunities = opportunities.slice(0, 5)

    return { connected: true, data: result }
  } catch (e) {
    return { connected: true, error: `fetch_failed: ${e instanceof Error ? e.message : 'unknown'}` }
  }
}
