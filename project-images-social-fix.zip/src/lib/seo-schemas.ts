/**
 * Central SEO / JSON-LD schema builders.
 *
 * ==========================================================================
 * WHY THIS FILE EXISTS
 * --------------------------------------------------------------------------
 * Before this file, every page that needed JSON-LD (product, breadcrumb,
 * organization, etc.) built its own schema object inline. That led to:
 *
 *   1. INCONSISTENT URLS — some pages used `process.env.NEXT_PUBLIC_SITE_URL`
 *      directly (which is empty in preview deployments), others used the
 *      DB-backed `getProductionDomain()`. Breadcrumbs ended up with relative
 *      URLs like `/produits` which Google Search Console flags as invalid
 *      ("item" must be a fully-qualified URL).
 *
 *   2. DUPLICATE SCHEMAS — the homepage rendered `WebSite` + `Store`
 *      schemas, but the root layout ALSO renders them → Google saw two
 *      identical schemas on the same page and flagged it as duplicate.
 *
 *   3. INVALID PRODUCT SCHEMA — missing `shippingDetails` and
 *      `hasMerchantReturnPolicy`, malformed `category` (string instead of
 *      the recommended `{ '@type': 'ProductType', name: ... }`), and
 *      `aggregateRating` emitted even when there were no published reviews
 *      on the page (just a stale count in the DB).
 *
 * This file is the SINGLE SOURCE OF TRUTH for building JSON-LD. All
 * storefront pages import from here. The schema objects it returns are
 * plain JSON (no React) so they can be serialized once and injected via
 * `<script type="application/ld+json">`.
 *
 * ==========================================================================
 * DESIGN RULES
 * --------------------------------------------------------------------------
 * - NEVER return relative URLs. If `siteUrl` is empty (preview deploy
 *   with no DB / env config), the function returns `null` for the entire
 *   schema — caller skips rendering it. We do NOT fabricate a domain.
 *
 * - For `Product` schema, `aggregateRating` is included ONLY when the
 *   product has at least one APPROVED review that is actually rendered on
 *   the page. A stale `reviewCount > 0` from the DB without visible
 *   reviews is forbidden (Google policy: structured data must reflect
 *   what the user sees).
 *
 * - `shippingDetails` and `hasMerchantReturnPolicy` are included ONLY
 *   when we have real, admin-configured values. We never assume free
 *   shipping or a default return window — those are legal claims.
 *
 * - `gtin` / `mpn` are NEVER fabricated. They're emitted only when the
 *   product row actually has a non-empty `barcode` (used as gtin13) —
 *   we don't invent a fake MPN from the SKU.
 *
 * - `category` is emitted as a plain string per Schema.org spec (the
 *   `ProductType` object form is optional and not recommended unless
 *   you have a product taxonomy ID). String is always valid.
 *
 * ==========================================================================
 */

import type { Product, Brand, Category, ProductImage, Review } from '@prisma/client'
import type { ProductDetail } from '@/types'

/**
 * Build an absolute URL for a path on the production domain.
 * Returns `null` when `siteUrl` is empty (no domain configured) — the
 * caller MUST skip rendering the schema in that case.
 */
export function absoluteUrl(siteUrl: string | null, path: string): string | null {
  if (!siteUrl) return null
  // Normalize: strip trailing slash from siteUrl, ensure leading slash on path
  const base = siteUrl.replace(/\/+$/, '')
  const p = path.startsWith('/') ? path : `/${path}`
  return `${base}${p}`
}

/**
 * Sanitize a string for safe inclusion in JSON-LD.
 * Removes control chars (newlines, tabs, etc.) that break JSON parsers.
 * Truncates to a reasonable max length to avoid huge payloads.
 */
function cleanText(s: string | null | undefined, maxLen = 5000): string | undefined {
  if (!s) return undefined
  // Collapse whitespace (newlines, tabs, multiple spaces) to single spaces
  const cleaned = s.replace(/\s+/g, ' ').trim()
  if (!cleaned) return undefined
  return cleaned.length > maxLen ? cleaned.slice(0, maxLen) : cleaned
}

/**
 * Pick the best available description for a product, in priority order:
 * 1. SEO description (admin-curated)
 * 2. Short description (catalog)
 * 3. Full description (truncated)
 * 4. undefined (let Google extract from page content)
 */
function pickProductDescription(product: ProductDetail): string | undefined {
  return (
    cleanText(product.seoDescription) ||
    cleanText(product.shortDescription) ||
    cleanText(product.description, 5000) ||
    undefined
  )
}

/**
 * Pick the best available image URLs for a product.
 * Returns at least 1, at most 6 image URLs (Schema.org recommendation).
 * Filters out empty/broken URLs. Returns `undefined` if no usable image.
 */
function pickProductImages(product: ProductDetail): string[] | undefined {
  const urls = product.images
    .map((i) => i.secureUrl || i.url)
    .filter((u): u is string => !!u && /^https?:\/\//.test(u))
    .slice(0, 6)
  return urls.length > 0 ? urls : undefined
}

/**
 * Compute the human-readable availability URL for Schema.org based on
 * the product's real stock state. Never fabricates "InStock" when the
 * product is actually out of stock.
 */
function pickAvailability(product: ProductDetail): string {
  const outOfStock =
    product.trackInventory && !product.allowBackorder && product.stockQuantity <= 0
  // BackOrder: product is orderable but not currently in stock — admin
  // explicitly allows it via `allowBackorder=true`.
  const backorder =
    product.trackInventory &&
    product.allowBackorder &&
    product.stockQuantity <= 0
  if (outOfStock) return 'https://schema.org/OutOfStock'
  if (backorder) return 'https://schema.org/PreOrder'
  return 'https://schema.org/InStock'
}

/**
 * Build the `Offer` sub-schema for a product.
 * Returns `null` if we can't construct a valid Offer (missing price or URL).
 */
function buildOffer(
  product: ProductDetail,
  siteUrl: string | null,
  shippingInfo: ShippingInfo | null,
  returnPolicy: ReturnPolicy | null,
): Record<string, unknown> | null {
  const url = absoluteUrl(siteUrl, `/produits/${product.slug}`)
  if (!url) return null
  const price = Number(product.price)
  if (!Number.isFinite(price) || price < 0) return null

  const offer: Record<string, unknown> = {
    '@type': 'Offer',
    url,
    priceCurrency: product.currencyCode || 'MAD',
    price: price.toFixed(2),
    availability: pickAvailability(product),
    itemCondition: 'https://schema.org/NewCondition',
  }

  // SKU — internal stock keeping unit. Always present (UNIQUE NOT NULL in DB).
  // This is the merchant's internal reference, not a global trade ID.
  if (product.sku) {
    offer.sku = product.sku
  }

  // GTIN-13 / EAN — emitted ONLY when the admin has entered a real barcode.
  // We do NOT fabricate one from the SKU. Google's policy: "Don't include
  // random numbers as gtin/mpn".
  if (product.barcode && /^\d{8,14}$/.test(product.barcode)) {
    offer.gtin13 = product.barcode
  }

  // MPN — emitted only when the brand has provided a real manufacturer part
  // number. The `barcode` field is sometimes used for this in practice,
  // but we don't double-use it: if it's a numeric barcode, it's a GTIN;
  // if it's alphanumeric, it might be an MPN. We avoid guessing.
  // → Intentionally NOT emitting mpn unless a dedicated field is added later.

  // shippingDetails — only when we have real, admin-configured shipping info.
  // We do NOT assume "free shipping" because that's a legal claim.
  if (shippingInfo) {
    offer.shippingDetails = {
      '@type': 'OfferShippingDetails',
      shippingRate: {
        '@type': 'MonetaryAmount',
        value: shippingInfo.rate.toFixed(2),
        currency: shippingInfo.currency || product.currencyCode || 'MAD',
      },
      shippingDestination: {
        '@type': 'DefinedRegion',
        addressCountry: 'MA',
      },
      ...(shippingInfo.deliveryTimeMinDays != null && shippingInfo.deliveryTimeMaxDays != null
        ? {
            deliveryTime: {
              '@type': 'ShippingDeliveryTime',
              handlingTime: {
                '@type': 'QuantitativeValue',
                minValue: 1,
                maxValue: 1,
                unitCode: 'DAY',
              },
              transitTime: {
                '@type': 'QuantitativeValue',
                minValue: shippingInfo.deliveryTimeMinDays,
                maxValue: shippingInfo.deliveryTimeMaxDays,
                unitCode: 'DAY',
              },
            },
          }
        : {}),
    }
  }

  // hasMerchantReturnPolicy — only when we have a real policy.
  // The Moroccan default (per /page/livraison-retours) is 7 days.
  //
  // IMPORTANT: Google now REQUIRES `returnShippingFeesAmount` when
  // `returnFees` is `https://schema.org/ReturnShippingFees` (i.e. the
  // customer pays for return shipping). Without it, GSC shows the
  // "Missing field returnShippingFeesAmount" warning.
  //
  // The amount comes from the DB-backed `returnShippingFeesAmount` setting
  // (admin-configurable in /admin/settings → Checkout tab). When the admin
  // sets it to 0, returns are free → we switch returnFees to
  // `https://schema.org/FreeReturn` and omit the amount field.
  if (returnPolicy) {
    const isFreeReturn = (returnPolicy.returnShippingFeesAmount ?? 0) === 0
    offer.hasMerchantReturnPolicy = {
      '@type': 'MerchantReturnPolicy',
      applicableCountry: 'MA',
      returnPolicyCategory: 'https://schema.org/MerchantReturnFiniteReturnWindow',
      merchantReturnDays: returnPolicy.days,
      returnMethod: 'https://schema.org/ReturnByMail',
      // Free returns → FreeReturn; customer pays → ReturnShippingFees + amount
      returnFees: isFreeReturn
        ? 'https://schema.org/FreeReturn'
        : 'https://schema.org/ReturnShippingFees',
      // Only include the amount when returns are NOT free
      ...(!isFreeReturn && returnPolicy.returnShippingFeesAmount != null
        ? {
            returnShippingFeesAmount: {
              '@type': 'MonetaryAmount',
              value: Number(returnPolicy.returnShippingFeesAmount).toFixed(2),
              currency: returnPolicy.returnShippingFeesCurrency || 'MAD',
            },
          }
        : {}),
    }
  }

  return offer
}

export interface ShippingInfo {
  /** Flat shipping rate in the store's currency. 0 = free shipping. */
  rate: number
  currency: string
  /** Min delivery time in days (null = unknown, omit transitTime) */
  deliveryTimeMinDays?: number | null
  /** Max delivery time in days (null = unknown, omit transitTime) */
  deliveryTimeMaxDays?: number | null
}

export interface ReturnPolicy {
  /** Number of days the customer has to return the product. */
  days: number
  /** Return shipping fees amount (what the customer pays to ship a return).
   *  Required by Google when returnFees = ReturnShippingFees. */
  returnShippingFeesAmount?: number
  /** Currency for the return shipping fees. */
  returnShippingFeesCurrency?: string
}

/**
 * Build the Product schema for a product detail page.
 *
 * Returns `null` when:
 *   - `siteUrl` is null (no production domain configured — preview deploy)
 *   - The product has no usable name or image (cannot form a valid Product)
 *
 * The caller should check for null and skip rendering the script tag.
 *
 * `visibleReviews` is the list of APPROVED reviews actually rendered on the
 * page. We use THIS (not the DB `reviewCount`) to decide whether to include
 * `aggregateRating` — Google requires that any rating in structured data
 * must be backed by visible reviews on the page.
 *
 * `fallbackBrandName` — when provided AND the product has no real brand,
 * we use this as the brand. This is the RETAILER's name (e.g. "Ismail Material"),
 * which is a legitimate brand identifier — not a fabricated manufacturer.
 * The admin can disable this in settings (useStoreNameAsFallbackBrand).
 */
export function buildProductSchema(
  product: ProductDetail,
  siteUrl: string | null,
  shippingInfo: ShippingInfo | null,
  returnPolicy: ReturnPolicy | null,
  visibleReviews: Review[] = [],
  fallbackBrandName?: string,
): Record<string, unknown> | null {
  if (!siteUrl) return null
  if (!product.name) return null

  const images = pickProductImages(product)
  const description = pickProductDescription(product)
  const offer = buildOffer(product, siteUrl, shippingInfo, returnPolicy)

  const schema: Record<string, unknown> = {
    '@context': 'https://schema.org',
    '@type': 'Product',
    name: product.name,
  }

  if (description) schema.description = description
  if (images) schema.image = images
  if (product.sku) schema.sku = product.sku

  // GTIN-13 on the Product level too (some validators want it here).
  if (product.barcode && /^\d{8,14}$/.test(product.barcode)) {
    schema.gtin13 = product.barcode
  }

  // brand — use the product's real brand when available. When no brand is
  // attached AND the admin enabled the fallback (useStoreNameAsFallbackBrand),
  // use the store name as the brand. This is the retailer's name — a
  // legitimate identifier, NOT a fabricated manufacturer brand.
  //
  // This addresses Google's "Missing GTIN, MPN or brand identifier" warning
  // (which is OPTIONAL). Google recommends providing at least ONE of
  // (gtin, mpn, brand). We already emit gtin13 when a real barcode exists;
  // the brand fallback covers the remaining products.
  if (product.brand && product.brand.name) {
    schema.brand = { '@type': 'Brand', name: product.brand.name }
  } else if (fallbackBrandName) {
    schema.brand = { '@type': 'Brand', name: fallbackBrandName }
  }

  // category — Schema.org accepts a plain string. We use the category name
  // from the DB (e.g. "Outillage électroportatif"). Do NOT wrap in
  // { '@type': 'ProductType', ... } unless you have a taxonomy ID — it's
  // optional and the string form is universally valid.
  if (product.category && product.category.name) {
    schema.category = product.category.name
  }

  // offers — single Offer (we don't have variants-as-separate-Offers yet).
  if (offer) {
    schema.offers = offer
  }

  // aggregateRating + review — INCLUDED ONLY when there are APPROVED reviews
  // actually rendered on the page. Google's policy:
  //   "You must include reviews or ratings that are available on your page
  //    to users. Don't include aggregate ratings that aren't visible."
  //
  // So we check `visibleReviews` (the rendered list), NOT `product.reviewCount`
  // (which is a stale counter that may include hidden/rejected reviews).
  if (visibleReviews.length > 0) {
    const ratings = visibleReviews
      .map((r) => r.rating)
      .filter((r): r is number => typeof r === 'number' && r >= 1 && r <= 5)
    if (ratings.length > 0) {
      const sum = ratings.reduce((a, b) => a + b, 0)
      const avg = sum / ratings.length
      schema.aggregateRating = {
        '@type': 'AggregateRating',
        ratingValue: Number(avg.toFixed(1)),
        reviewCount: ratings.length,
      }
    }
    // Also emit individual `review` entries for the visible ones.
    // This is optional but helps with rich-result eligibility.
    schema.review = visibleReviews.slice(0, 20).map((r) => ({
      '@type': 'Review',
      author: { '@type': 'Person', name: r.customerName },
      reviewRating: {
        '@type': 'Rating',
        ratingValue: r.rating,
        bestRating: 5,
        worstRating: 1,
      },
      ...(r.title ? { name: r.title } : {}),
      ...(r.body ? { reviewBody: r.body } : {}),
    }))
  }

  return schema
}

/**
 * Build a BreadcrumbList schema from a list of crumbs.
 *
 * Each crumb is `{ name: string, path: string }`. The path is relative
 * (e.g. `/produits`, `/categories/outillage`). We resolve it against
 * `siteUrl` to produce an absolute URL — required by Schema.org.
 *
 * Returns `null` when `siteUrl` is null (no production domain configured).
 * The caller should skip rendering the script tag in that case.
 *
 * The LAST crumb (current page) is included per Schema.org spec — Google
 * recommends including the current page in the breadcrumb trail. We use
 * the page's URL for its `item` field.
 */
export function buildBreadcrumbSchema(
  siteUrl: string | null,
  crumbs: Array<{ name: string; path: string }>,
): Record<string, unknown> | null {
  if (!siteUrl) return null
  if (crumbs.length === 0) return null

  const itemListElement = crumbs.map((c, i) => {
    const item = absoluteUrl(siteUrl, c.path)
    return {
      '@type': 'ListItem',
      position: i + 1,
      name: c.name,
      item, // absolute URL — never relative
    }
  })

  return {
    '@context': 'https://schema.org',
    '@type': 'BreadcrumbList',
    itemListElement,
  }
}

/**
 * Build the Organization / Store schema for the site root.
 * Returned once per page (rendered in the root layout).
 *
 * Returns `null` when `siteUrl` is null.
 */
export function buildOrganizationSchema(
  siteUrl: string | null,
  opts: {
    siteName: string
    description: string
    supportPhone?: string
    supportEmail?: string
    address?: string
    logoUrl?: string | null
    ogImage?: string | null
    sameAs?: string[]
  },
): Record<string, unknown> | null {
  if (!siteUrl) return null
  const schema: Record<string, unknown> = {
    '@context': 'https://schema.org',
    '@type': 'Store',
    name: opts.siteName,
    url: siteUrl,
    description: opts.description,
  }
  if (opts.supportPhone) schema.telephone = opts.supportPhone
  if (opts.supportEmail) schema.email = opts.supportEmail
  if (opts.address) {
    schema.address = {
      '@type': 'PostalAddress',
      addressLocality: opts.address.split(',')[0] || 'Casablanca',
      addressCountry: 'MA',
    }
  }
  if (opts.sameAs && opts.sameAs.length > 0) {
    schema.sameAs = opts.sameAs
  }
  schema.logo = opts.logoUrl || `${siteUrl}/icon-512x512.png`
  schema.image = opts.ogImage || opts.logoUrl || `${siteUrl}/og-image.png`
  return schema
}

/**
 * Build the WebSite schema for the site root.
 * Returned once per page (rendered in the root layout).
 *
 * Returns `null` when `siteUrl` is null.
 */
export function buildWebSiteSchema(
  siteUrl: string | null,
  opts: {
    siteName: string
    description: string
  },
): Record<string, unknown> | null {
  if (!siteUrl) return null
  const searchUrl = absoluteUrl(siteUrl, '/recherche?q={search_term_string}')
  return {
    '@context': 'https://schema.org',
    '@type': 'WebSite',
    name: opts.siteName,
    url: siteUrl,
    description: opts.description,
    potentialAction: {
      '@type': 'SearchAction',
      target: `${searchUrl}`,
      'query-input': 'required name=search_term_string',
    },
  }
}
