/**
 * Lightweight HTML sanitization for user-submitted rich text.
 *
 * WHY
 * ---
 * Product / page descriptions can contain HTML (bold, lists, links) so the
 * admin UI ships a rich-text editor. But we MUST NOT trust that HTML on the
 * server — a compromised admin account or a content-seo-manager role could
 * inject `<script>` / `<iframe>` / `on*=` event handlers / `javascript:`
 * URLs that would later execute in the storefront and steal customer data.
 *
 * APPROACH
 * --------
 * We deliberately avoid a heavyweight dependency (DOMPurify needs a DOM
 * implementation on the server, which adds 80+ KB and a JSDOM dependency).
 * Instead, we escape everything aggressively, then re-enable a tiny
 * allow-list of tags & attributes that the rich-text editor actually uses.
 *
 * This is a SAFE-BY-DEFAULT approach: anything we forget to allow is
 * escaped, never executed. The trade-off is that some legitimately-styled
 * HTML may render as plain text — preferable to an XSS hole.
 */

const ALLOWED_TAGS = new Set([
  'p', 'br', 'strong', 'b', 'em', 'i', 'u', 's', 'small',
  'h1', 'h2', 'h3', 'h4', 'h5', 'h6',
  'ul', 'ol', 'li',
  'a', 'span', 'div', 'blockquote',
  'img', 'figure', 'figcaption',
  'table', 'thead', 'tbody', 'tr', 'th', 'td',
  'hr',
])

const ALLOWED_ATTRS: Record<string, Set<string>> = {
  a: new Set(['href', 'title', 'target', 'rel']),
  img: new Set(['src', 'alt', 'title', 'width', 'height', 'loading']),
  span: new Set(['class']),
  div: new Set(['class']),
  p: new Set(['class']),
  td: new Set(['colspan', 'rowspan']),
  th: new Set(['colspan', 'rowspan']),
}

const VOID_TAGS = new Set(['br', 'hr', 'img'])

/**
 * Sanitize an HTML string for safe display in the storefront.
 *
 * - Strips <script>, <style>, <iframe>, <object>, <embed>, <form>, <input>,
 *   <meta>, <link>, and any other tag NOT in the allow-list.
 * - Strips ALL event-handler attributes (onload, onclick, onerror, …).
 * - Strips `style="..."` attributes (CSS expression injection is a real risk).
 * - Forces `rel="noopener noreferrer"` on `target="_blank"` links.
 * - Rewrites `javascript:` / `data:` / `vbscript:` URLs to `#`.
 */
export function sanitizeHtml(input: string): string {
  if (!input || typeof input !== 'string') return ''
  // First pass: neutralize the most dangerous patterns BEFORE parsing
  // (so even our own parser can't be tricked by malformed HTML)
  let s = input
  // Drop CDATA sections entirely (they can hide scripts from naive parsers)
  s = s.replace(/<!\[CDATA\[[\s\S]*?\]\]>/gi, '')
  // Drop XML processing instructions
  s = s.replace(/<\?[\s\S]*?\?>/gi, '')
  // Drop HTML comments (they can hide conditional-comment IE exploits)
  s = s.replace(/<!--[\s\S]*?-->/gi, '')
  // Decode HTML entities so we can re-encode them safely
  // (this defeats the classic `<script>alert(1)</script>` bypass via &lt;script&gt;)
  s = decodeEntities(s)

  // Tokenize: walk through tags and text, rebuilding only the safe parts.
  const out: string[] = []
  const tagRe = /<\/?([a-zA-Z][a-zA-Z0-9]*)((?:\s+[^<>]*)?)(\/?)>/g
  let lastIndex = 0
  let m: RegExpExecArray | null
  while ((m = tagRe.exec(s)) !== null) {
    // Text before the tag
    if (m.index > lastIndex) {
      out.push(escapeText(s.slice(lastIndex, m.index)))
    }
    const tagName = m[1].toLowerCase()
    const attrsRaw = m[2] || ''
    const selfClose = m[3] === '/'
    const isClosing = m[0][1] === '/'
    if (!ALLOWED_TAGS.has(tagName)) {
      // Unknown tag — drop the tag but KEEP its inner text (so `<script>alert(1)</script>`
      // renders as "alert(1)" instead of executing). For known-dangerous
      // tags (script/style/iframe) we want the inner text gone too — but
      // our parser already sees them as a single matched pair, so the inner
      // text is consumed by the regex's next text run. To be safe, we drop
      // known-dangerous tag content by skipping ahead.
      if (['script', 'style', 'iframe', 'object', 'embed', 'noscript', 'template'].includes(tagName)) {
        // Skip until matching closing tag
        const closeRe = new RegExp(`</${tagName}\\s*>`, 'gi')
        const after = tagRe.lastIndex
        closeRe.lastIndex = after
        const closeM = closeRe.exec(s)
        if (closeM) {
          tagRe.lastIndex = closeM.index + closeM[0].length
        } else {
          // no closing tag — skip the rest
          tagRe.lastIndex = s.length
        }
      }
      lastIndex = tagRe.lastIndex
      continue
    }
    if (isClosing) {
      out.push(`</${tagName}>`)
    } else {
      const attrs = sanitizeAttrs(tagName, attrsRaw)
      out.push(`<${tagName}${attrs}${selfClose ? ' /' : ''}${VOID_TAGS.has(tagName) ? ' /' : ''}>`)
    }
    lastIndex = tagRe.lastIndex
  }
  if (lastIndex < s.length) {
    out.push(escapeText(s.slice(lastIndex)))
  }
  return out.join('')
}

function sanitizeAttrs(tagName: string, raw: string): string {
  const allowed = ALLOWED_ATTRS[tagName]
  const out: string[] = []
  // Match: name="value" | name='value' | name=value | name
  const attrRe = /([a-zA-Z_:][a-zA-Z0-9_:.-]*)(?:\s*=\s*("([^"]*)"|'([^']*)'|([^\s>]+)))?/g
  let am: RegExpExecArray | null
  while ((am = attrRe.exec(raw)) !== null) {
    const name = am[1].toLowerCase()
    const value = am[3] ?? am[4] ?? am[5] ?? ''
    // Block ANY event handler
    if (name.startsWith('on')) continue
    // Block style attribute
    if (name === 'style') continue
    // Block unknown attributes when an allowlist exists
    if (allowed && !allowed.has(name)) continue
    // URL attributes — block dangerous schemes
    if (name === 'href' || name === 'src') {
      const v = value.trim().toLowerCase()
      if (
        v.startsWith('javascript:') ||
        v.startsWith('data:') ||
        v.startsWith('vbscript:') ||
        v.startsWith('file:')
      ) {
        continue
      }
    }
    // Force rel="noopener noreferrer" on links with target=_blank
    if (tagName === 'a' && name === 'target' && value === '_blank') {
      out.push(` target="_blank"`)
      out.push(` rel="noopener noreferrer"`)
      continue
    }
    // Escape the attribute value
    out.push(` ${name}="${escapeAttr(value)}"`)
  }
  return out.join('')
}

function escapeText(s: string): string {
  return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
}

function escapeAttr(s: string): string {
  return s
    .replace(/&/g, '&amp;')
    .replace(/"/g, '&quot;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
}

function decodeEntities(s: string): string {
  const map: Record<string, string> = {
    '&lt;': '<', '&gt;': '>', '&amp;': '&', '&quot;': '"', '&#39;': "'",
    '&#x27;': "'", '&#x2F;': '/', '&#47;': '/',
  }
  return s.replace(/&(?:lt|gt|amp|quot|#39|#x27|#47|#x2F);/g, (e) => map[e] ?? e)
}

/** Strip ALL HTML tags and return plain text (used for meta descriptions). */
export function htmlToPlainText(input: string, maxLen = 200): string {
  if (!input) return ''
  let s = input.replace(/<[^>]+>/g, ' ')
  s = s.replace(/&nbsp;/g, ' ').replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&#39;/g, "'")
  s = s.replace(/\s+/g, ' ').trim()
  if (s.length > maxLen) s = s.slice(0, maxLen - 1).trimEnd() + '…'
  return s
}
