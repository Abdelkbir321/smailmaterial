import { PrismaClient } from '@prisma/client'

/**
 * Database client singleton.
 *
 * In production (Netlify/VPS) the platform injects env vars directly via the
 * Netlify site settings, so no `.env` file reading is needed. In development,
 * Next.js + Prisma automatically load `.env`, `.env.local`, etc.
 *
 * We previously had a custom `loadEnvOverride()` function here that read `.env`
 * files with `fs.existsSync` / `fs.readFileSync`. That caused problems:
 *   1. Turbopack traced the entire project (including public/) into the
 *      serverless function bundle, bloating deploy size.
 *   2. On Netlify, the `.env` file doesn't exist (env vars come from the
 *      platform), so the loader was a no-op anyway.
 *
 * Removing the dynamic fs access fixes both issues.
 */

const globalForPrisma = globalThis as unknown as {
  prisma: PrismaClient | undefined
}

export const db =
  globalForPrisma.prisma ??
  new PrismaClient({
    log: process.env.NODE_ENV === 'development' ? ['error', 'warn'] : ['error'],
  })

if (process.env.NODE_ENV !== 'production') globalForPrisma.prisma = db
