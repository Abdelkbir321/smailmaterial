import { z } from 'zod'
import type { OrderField } from '@prisma/client'

/**
 * Build a per-request Zod schema for /api/orders POST body that respects
 * the CURRENT OrderField table configuration.
 *
 * ==========================================================================
 * WHY THIS EXISTS
 * --------------------------------------------------------------------------
 * The original bug: `/api/orders/route.ts` used a HARDCODED `baseSchema`
 * with `z.string().min(6)` for `customerPhone` etc. When the admin
 * deactivated the `phone` OrderField (or set `required: false`), the
 * checkout form stopped rendering the phone input — but the baseSchema
 * still required `customerPhone.min(6)`. The user could not submit a
 * valid order; the server kept returning:
 *
 *   "المرجو تصحيح الحقول المشار إليها بالأحمر."
 *
 * The fix: build the schema DYNAMICALLY from the OrderField rows.
 *
 * ==========================================================================
 * RULES
 * --------------------------------------------------------------------------
 * For each STRUCTURED field key (full_name, phone, country, city,
 * address, postal_code, notes):
 *
 *   - Field row MISSING OR `isActive === false` → the corresponding
 *     structured column becomes OPTIONAL (accepts empty string).
 *
 *   - Field row present, `required === true` → apply full type-specific
 *     validation (length, regex).
 *
 *   - Field row present, `required === false` → apply only FORMAT
 *     validation when a value IS provided; empty string accepted.
 *
 * For `countryId` (foreign key, NOT NULL at DB level):
 *   - When `country` field is active + required → require non-empty
 *   - When `country` field is active + required=false → accept empty,
 *     `createOrder` resolves the default country server-side.
 *   - When `country` field is deactivated → accept empty, `createOrder`
 *     resolves the default country server-side.
 *
 * The `items` array is ALWAYS required (min 1, can't checkout with empty cart).
 *
 * ==========================================================================
 * NOTE
 * --------------------------------------------------------------------------
 * For DB write: structured columns (`customer_phone`, `customer_full_name`)
 * are NOT NULL in the Prisma schema. When a structured field is deactivated,
 * `createOrder` writes an empty string `''` — satisfies NOT NULL without
 * fabricating fake data.
 *
 * ==========================================================================
 */

/**
 * Map of order field key → structured Order column.
 *
 * Structured columns are first-class fields stored in dedicated columns
 * on the `orders` table (customer_full_name, customer_phone, etc.).
 * They get SQL-indexed lookups, dashboard filtering, and clean display.
 *
 * ==========================================================================
 * ALIASES — critical for production data
 * --------------------------------------------------------------------------
 * The canonical keys are `full_name`, `address`, etc. (snake_case, English).
 * However, the production database may contain ALTERNATE keys that were
 * created by the admin (e.g. `name` instead of `full_name`, or `adress`
 * with a typo instead of `address`). Without these aliases, the checkout
 * form sends those fields through the `customFields` JSON path instead of
 * the structured column path, and the API stores empty strings for
 * `customerFullName`, `shippingAddress`, etc.
 *
 * The fix: treat `name`, `adress`, and any other historical alias as
 * equivalents to their canonical key. This is a *read* alias — we never
 * write `name` to the `customer_full_name` column; we just accept it
 * from the form payload as if it were `full_name`.
 *
 * Adding new aliases here is safe and backward-compatible: existing
 * orders with `customFields.name = 'X'` are not migrated (their values
 * are preserved as-is), but NEW orders will write the value to the
 * structured column instead.
 */
export const FIELD_KEY_TO_STRUCTURED: Record<string, string> = {
  // Canonical keys
  full_name: 'customerFullName',
  phone: 'customerPhone',
  email: 'customerEmail',
  country: 'countryId',
  city: 'shippingCity',
  address: 'shippingAddress',
  postal_code: 'shippingPostalCode',
  notes: 'notes',
  // ─── Aliases (historical / typo) ─────────────────────────────────
  // These resolve to the SAME structured column as their canonical key.
  'name': 'customerFullName',     // admin sometimes uses `name` instead of `full_name`
  'fullname': 'customerFullName', // single-word variant
  'tel': 'customerPhone',         // alternative for phone
  'country_name': 'countryId',    // unlikely but defensive
  'adress': 'shippingAddress',    // common typo
  'addr': 'shippingAddress',      // shorthand
  'postalcode': 'shippingPostalCode',
  'zip': 'shippingPostalCode',
  'comment': 'notes',             // alternative for notes
}

/**
 * Reverse map — structured column → CANONICAL field key.
 * Used to translate server-side Zod errors back to the form field key
 * so the error appears next to the right input.
 *
 * NOTE: this always returns the canonical key. If the form was rendered
 * with an alias (e.g. `name`), the frontend remaps that alias back to
 * `name` itself via its own `STRUCTURED_TO_FIELD_KEY` table (which
 * includes the alias). So the error message ends up on the right input.
 */
export const STRUCTURED_TO_FIELD_KEY: Record<string, string> = {
  customerFullName: 'full_name',
  customerPhone: 'phone',
  customerEmail: 'email',
  countryId: 'country',
  shippingCity: 'city',
  shippingAddress: 'address',
  shippingPostalCode: 'postal_code',
  notes: 'notes',
  items: 'items',
}

/**
 * The set of all keys (canonical + aliases) that map to a structured
 * column. Used by the order detail page to decide which `customFields`
 * entries are already shown in the dedicated Customer/Shipping cards
 * (and should NOT be duplicated in the "extra fields" list).
 */
export const STRUCTURED_FIELD_KEY_OR_ALIASES = new Set(
  Object.keys(FIELD_KEY_TO_STRUCTURED),
)

type FieldValidatorType = 'text' | 'phone' | 'email' | 'textarea' | 'select'

/**
 * For each canonical field key, the list of all keys (canonical + aliases)
 * that should be looked up in the OrderField table to find the row that
 * controls validation for that structured column.
 *
 * The FIRST key found in the table (in array order) wins. Canonical
 * keys are always tried first; aliases follow.
 */
const FIELD_KEY_LOOKUP_ORDER: Record<string, string[]> = {
  full_name: ['full_name', 'name', 'fullname'],
  phone: ['phone', 'tel'],
  email: ['email'],
  country: ['country', 'country_name'],
  city: ['city'],
  address: ['address', 'adress', 'addr'],
  postal_code: ['postal_code', 'postalcode', 'zip'],
  notes: ['notes', 'comment'],
}

/**
 * Build the Zod validator for a single structured field.
 * Returns null if the field is deactivated (use .optional().or(literal(''))).
 *
 * Looks up the OrderField row by trying the canonical key first, then
 * any known aliases (e.g. `name` for `full_name`, `adress` for `address`).
 * The first match wins. This lets the admin rename fields to their
 * preferred key without breaking the structured-column mapping.
 */
function buildFieldValidator(
  fieldKey: string,
  type: FieldValidatorType,
  fieldByKey: Map<string, OrderField>,
): z.ZodString | null {
  const lookupOrder = FIELD_KEY_LOOKUP_ORDER[fieldKey] || [fieldKey]
  let row: OrderField | undefined
  for (const k of lookupOrder) {
    const r = fieldByKey.get(k)
    if (r) {
      row = r
      break
    }
  }
  if (!row || !row.isActive) return null

  let validator = z.string()
  // Length bounds
  if (row.minLength && row.minLength > 0) {
    validator = validator.min(row.minLength, `الحد الأدنى ${row.minLength} أحرف`)
  } else if (row.required) {
    // No explicit minLength but required → min 1 char (non-empty after trim)
    validator = validator.min(1, 'هذا الحقل إجباري.')
  }
  if (row.maxLength) {
    validator = validator.max(row.maxLength, `الحد الأقصى ${row.maxLength} أحرف`)
  }
  // Type-specific format validation
  if (type === 'phone') {
    // `*` quantifier allows empty string when not required
    validator = validator.regex(/^[+\d\s().-]*$/, 'صيغة الهاتف غير صالحة')
  } else if (type === 'email') {
    // Allow empty OR valid email format
    validator = validator.regex(/^[^\s@]*@[^\s@]*\.[^\s@]*$|^$/, 'البريد الإلكتروني غير صالح.')
  }

  return validator
}

/**
 * Build the dynamic Zod schema for an order creation payload, given the
 * list of ALL OrderField rows (active AND inactive — needed to check
 * `required` and `isActive` flags).
 */
export function buildOrderSchemaFromFields(allFields: OrderField[]) {
  const fieldByKey = new Map(allFields.map((f) => [f.key, f]))

  const fullNameValidator = buildFieldValidator('full_name', 'text', fieldByKey)
  const phoneValidator = buildFieldValidator('phone', 'phone', fieldByKey)
  const emailValidator = buildFieldValidator('email', 'email', fieldByKey)
  const cityValidator = buildFieldValidator('city', 'text', fieldByKey)
  const addressValidator = buildFieldValidator('address', 'textarea', fieldByKey)
  const postalValidator = buildFieldValidator('postal_code', 'text', fieldByKey)
  const notesValidator = buildFieldValidator('notes', 'textarea', fieldByKey)

  // Country is a foreign key — always required at DB level. But if the
  // admin DELETED or DEACTIVATED the `country` field in the form, the user
  // can't pick one. We resolve the default country server-side in createOrder.
  //
  // CRITICAL FIX: When the `country` field row is MISSING from the DB
  // (admin deleted it entirely), `countryRow` is undefined. The old code
  // treated this as "active + required" because `undefined?.isActive !== false`
  // evaluates to `true`. This caused the checkout to fail with
  // "الدولة إجبارية" even though the country field wasn't shown in the form.
  //
  // Now: MISSING row OR isActive=false → treat as deactivated → accept empty.
  // Try canonical `country` first, then `country_name` alias.
  const countryLookup = FIELD_KEY_LOOKUP_ORDER.country || ['country']
  let countryRow: OrderField | undefined
  for (const k of countryLookup) {
    const r = fieldByKey.get(k)
    if (r) { countryRow = r; break }
  }
  const countryActive = countryRow?.isActive === true
  const countryRequired = countryActive && (countryRow?.required ?? true)
  const countryIdSchema = countryRequired
    ? z.string().min(1, 'الدولة إجبارية')
    : z.string().optional().or(z.literal(''))

  return z.object({
    customerFullName: fullNameValidator ?? z.string().optional().or(z.literal('')),
    customerPhone: phoneValidator ?? z.string().optional().or(z.literal('')),
    customerEmail: emailValidator ?? z.string().optional().or(z.literal('')),
    countryId: countryIdSchema,
    shippingCity: cityValidator ?? z.string().optional().or(z.literal('')),
    shippingAddress: addressValidator ?? z.string().optional().or(z.literal('')),
    shippingPostalCode: postalValidator ?? z.string().max(20).optional().or(z.literal('')),
    notes: notesValidator ?? z.string().max(1000).optional().or(z.literal('')),
    couponCode: z.string().max(50).optional().or(z.literal('')),
    items: z
      .array(
        z.object({
          productId: z.string().min(1),
          variantId: z.string().optional().nullable(),
          quantity: z.number().int().min(1).max(999),
        }),
      )
      .min(1, 'السلة فارغة'),
    customFields: z.record(z.string(), z.string()).optional(),
    idempotencyKey: z.string().min(8).max(100).optional(),
  })
}
