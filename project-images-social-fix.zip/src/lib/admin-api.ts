import { getCurrentAdmin } from './auth'
import { db } from './db'
import type { AdminUser } from '@prisma/client'

export async function requireAdmin(): Promise<AdminUser | null> {
  return getCurrentAdmin()
}

export async function audit(
  adminUserId: string | null,
  action: string,
  entity: string,
  entityId?: string | null,
  metadata: Record<string, unknown> = {},
  meta: { ip?: string; userAgent?: string } = {},
) {
  try {
    await db.auditLog.create({
      data: {
        adminUserId,
        action,
        entity,
        entityId: entityId ?? null,
        metadata: metadata as object,
        // Truncate IPs to 3 octets (e.g. 196.200.1.x) before storing — this
        // is a GDPR/CCPA best practice for pseudonymization. The truncated
        // IP is still useful for rate-limiting and fraud detection (you can
        // block a /24 subnet) but does NOT uniquely identify a person.
        ip: meta.ip ? truncateIp(meta.ip) : undefined,
        userAgent: meta.userAgent,
      },
    })
  } catch (e) {
    console.error('[audit] failed to log', action, e)
  }
}

export function clientMeta(req: Request) {
  const forwarded = req.headers.get('x-forwarded-for')
  const rawIp = forwarded?.split(',')[0]?.trim() || req.headers.get('x-real-ip') || undefined
  const userAgent = req.headers.get('user-agent') || undefined
  return {
    // Store the truncated IP — the full IP is only kept in memory for the
    // duration of the request (rate limiting, fraud checks) and never
    // written to the database.
    ip: rawIp ? truncateIp(rawIp) : undefined,
    userAgent,
  }
}

/**
 * Truncate an IPv4 or IPv6 address for pseudonymized storage.
 *
 * - IPv4: keep the first 3 octets, zero the last → 196.200.1.0
 * - IPv6: keep the first 4 hextets, zero the rest → 2001:db8:abcd:ef00::
 *
 * This follows the GDPR "pseudonymization" recommendation: the truncated
 * IP can no longer uniquely identify a single device/person, but is still
 * useful for:
 *   - Rate limiting (block an abusive /24 subnet)
 *   - GeoIP (country/region level — city-level needs the full IP)
 *   - Fraud detection (pattern matching on subnet)
 *
 * The full IP is NEVER written to the database. It's only kept in memory
 * for the duration of the request.
 */
export function truncateIp(ip: string): string {
  const trimmed = ip.trim()
  // IPv4
  if (/^\d{1,3}(\.\d{1,3}){3}$/.test(trimmed)) {
    const parts = trimmed.split('.')
    return `${parts[0]}.${parts[1]}.${parts[2]}.0`
  }
  // IPv6 — keep the first 4 hextets
  if (trimmed.includes(':')) {
    const parts = trimmed.split(':')
    if (parts.length >= 4) {
      return `${parts.slice(0, 4).join(':')}::`
    }
  }
  // Unknown format — return as-is (rare)
  return trimmed
}

export function jsonError(message: string, status = 400, fieldErrors?: Record<string, string>) {
  return Response.json({ ok: false, error: message, fieldErrors }, { status })
}

export function jsonOk(data: Record<string, unknown>, status = 200) {
  return Response.json({ ok: true, ...data }, { status })
}
