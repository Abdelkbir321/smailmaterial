/**
 * Simple in-memory rate limiter for serverless.
 *
 * NOTE: On Netlify serverless, each function instance has its own memory, so
 * this is a "best effort" limiter — a determined attacker hitting many
 * instances could bypass it. For true production-grade rate limiting, use
 * Netlify Edge Functions + a shared store (Upstash Redis, etc). This catches
 * the common case (single-instance brute force, spam bots).
 *
 * Usage:
 *   const { ok, retryAfter } = rateLimit(`login:${ip}`, 5, 15 * 60 * 1000)
 *   if (!ok) return Response.json({ error: 'Too many attempts' }, { status: 429, headers: { 'Retry-After': String(retryAfter) } })
 */

interface Bucket {
  count: number
  resetAt: number
}

const store = new Map<string, Bucket>()

// Periodic cleanup (every 5 min) to avoid memory growth
let lastCleanup = Date.now()
function cleanup() {
  const now = Date.now()
  if (now - lastCleanup < 5 * 60 * 1000) return
  lastCleanup = now
  for (const [key, bucket] of store) {
    if (bucket.resetAt < now) store.delete(key)
  }
}

/**
 * @param key     unique identifier (e.g. `login:1.2.3.4`, `order:1.2.3.4`)
 * @param limit   max requests in the window
 * @param windowMs window duration in milliseconds
 * @returns { ok, retryAfter } — ok=false means rate limited; retryAfter = seconds to wait
 */
export function rateLimit(key: string, limit: number, windowMs: number): { ok: boolean; retryAfter: number; remaining: number } {
  cleanup()
  const now = Date.now()
  const existing = store.get(key)
  if (!existing || existing.resetAt < now) {
    store.set(key, { count: 1, resetAt: now + windowMs })
    return { ok: true, retryAfter: 0, remaining: limit - 1 }
  }
  existing.count++
  if (existing.count > limit) {
    const retryAfter = Math.ceil((existing.resetAt - now) / 1000)
    return { ok: false, retryAfter, remaining: 0 }
  }
  return { ok: true, retryAfter: 0, remaining: limit - existing.count }
}

/** Convenience: rate limit by IP for a given action. */
export function rateLimitByIp(ip: string | undefined, action: string, limit: number, windowMs: number) {
  return rateLimit(`${action}:${ip || 'unknown'}`, limit, windowMs)
}
