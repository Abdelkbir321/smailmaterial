/**
 * Analytics tracking utilities
 * ============================
 *
 * - Bot detection (lightweight, reduces pollution from crawlers)
 * - Device/browser/OS parsing from User-Agent
 * - Traffic source detection (direct, organic, social, referral, etc.)
 * - Session ID generation (stored in cookie, 30 min idle timeout)
 */

import { NextRequest } from 'next/server'

const SESSION_COOKIE = 'v_sid'
const SESSION_MAX_AGE = 30 * 60 * 30 // 30 min * 30 days = ~15 days of inactivity before reset

/** Known bot patterns — lightweight detection to filter crawlers. */
const BOT_PATTERNS = [
  /bot\b/i, /crawler\b/i, /spider\b/i, /scraper\b/i, /facebookexternalhit/i,
  /googlebot/i, /bingbot/i, /yandexbot/i, /baiduspider/i, /twitterbot/i,
  /linkedinbot/i, /telegrambot/i, /whatsapp/i, /preview/i, /facebot/i,
  /ia_archiver/i, /sitespeed/i, /gtmetrix/i, /lighthouse/i, /page_speed/i,
  /uptime/i, /monitor/i, /pingdom/i, /headless/i, /phantom/i, /selenium/i,
  /puppeteer/i, /wkhtml/i, /wget/i, /curl/i, /python-requests/i, /go-http-client/i,
]

export function isBot(userAgent: string | null): boolean {
  if (!userAgent) return false
  return BOT_PATTERNS.some((p) => p.test(userAgent))
}

/** Parse device type from User-Agent. */
export function parseDevice(userAgent: string | null): string {
  if (!userAgent) return 'unknown'
  const ua = userAgent.toLowerCase()
  if (/ipad|tablet|playbook|silk/.test(ua)) return 'tablet'
  if (/mobile|iphone|ipod|android.*mobile|windows phone|blackberry|opera mini/i.test(ua)) return 'mobile'
  if (/desktop|windows|macintosh|linux|x11|ubuntu|fedora/i.test(ua)) return 'desktop'
  return 'unknown'
}

/** Parse browser name from User-Agent. */
export function parseBrowser(userAgent: string | null): string | null {
  if (!userAgent) return null
  const ua = userAgent.toLowerCase()
  if (/edg\//.test(ua)) return 'Edge'
  if (/opr\/|opera/.test(ua)) return 'Opera'
  if (/chrome|crios|chromium/.test(ua)) return 'Chrome'
  if (/firefox|fxios/.test(ua)) return 'Firefox'
  if (/safari/.test(ua)) return 'Safari'
  return 'Other'
}

/** Parse OS name from User-Agent. */
export function parseOS(userAgent: string | null): string | null {
  if (!userAgent) return null
  const ua = userAgent.toLowerCase()
  if (/windows nt 10/.test(ua)) return 'Windows'
  if (/windows nt/.test(ua)) return 'Windows'
  if (/mac os x|macintosh|iphone|ipad|ipod/.test(ua)) return 'macOS/iOS'
  if (/android/.test(ua)) return 'Android'
  if (/linux|ubuntu|fedora|debian/.test(ua)) return 'Linux'
  return 'Other'
}

/** Known social media domains for organic social detection. */
const SOCIAL_DOMAINS = [
  'facebook.com', 'fb.com', 'instagram.com', 'twitter.com', 'x.com',
  'tiktok.com', 'youtube.com', 'youtu.be', 'linkedin.com', 'pinterest.com',
  'snapchat.com', 'reddit.com', 'whatsapp.com', 'telegram.org',
]

/** Known search engine domains. */
const SEARCH_DOMAINS = [
  'google.', 'bing.com', 'yahoo.com', 'baidu.com', 'yandex.ru', 'duckduckgo.com',
  'search.yahoo.com', 'ask.com', 'aol.com', 'ecosia.org',
]

/**
 * Determine traffic source from referrer + UTM params.
 *
 * Priority:
 *  1. UTM medium (if present, maps to paid/organic search/social)
 *  2. Referrer domain (if it's a known search/social/referral)
 *  3. Direct (no referrer or same-domain)
 */
export function detectTrafficSource(opts: {
  referrer: string | null
  utmSource?: string | null
  utmMedium?: string | null
}): string {
  const { referrer, utmSource, utmMedium } = opts

  // UTM-based detection (highest priority)
  if (utmMedium) {
    const m = utmMedium.toLowerCase()
    if (m.includes('cpc') || m.includes('ppc') || m.includes('paid')) {
      if (utmSource && SOCIAL_DOMAINS.some((s) => utmSource.toLowerCase().includes(s))) {
        return 'paid_social'
      }
      return 'paid_search'
    }
    if (m.includes('social') || m.includes('facebook') || m.includes('instagram') || m.includes('tiktok')) {
      return 'organic_social'
    }
    if (m.includes('email') || m.includes('newsletter')) {
      return 'email'
    }
    if (m.includes('referral') || m.includes('affiliate')) {
      return 'referral'
    }
    if (m.includes('organic') || m.includes('search')) {
      return 'organic_search'
    }
  }

  // Referrer-based detection
  if (referrer) {
    try {
      const refUrl = new URL(referrer)
      const host = refUrl.hostname.toLowerCase()

      // Same domain = direct
      if (host === 'ismailmaterial.netlify.app' || host.includes('localhost')) {
        return 'direct'
      }

      // Search engines
      if (SEARCH_DOMAINS.some((s) => host.includes(s))) {
        return 'organic_search'
      }

      // Social media
      if (SOCIAL_DOMAINS.some((s) => host.includes(s))) {
        return 'organic_social'
      }

      // Everything else with a referrer = referral
      return 'referral'
    } catch {
      // Invalid referrer URL
    }
  }

  return 'direct'
}

/** Generate a random session ID. */
export function generateSessionId(): string {
  // Use crypto.randomUUID if available (Node 19+ / modern browsers)
  if (typeof crypto !== 'undefined' && crypto.randomUUID) {
    return crypto.randomUUID()
  }
  // Fallback
  return `s-${Date.now()}-${Math.random().toString(36).slice(2, 11)}`
}

/** Read or create session ID from cookies. */
export function getSessionId(req: NextRequest): { sessionId: string; isNew: boolean } {
  const existing = req.cookies.get(SESSION_COOKIE)?.value
  if (existing) return { sessionId: existing, isNew: false }
  return { sessionId: generateSessionId(), isNew: true }
}

export { SESSION_COOKIE, SESSION_MAX_AGE }
