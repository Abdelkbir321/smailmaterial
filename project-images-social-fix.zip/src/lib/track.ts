/**
 * Client-side analytics event tracking helpers.
 *
 * Usage:
 *   import { trackEvent } from '@/lib/track'
 *   trackEvent('view_item', { productSlug: 'perceuse-18v', productName: 'Perceuse 18V' })
 *   trackEvent('add_to_cart', { productId: 'abc', productName: 'Perceuse', price: 299 })
 *   trackEvent('begin_checkout', { cartValue: 599, itemCount: 2 })
 *   trackEvent('search', { query: 'perceuse' })
 *   trackEvent('purchase', { orderNumber: 'ORD-2024-00001', total: 599 })
 */

type EventData = Record<string, string | number | boolean | null | undefined>

export function trackEvent(event: string, data: EventData = {}) {
  if (typeof window === 'undefined') return
  if (typeof navigator === 'undefined') return

  // Don't track admin pages
  const path = window.location.pathname
  if (path.startsWith('/admin') || path.startsWith('/api')) return

  const payload = {
    event,
    pageUrl: window.location.href,
    pagePath: path,
    referrer: document.referrer || null,
    eventData: data,
  }

  // Use sendBeacon for reliability (works during page unload)
  if (navigator.sendBeacon) {
    const blob = new Blob([JSON.stringify(payload)], { type: 'application/json' })
    navigator.sendBeacon('/api/track', blob)
  } else {
    fetch('/api/track', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
      keepalive: true,
    }).catch(() => {})
  }
}
