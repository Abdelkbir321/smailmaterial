import { cookies } from 'next/headers'
import { db } from './db'
import { hashToken, randomToken, verifyPassword } from './password'
import { audit } from './admin-api'
import type { AdminUser, Role } from '@prisma/client'

export const SESSION_COOKIE = 'adm_session'
const SESSION_TTL_DAYS = 7

function getAuthSecret(): string {
  const s = process.env.AUTH_SECRET
  if (!s || s.length < 16) {
    throw new Error(
      'AUTH_SECRET is not configured. Set it in your environment variables (32+ chars).',
    )
  }
  return s
}

export interface AdminAuthResult {
  ok: boolean
  error?: string
  admin?: AdminUser & { role: Role }
}

/**
 * Attempt admin login. Enforces a lightweight brute-force lockout.
 * Returns a token that the caller MUST set as an HttpOnly cookie.
 *
 * All login attempts (success + failure) are recorded in the audit log
 * so the admin can review suspicious activity. Failed attempts record
 * the attempted email (lowercased, trimmed) but NEVER the password.
 */
export async function loginAdmin(
  email: string,
  password: string,
  meta: { ip?: string; userAgent?: string } = {},
): Promise<AdminAuthResult & { token?: string }> {
  if (!email || !password) return { ok: false, error: 'Email and password are required.' }

  const normalizedEmail = email.toLowerCase().trim()
  const admin = await db.adminUser.findFirst({
    where: { email: normalizedEmail },
    include: { role: true },
  })
  if (!admin) {
    // constant-time-ish: still hash to avoid timing leaks
    await verifyPassword(password, 'scrypt$00$00$16384$8$1')
    // Audit: login failed — user not found. We record the attempted email
    // so the admin can see patterns (e.g. someone trying admin@, root@, etc.).
    await audit(null, 'auth.login_failed', 'admin_user', null, { attemptedEmail: normalizedEmail, reason: 'user_not_found' }, meta)
    return { ok: false, error: 'Invalid credentials.' }
  }

  // lockout check
  if (admin.lockedUntil && admin.lockedUntil > new Date()) {
    await audit(admin.id, 'auth.login_failed', 'admin_user', admin.id, { reason: 'locked_out' }, meta)
    return { ok: false, error: 'Too many attempts. Try again later.' }
  }

  const valid = await verifyPassword(password, admin.passwordHash)
  if (!valid) {
    const attempts = admin.failedAttempts + 1
    const lockFor = attempts >= 5 ? new Date(Date.now() + 15 * 60 * 1000) : null
    await db.adminUser.update({
      where: { id: admin.id },
      data: { failedAttempts: attempts, lockedUntil: lockFor ?? undefined },
    })
    await audit(admin.id, 'auth.login_failed', 'admin_user', admin.id, {
      reason: 'wrong_password',
      attemptCount: attempts,
      locked: !!lockFor,
    }, meta)
    return { ok: false, error: 'Invalid credentials.' }
  }

  // success — issue session token
  const token = randomToken(32)
  const tokenHash = hashToken(token)
  const expires = new Date(Date.now() + SESSION_TTL_DAYS * 24 * 60 * 60 * 1000)
  await db.adminSession.create({
    data: {
      adminUserId: admin.id,
      tokenHash,
      ip: meta.ip,
      userAgent: meta.userAgent,
      expiresAt: expires,
    },
  })
  await db.adminUser.update({
    where: { id: admin.id },
    data: { failedAttempts: 0, lockedUntil: null, lastLoginAt: new Date(), lastLoginIp: meta.ip },
  })
  return { ok: true, admin, token }
}

export async function getCurrentAdmin(): Promise<(AdminUser & { role: Role }) | null> {
  const store = await cookies()
  const token = store.get(SESSION_COOKIE)?.value
  if (!token) return null
  const tokenHash = hashToken(token)
  const session = await db.adminSession.findUnique({
    where: { tokenHash },
    include: { adminUser: { include: { role: true } } },
  })
  if (!session) return null
  if (session.expiresAt < new Date()) {
    await db.adminSession.delete({ where: { id: session.id } }).catch(() => {})
    return null
  }
  if (session.adminUser.status !== 'ACTIVE') return null
  return session.adminUser
}

export async function logoutAdmin(): Promise<void> {
  const store = await cookies()
  const token = store.get(SESSION_COOKIE)?.value
  if (token) {
    const tokenHash = hashToken(token)
    await db.adminSession.deleteMany({ where: { tokenHash } }).catch(() => {})
  }
}

export function setSessionCookie(token: string): {
  name: string
  value: string
  httpOnly: boolean
  secure: boolean
  sameSite: 'lax' | 'strict' | 'none'
  path: string
  maxAge: number
} {
  return {
    name: SESSION_COOKIE,
    value: token,
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'lax',
    path: '/',
    maxAge: SESSION_TTL_DAYS * 24 * 60 * 60,
  }
}

export { getAuthSecret }
