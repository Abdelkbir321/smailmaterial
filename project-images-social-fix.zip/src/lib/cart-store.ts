'use client'

import { create } from 'zustand'
import { persist, createJSONStorage } from 'zustand/middleware'

export interface CartItem {
  productId: string
  slug: string
  name: string
  sku: string
  price: number
  image?: string | null
  quantity: number
  variantId?: string | null
  variantName?: string | null
  maxStock?: number
}

interface CartState {
  items: CartItem[]
  isOpen: boolean
  add: (item: Omit<CartItem, 'quantity'>, qty?: number) => void
  remove: (productId: string, variantId?: string | null) => void
  setQty: (productId: string, variantId: string | null | undefined, qty: number) => void
  clear: () => void
  open: () => void
  close: () => void
  toggle: () => void
  count: () => number
  subtotal: () => number
}

const sameLine = (a: CartItem, b: { productId: string; variantId?: string | null }) =>
  a.productId === b.productId && (a.variantId ?? null) === (b.variantId ?? null)

export const useCart = create<CartState>()(
  persist(
    (set, get) => ({
      items: [],
      isOpen: false,
      add: (item, qty = 1) => {
        const existing = get().items.find((i) => sameLine(i, item))
        if (existing) {
          set({
            items: get().items.map((i) =>
              sameLine(i, item)
                ? {
                    ...i,
                    quantity: Math.min(i.quantity + qty, i.maxStock && i.maxStock > 0 ? i.maxStock : 999),
                  }
                : i,
            ),
            isOpen: true,
          })
        } else {
          set({ items: [...get().items, { ...item, quantity: qty }], isOpen: true })
        }
      },
      remove: (productId, variantId) =>
        set({ items: get().items.filter((i) => !(i.productId === productId && (i.variantId ?? null) === (variantId ?? null))) }),
      setQty: (productId, variantId, qty) => {
        if (qty <= 0) {
          set({ items: get().items.filter((i) => !(i.productId === productId && (i.variantId ?? null) === (variantId ?? null))) })
          return
        }
        set({
          items: get().items.map((i) =>
            i.productId === productId && (i.variantId ?? null) === (variantId ?? null)
              ? { ...i, quantity: Math.min(qty, i.maxStock && i.maxStock > 0 ? i.maxStock : 999) }
              : i,
          ),
        })
      },
      clear: () => set({ items: [] }),
      open: () => set({ isOpen: true }),
      close: () => set({ isOpen: false }),
      toggle: () => set({ isOpen: !get().isOpen }),
      count: () => get().items.reduce((s, i) => s + i.quantity, 0),
      subtotal: () => get().items.reduce((s, i) => s + i.price * i.quantity, 0),
    }),
    {
      name: 'ismail-cart',
      storage: createJSONStorage(() => (typeof window !== 'undefined' ? localStorage : (undefined as unknown as Storage))),
    },
  ),
)
