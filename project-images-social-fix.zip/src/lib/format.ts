import { clsx, type ClassValue } from 'clsx'
import { twMerge } from 'tailwind-merge'

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

/** Format a monetary amount in a given currency. */
export function formatPrice(
  amount: number | string | null | undefined,
  currency: { code: string; symbol: string; locale?: string } = {
    code: 'MAD',
    symbol: 'DH',
    locale: 'fr-MA',
  },
): string {
  if (amount === null || amount === undefined) return '—'
  const value = typeof amount === 'string' ? parseFloat(amount) : amount
  if (Number.isNaN(value)) return '—'
  try {
    return new Intl.NumberFormat(currency.locale || 'fr-MA', {
      style: 'currency',
      currency: currency.code,
      maximumFractionDigits: 2,
    }).format(value)
  } catch {
    return `${value.toFixed(2)} ${currency.symbol}`
  }
}

/** Compact number formatting for dashboard stats. */
export function formatCompact(n: number): string {
  return new Intl.NumberFormat('en', { notation: 'compact', maximumFractionDigits: 1 }).format(n)
}

export function discountPercent(price: number, compareAt?: number | null): number | null {
  if (!compareAt || compareAt <= 0 || compareAt <= price) return null
  return Math.round(((compareAt - price) / compareAt) * 100)
}

export function slugify(input: string): string {
  return input
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/(^-|-$)+/g, '')
    .slice(0, 80)
}

export function truncate(s: string, max = 120): string {
  if (s.length <= max) return s
  return s.slice(0, max - 1).trimEnd() + '…'
}

export function timeAgo(date: Date | string): string {
  const d = typeof date === 'string' ? new Date(date) : date
  const diff = (Date.now() - d.getTime()) / 1000
  if (diff < 60) return 'à l\'instant'
  if (diff < 3600) return `il y a ${Math.floor(diff / 60)} min`
  if (diff < 86400) return `il y a ${Math.floor(diff / 3600)} h`
  if (diff < 604800) return `il y a ${Math.floor(diff / 86400)} j`
  return d.toLocaleDateString('fr-MA')
}

/** Arabic relative time formatter for the admin dashboard. */
export function timeAgoAr(date: Date | string): string {
  const d = typeof date === 'string' ? new Date(date) : date
  const diff = (Date.now() - d.getTime()) / 1000
  if (diff < 60) return 'الآن'
  if (diff < 3600) return `منذ ${Math.floor(diff / 60)} دقيقة`
  if (diff < 86400) return `منذ ${Math.floor(diff / 3600)} ساعة`
  if (diff < 604800) return `منذ ${Math.floor(diff / 86400)} يوم`
  return d.toLocaleDateString('ar-MA')
}

/** Arabic absolute date (e.g. 2025/01/12) */
export function formatDateAr(date: Date | string): string {
  const d = typeof date === 'string' ? new Date(date) : date
  return d.toLocaleDateString('ar-MA')
}

export function classForStatus(status: string): string {
  const map: Record<string, string> = {
    NEW: 'bg-amber-50 text-amber-700 ring-amber-600/20',
    CONTACTED: 'bg-orange-50 text-orange-700 ring-orange-600/20',
    CONFIRMED: 'bg-teal-50 text-teal-700 ring-teal-600/20',
    PROCESSING: 'bg-violet-50 text-violet-700 ring-violet-600/20',
    SHIPPED: 'bg-cyan-50 text-cyan-700 ring-cyan-600/20',
    DELIVERED: 'bg-emerald-50 text-emerald-700 ring-emerald-600/20',
    CANCELLED: 'bg-rose-50 text-rose-700 ring-rose-600/20',
    RETURNED: 'bg-orange-50 text-orange-700 ring-orange-600/20',
    UNREACHABLE: 'bg-zinc-50 text-zinc-700 ring-zinc-600/20',
  }
  return map[status] || 'bg-zinc-50 text-zinc-700 ring-zinc-600/20'
}

export function nextOrderNumber(n: number): string {
  const year = new Date().getFullYear()
  const seq = String(n + 1).padStart(5, '0')
  return `ORD-${year}-${seq}`
}
