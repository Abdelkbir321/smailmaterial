import type {
  Product,
  ProductImage,
  ProductVideo,
  ProductVariant,
  Category,
  Brand,
  Order,
  OrderItem,
  Country,
  Review,
} from '@prisma/client'

// Public product card (for grids/listings)
export type ProductCard = Pick<
  Product,
  | 'id'
  | 'slug'
  | 'name'
  | 'sku'
  | 'price'
  | 'compareAtPrice'
  | 'currencyCode'
  | 'stockQuantity'
  | 'trackInventory'
  | 'allowBackorder'
  | 'isFeatured'
  | 'isBestSeller'
  | 'isNewArrival'
  | 'rating'
  | 'reviewCount'
  | 'shortDescription'
> & {
  mainImage: Pick<ProductImage, 'url' | 'secureUrl' | 'publicId' | 'altText'> | null
  brand: Pick<Brand, 'id' | 'slug' | 'name'> | null
  category: Pick<Category, 'id' | 'slug' | 'name'> | null
}

export type ProductDetail = Product & {
  images: ProductImage[]
  videos: ProductVideo[]
  brand: Brand | null
  category: Category
  variants: ProductVariant[]
  reviews: Review[]
}

export type CartItemInput = {
  productId: string
  variantId?: string | null
  quantity: number
}

export type CartLine = {
  productId: string
  slug: string
  name: string
  sku: string
  variantId?: string | null
  variantName?: string | null
  unitPrice: number
  quantity: number
  lineTotal: number
  image?: string | null
  stockQuantity: number
  trackInventory: boolean
  allowBackorder: boolean
  currencyCode: string
}

export interface CreateOrderInput {
  // Structured Order columns. All of them are NOT NULL in the DB schema,
  // but when the admin DEACTIVATES a corresponding OrderField, the value
  // comes through as an empty string `''` (which satisfies the NOT NULL
  // constraint without polluting the record with fake data).
  customerFullName: string
  customerPhone: string
  customerEmail?: string | null
  countryId: string
  shippingCity: string
  shippingAddress: string
  shippingPostalCode?: string | null
  notes?: string | null
  items: CartItemInput[]
  couponCode?: string | null
  // browser meta
  ip?: string | null
  userAgent?: string | null
}

export interface OrderResult {
  ok: boolean
  error?: string
  fieldErrors?: Record<string, string>
  order?: {
    id: string
    number: string
    total: number
    subtotal: number
    shippingCost: number
    discountTotal: number
    currencyCode: string
    status: string
    items: Array<{ name: string; quantity: number; lineTotal: number }>
  }
}

export interface AdminProductListItem {
  id: string
  slug: string
  name: string
  sku: string
  price: number
  compareAtPrice: number | null
  stockQuantity: number
  status: string
  categoryName: string | null
  brandName: string | null
  isFeatured: boolean
  mainImage: string | null
  createdAt: Date
}

export interface DashboardStats {
  totalOrders: number
  todayOrders: number
  totalSales: number
  pendingOrders: number
  confirmedOrders: number
  deliveredOrders: number
  cancelledOrders: number
  totalProducts: number
  lowStockProducts: number
  currencyCode: string
}

export interface DashboardActivity {
  recentOrders: Array<
    Pick<Order, 'id' | 'number' | 'customerFullName' | 'status' | 'total' | 'placedAt'>
  >
  bestSellers: Array<{
    id: string
    name: string
    slug: string
    salesCount: number
    stockQuantity: number
    mainImage: string | null
    price: number
  }>
}
