import { NextRequest } from 'next/server'
import { getProductBySlug, getRelatedProducts } from '@/services/catalog'

export const dynamic = "force-dynamic"

export async function GET(_req: NextRequest, { params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params
  const product = await getProductBySlug(slug)
  if (!product) return Response.json({ ok: false, error: 'Produit introuvable' }, { status: 404 })
  const related = await getRelatedProducts(product.id, 4)
  return Response.json({ ok: true, product, related })
}
