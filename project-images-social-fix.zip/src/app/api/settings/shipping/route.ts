import { getShippingReturnSettings } from '@/services/site-settings'

export const dynamic = 'force-dynamic'

/**
 * Public endpoint — returns the store's shipping + return policy settings.
 *
 * Used by the checkout page to compute the shipping cost client-side
 * (so the user sees the correct total before confirming the order).
 *
 * The server-side `createOrder` re-validates the shipping cost using the
 * same settings — this endpoint is just for display. We never trust the
 * client-computed total for the actual charge.
 *
 * Returns:
 *   - shippingRate, shippingCurrency, freeShippingThreshold
 *   - deliveryTimeMinDays, deliveryTimeMaxDays
 *   - returnsEnabled, returnPolicyDays
 *
 * Does NOT return the reviews settings (those are admin-only).
 */
export async function GET() {
  const s = await getShippingReturnSettings()
  return Response.json({
    ok: true,
    shipping: {
      rate: s.shippingRate,
      currency: s.shippingCurrency,
      freeShippingThreshold: s.freeShippingThreshold,
      deliveryTimeMinDays: s.deliveryTimeMinDays,
      deliveryTimeMaxDays: s.deliveryTimeMaxDays,
      returnsEnabled: s.returnsEnabled,
      returnPolicyDays: s.returnPolicyDays,
    },
  })
}
