import { getCheckoutTexts } from '@/services/site-settings'

export const dynamic = 'force-dynamic'

// Public endpoint — returns checkout texts for the storefront.
// No auth required (these are public UI labels, not secrets).
export async function GET() {
  const texts = await getCheckoutTexts()
  return Response.json({ ok: true, texts })
}
