import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import {
  isBot, parseDevice, parseBrowser, parseOS,
  detectTrafficSource, getSessionId, SESSION_COOKIE, SESSION_MAX_AGE,
} from '@/lib/analytics'
import { rateLimitByIp } from '@/lib/rate-limit'
import { z } from 'zod'

export const dynamic = 'force-dynamic'
export const runtime = 'nodejs'

// =========================================================================
// POST /api/track — collect analytics events from the storefront
// =========================================================================
//
// This endpoint is PUBLIC (no auth required) — it collects visitor events.
// Security measures:
//  1. Bot filtering (rejects known crawler User-Agents)
//  2. Admin path exclusion (doesn't track /admin/* requests)
//  3. Rate limiting: 60 events / minute / IP (anti-spam, anti-flood)
//  4. In-memory dedup (same session+event+path within 2s = ignored)
//  5. No PII stored (no full IP — truncated to /24, no fingerprinting)
//  6. Zod validation on all inputs
//  7. UTM params extracted from URL, not from client-provided body
//

const VALID_EVENTS = new Set([
  'page_view', 'session_start', 'view_item', 'add_to_cart',
  'begin_checkout', 'purchase', 'search',
])

const trackSchema = z.object({
  event: z.string().min(1).max(50),
  pageUrl: z.string().url().max(2000).optional(),
  pagePath: z.string().max(500).optional(),
  referrer: z.string().url().max(2000).optional().nullable(),
  eventData: z.record(z.unknown()).optional().default({}),
})

// Simple in-memory dedup: {key: timestamp}
// Prevents duplicate events from React re-renders or rapid navigation.
const recentEvents = new Map<string, number>()
const DEDUP_WINDOW_MS = 2000 // 2 seconds

export async function POST(req: NextRequest) {
  // 0. Rate limit: 60 events / 60s / IP — prevents flood attacks and
  // runaway client loops. A normal visitor sends ~5-10 events/min.
  const forwarded = req.headers.get('x-forwarded-for')
  const ip = forwarded?.split(',')[0]?.trim() || req.headers.get('x-real-ip') || 'unknown'
  const rl = rateLimitByIp(ip, 'track', 60, 60 * 1000)
  if (!rl.ok) {
    return NextResponse.json(
      { ok: false, error: 'Rate limited' },
      { status: 429, headers: { 'Retry-After': String(rl.retryAfter) } },
    )
  }

  // 1. Parse and validate body
  let body: z.infer<typeof trackSchema>
  try {
    body = trackSchema.parse(await req.json())
  } catch {
    return NextResponse.json({ ok: false, error: 'Invalid' }, { status: 400 })
  }

  // 2. Only track valid event names
  if (!VALID_EVENTS.has(body.event)) {
    return NextResponse.json({ ok: false, error: 'Unknown event' }, { status: 400 })
  }

  // 3. Determine page URL/path
  const pageUrl = body.pageUrl || req.headers.get('referer') || ''
  let pagePath = body.pagePath || ''
  if (!pagePath && pageUrl) {
    try { pagePath = new URL(pageUrl).pathname } catch { pagePath = '/' }
  }
  if (!pagePath) pagePath = '/'

  // 4. Exclude admin paths from storefront analytics
  if (pagePath.startsWith('/admin') || pagePath.startsWith('/api')) {
    return NextResponse.json({ ok: true, skipped: 'admin' })
  }

  // 5. Bot filtering
  const userAgent = req.headers.get('user-agent') || ''
  if (isBot(userAgent)) {
    return NextResponse.json({ ok: true, skipped: 'bot' })
  }

  // 6. Session management
  const { sessionId, isNew } = getSessionId(req)

  // 7. Dedup check — same session + event + path within 2 seconds
  const dedupKey = `${sessionId}:${body.event}:${pagePath}`
  const now = Date.now()
  const lastTime = recentEvents.get(dedupKey)
  if (lastTime && (now - lastTime) < DEDUP_WINDOW_MS) {
    // Duplicate event — silently ignore
    return NextResponse.json({ ok: true, deduped: true })
  }
  recentEvents.set(dedupKey, now)
  // Clean old entries (prevent memory leak)
  if (recentEvents.size > 10000) {
    for (const [k, t] of recentEvents) {
      if (now - t > DEDUP_WINDOW_MS * 10) recentEvents.delete(k)
    }
  }

  // 8. Extract UTM params from the page URL
  let utmSource: string | null = null
  let utmMedium: string | null = null
  let utmCampaign: string | null = null
  let utmContent: string | null = null
  let utmTerm: string | null = null
  if (pageUrl) {
    try {
      const u = new URL(pageUrl)
      utmSource = u.searchParams.get('utm_source')
      utmMedium = u.searchParams.get('utm_medium')
      utmCampaign = u.searchParams.get('utm_campaign')
      utmContent = u.searchParams.get('utm_content')
      utmTerm = u.searchParams.get('utm_term')
    } catch {}
  }

  // 9. Determine traffic source
  const referrer = body.referrer || req.headers.get('referer') || null
  const trafficSource = detectTrafficSource({ referrer, utmSource, utmMedium })

  // 10. Device info
  const device = parseDevice(userAgent)
  const browser = parseBrowser(userAgent)
  const os = parseOS(userAgent)

  // 11. Country (from CDN/proxy headers — NOT from IP storage)
  // We check ALL the major CDN headers so the country is captured on every
  // hosting provider (Netlify, Vercel, Cloudflare, AWS CloudFront, GCP).
  // Previously we only checked CF + Vercel + generic — Netlify's specific
  // header `x-nf-client-geo-country` was missing, causing country=NULL for
  // most production traffic. Now we cover all of them.
  const country = (
    req.headers.get('cf-ipcountry') ||           // Cloudflare
    req.headers.get('x-vercel-ip-country') ||    // Vercel
    req.headers.get('x-nf-client-geo-country') || // Netlify
    req.headers.get('x-country-code') ||         // Generic / some proxies
    req.headers.get('x-geo-country') ||          // AWS CloudFront / ALB
    req.headers.get('geoip-country-code') ||     // nginx GeoIP
    null
  )?.toUpperCase().trim() || null

  // 12. Store event
  try {
    await db.analyticsEvent.create({
      data: {
        sessionId,
        eventName: body.event,
        pageUrl: pageUrl || '/',
        pagePath,
        referrer: referrer || null,
        utmSource,
        utmMedium,
        utmCampaign,
        utmContent,
        utmTerm,
        trafficSource,
        device,
        browser,
        os,
        country,
        eventData: body.eventData || {},
      },
    })

    // 13. If this is a new session, also fire session_start
    if (isNew && body.event === 'page_view') {
      await db.analyticsEvent.create({
        data: {
          sessionId,
          eventName: 'session_start',
          pageUrl: pageUrl || '/',
          pagePath,
          referrer: referrer || null,
          utmSource,
          utmMedium,
          utmCampaign,
          utmContent,
          utmTerm,
          trafficSource,
          device,
          browser,
          os,
          country,
          eventData: {},
        },
      })
    }
  } catch (e) {
    // Don't fail the user's request if analytics fails
    console.error('[track] failed to store event:', e)
  }

  // 14. Set/refresh session cookie
  const response = NextResponse.json({ ok: true })
  response.cookies.set(SESSION_COOKIE, sessionId, {
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'lax',
    path: '/',
    maxAge: SESSION_MAX_AGE,
  })
  return response
}
