import { NextResponse } from 'next/server'
import { getSetting } from '@/services/settings'
import { unstable_cache } from 'next/cache'

/**
 * Google Search Console HTML file verification endpoint.
 *
 * This endpoint is REACHED via a rewrite from `/google*.html` (handled in
 * `src/proxy.ts`). Google gives you a file like `google1234567890abcdef.html`
 * to upload at the site root; we serve its content dynamically from the DB
 * setting `gsc_verification_file_content` (super-admin editable in
 * /admin/seo under "الدومين والنشر" tab).
 *
 * The user-visible URL remains `/google1234567890abcdef.html` — only the
 * internal handler changes.
 *
 * SECURITY
 * --------
 * - The file content is validated to start with `google-site-verification:`
 *   (Google's documented format). Anything else is rejected with 404.
 * - When the setting is empty, this route returns 404 — Google sees nothing.
 * - We NEVER serve arbitrary HTML from this route — only the strict
 *   verification string with a trailing newline.
 * - The route is publicly accessible (Google must reach it without auth),
 *   but the SETTING is super-admin-only.
 */

export const dynamic = 'force-dynamic'

const cachedContent = unstable_cache(
  async () => {
    try {
      return await getSetting('gsc_verification_file_content')
    } catch {
      return null
    }
  },
  ['gsc-verification-file'],
  { revalidate: 60, tags: ['settings'] },
)

export async function GET() {
  const content = await cachedContent()
  if (!content || typeof content !== 'string') {
    // No verification file configured — return 404 so Google sees nothing.
    return new NextResponse('Not Found', { status: 404 })
  }
  const trimmed = content.trim()
  // Validate format — Google's HTML file ALWAYS starts with this string.
  // We don't allow arbitrary HTML to be served from this route.
  if (!/^google-site-verification:\s*google[a-z0-9]+\.html$/i.test(trimmed)) {
    return new NextResponse('Not Found', { status: 404 })
  }
  // Google expects the file to contain EXACTLY the verification string
  // (with a trailing newline). We append a newline to match the official
  // spec. We never include any HTML tags — Google's verification files
  // are plain text, not HTML documents.
  const body = `${trimmed}\n`
  return new NextResponse(body, {
    status: 200,
    headers: {
      'Content-Type': 'text/html; charset=utf-8',
      'Cache-Control': 'public, max-age=3600, s-maxage=3600',
      'X-Robots-Tag': 'noindex, nofollow',
    },
  })
}
