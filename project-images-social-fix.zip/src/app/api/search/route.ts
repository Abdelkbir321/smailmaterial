import { NextRequest } from 'next/server'
import { searchProducts } from '@/services/catalog'
export const dynamic = 'force-dynamic'
export async function GET(req: NextRequest) {
  const q = req.nextUrl.searchParams.get('q') || ''
  return Response.json({ ok: true, products: await searchProducts(q, 20) })
}
