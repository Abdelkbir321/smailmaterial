import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { requirePermission, isSuperAdmin, countActiveSuperAdmins } from '@/lib/permissions'
import { hashPassword, verifyPassword } from '@/lib/password'
import { audit, clientMeta } from '@/lib/admin-api'
import { z } from 'zod'

export const dynamic = 'force-dynamic'

/** GET /api/admin/admin-users/[id] — get one admin */
export async function GET(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const admin = await requirePermission('admin_users', 'view')
  if (admin instanceof Response) return admin
  const { id } = await params
  const user = await db.adminUser.findUnique({
    where: { id },
    include: { role: true },
  })
  if (!user) return Response.json({ ok: false, error: 'غير موجود' }, { status: 404 })
  return Response.json({
    ok: true,
    user: {
      id: user.id,
      email: user.email,
      fullName: user.fullName,
      roleId: user.roleId,
      role: user.role,
      status: user.status,
      lastLoginAt: user.lastLoginAt,
      createdAt: user.createdAt,
      permissions: user.role.permissions,
    },
  })
}

const updateSchema = z.object({
  email: z.string().email().optional(),
  fullName: z.string().min(2).max(120).optional(),
  roleId: z.string().min(1).optional(),
  status: z.enum(['ACTIVE', 'DISABLED', 'LOCKED']).optional(),
  password: z.string().min(8).optional(),
})

/** PUT /api/admin/admin-users/[id] — edit admin (info, role, status, password reset) */
export async function PUT(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const admin = await requirePermission('admin_users', 'edit')
  if (admin instanceof Response) return admin
  const { id } = await params
  const target = await db.adminUser.findUnique({ where: { id }, include: { role: true } })
  if (!target) return Response.json({ ok: false, error: 'غير موجود' }, { status: 404 })

  const body = await req.json().catch(() => ({}))
  const parsed = updateSchema.safeParse(body)
  if (!parsed.success) {
    const fe: Record<string, string> = {}
    for (const e of parsed.error.issues) fe[e.path.join('.')] = e.message
    return Response.json({ ok: false, error: 'بيانات غير صالحة', fieldErrors: fe }, { status: 422 })
  }
  const d = parsed.data
  const update: Record<string, unknown> = {}

  // Role change checks
  if (d.roleId && d.roleId !== target.roleId) {
    const newRole = await db.role.findUnique({ where: { id: d.roleId } })
    if (!newRole) return Response.json({ ok: false, error: 'الدور غير موجود' }, { status: 404 })
    // Non-super-admins cannot assign super-admin role
    if (newRole.slug === 'super-admin' && !isSuperAdmin(admin)) {
      return Response.json({ ok: false, error: 'ممنوع تعيين دور المسؤول المطلق' }, { status: 403 })
    }
    // Prevent removing super-admin from the last active super-admin
    if (target.role.slug === 'super-admin' && newRole.slug !== 'super-admin' && target.status === 'ACTIVE') {
      const count = await countActiveSuperAdmins()
      if (count <= 1) {
        return Response.json({ ok: false, error: 'ممنوع — آخر مسؤول مطلق. عيّن مسؤول مطلق آخر قبل تغيير هذا.' }, { status: 409 })
      }
    }
    update.roleId = d.roleId
  }

  // Status change checks
  if (d.status && d.status !== target.status) {
    // Prevent disabling the last active super-admin
    if (target.role.slug === 'super-admin' && d.status !== 'ACTIVE') {
      const count = await countActiveSuperAdmins()
      if (count <= 1) {
        return Response.json({ ok: false, error: 'ممنوع تعطيل آخر مسؤول مطلق' }, { status: 409 })
      }
    }
    update.status = d.status
    // If disabling, revoke sessions
    if (d.status !== 'ACTIVE') {
      await db.adminSession.deleteMany({ where: { adminUserId: id } }).catch(() => {})
    }
  }

  if (d.email) update.email = d.email.toLowerCase()
  if (d.fullName) update.fullName = d.fullName
  if (d.password) update.passwordHash = await hashPassword(d.password)

  const updated = await db.adminUser.update({ where: { id }, data: update, include: { role: true } })
  await audit(admin.id, 'admin_user.update', 'admin_user', id, { changed: Object.keys(update) }, clientMeta(req))
  return Response.json({ ok: true, user: { ...updated, passwordHash: undefined } })
}

/** DELETE — soft delete (DISABLED) with super-admin protection */
export async function DELETE(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const admin = await requirePermission('admin_users', 'delete')
  if (admin instanceof Response) return admin
  const { id } = await params
  if (id === admin.id) {
    return Response.json({ ok: false, error: 'ممنوع حذف حسابك الحالي' }, { status: 409 })
  }
  const target = await db.adminUser.findUnique({ where: { id }, include: { role: true } })
  if (!target) return Response.json({ ok: false, error: 'غير موجود' }, { status: 404 })

  // Prevent deleting the last active super-admin
  if (target.role.slug === 'super-admin' && target.status === 'ACTIVE') {
    const count = await countActiveSuperAdmins()
    if (count <= 1) {
      return Response.json({ ok: false, error: 'ممنوع حذف آخر مسؤول مطلق' }, { status: 409 })
    }
  }

  // Hard delete (cascades sessions). Audit log keeps the action record.
  await db.adminUser.delete({ where: { id } })
  await audit(admin.id, 'admin_user.delete', 'admin_user', id, { email: target.email }, clientMeta(req))
  return Response.json({ ok: true })
}
