import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { requirePermission } from '@/lib/permissions'
import { hashPassword } from '@/lib/password'
import { audit, clientMeta } from '@/lib/admin-api'
import { ROLE_PERMISSIONS } from '@/lib/permissions'
import { revalidateTag } from 'next/cache'
import { z } from 'zod'

export const dynamic = 'force-dynamic'

/** GET /api/admin/admin-users — list all admins (requires admin_users:view) */
export async function GET() {
  const admin = await requirePermission('admin_users', 'view')
  if (admin instanceof Response) return admin

  const users = await db.adminUser.findMany({
    orderBy: { createdAt: 'desc' },
    include: { role: { select: { id: true, slug: true, name: true } } },
  })

  return Response.json({
    ok: true,
    users: users.map((u) => ({
      id: u.id,
      email: u.email,
      fullName: u.fullName,
      roleId: u.roleId,
      role: u.role,
      status: u.status,
      lastLoginAt: u.lastLoginAt,
      lastLoginIp: u.lastLoginIp,
      createdAt: u.createdAt,
    })),
    roles: await db.role.findMany({ orderBy: { name: 'asc' }, select: { id: true, slug: true, name: true, description: true } }),
  })
}

const createSchema = z.object({
  email: z.string().email(),
  fullName: z.string().min(2).max(120),
  password: z.string().min(8, 'كلمة المرور 8 أحرف على الأقل'),
  roleId: z.string().min(1),
  status: z.enum(['ACTIVE', 'DISABLED', 'LOCKED']).default('ACTIVE'),
})

/** POST /api/admin/admin-users — create a new admin (requires admin_users:create) */
export async function POST(req: NextRequest) {
  const admin = await requirePermission('admin_users', 'create')
  if (admin instanceof Response) return admin

  // Prevent non-super-admins from creating super-admins
  const body = await req.json().catch(() => ({}))
  const parsed = createSchema.safeParse(body)
  if (!parsed.success) {
    const fe: Record<string, string> = {}
    for (const e of parsed.error.issues) fe[e.path.join('.')] = e.message
    return Response.json({ ok: false, error: 'بيانات غير صالحة', fieldErrors: fe }, { status: 422 })
  }
  const d = parsed.data

  // Check target role — non-super-admins cannot assign super-admin role
  const targetRole = await db.role.findUnique({ where: { id: d.roleId } })
  if (!targetRole) return Response.json({ ok: false, error: 'الدور غير موجود' }, { status: 404 })
  if (targetRole.slug === 'super-admin' && admin.role.slug !== 'super-admin') {
    return Response.json({ ok: false, error: 'ممنوع إنشاء مسؤول مطلق إلا من طرف مسؤول مطلق آخر' }, { status: 403 })
  }

  // Email uniqueness
  if (await db.adminUser.findUnique({ where: { email: d.email.toLowerCase() } })) {
    return Response.json({ ok: false, error: 'البريد مستعمل من قبل', fieldErrors: { email: 'مستعمل' } }, { status: 409 })
  }

  const passwordHash = await hashPassword(d.password)
  const user = await db.adminUser.create({
    data: {
      email: d.email.toLowerCase(),
      fullName: d.fullName,
      passwordHash,
      roleId: d.roleId,
      status: d.status,
    },
    include: { role: true },
  })

  await audit(admin.id, 'admin_user.create', 'admin_user', user.id, { email: user.email, roleId: d.roleId }, clientMeta(req))
  return Response.json({
    ok: true,
    user: { id: user.id, email: user.email, fullName: user.fullName, role: user.role, status: user.status },
  }, { status: 201 })
}
