import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { requireAdmin, jsonError, audit, clientMeta } from '@/lib/admin-api'
import { revalidateTag } from 'next/cache'
import { updateProductRating } from '@/app/api/reviews/route'

export const dynamic = 'force-dynamic'

/**
 * GET /api/admin/reviews
 * List all reviews for moderation. Supports filtering by status and product.
 *
 * Query params:
 *   - status: PENDING | APPROVED | REJECTED | HIDDEN (optional)
 *   - productId: filter by product (optional)
 *   - q: search by customer name or body (optional)
 *   - page, pageSize: pagination (default 20, max 50)
 */
export async function GET(req: NextRequest) {
  const admin = await requireAdmin()
  if (!admin) return jsonError('غير مصرّح', 401)

  const { searchParams } = req.nextUrl
  const status = searchParams.get('status')
  const productId = searchParams.get('productId')
  const q = searchParams.get('q')
  const page = Math.max(1, Number(searchParams.get('page')) || 1)
  const pageSize = Math.min(50, Number(searchParams.get('pageSize')) || 20)

  const validStatuses = ['PENDING', 'APPROVED', 'REJECTED', 'HIDDEN']
  const where: Record<string, unknown> = {}
  if (status && validStatuses.includes(status)) where.status = status
  if (productId) where.productId = productId
  if (q) {
    where.OR = [
      { customerName: { contains: q, mode: 'insensitive' } },
      { body: { contains: q, mode: 'insensitive' } },
      { title: { contains: q, mode: 'insensitive' } },
    ]
  }

  const [items, total] = await Promise.all([
    db.review.findMany({
      where,
      orderBy: { createdAt: 'desc' },
      take: pageSize,
      skip: (page - 1) * pageSize,
      include: {
        product: { select: { id: true, name: true, slug: true } },
      },
    }),
    db.review.count({ where }),
  ])

  return Response.json({
    ok: true,
    items: items.map((r) => ({
      id: r.id,
      productId: r.productId,
      productName: r.product.name,
      productSlug: r.product.slug,
      customerId: r.customerId,
      customerName: r.customerName,
      rating: r.rating,
      title: r.title,
      body: r.body,
      status: r.status,
      isVerified: r.isVerified,
      orderId: r.orderId,
      adminReply: r.adminReply,
      createdAt: r.createdAt,
      updatedAt: r.updatedAt,
    })),
    total,
    page,
    pageSize,
  })
}
