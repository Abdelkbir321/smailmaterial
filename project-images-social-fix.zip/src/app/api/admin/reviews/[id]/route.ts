import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { requireAdmin, jsonError, audit, clientMeta } from '@/lib/admin-api'
import { requirePermission } from '@/lib/permissions'
import { revalidateTag } from 'next/cache'
import { updateProductRating } from '@/app/api/reviews/route'
import { z } from 'zod'

export const dynamic = 'force-dynamic'

const patchSchema = z.object({
  // Status change: PENDING → APPROVED/REJECTED/HIDDEN
  status: z.enum(['PENDING', 'APPROVED', 'REJECTED', 'HIDDEN']).optional(),
  // Admin reply (shown publicly under the review)
  adminReply: z.string().max(1000).optional().nullable(),
  // Toggle the Verified Purchase badge (admin override)
  isVerified: z.boolean().optional(),
})

/**
 * PATCH /api/admin/reviews/[id]
 * Update a review's status, admin reply, or verified flag.
 *
 * When the status changes TO or FROM APPROVED, we recompute the product's
 * aggregate rating + review count so the storefront stays in sync.
 */
export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const admin = await requireAdmin()
  if (!admin) return jsonError('غير مصرّح', 401)
  const check = await requirePermission('products', 'edit')
  if (check instanceof Response) return check

  const { id } = await params
  const existing = await db.review.findUnique({ where: { id } })
  if (!existing) return jsonError('التقييم غير موجود.', 404)

  let body: z.infer<typeof patchSchema>
  try {
    body = patchSchema.parse(await req.json())
  } catch (e) {
    return jsonError('بيانات غير صالحة.', 400, { error: e instanceof Error ? e.message : 'parse error' })
  }

  const data: Record<string, unknown> = {}
  if (body.status !== undefined) data.status = body.status
  if (body.adminReply !== undefined) data.adminReply = body.adminReply || null
  if (body.isVerified !== undefined) data.isVerified = body.isVerified

  const updated = await db.review.update({ where: { id }, data })

  // If the status changed in a way that affects the aggregate, recompute
  const statusChanged = body.status !== undefined && body.status !== existing.status
  const becameApproved = body.status === 'APPROVED'
  const leftApproved = existing.status === 'APPROVED' && body.status !== undefined && body.status !== 'APPROVED'
  if (statusChanged && (becameApproved || leftApproved)) {
    await updateProductRating(existing.productId)
  }

  revalidateTag('catalog')
  await audit(admin.id, 'review.update', 'review', id, {
    changed: Object.keys(body),
    fromStatus: existing.status,
    toStatus: body.status,
  }, clientMeta(req))

  return Response.json({ ok: true, review: updated })
}

/**
 * DELETE /api/admin/reviews/[id]
 * Permanently delete a review. Use with caution — the preferred flow is
 * to set status=HIDDEN (soft-hide) so the data is preserved for audit.
 *
 * This endpoint exists for cases like spam, abuse, or GDPR erasure requests.
 * It DOES update the product's aggregate rating (since an APPROVED review
 * is being removed).
 */
export async function DELETE(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const admin = await requireAdmin()
  if (!admin) return jsonError('غير مصرّح', 401)
  const check = await requirePermission('products', 'delete')
  if (check instanceof Response) return check

  const { id } = await params
  const existing = await db.review.findUnique({ where: { id } })
  if (!existing) return jsonError('التقييم غير موجود.', 404)

  await db.review.delete({ where: { id } })

  // Recompute the product's aggregate (the deleted review may have been APPROVED)
  await updateProductRating(existing.productId)

  revalidateTag('catalog')
  await audit(admin.id, 'review.delete', 'review', id, {
    productId: existing.productId,
    wasApproved: existing.status === 'APPROVED',
  }, clientMeta(req))

  return Response.json({ ok: true })
}
