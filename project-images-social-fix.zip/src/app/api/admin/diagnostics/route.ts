import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { requireAdmin, jsonError } from '@/lib/admin-api'

export const dynamic = 'force-dynamic'

/**
 * GET /api/admin/diagnostics
 * ==========================
 *
 * Returns a comprehensive system health report for the admin dashboard.
 *
 * Sections:
 *   1. Product completeness — counts of products missing images, descriptions,
 *      categories, SEO fields, etc. + the actual list of incomplete products.
 *   2. Order stats — pending orders, confirmed today, cancelled this week.
 *   3. Review moderation queue — count of PENDING reviews.
 *   4. System health — DB connection, sitemap status, robots status,
 *      production domain configured?, Cloudinary configured?, etc.
 *   5. Recent errors — last 10 audit log entries with action containing
 *      "error" or "fail".
 *
 * This endpoint is read-only — it never modifies data. It's safe to call
 * frequently (e.g. every 30s from the admin dashboard).
 */
export async function GET(_req: NextRequest) {
  const admin = await requireAdmin()
  if (!admin) return jsonError('غير مصرّح', 401)

  // ─── 1. Product completeness ────────────────────────────────────────
  const allProducts = await db.product.findMany({
    select: {
      id: true,
      name: true,
      slug: true,
      sku: true,
      status: true,
      price: true,
      categoryId: true,
      shortDescription: true,
      description: true,
      seoTitle: true,
      seoDescription: true,
      brandId: true,
      _count: { select: { images: true } },
    },
  })

  const productIssues = {
    total: allProducts.length,
    published: allProducts.filter((p) => p.status === 'PUBLISHED').length,
    drafts: allProducts.filter((p) => p.status === 'DRAFT').length,
    noImages: 0,
    noDescription: 0,
    noCategory: 0,
    noSeoTitle: 0,
    noSeoDescription: 0,
    noBrand: 0,
    noPrice: 0,
  }
  const incompleteProducts: Array<{
    id: string
    name: string
    slug: string
    sku: string
    status: string
    issues: string[]
  }> = []

  for (const p of allProducts) {
    const issues: string[] = []
    if (p._count.images === 0) { issues.push('no_images'); productIssues.noImages++ }
    if (!p.shortDescription && !p.description) { issues.push('no_description'); productIssues.noDescription++ }
    if (!p.categoryId) { issues.push('no_category'); productIssues.noCategory++ }
    if (!p.seoTitle) { issues.push('no_seo_title'); productIssues.noSeoTitle++ }
    if (!p.seoDescription) { issues.push('no_seo_desc'); productIssues.noSeoDescription++ }
    if (!p.brandId) { issues.push('no_brand'); productIssues.noBrand++ }
    if (Number(p.price) <= 0) { issues.push('no_price'); productIssues.noPrice++ }
    if (issues.length > 0) {
      incompleteProducts.push({
        id: p.id,
        name: p.name,
        slug: p.slug,
        sku: p.sku,
        status: p.status,
        issues,
      })
    }
  }

  // ─── 2. Order stats ─────────────────────────────────────────────────
  const now = new Date()
  const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate())
  const weekAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000)

  const [pendingOrders, todayOrders, cancelledThisWeek, totalOrders] = await Promise.all([
    db.order.count({ where: { status: 'NEW' } }),
    db.order.count({ where: { placedAt: { gte: todayStart } } }),
    db.order.count({ where: { status: 'CANCELLED', placedAt: { gte: weekAgo } } }),
    db.order.count(),
  ])

  // ─── 3. Review moderation queue ─────────────────────────────────────
  const [pendingReviews, approvedReviews, totalReviews] = await Promise.all([
    db.review.count({ where: { status: 'PENDING' } }),
    db.review.count({ where: { status: 'APPROVED' } }),
    db.review.count(),
  ])

  // ─── 4. System health ───────────────────────────────────────────────
  const systemHealth = {
    database: true, // if we got here, the DB is reachable
    cloudinaryConfigured: !!(process.env.CLOUDINARY_CLOUD_NAME && process.env.CLOUDINARY_API_KEY && process.env.CLOUDINARY_API_SECRET),
    siteUrlConfigured: !!(process.env.NEXT_PUBLIC_SITE_URL),
    nodeEnv: process.env.NODE_ENV || 'development',
    timestamp: new Date().toISOString(),
  }

  // Check if the production domain is set in the DB (single source of truth)
  try {
    const siteUrlSetting = await db.siteSetting.findUnique({ where: { key: 'site_url' } })
    systemHealth.siteUrlConfigured = systemHealth.siteUrlConfigured || !!siteUrlSetting?.value
  } catch {
    // ignore — DB read failed (already caught by database: true)
  }

  // ─── 5. Recent audit logs (last 20, for the change log) ────────────
  const recentAuditLogs = await db.auditLog.findMany({
    take: 20,
    orderBy: { createdAt: 'desc' },
    select: {
      id: true,
      action: true,
      entity: true,
      entityId: true,
      createdAt: true,
      adminUser: { select: { fullName: true, email: true } },
    },
  })

  // ─── 6. Category & Brand counts ─────────────────────────────────────
  const [totalCategories, totalBrands] = await Promise.all([
    db.category.count(),
    db.brand.count(),
  ])

  return Response.json({
    ok: true,
    productIssues,
    incompleteProducts: incompleteProducts.slice(0, 50), // cap at 50 for UI
    orderStats: {
      total: totalOrders,
      pending: pendingOrders,
      today: todayOrders,
      cancelledThisWeek,
    },
    reviewStats: {
      total: totalReviews,
      pending: pendingReviews,
      approved: approvedReviews,
    },
    catalogStats: {
      totalCategories,
      totalBrands,
      totalProducts: allProducts.length,
    },
    systemHealth,
    recentAuditLogs: recentAuditLogs.map((log) => ({
      id: log.id,
      action: log.action,
      entity: log.entity,
      entityId: log.entityId,
      createdAt: log.createdAt,
      adminName: log.adminUser?.fullName || 'System',
      adminEmail: log.adminUser?.email || null,
    })),
  })
}
