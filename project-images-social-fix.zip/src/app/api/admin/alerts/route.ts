import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { requireAdmin, jsonError } from '@/lib/admin-api'

export const dynamic = 'force-dynamic'

/**
 * GET /api/admin/alerts
 *
 * Returns a unified list of actionable alerts from real system state:
 *   - Inventory: products with low stock or out of stock
 *   - Orders: orders pending for > 24h, or recently cancelled
 *   - Reviews: pending reviews awaiting moderation
 *   - Integrations: GA4/GSC/PageSpeed/Cloudinary not connected
 *   - SEO: products missing critical SEO fields
 *
 * Each alert has: severity (critical/warning/info), category, title,
 * description, actionUrl, actionLabel, createdAt.
 *
 * NO FAKE ALERTS — every alert is derived from real DB state or env vars.
 */
export async function GET(_req: NextRequest) {
  const admin = await requireAdmin()
  if (!admin) return jsonError('غير مصرّح', 401)

  const alerts: Array<{
    id: string
    severity: 'critical' | 'warning' | 'info'
    category: string
    title: string
    description: string
    actionUrl?: string
    actionLabel?: string
    createdAt: string
  }> = []

  // ─── 1. Inventory alerts ───────────────────────────────────────────
  const lowStockProducts = await db.product.findMany({
    where: {
      trackInventory: true,
      status: 'PUBLISHED',
      stockQuantity: { lte: 5 },
    },
    select: { id: true, name: true, slug: true, stockQuantity: true },
    take: 20,
  })
  for (const p of lowStockProducts) {
    const isOut = p.stockQuantity === 0
    alerts.push({
      id: `stock-${p.id}`,
      severity: isOut ? 'critical' : 'warning',
      category: 'inventory',
      title: isOut ? `نفد المخزون: ${p.name}` : `مخزون منخفض: ${p.name}`,
      description: isOut
        ? `المنتج "${p.name}" نفد من المخزون ولا يمكن طلبه.`
        : `باقي ${p.stockQuantity} وحدة فقط من "${p.name}".`,
      actionUrl: `/admin/products/${p.id}`,
      actionLabel: 'تعديل المنتج',
      createdAt: new Date().toISOString(),
    })
  }

  // ─── 2. Order alerts ───────────────────────────────────────────────
  const dayAgo = new Date(Date.now() - 24 * 60 * 60 * 1000)
  const staleOrders = await db.order.count({
    where: {
      status: 'NEW',
      placedAt: { lt: dayAgo },
    },
  })
  if (staleOrders > 0) {
    alerts.push({
      id: 'stale-orders',
      severity: 'warning',
      category: 'orders',
      title: `${staleOrders} طلب في انتظار التأكيد لأكثر من 24 ساعة`,
      description: 'طلبات بحالة NEW لم يتم تأكيدها منذ أكثر من يوم. تواصل مع الزبائن.',
      actionUrl: '/admin/orders?status=NEW',
      actionLabel: 'عرض الطلبات',
      createdAt: new Date().toISOString(),
    })
  }

  // ─── 3. Review moderation queue ────────────────────────────────────
  const pendingReviews = await db.review.count({ where: { status: 'PENDING' } })
  if (pendingReviews > 0) {
    alerts.push({
      id: 'pending-reviews',
      severity: 'info',
      category: 'reviews',
      title: `${pendingReviews} تقييم في انتظار المراجعة`,
      description: 'تقييمات جديدة بحاجة إلى موافقتك قبل نشرها.',
      actionUrl: '/admin/reviews?status=PENDING',
      actionLabel: 'مراجعة التقييمات',
      createdAt: new Date().toISOString(),
    })
  }

  // ─── 4. Integration alerts ─────────────────────────────────────────
  const ga4Configured = !!(process.env.GA4_MEASUREMENT_ID && process.env.GA4_MEASUREMENT_ID.startsWith('G-'))
  const gscConfigured = !!(process.env.GOOGLE_SERVICE_ACCOUNT_EMAIL && process.env.GOOGLE_SERVICE_ACCOUNT_PRIVATE_KEY && process.env.GSC_SITE_URL)
  const pagespeedConfigured = !!process.env.PAGESPEED_API_KEY
  const cloudinaryConfigured = !!(process.env.CLOUDINARY_CLOUD_NAME && process.env.CLOUDINARY_API_KEY && process.env.CLOUDINARY_API_SECRET)

  if (!ga4Configured) {
    alerts.push({
      id: 'ga4-not-configured',
      severity: 'info',
      category: 'integration',
      title: 'Google Analytics 4 غير مربوط',
      description: 'للحصول على تحليلات تفصيلية للزوار، اربط GA4. أضف GA4_MEASUREMENT_ID في env vars.',
      actionUrl: '/admin/seo-performance',
      actionLabel: 'تعرف على الخطوات',
      createdAt: new Date().toISOString(),
    })
  }
  if (!gscConfigured) {
    alerts.push({
      id: 'gsc-not-configured',
      severity: 'info',
      category: 'integration',
      title: 'Google Search Console غير مربوط',
      description: 'للاطلاع على أداء SEO الحقيقي (نقرات، ظهور، كلمات مفتاحية)، اربط GSC API.',
      actionUrl: '/admin/seo-performance',
      actionLabel: 'تعرف على الخطوات',
      createdAt: new Date().toISOString(),
    })
  }
  if (!pagespeedConfigured) {
    alerts.push({
      id: 'pagespeed-not-configured',
      severity: 'info',
      category: 'integration',
      title: 'PageSpeed Insights غير مربوط',
      description: 'لمراقبة سرعة الموقع و Core Web Vitals، أضف PAGESPEED_API_KEY.',
      actionUrl: '/admin/seo-performance',
      actionLabel: 'تعرف على الخطوات',
      createdAt: new Date().toISOString(),
    })
  }
  if (!cloudinaryConfigured) {
    alerts.push({
      id: 'cloudinary-not-configured',
      severity: 'warning',
      category: 'integration',
      title: 'Cloudinary غير مُكون',
      description: 'رفع الصور معطل. أضف CLOUDINARY_CLOUD_NAME, CLOUDINARY_API_KEY, CLOUDINARY_API_SECRET.',
      actionUrl: '/admin/diagnostics',
      actionLabel: 'تشخيص النظام',
      createdAt: new Date().toISOString(),
    })
  }

  // ─── 5. SEO completeness alerts ────────────────────────────────────
  const publishedProducts = await db.product.findMany({
    where: { status: 'PUBLISHED' },
    select: {
      id: true, name: true, slug: true,
      seoTitle: true, seoDescription: true,
      _count: { select: { images: true } },
    },
  })
  const noSeoTitle = publishedProducts.filter((p) => !p.seoTitle)
  const noSeoDesc = publishedProducts.filter((p) => !p.seoDescription)
  const noImages = publishedProducts.filter((p) => p._count.images === 0)

  if (noSeoTitle.length > 0) {
    alerts.push({
      id: 'seo-no-title',
      severity: 'warning',
      category: 'seo',
      title: `${noSeoTitle.length} منتج بدون عنوان SEO`,
      description: 'منتجات منشورة بدون SEO Title — قد لا تظهر بشكل جيد في نتائج البحث.',
      actionUrl: '/admin/diagnostics',
      actionLabel: 'عرض المنتجات',
      createdAt: new Date().toISOString(),
    })
  }
  if (noImages.length > 0) {
    alerts.push({
      id: 'seo-no-images',
      severity: 'warning',
      category: 'seo',
      title: `${noImages.length} منتج بدون صور`,
      description: 'منتجات منشورة بدون أي صورة — يؤثر على التجربة و SEO.',
      actionUrl: '/admin/diagnostics',
      actionLabel: 'عرض المنتجات',
      createdAt: new Date().toISOString(),
    })
  }

  // Sort by severity: critical first, then warning, then info
  const severityOrder = { critical: 0, warning: 1, info: 2 }
  alerts.sort((a, b) => severityOrder[a.severity] - severityOrder[b.severity])

  return Response.json({
    ok: true,
    alerts,
    summary: {
      total: alerts.length,
      critical: alerts.filter((a) => a.severity === 'critical').length,
      warning: alerts.filter((a) => a.severity === 'warning').length,
      info: alerts.filter((a) => a.severity === 'info').length,
    },
  })
}
