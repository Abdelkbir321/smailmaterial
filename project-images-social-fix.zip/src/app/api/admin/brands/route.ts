import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { requireAdmin, jsonError } from '@/lib/admin-api'
import { brandInputSchema } from '@/validations'
import { revalidateTag } from 'next/cache'

export const dynamic = 'force-dynamic'
export async function GET() {
  const admin = await requireAdmin()
  if (!admin) return jsonError('Unauthorized', 401)
  const brands = await db.brand.findMany({ orderBy: { sortOrder: 'asc' }, include: { _count: { select: { products: true } } } })
  return Response.json({ ok: true, brands })
}
export async function POST(req: NextRequest) {
  const admin = await requireAdmin()
  if (!admin) return jsonError('Unauthorized', 401)
  const parsed = brandInputSchema.safeParse(await req.json().catch(() => ({})))
  if (!parsed.success) return jsonError('Champs invalides', 422)
  const d = parsed.data
  if (await db.brand.findUnique({ where: { slug: d.slug } })) return jsonError('Slug déjà utilisé', 409)
  const brand = await db.brand.create({ data: d as any })
  revalidateTag('catalog')
  return Response.json({ ok: true, brand }, { status: 201 })
}
