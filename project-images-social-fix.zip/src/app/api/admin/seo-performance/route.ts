import { NextRequest } from 'next/server'
import { requireAdmin, jsonError } from '@/lib/admin-api'
import { querySearchAnalytics, listSitemaps, isGscConfigured } from '@/services/google-search-console'

export const dynamic = 'force-dynamic'

/**
 * GET /api/admin/seo-performance?period=28d
 *
 * Returns Google Search Console data (clicks, impressions, CTR, position,
 * top queries, top pages) + sitemap status.
 *
 * When GSC is not configured (no service account credentials), returns
 * `connected: false` with setup instructions — NEVER fake data.
 *
 * Period presets:
 *   - 7d, 28d, 3m (90 days), 6m (180 days), 1y (365 days)
 *   - GSC API allows max ~16 months of data, but we cap at 1y for sanity.
 */
export async function GET(req: NextRequest) {
  const admin = await requireAdmin()
  if (!admin) return jsonError('غير مصرّح', 401)

  const period = req.nextUrl.searchParams.get('period') || '28d'
  const now = new Date()
  const days = period === '7d' ? 7 : period === '3m' ? 90 : period === '6m' ? 180 : period === '1y' ? 365 : 28
  const startDate = new Date(now)
  startDate.setDate(startDate.getDate() - days)
  const startStr = startDate.toISOString().slice(0, 10)
  const endStr = now.toISOString().slice(0, 10)

  // Check if GSC is configured
  if (!isGscConfigured()) {
    return Response.json({
      ok: true,
      connected: false,
      setupSteps: [
        'أنشئ مشروعاً في Google Cloud Console',
        'فعّل Google Search Console API',
        'أنشئ Service Account وحمّل مفتاح JSON',
        'في Search Console، أضف إيميل الـ Service Account كمستخدم',
        'في Netlify Environment Variables، أضف:',
        '  - GOOGLE_SERVICE_ACCOUNT_EMAIL',
        '  - GOOGLE_SERVICE_ACCOUNT_PRIVATE_KEY',
        '  - GSC_SITE_URL (مثال: https://ismailmaterial.ma)',
        'أعد النشر — سترى البيانات الحقيقية هنا',
      ],
      data: null,
    })
  }

  // GSC is configured — fetch real data
  const [queries, pages, countries, devices, sitemaps] = await Promise.all([
    querySearchAnalytics('query', startStr, endStr),
    querySearchAnalytics('page', startStr, endStr),
    querySearchAnalytics('country', startStr, endStr),
    querySearchAnalytics('device', startStr, endStr),
    listSitemaps(),
  ])

  return Response.json({
    ok: true,
    connected: true,
    period: { start: startStr, end: endStr, days },
    data: {
      queries: queries.data ? {
        totals: {
          clicks: queries.data.clicks,
          impressions: queries.data.impressions,
          ctr: queries.data.ctr,
          position: queries.data.position,
        },
        top: queries.data.rows.slice(0, 20).map((r) => ({
          query: r.keys[0],
          clicks: r.clicks,
          impressions: r.impressions,
          ctr: Number((r.ctr * 100).toFixed(2)),
          position: Number(r.position.toFixed(1)),
        })),
      } : null,
      queriesError: queries.error,
      pages: pages.data ? {
        top: pages.data.rows.slice(0, 20).map((r) => ({
          url: r.keys[0],
          clicks: r.clicks,
          impressions: r.impressions,
          ctr: Number((r.ctr * 100).toFixed(2)),
          position: Number(r.position.toFixed(1)),
        })),
      } : null,
      pagesError: pages.error,
      countries: countries.data ? {
        top: countries.data.rows.slice(0, 15).map((r) => ({
          country: r.keys[0],
          clicks: r.clicks,
          impressions: r.impressions,
          ctr: Number((r.ctr * 100).toFixed(2)),
          position: Number(r.position.toFixed(1)),
        })),
      } : null,
      countriesError: countries.error,
      devices: devices.data ? {
        breakdown: devices.data.rows.map((r) => ({
          device: r.keys[0],
          clicks: r.clicks,
          impressions: r.impressions,
          ctr: Number((r.ctr * 100).toFixed(2)),
        })),
      } : null,
      devicesError: devices.error,
      sitemaps: sitemaps.data || [],
      sitemapsError: sitemaps.error,
    },
  })
}
