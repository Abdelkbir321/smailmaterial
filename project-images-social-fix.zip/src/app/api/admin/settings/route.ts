import { NextRequest } from 'next/server'
import { getAllSettings, setSettingsBulk, getFeatureFlags } from '@/services/settings'
import { requireAdmin, jsonError, audit, clientMeta } from '@/lib/admin-api'
import { requirePermission } from '@/lib/permissions'
import { revalidateTag } from 'next/cache'
import { z } from 'zod'

export const dynamic = 'force-dynamic'

/**
 * Settings API
 * ------------
 *
 * Permission model:
 *  - GET: any authenticated admin (all settings are visible)
 *  - PUT general keys (site_name, support_phone, ...):
 *      `store_settings.manage_settings`
 *  - SEO keys (seo_title, seo_description, og_default_image, site_url):
 *      `seo.manage_settings`
 *  - `site_url` (the canonical domain) is RESTRICTED to super-admin only.
 *
 * `site_url` is the most security-sensitive value here — it's used to build
 * every absolute URL (sitemap, OG tags, canonical). A malicious change here
 * could redirect Google to a different site. We require super-admin.
 */

const SEO_KEYS = new Set([
  'seo_title',
  'seo_description',
  'seo_keywords',
  'og_default_image',
  'og_default_title',
  'robots_extra_disallow',
  'hreflang_enabled',
])

/**
 * Restricted keys — super-admin only.
 *
 * - `site_url` — production domain (single source of truth for all absolute URLs)
 * - `gsc_verification_token` — Google Search Console meta tag verification
 * - `gsc_verification_file_content` — Google Search Console HTML file verification
 *
 * These affect SEO / search engine verification, so a compromised content-seo-manager
 * account must NOT be able to spoof them.
 */
const RESTRICTED_KEYS = new Set([
  'site_url',
  'gsc_verification_token',
  'gsc_verification_file_content',
])

export async function GET() {
  const admin = await requireAdmin()
  if (!admin) return jsonError('Unauthorized', 401)
  const [settings, flags] = await Promise.all([getAllSettings(), getFeatureFlags()])
  // Mask sensitive keys (currently none in settings — but defensive)
  return Response.json({ ok: true, settings, featureFlags: flags })
}

const putSchema = z.object({
  settings: z.record(z.string(), z.string()).optional(),
  featureFlags: z.record(z.string(), z.boolean()).optional(),
})

export async function PUT(req: NextRequest) {
  const admin = await requireAdmin()
  if (!admin) return jsonError('Unauthorized', 401)
  let body: z.infer<typeof putSchema>
  try {
    body = putSchema.parse(await req.json())
  } catch {
    return jsonError('Requête invalide.')
  }

  const changedKeys: string[] = []
  if (body.settings) {
    // Bucket the keys by required permission
    const general: Array<{ key: string; value: string }> = []
    const seo: Array<{ key: string; value: string }> = []
    const restricted: Array<{ key: string; value: string }> = []

    for (const [key, value] of Object.entries(body.settings)) {
      if (RESTRICTED_KEYS.has(key)) {
        restricted.push({ key, value: String(value) })
      } else if (SEO_KEYS.has(key)) {
        seo.push({ key, value: String(value) })
      } else {
        general.push({ key, value: String(value) })
      }
    }

    // Validate restricted keys
    for (const r of restricted) {
      if (r.key === 'site_url') {
        const v = r.value.trim().replace(/\/+$/, '')
        // Must be https://domain.tld — no paths, queries, fragments, credentials
        // Allow http:// only on localhost (dev)
        let parsed: URL
        try {
          parsed = new URL(v)
        } catch {
          return jsonError('رابط الموقع غير صالح. مثال: https://example.com', 422, { site_url: 'invalid' })
        }
        const isLocalhost = parsed.hostname === 'localhost' || parsed.hostname === '127.0.0.1'
        if (parsed.protocol !== 'https:' && !(parsed.protocol === 'http:' && isLocalhost)) {
          return jsonError('الدومين خاصو يبدأ بـ https:// (http:// مسموح فقط لـ localhost).', 422, { site_url: 'invalid' })
        }
        if (parsed.pathname !== '/' && parsed.pathname !== '') {
          return jsonError('الدومين ما يجبش يحتوي على مسار (path).', 422, { site_url: 'invalid' })
        }
        if (parsed.search || parsed.hash) {
          return jsonError('الدومين ما يجبش يحتوي على query أو fragment.', 422, { site_url: 'invalid' })
        }
        if (parsed.username || parsed.password) {
          return jsonError('الدومين ما يجبش يحتوي على credentials.', 422, { site_url: 'invalid' })
        }
        r.value = v
      }
      if (r.key === 'gsc_verification_token') {
        // Validate format: google-site-verification=googleXXXXXXXX.html
        const v = r.value.trim()
        if (v && !/^google-site-verification=\s*google[a-z0-9_-]+\.html$/i.test(v)) {
          return jsonError('صيغة Meta Tag غير صالحة. مثال: google-site-verification=google1234567890abcdef.html', 422, { gsc_verification_token: 'invalid' })
        }
        r.value = v
      }
      if (r.key === 'gsc_verification_file_content') {
        // Validate format: google-site-verification: googleXXXXXXXX.html
        const v = r.value.trim()
        if (v && !/^google-site-verification:\s*google[a-z0-9]+\.html$/i.test(v)) {
          return jsonError('صيغة محتوى الملف غير صالحة. مثال: google-site-verification: google1234567890abcdef.html', 422, { gsc_verification_file_content: 'invalid' })
        }
        r.value = v
      }
    }

    // Apply restricted (site_url, GSC verification) — super-admin only
    if (restricted.length > 0) {
      if (admin.role.slug !== 'super-admin') {
        return jsonError('تغيير الدومين الرسمي وإعدادات Google Search Console ممنوع إلا على Super-Admin', 403, { restricted: 'forbidden' })
      }
      await setSettingsBulk(restricted)
      changedKeys.push(...restricted.map((r) => r.key))
    }

    // Apply SEO keys — requires seo.manage_settings
    if (seo.length > 0) {
      const check = await requirePermission('seo', 'manage_settings')
      if (check instanceof Response) return check
      await setSettingsBulk(seo)
      changedKeys.push(...seo.map((s) => s.key))
    }

    // Apply general keys — requires store_settings.manage_settings
    if (general.length > 0) {
      const check = await requirePermission('store_settings', 'manage_settings')
      if (check instanceof Response) return check
      await setSettingsBulk(general)
      changedKeys.push(...general.map((g) => g.key))
    }
  }

  if (body.featureFlags) {
    const { db } = await import('@/lib/db')
    await Promise.all(
      Object.entries(body.featureFlags).map(([key, isEnabled]) =>
        db.featureFlag.upsert({
          where: { key },
          create: { key, label: key, isEnabled },
          update: { isEnabled },
        }),
      ),
    )
    changedKeys.push('feature_flags')
  }

  revalidateTag('settings')
  revalidateTag('sitemap') // site_url affects sitemap; SEO keys affect OG
  await audit(admin.id, 'settings.update', 'site_setting', null, { keys: changedKeys }, clientMeta(req))
  return Response.json({ ok: true, changed: changedKeys })
}
