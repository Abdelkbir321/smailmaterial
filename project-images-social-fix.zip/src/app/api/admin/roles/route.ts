import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { requirePermission, PERMISSION_SECTIONS, ROLE_PERMISSIONS } from '@/lib/permissions'

export const dynamic = 'force-dynamic'

/** GET /api/admin/roles — list roles + the full permission section catalog */
export async function GET() {
  const admin = await requirePermission('permissions', 'view')
  if (admin instanceof Response) return admin
  const roles = await db.role.findMany({ orderBy: { name: 'asc' } })
  return Response.json({
    ok: true,
    roles: roles.map((r) => ({ id: r.id, slug: r.slug, name: r.name, description: r.description, permissions: r.permissions })),
    sections: PERMISSION_SECTIONS.map((s) => ({ key: s.key, label: s.label, labelAr: s.labelAr, actions: s.actions })),
    roleTemplates: ROLE_PERMISSIONS,
  })
}
