import { NextRequest } from 'next/server'
import { requirePermission } from '@/lib/permissions'
import { jsonError } from '@/lib/admin-api'
import { revalidateTag } from 'next/cache'

export const dynamic = 'force-dynamic'

/**
 * POST /api/admin/seo/revalidate
 *
 * Force-refresh the sitemap + robots + catalog caches. Useful right after
 * publishing, deleting, or un-publishing products/categories/brands, so
 * the sitemap reflects the change immediately instead of waiting up to 1h.
 *
 * Body: { tags?: string[] } — defaults to ['sitemap', 'catalog', 'redirects'].
 */
export async function POST(req: NextRequest) {
  const admin = await requirePermission('seo', 'manage_settings')
  if (admin instanceof Response) return admin

  let tags: string[] = ['sitemap', 'catalog', 'redirects', 'settings']
  try {
    const body = await req.json()
    if (Array.isArray(body?.tags)) {
      const allowed = new Set(['sitemap', 'catalog', 'redirects', 'settings', 'categories-list', 'brands-list', 'countries-list'])
      tags = body.tags.filter((t: string) => allowed.has(t))
      if (tags.length === 0) tags = ['sitemap', 'catalog', 'redirects', 'settings']
    }
  } catch {
    // ignore — use defaults
  }

  for (const t of tags) {
    try {
      revalidateTag(t)
    } catch {
      // ignore individual failures
    }
  }

  return Response.json({ ok: true, revalidated: tags })
}
