import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { requirePermission } from '@/lib/permissions'
import { jsonError } from '@/lib/admin-api'

export const dynamic = 'force-dynamic'

/**
 * GET /api/admin/seo/slug-check?slug=...&type=product|category|brand|page&excludeId=...
 *
 * Detects slug collisions across ALL content types so the admin UI can warn
 * BEFORE saving. A slug must be unique across the site (URLs are flat at the
 * path level), so we check every type.
 *
 * Returns:
 *   { ok: true, slug, conflicts: [{ type, id, name, url }] }
 *   `conflicts` is empty when the slug is free.
 */
export async function GET(req: NextRequest) {
  const admin = await requirePermission('seo', 'view')
  if (admin instanceof Response) return admin

  const slug = (req.nextUrl.searchParams.get('slug') || '').trim().toLowerCase()
  if (!slug) return jsonError('slug مطلوب', 422)
  if (!/^[a-z0-9-]+$/.test(slug)) return jsonError('slug غير صالح (a-z, 0-9, -)', 422)
  const excludeId = req.nextUrl.searchParams.get('excludeId') || undefined

  const conflicts: Array<{ type: string; id: string; name: string; url: string }> = []

  // Products
  const product = await db.product.findUnique({
    where: { slug },
    select: { id: true, name: true },
  })
  if (product && product.id !== excludeId) {
    conflicts.push({ type: 'product', id: product.id, name: product.name, url: `/produits/${slug}` })
  }

  // Categories
  const category = await db.category.findUnique({
    where: { slug },
    select: { id: true, name: true },
  })
  if (category && category.id !== excludeId) {
    conflicts.push({ type: 'category', id: category.id, name: category.name, url: `/categories/${slug}` })
  }

  // Brands
  const brand = await db.brand.findUnique({
    where: { slug },
    select: { id: true, name: true },
  })
  if (brand && brand.id !== excludeId) {
    conflicts.push({ type: 'brand', id: brand.id, name: brand.name, url: `/brands/${slug}` })
  }

  // Pages
  const page = await db.page.findUnique({
    where: { slug },
    select: { id: true, title: true },
  })
  if (page && page.id !== excludeId) {
    conflicts.push({ type: 'page', id: page.id, name: page.title, url: `/page/${slug}` })
  }

  // Redirect fromPath collision — a slug that's also the source of a redirect
  // would conflict with the redirect engine.
  const redirect = await db.redirect.findUnique({
    where: { fromPath: slug },
    select: { id: true, toPath: true, statusCode: true },
  })
  if (redirect) {
    conflicts.push({
      type: 'redirect',
      id: redirect.id,
      name: `→ ${redirect.toPath} (${redirect.statusCode})`,
      url: slug,
    })
  }

  return Response.json({ ok: true, slug, conflicts })
}
