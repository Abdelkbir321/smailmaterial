import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { requireAdmin, jsonError, audit, clientMeta } from '@/lib/admin-api'
import { requirePermission } from '@/lib/permissions'
import { updateOrderStatus } from '@/services/orders'
import { revalidateTag } from 'next/cache'
import { z } from 'zod'

export const dynamic = 'force-dynamic'

const VALID_STATUSES = ['NEW', 'CONTACTED', 'CONFIRMED', 'PROCESSING', 'SHIPPED', 'DELIVERED', 'CANCELLED', 'RETURNED', 'UNREACHABLE']

const bulkSchema = z.object({
  ids: z.array(z.string()).min(1).max(500),
  action: z.enum(['delete', 'status']),
  // For status change:
  status: z.string().optional(),
  note: z.string().optional(),
})

// POST — bulk operations on orders
export async function POST(req: NextRequest) {
  const admin = await requireAdmin()
  if (!admin) return jsonError('Unauthorized', 401)

  let body: z.infer<typeof bulkSchema>
  try {
    body = bulkSchema.parse(await req.json())
  } catch (e) {
    return jsonError('بيانات غير صالحة', 400, { error: e instanceof Error ? e.message : 'parse error' })
  }

  const { ids, action } = body

  if (action === 'delete') {
    const check = await requirePermission('orders', 'delete')
    if (check instanceof Response) return check

    // Use transaction to delete orders + their items + status history
    // (OrderItem and OrderStatusHistory have onDelete: Cascade, so they're auto-deleted)
    try {
      const result = await db.order.deleteMany({
        where: { id: { in: ids } },
      })
      revalidateTag('catalog')
      await audit(admin.id, 'order.bulk_delete', 'order', null, { ids, count: result.count }, clientMeta(req))
      return Response.json({ ok: true, deleted: result.count })
    } catch (e) {
      const msg = e instanceof Error ? e.message : 'فشل الحذف الجماعي'
      return jsonError(msg, 422)
    }
  }

  if (action === 'status') {
    const check = await requirePermission('orders', 'edit')
    if (check instanceof Response) return check

    if (!body.status || !VALID_STATUSES.includes(body.status)) {
      return jsonError('حالة غير صالحة', 400)
    }

    // Update each order's status (uses the service to write status history)
    let updated = 0
    const errors: string[] = []
    for (const id of ids) {
      try {
        await updateOrderStatus(id, body.status as any, admin.id, body.note)
        updated++
      } catch (e) {
        errors.push(`${id}: ${e instanceof Error ? e.message : 'فشل'}`)
      }
    }

    revalidateTag('catalog')
    await audit(admin.id, 'order.bulk_status', 'order', null, { ids, count: updated, status: body.status }, clientMeta(req))
    return Response.json({ ok: true, updated, errors: errors.length > 0 ? errors : undefined })
  }

  return jsonError('إجراء غير معروف', 400)
}
