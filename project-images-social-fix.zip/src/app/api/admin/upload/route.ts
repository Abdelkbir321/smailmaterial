import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { requireAdmin, jsonError, audit, clientMeta } from '@/lib/admin-api'
import { revalidateTag } from 'next/cache'
import {
  uploadBuffer,
  validateImageFile,
  verifyImageMagicBytes,
  validateExternalImageUrl,
  isCloudinaryConfigured,
} from '@/lib/cloudinary'

export const dynamic = 'force-dynamic'

/**
 * POST /api/admin/upload
 * ======================
 *
 * Universal image upload endpoint used by:
 *   - ProductForm (product images)
 *   - MediaManager (media library)
 *   - tab-logo page (favicon)
 *   - hero-image page (homepage hero)
 *   - visual-identity page (logo, OG image)
 *   - site-identity page (site logo)
 *   - media page (bulk media library uploads)
 *
 * Accepts TWO content types:
 *   1. multipart/form-data with a `file` field (binary upload)
 *   2. application/json with an `externalUrl` field (hot-link an external image)
 *
 * Both modes optionally take:
 *   - `productId` — if set, the uploaded image is attached to the product
 *     as a ProductImage row (with `isMain` flag when there are no other
 *     images yet for this product).
 *   - `altText` — accessibility text for the image.
 *   - `isMain` — force this image to be the main one (overrides the
 *     "first image is main" default).
 *
 * Returns `{ ok: true, image, asset }` where:
 *   - `image` is the ProductImage row (when productId was provided) or null
 *   - `asset` is the MediaAsset row (always created, for the media library)
 *
 * ==========================================================================
 * SECURITY
 * --------------------------------------------------------------------------
 * - Requires admin auth (requireAdmin).
 * - Validates the file MIME type AND verifies magic bytes (does not trust
 *   the browser-supplied Content-Type).
 * - Caps file size at 25 MB (Cloudinary handles larger, but we stay sane).
 * - For external URLs: SSRF protection (blocks localhost, private IPs,
 *   cloud metadata endpoints).
 * - When Cloudinary is NOT configured (dev/preview), we fall back to a
 *   placeholder row so the admin UI stays functional. The image URL will
 *   point to a static placeholder SVG in /public.
 * ==========================================================================
 */

const PLACEHOLDER_URL = '/products/placeholder.svg'
const PLACEHOLDER_PUBLIC_ID = null

export async function POST(req: NextRequest) {
  const admin = await requireAdmin()
  if (!admin) return jsonError('غير مصرّح', 401)

  const contentType = (req.headers.get('content-type') || '').toLowerCase()
  const isFormData = contentType.startsWith('multipart/form-data')
  const isJson = contentType.includes('application/json')

  if (!isFormData && !isJson) {
    return jsonError('نوع المحتوى غير مدعوم. استعمل multipart/form-data أو application/json.', 415)
  }

  // ─── Parse the request ──────────────────────────────────────────────
  let fileBuffer: Buffer | null = null
  let fileMeta: { name?: string; type: string; size: number } | null = null
  let externalUrl: string | null = null
  let productId: string | undefined
  let altText: string | undefined
  let isMain: boolean | undefined

  if (isFormData) {
    try {
      const formData = await req.formData()
      const file = formData.get('file')
      productId = (formData.get('productId') as string) || undefined
      altText = (formData.get('altText') as string) || undefined
      const isMainRaw = formData.get('isMain')
      isMain = isMainRaw === 'true' || isMainRaw === '1'
      if (file && file instanceof File) {
        fileMeta = { name: file.name, type: file.type, size: file.size }
        const arrayBuffer = await file.arrayBuffer()
        fileBuffer = Buffer.from(arrayBuffer)
      }
    } catch {
      return jsonError('فشل قراءة الطلب (FormData غير صالح).', 400)
    }
  } else {
    // JSON mode — external URL hot-linking
    try {
      const body = await req.json()
      externalUrl = (body.externalUrl as string) || null
      productId = body.productId as string | undefined
      altText = body.altText as string | undefined
      isMain = body.isMain === true
    } catch {
      return jsonError('JSON غير صالح.', 400)
    }
  }

  // ─── Branch 1: external URL ────────────────────────────────────────
  if (externalUrl) {
    return handleExternalUpload(req, admin, externalUrl, {
      productId,
      altText,
      isMain,
    })
  }

  // ─── Branch 2: binary file upload ──────────────────────────────────
  if (!fileBuffer || !fileMeta) {
    return jsonError('لم يتم استلام أي ملف.', 400)
  }

  // Validate the file
  const fileCheck = validateImageFile(fileMeta)
  if (!fileCheck.ok) {
    return jsonError(fileCheck.error || 'ملف غير صالح.', 422)
  }

  // Verify magic bytes — DO NOT trust the browser-supplied MIME type
  const magic = verifyImageMagicBytes(fileBuffer)
  if (!magic.ok) {
    return jsonError('الملف ليس صورة صالحة (فشل التحقق من التوقيع).', 422)
  }

  // Upload to Cloudinary (or fall back to placeholder)
  // CRITICAL: When Cloudinary is NOT configured, we fall back to a static
  // placeholder SVG so the admin UI stays functional. But we MUST tell the
  // client that this is a placeholder, not a real upload — otherwise the
  // admin sees a "success" toast but the image they see is a generic icon,
  // not their uploaded file. This was the root cause of the "image shows as
  // text/link instead of the actual image" complaint.
  const folder = `ismail-material/products/${productId || 'unassigned'}`
  const cloudinaryConfigured = isCloudinaryConfigured()
  const uploaded = cloudinaryConfigured
    ? await uploadBuffer(fileBuffer, folder)
    : null

  // If Cloudinary IS configured but the upload failed (network error, bad
  // credentials, etc.), return an EXPLICIT error — do NOT fall back to
  // placeholder silently. The admin needs to know the upload failed.
  if (cloudinaryConfigured && !uploaded) {
    return jsonError('فشل رفع الصورة إلى Cloudinary. تحقق من المفاتيح في إعدادات Netlify.', 502)
  }

  // If Cloudinary is NOT configured at all, return a clear error — NOT a
  // silent placeholder. The admin must configure Cloudinary before uploading.
  // The placeholder SVG is only used for DISPLAY fallback in the storefront
  // (when a product has no image), NOT as a fake upload result.
  if (!cloudinaryConfigured) {
    return jsonError(
      'Cloudinary غير مُهيّأ. يجب إضافة CLOUDINARY_CLOUD_NAME, CLOUDINARY_API_KEY, CLOUDINARY_API_SECRET في متغيرات البيئة قبل رفع الصور.',
      503,
    )
  }

  // At this point, `uploaded` is guaranteed to be non-null (we returned early
  // above if it was null).
  const secureUrl = uploaded!.secureUrl
  const publicId = uploaded!.publicId
  const sourceType = 'cloudinary'

  // Create a MediaAsset row (for the media library)
  const asset = await db.mediaAsset.create({
    data: {
      sourceType,
      publicId,
      externalUrl: uploaded ? null : secureUrl,
      secureUrl,
      url: secureUrl,
      width: uploaded?.width || null,
      height: uploaded?.height || null,
      format: uploaded?.format || fileMeta.type.split('/')[1] || null,
      bytes: uploaded?.bytes || fileMeta.size,
      resourceType: 'image',
      altText: altText || null,
      uploadedByAdminId: admin.id,
    },
  })

  // Optionally attach to a product
  let image: { id: string } | null = null
  if (productId) {
    const product = await db.product.findUnique({ where: { id: productId } })
    if (!product) {
      // Don't fail — the asset is already saved. Just skip the product attachment.
      // The admin will see the asset in the media library.
    } else {
      const existingCount = await db.productImage.count({ where: { productId } })
      const shouldBeMain = isMain !== undefined ? isMain : existingCount === 0
      // If this image is main, unmain the others
      if (shouldBeMain) {
        await db.productImage.updateMany({
          where: { productId, isMain: true },
          data: { isMain: false },
        })
      }
      image = await db.productImage.create({
        data: {
          productId,
          sourceType,
          publicId,
          externalUrl: uploaded ? null : secureUrl,
          secureUrl,
          url: secureUrl,
          width: uploaded?.width || null,
          height: uploaded?.height || null,
          format: uploaded?.format || fileMeta.type.split('/')[1] || null,
          altText: altText || null,
          sortOrder: existingCount,
          isMain: shouldBeMain,
        },
      })
      revalidateTag('catalog')
    }
  }

  await audit(admin.id, 'media.upload', 'media_asset', asset.id, {
    sourceType,
    hasProduct: !!productId,
    publicId: publicId || undefined,
  }, clientMeta(req))

  return Response.json({ ok: true, image, asset }, { status: 201 })
}

/**
 * Handle external URL hot-linking.
 * Validates the URL (SSRF protection), optionally HEAD-checks it, and
 * creates a MediaAsset + (optional) ProductImage row with sourceType='external'.
 */
async function handleExternalUpload(
  req: NextRequest,
  admin: { id: string },
  url: string,
  opts: { productId?: string; altText?: string; isMain?: boolean },
) {
  const trimmed = url.trim()
  if (!trimmed) return jsonError('الرابط فارغ.', 422)
  if (!/^https?:\/\//i.test(trimmed)) {
    return jsonError('الرابط غير صالح (يجب أن يبدأ بـ http(s)://).', 422)
  }

  const validation = await validateExternalImageUrl(trimmed, { timeoutMs: 4000 })
  if (!validation.ok) {
    return jsonError(validation.error || 'الرابط غير صالح.', 422)
  }

  const sourceType = 'external'
  const secureUrl = trimmed

  // Create a MediaAsset row
  const asset = await db.mediaAsset.create({
    data: {
      sourceType,
      publicId: null,
      externalUrl: secureUrl,
      secureUrl,
      url: secureUrl,
      width: null,
      height: null,
      format: validation.contentType?.split('/')[1] || null,
      bytes: validation.bytes || null,
      resourceType: 'image',
      altText: opts.altText || null,
      uploadedByAdminId: admin.id,
    },
  })

  // Optionally attach to a product
  let image: { id: string } | null = null
  if (opts.productId) {
    const product = await db.product.findUnique({ where: { id: opts.productId } })
    if (product) {
      const existingCount = await db.productImage.count({ where: { productId: opts.productId } })
      const shouldBeMain = opts.isMain !== undefined ? opts.isMain : existingCount === 0
      if (shouldBeMain) {
        await db.productImage.updateMany({
          where: { productId: opts.productId, isMain: true },
          data: { isMain: false },
        })
      }
      image = await db.productImage.create({
        data: {
          productId: opts.productId,
          sourceType,
          publicId: null,
          externalUrl: secureUrl,
          secureUrl,
          url: secureUrl,
          altText: opts.altText || null,
          sortOrder: existingCount,
          isMain: shouldBeMain,
        },
      })
      revalidateTag('catalog')
    }
  }

  await audit(admin.id, 'media.upload_external', 'media_asset', asset.id, {
    sourceType,
    hasProduct: !!opts.productId,
    verified: validation.verified,
  }, clientMeta(req))

  return Response.json({ ok: true, image, asset }, { status: 201 })
}
