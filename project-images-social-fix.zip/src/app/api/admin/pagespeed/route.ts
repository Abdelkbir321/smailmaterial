import { NextRequest } from 'next/server'
import { requireAdmin, jsonError } from '@/lib/admin-api'
import { fetchPageSpeed, isPageSpeedConfigured } from '@/services/pagespeed'
import { getProductionDomain } from '@/services/settings'

export const dynamic = 'force-dynamic'

/**
 * GET /api/admin/pagespeed?url=...&strategy=mobile
 *
 * Fetches PageSpeed Insights for a URL. When no URL is provided, defaults
 * to the homepage (using the production domain from DB settings).
 *
 * When PageSpeed API key is not configured, returns `connected: false`
 * with setup instructions — NEVER fake data.
 *
 * NOTE: This API can take 10-30 seconds to respond (PageSpeed runs a full
 * Lighthouse audit). The admin UI should show a loading spinner and not
 * call this endpoint on every page load — cache the result client-side.
 */
export async function GET(req: NextRequest) {
  const admin = await requireAdmin()
  if (!admin) return jsonError('غير مصرّح', 401)

  const url = req.nextUrl.searchParams.get('url')
  const strategy = (req.nextUrl.searchParams.get('strategy') || 'mobile') as 'mobile' | 'desktop'

  if (strategy !== 'mobile' && strategy !== 'desktop') {
    return jsonError('الاستراتيجية يجب أن تكون mobile أو desktop', 400)
  }

  if (!isPageSpeedConfigured()) {
    return Response.json({
      ok: true,
      connected: false,
      setupSteps: [
        'أنشئ مشروعاً في Google Cloud Console',
        'فعّل PageSpeed Insights API',
        'أنشئ API key وقيّدها بـ PageSpeed Insights API',
        'في Netlify Environment Variables، أضف:',
        '  - PAGESPEED_API_KEY',
        'أعد النشر — سترى نتائج حقيقية هنا',
      ],
      data: null,
    })
  }

  // Determine the URL to test
  let testUrl = url
  if (!testUrl) {
    const siteUrl = await getProductionDomain()
    if (!siteUrl) {
      return jsonError('النطاق الرسمي غير مُكون. اضبطه في إعدادات SEO.', 400)
    }
    testUrl = siteUrl
  }

  const result = await fetchPageSpeed(testUrl, strategy)
  if (!result.connected) {
    return Response.json({ ok: true, connected: false, data: null })
  }
  if (result.error) {
    return Response.json({ ok: true, connected: true, error: result.error, data: null })
  }

  return Response.json({ ok: true, connected: true, data: result.data })
}
