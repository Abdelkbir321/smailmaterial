import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { requireAdmin, jsonError, audit, clientMeta } from '@/lib/admin-api'
import { requirePermission } from '@/lib/permissions'
import { revalidateTag } from 'next/cache'
import { z } from 'zod'

export const dynamic = 'force-dynamic'

const bulkSchema = z.object({
  ids: z.array(z.string()).min(1).max(100),
  action: z.enum(['delete', 'show', 'hide']),
  // For delete with products:
  productAction: z.enum(['move', 'cancel']).default('cancel'),
  targetCategoryId: z.string().optional(),
})

// POST — bulk operations on categories
export async function POST(req: NextRequest) {
  const admin = await requireAdmin()
  if (!admin) return jsonError('Unauthorized', 401)

  let body: z.infer<typeof bulkSchema>
  try {
    body = bulkSchema.parse(await req.json())
  } catch (e) {
    return jsonError('بيانات غير صالحة', 400, { error: e instanceof Error ? e.message : 'parse error' })
  }

  const { ids, action } = body

  if (action === 'delete') {
    const check = await requirePermission('categories', 'delete')
    if (check instanceof Response) return check

    // Check if any category has products
    const categoriesWithProducts = await db.category.findMany({
      where: { id: { in: ids } },
      include: { _count: { select: { products: true } } },
    })

    const totalProducts = categoriesWithProducts.reduce((sum, c) => sum + c._count.products, 0)

    if (totalProducts > 0 && body.productAction === 'cancel') {
      return Response.json(
        {
          ok: false,
          error: `بعض الفئات تحتوي على ${totalProducts} منتج. اختر فئة للنقل أو ألغِ العملية.`,
          requiresAction: true,
          totalProducts,
          categories: categoriesWithProducts.map((c) => ({
            id: c.id,
            name: c.name,
            productCount: c._count.products,
          })),
        },
        { status: 409 },
      )
    }

    if (body.productAction === 'move' && !body.targetCategoryId) {
      return jsonError('حدد فئة الهدف لنقل المنتجات', 400)
    }

    if (body.productAction === 'move') {
      const target = await db.category.findUnique({ where: { id: body.targetCategoryId! } })
      if (!target) return jsonError('الفئة الهدف غير موجودة', 404)
      if (ids.includes(body.targetCategoryId!)) {
        return jsonError('لا يمكن نقل المنتجات إلى فئة سيتم حذفها', 422)
      }
    }

    try {
      await db.$transaction(async (tx) => {
        if (body.productAction === 'move') {
          await tx.product.updateMany({
            where: { categoryId: { in: ids } },
            data: { categoryId: body.targetCategoryId! },
          })
        }

        const catsToDelete = await tx.category.findMany({
          where: { id: { in: ids } },
          select: { id: true, parentId: true },
        })

        for (const cat of catsToDelete) {
          await tx.category.updateMany({
            where: { parentId: cat.id },
            data: { parentId: cat.parentId },
          })
        }

        await tx.category.deleteMany({ where: { id: { in: ids } } })
      })
    } catch (e) {
      const msg = e instanceof Error ? e.message : 'فشل الحذف الجماعي'
      return jsonError(msg, 422)
    }

    revalidateTag('catalog')
    revalidateTag('sitemap')
    await audit(admin.id, 'category.bulk_delete', 'category', null, { ids, count: ids.length, productAction: body.productAction }, clientMeta(req))
    return Response.json({ ok: true, deleted: ids.length })
  }

  if (action === 'show' || action === 'hide') {
    const check = await requirePermission('categories', 'edit')
    if (check instanceof Response) return check

    const isVisible = action === 'show'
    await db.category.updateMany({
      where: { id: { in: ids } },
      data: { isVisible },
    })

    revalidateTag('catalog')
    await audit(admin.id, 'category.bulk_visibility', 'category', null, { ids, count: ids.length, isVisible }, clientMeta(req))
    return Response.json({ ok: true, updated: ids.length })
  }

  return jsonError('إجراء غير معروف', 400)
}
