import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { requireAdmin, jsonError, audit, clientMeta } from '@/lib/admin-api'
import { requirePermission } from '@/lib/permissions'
import { revalidateTag } from 'next/cache'
import { z } from 'zod'

export const dynamic = 'force-dynamic'

// GET — single category
export async function GET(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const admin = await requireAdmin()
  if (!admin) return jsonError('Unauthorized', 401)
  const { id } = await params
  const category = await db.category.findUnique({
    where: { id },
    include: { _count: { select: { products: true, children: true } } },
  })
  if (!category) return jsonError('الفئة غير موجودة', 404)
  return Response.json({ ok: true, category })
}

const updateSchema = z.object({
  name: z.string().min(1).max(100).optional(),
  slug: z.string().min(1).max(100).optional(),
  nameAr: z.string().max(100).optional().nullable(),
  description: z.string().max(500).optional().nullable(),
  imageUrl: z.string().url().optional().nullable(),
  imagePublicId: z.string().optional().nullable(),
  parentId: z.string().optional().nullable(),
  sortOrder: z.number().int().min(0).max(9999).optional(),
  isVisible: z.boolean().optional(),
  seoTitle: z.string().max(200).optional().nullable(),
  seoDescription: z.string().max(300).optional().nullable(),
})

// PUT — update category
export async function PUT(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const admin = await requireAdmin()
  if (!admin) return jsonError('Unauthorized', 401)
  const check = await requirePermission('categories', 'edit')
  if (check instanceof Response) return check

  const { id } = await params
  const existing = await db.category.findUnique({ where: { id } })
  if (!existing) return jsonError('الفئة غير موجودة', 404)

  let body: z.infer<typeof updateSchema>
  try {
    body = updateSchema.parse(await req.json())
  } catch (e) {
    return jsonError('بيانات غير صالحة', 400, { error: e instanceof Error ? e.message : 'parse error' })
  }

  // Slug uniqueness check
  if (body.slug && body.slug !== existing.slug) {
    const conflict = await db.category.findUnique({ where: { slug: body.slug } })
    if (conflict) return jsonError('الرابط (slug) مستخدم من طرف فئة أخرى', 409)
  }

  // Prevent circular parent reference
  if (body.parentId) {
    if (body.parentId === id) return jsonError('لا يمكن تعيين الفئة كأب لنفسها', 422)
    const parent = await db.category.findUnique({ where: { id: body.parentId } })
    if (!parent) return jsonError('الفئة الأب غير موجودة', 404)
  }

  const category = await db.category.update({ where: { id }, data: body })
  revalidateTag('catalog')
  revalidateTag('sitemap')
  await audit(admin.id, 'category.update', 'category', id, body, clientMeta(req))
  return Response.json({ ok: true, category })
}

// DELETE — delete category with product migration options
const deleteSchema = z.object({
  productAction: z.enum(['move', 'orphan', 'cancel']).default('cancel'),
  targetCategoryId: z.string().optional(),
})

export async function DELETE(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const admin = await requireAdmin()
  if (!admin) return jsonError('Unauthorized', 401)
  const check = await requirePermission('categories', 'delete')
  if (check instanceof Response) return check

  const { id } = await params
  const existing = await db.category.findUnique({
    where: { id },
    include: { _count: { select: { products: true } } },
  })
  if (!existing) return jsonError('الفئة غير موجودة', 404)

  let body: z.infer<typeof deleteSchema>
  try {
    body = deleteSchema.parse(await req.json().catch(() => ({})))
  } catch {
    return jsonError('بيانات غير صالحة', 400)
  }

  const productCount = existing._count.products

  // If category has products, require explicit action
  if (productCount > 0 && body.productAction === 'cancel') {
    return Response.json(
      {
        ok: false,
        error: 'هذه الفئة تحتوي على منتجات. اختر إجراءً للمتابعة.',
        requiresAction: true,
        productCount,
      },
      { status: 409 },
    )
  }

  // Execute deletion in a transaction
  try {
    await db.$transaction(async (tx) => {
      // Handle products
      if (productCount > 0) {
        if (body.productAction === 'move') {
          if (!body.targetCategoryId) {
            throw new Error('targetCategoryId required for move action')
          }
          const target = await tx.category.findUnique({ where: { id: body.targetCategoryId } })
          if (!target) throw new Error('الفئة الهدف غير موجودة')
          await tx.product.updateMany({
            where: { categoryId: id },
            data: { categoryId: body.targetCategoryId },
          })
        } else if (body.productAction === 'orphan') {
          // Products stay but with null category — but categoryId is required (not nullable)
          // So we can't truly orphan them. Instead, we need a fallback category.
          // For safety, we refuse orphan if categoryId is non-nullable.
          throw new Error('لا يمكن ترك المنتجات بدون فئة. اختر فئة أخرى للنقل.')
        }
      }

      // Update children to point to parent's parent (or null)
      await tx.category.updateMany({
        where: { parentId: id },
        data: { parentId: existing.parentId },
      })

      // Delete the category
      await tx.category.delete({ where: { id } })
    })
  } catch (e) {
    const msg = e instanceof Error ? e.message : 'فشل الحذف'
    return jsonError(msg, 422)
  }

  revalidateTag('catalog')
  revalidateTag('sitemap')
  await audit(admin.id, 'category.delete', 'category', id, { productAction: body.productAction, targetCategoryId: body.targetCategoryId, productCount }, clientMeta(req))
  return Response.json({ ok: true })
}
