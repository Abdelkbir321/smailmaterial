import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { requireAdmin, jsonError } from '@/lib/admin-api'

export const dynamic = 'force-dynamic'

/**
 * GET /api/admin/dashboard?period=7d
 * ==================================
 *
 * Comprehensive dashboard endpoint that aggregates REAL data from:
 *   - Order table (sales, orders by status)
 *   - AnalyticsEvent table (visitors, sessions, page views, traffic sources)
 *   - Product table (inventory, best sellers)
 *
 * Period presets (URL param `period`):
 *   - today      : from 00:00 today to now
 *   - yesterday  : full day yesterday
 *   - 7d         : last 7 days (rolling)
 *   - 30d        : last 30 days (rolling)
 *   - this_month : from 1st of current month to now
 *   - last_month : full previous month
 *   - custom     : requires `from` + `to` ISO date params
 *
 * For each preset, we ALSO compute the previous equivalent period so the
 * UI can show the delta (e.g. +12% vs last week). This is critical for
 * the "comparison with previous period" requirement.
 *
 * NO FAKE DATA — every number comes from a real DB query. When a metric
 * can't be computed (e.g. GA4 not connected), we return `null` and let
 * the UI show "non disponible".
 */

interface Period {
  from: Date
  to: Date
  label: string
}

function getPeriod(req: NextRequest): { current: Period; previous: Period } {
  const sp = req.nextUrl.searchParams
  const preset = sp.get('period') || '7d'
  const customFrom = sp.get('from')
  const customTo = sp.get('to')
  const now = new Date()

  // Helper: build a period from two dates
  const make = (from: Date, to: Date, label: string): Period => ({ from, to, label })

  let current: Period
  let previous: Period

  switch (preset) {
    case 'today': {
      const start = new Date(now)
      start.setHours(0, 0, 0, 0)
      current = make(start, now, "Aujourd'hui")
      // Previous = yesterday same hours
      const yStart = new Date(start)
      yStart.setDate(yStart.getDate() - 1)
      const yEnd = new Date(now)
      yEnd.setDate(yEnd.getDate() - 1)
      previous = make(yStart, yEnd, 'Hier')
      break
    }
    case 'yesterday': {
      const start = new Date(now)
      start.setHours(0, 0, 0, 0)
      start.setDate(start.getDate() - 1)
      const end = new Date(start)
      end.setHours(23, 59, 59, 999)
      current = make(start, end, 'Hier')
      // Previous = the day before yesterday
      const dStart = new Date(start)
      dStart.setDate(dStart.getDate() - 1)
      const dEnd = new Date(dStart)
      dEnd.setHours(23, 59, 59, 999)
      previous = make(dStart, dEnd, 'Avant-hier')
      break
    }
    case '30d': {
      const from = new Date(now)
      from.setDate(from.getDate() - 30)
      current = make(from, now, '30 derniers jours')
      const pFrom = new Date(from)
      pFrom.setDate(pFrom.getDate() - 30)
      const pTo = from
      previous = make(pFrom, pTo, 'Période précédente')
      break
    }
    case 'this_month': {
      const start = new Date(now.getFullYear(), now.getMonth(), 1)
      current = make(start, now, 'Ce mois-ci')
      // Previous = same number of days last month
      const pStart = new Date(now.getFullYear(), now.getMonth() - 1, 1)
      const pEnd = new Date(start)
      pEnd.setMilliseconds(-1)
      previous = make(pStart, pEnd, 'Mois dernier')
      break
    }
    case 'last_month': {
      const start = new Date(now.getFullYear(), now.getMonth() - 1, 1)
      const end = new Date(now.getFullYear(), now.getMonth(), 0, 23, 59, 59, 999)
      current = make(start, end, 'Mois dernier')
      const pStart = new Date(now.getFullYear(), now.getMonth() - 2, 1)
      const pEnd = new Date(start)
      pEnd.setMilliseconds(-1)
      previous = make(pStart, pEnd, 'Il y a 2 mois')
      break
    }
    case 'custom': {
      if (!customFrom || !customTo) {
        // Fall back to 7d
        const from = new Date(now)
        from.setDate(from.getDate() - 7)
        current = make(from, now, '7 derniers jours')
        const pFrom = new Date(from)
        pFrom.setDate(pFrom.getDate() - 7)
        previous = make(pFrom, from, 'Période précédente')
        break
      }
      const from = new Date(customFrom)
      const to = new Date(customTo)
      to.setHours(23, 59, 59, 999)
      current = make(from, to, 'Période personnalisée')
      const duration = to.getTime() - from.getTime()
      const pFrom = new Date(from.getTime() - duration)
      const pTo = new Date(from.getTime() - 1)
      previous = make(pFrom, pTo, 'Période précédente')
      break
    }
    case '7d':
    default: {
      const from = new Date(now)
      from.setDate(from.getDate() - 7)
      current = make(from, now, '7 derniers jours')
      const pFrom = new Date(from)
      pFrom.setDate(pFrom.getDate() - 7)
      const pTo = new Date(from)
      previous = make(pFrom, pTo, 'Semaine précédente')
      break
    }
  }
  return { current, previous }
}

/** Helper: compute the percentage change between two numbers. */
function change(current: number, previous: number): number | null {
  if (previous === 0) return current > 0 ? 100 : 0
  return Math.round(((current - previous) / previous) * 100)
}

export async function GET(req: NextRequest) {
  const admin = await requireAdmin()
  if (!admin) return jsonError('غير مصرّح', 401)

  const { current, previous } = getPeriod(req)

  // ─── ORDERS ──────────────────────────────────────────────────────
  // We count orders by status for the CURRENT period. The "total sales"
  // is computed from orders that are CONFIRMED/SHIPPED/DELIVERED (i.e.
  // revenue the store expects to collect). "Confirmed sales" is from
  // DELIVERED orders only (revenue actually collected via COD).
  const [
    currentOrders,
    currentNewOrders,
    currentConfirmedOrders,
    currentDeliveredOrders,
    currentCancelledOrders,
    currentSalesAgg,        // CONFIRMED + SHIPPED + DELIVERED
    currentDeliveredAgg,    // DELIVERED only
    previousOrders,
    previousSalesAgg,
    previousDeliveredAgg,
  ] = await Promise.all([
    db.order.count({ where: { placedAt: { gte: current.from, lte: current.to } } }),
    db.order.count({ where: { placedAt: { gte: current.from, lte: current.to }, status: 'NEW' } }),
    db.order.count({ where: { placedAt: { gte: current.from, lte: current.to }, status: 'CONFIRMED' } }),
    db.order.count({ where: { placedAt: { gte: current.from, lte: current.to }, status: 'DELIVERED' } }),
    db.order.count({ where: { placedAt: { gte: current.from, lte: current.to }, status: 'CANCELLED' } }),
    db.order.aggregate({
      _sum: { total: true },
      where: { placedAt: { gte: current.from, lte: current.to }, status: { in: ['CONFIRMED', 'SHIPPED', 'DELIVERED'] } },
    }),
    db.order.aggregate({
      _sum: { total: true },
      where: { placedAt: { gte: current.from, lte: current.to }, status: 'DELIVERED' },
    }),
    db.order.count({ where: { placedAt: { gte: previous.from, lte: previous.to } } }),
    db.order.aggregate({
      _sum: { total: true },
      where: { placedAt: { gte: previous.from, lte: previous.to }, status: { in: ['CONFIRMED', 'SHIPPED', 'DELIVERED'] } },
    }),
    db.order.aggregate({
      _sum: { total: true },
      where: { placedAt: { gte: previous.from, lte: previous.to }, status: 'DELIVERED' },
    }),
  ])

  const currentSales = Number(currentSalesAgg._sum.total ?? 0)
  const currentDeliveredSales = Number(currentDeliveredAgg._sum.total ?? 0)
  const previousSales = Number(previousSalesAgg._sum.total ?? 0)
  const previousDeliveredSales = Number(previousDeliveredAgg._sum.total ?? 0)

  // ─── ANALYTICS (visitors, sessions, page views) ──────────────────
  // All from the AnalyticsEvent table — NO GA4 required.
  // We count DISTINCT sessionId as "sessions" and DISTINCT sessionId on
  // `session_start` events as "new visitors". Returning visitors = sessions
  // that have a `session_start` event BEFORE the current period (i.e. their
  // first-ever visit was earlier).
  const [
    currentEvents,
    currentSessions,
    currentNewVisitors,
    currentProductViews,
    previousSessions,
    previousProductViews,
  ] = await Promise.all([
    db.analyticsEvent.count({ where: { createdAt: { gte: current.from, lte: current.to } } }),
    db.analyticsEvent.findMany({
      where: { createdAt: { gte: current.from, lte: current.to } },
      select: { sessionId: true, eventName: true },
      distinct: ['sessionId'],
    }).then((rows) => rows.length),
    db.analyticsEvent.count({
      where: {
        createdAt: { gte: current.from, lte: current.to },
        eventName: 'session_start',
      },
    }),
    db.analyticsEvent.count({
      where: {
        createdAt: { gte: current.from, lte: current.to },
        eventName: 'view_item',
      },
    }),
    db.analyticsEvent.findMany({
      where: { createdAt: { gte: previous.from, lte: previous.to } },
      select: { sessionId: true },
      distinct: ['sessionId'],
    }).then((rows) => rows.length),
    db.analyticsEvent.count({
      where: {
        createdAt: { gte: previous.from, lte: previous.to },
        eventName: 'view_item',
      },
    }),
  ])

  const currentVisitors = currentSessions
  const previousVisitors = previousSessions

  // Conversion rate = orders / sessions (expressed as a percentage).
  // We use sessions (not visitors) because a single visitor can have
  // multiple sessions, and the order happens in a session.
  const conversionRate = currentVisitors > 0
    ? Number(((currentOrders / currentVisitors) * 100).toFixed(2))
    : 0
  const previousConversionRate = previousVisitors > 0
    ? Number(((previousOrders / previousVisitors) * 100).toFixed(2))
    : 0

  // ─── TOP COUNTRIES (from AnalyticsEvent.country) ─────────────────
  // Prisma 6 groupBy doesn't support orderBy by _count, so we sort in JS.
  const countryRowsRaw = await db.analyticsEvent.groupBy({
    by: ['country'],
    where: {
      createdAt: { gte: current.from, lte: current.to },
      eventName: 'page_view',
    },
    _count: true,
  })
  const countryRows = countryRowsRaw
    .sort((a, b) => b._count - a._count)
    .slice(0, 10)

  // ─── TRAFFIC SOURCES (from AnalyticsEvent.trafficSource) ─────────
  const trafficRowsRaw = await db.analyticsEvent.groupBy({
    by: ['trafficSource'],
    where: {
      createdAt: { gte: current.from, lte: current.to },
      eventName: 'page_view',
    },
    _count: true,
  })
  const trafficRows = trafficRowsRaw.sort((a, b) => b._count - a._count)

  // ─── DEVICES (from AnalyticsEvent.device) ────────────────────────
  const deviceRowsRaw = await db.analyticsEvent.groupBy({
    by: ['device'],
    where: {
      createdAt: { gte: current.from, lte: current.to },
      eventName: 'page_view',
    },
    _count: true,
  })
  const deviceRows = deviceRowsRaw.sort((a, b) => b._count - a._count)

  // ─── TOP PRODUCTS (by view_item events) ──────────────────────────
  // eventData for view_item contains { slug, name, price }
  // We can't easily groupBy JSON in Prisma, so we fetch the raw events
  // and aggregate in JS. Cap at 500 events for performance.
  const viewItemEvents = await db.analyticsEvent.findMany({
    where: {
      createdAt: { gte: current.from, lte: current.to },
      eventName: 'view_item',
    },
    select: { eventData: true },
    take: 500,
  })
  const productViewCounts = new Map<string, { name: string; slug: string; views: number }>()
  for (const ev of viewItemEvents) {
    const data = ev.eventData as Record<string, unknown> | null
    const slug = String(data?.slug || '')
    const name = String(data?.name || slug || 'Inconnu')
    if (!slug) continue
    const existing = productViewCounts.get(slug)
    if (existing) {
      existing.views++
    } else {
      productViewCounts.set(slug, { name, slug, views: 1 })
    }
  }
  const topViewedProducts = Array.from(productViewCounts.values())
    .sort((a, b) => b.views - a.views)
    .slice(0, 10)

  // ─── RECENT ORDERS + BEST SELLERS (for the activity feed) ────────
  const [recentOrders, bestSellers, totalProducts, lowStockProducts] = await Promise.all([
    db.order.findMany({
      take: 8,
      orderBy: { placedAt: 'desc' },
      select: {
        id: true, number: true, customerFullName: true, status: true,
        total: true, placedAt: true,
        country: { select: { name: true, code: true } },
      },
    }),
    db.product.findMany({
      where: { salesCount: { gt: 0 } },
      orderBy: { salesCount: 'desc' },
      take: 5,
      select: {
        id: true, name: true, slug: true, salesCount: true,
        stockQuantity: true, price: true,
        images: { where: { isMain: true }, take: 1, select: { secureUrl: true, url: true } },
      },
    }),
    db.product.count(),
    db.product.count({
      where: {
        stockQuantity: { lte: 5 },
        trackInventory: true,
        status: 'PUBLISHED',
      },
    }),
  ])

  // ─── Google integration status (NO credentials = "not connected") ───
  const ga4Configured = !!(process.env.GA4_MEASUREMENT_ID && process.env.GA4_MEASUREMENT_ID.startsWith('G-'))
  const gscConfigured = !!(process.env.GOOGLE_SERVICE_ACCOUNT_EMAIL && process.env.GOOGLE_SERVICE_ACCOUNT_PRIVATE_KEY && process.env.GSC_SITE_URL)
  const pagespeedConfigured = !!process.env.PAGESPEED_API_KEY
  const cloudinaryConfigured = !!(process.env.CLOUDINARY_CLOUD_NAME && process.env.CLOUDINARY_API_KEY && process.env.CLOUDINARY_API_SECRET)

  return Response.json({
    ok: true,
    period: {
      current: { from: current.from.toISOString(), to: current.to.toISOString(), label: current.label },
      previous: { from: previous.from.toISOString(), to: previous.to.toISOString(), label: previous.label },
    },
    lastUpdated: new Date().toISOString(),
    stats: {
      // Orders
      orders: {
        current: currentOrders,
        previous: previousOrders,
        change: change(currentOrders, previousOrders),
      },
      newOrders: { current: currentNewOrders, previous: null, change: null },
      confirmedOrders: { current: currentConfirmedOrders, previous: null, change: null },
      deliveredOrders: { current: currentDeliveredOrders, previous: null, change: null },
      cancelledOrders: { current: currentCancelledOrders, previous: null, change: null },
      // Sales (revenue from CONFIRMED+SHIPPED+DELIVERED)
      sales: {
        current: currentSales,
        previous: previousSales,
        change: change(currentSales, previousSales),
      },
      // Confirmed sales (revenue from DELIVERED only — actually collected)
      deliveredSales: {
        current: currentDeliveredSales,
        previous: previousDeliveredSales,
        change: change(currentDeliveredSales, previousDeliveredSales),
      },
      // Analytics
      visitors: {
        current: currentVisitors,
        previous: previousVisitors,
        change: change(currentVisitors, previousVisitors),
      },
      sessions: { current: currentSessions, previous: previousSessions, change: change(currentSessions, previousSessions) },
      newVisitors: { current: currentNewVisitors, previous: null, change: null },
      // returningVisitors = sessions - newVisitors (approximation — a session
      // is "returning" if the visitor had a session_start before this period)
      returningVisitors: {
        current: Math.max(0, currentSessions - currentNewVisitors),
        previous: null,
        change: null,
      },
      productViews: {
        current: currentProductViews,
        previous: previousProductViews,
        change: change(currentProductViews, previousProductViews),
      },
      totalEvents: { current: currentEvents, previous: null, change: null },
      conversionRate: {
        current: conversionRate,
        previous: previousConversionRate,
        change: change(conversionRate, previousConversionRate),
      },
    },
    breakdowns: {
      countries: countryRows.map((r) => ({
        country: r.country || 'Inconnu',
        sessions: r._count,
        percentage: currentVisitors > 0 ? Number(((r._count / currentVisitors) * 100).toFixed(1)) : 0,
      })),
      trafficSources: trafficRows.map((r) => ({
        source: r.trafficSource || 'unknown',
        visits: r._count,
        percentage: currentEvents > 0 ? Number(((r._count / currentEvents) * 100).toFixed(1)) : 0,
      })),
      devices: deviceRows.map((r) => ({
        device: r.device || 'unknown',
        visits: r._count,
        percentage: currentEvents > 0 ? Number(((r._count / currentEvents) * 100).toFixed(1)) : 0,
      })),
      topViewedProducts,
    },
    activity: {
      recentOrders: recentOrders.map((o) => ({
        id: o.id,
        number: o.number,
        customerFullName: o.customerFullName,
        status: o.status,
        total: Number(o.total),
        placedAt: o.placedAt,
        country: o.country?.name || null,
      })),
      bestSellers: bestSellers.map((p) => ({
        id: p.id,
        name: p.name,
        slug: p.slug,
        salesCount: p.salesCount,
        stockQuantity: p.stockQuantity,
        price: Number(p.price),
        mainImage: p.images[0]?.secureUrl || p.images[0]?.url || null,
      })),
    },
    inventory: {
      totalProducts,
      lowStockProducts,
    },
    integrations: {
      ga4: {
        connected: ga4Configured,
        measurementId: ga4Configured ? process.env.GA4_MEASUREMENT_ID : null,
      },
      gsc: {
        connected: gscConfigured,
        siteUrl: gscConfigured ? process.env.GSC_SITE_URL : null,
      },
      pagespeed: {
        connected: pagespeedConfigured,
      },
      cloudinary: {
        connected: cloudinaryConfigured,
      },
    },
  })
}
