import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { requirePermission } from '@/lib/permissions'
import { jsonError } from '@/lib/admin-api'

export const dynamic = 'force-dynamic'

export async function GET(req: NextRequest) {
  const admin = await requirePermission('audit_logs', 'view')
  if (admin instanceof Response) return admin

  const { searchParams } = req.nextUrl
  const take = Math.min(100, Number(searchParams.get('take')) || 50)
  const page = Math.max(1, Number(searchParams.get('page')) || 1)
  const q = searchParams.get('q') || ''
  const entity = searchParams.get('entity')
  const skip = (page - 1) * take

  const where: Record<string, unknown> = {}
  if (entity && entity !== 'all') where.entity = entity
  if (q) {
    where.OR = [
      { action: { contains: q, mode: 'insensitive' } },
      { entityId: { contains: q, mode: 'insensitive' } },
      { adminUser: { fullName: { contains: q, mode: 'insensitive' } } },
      { adminUser: { email: { contains: q, mode: 'insensitive' } } },
    ]
  }

  const [logs, total] = await Promise.all([
    db.auditLog.findMany({
      where,
      take,
      skip,
      orderBy: { createdAt: 'desc' },
      include: { adminUser: { select: { email: true, fullName: true } } },
    }),
    db.auditLog.count({ where }),
  ])

  return Response.json({ ok: true, logs, total, page, take })
}
