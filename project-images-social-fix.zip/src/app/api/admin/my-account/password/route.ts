import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { getCurrentAdmin } from '@/lib/auth'
import { hashPassword, verifyPassword } from '@/lib/password'
import { audit, clientMeta } from '@/lib/admin-api'
import { z } from 'zod'

export const dynamic = 'force-dynamic'

/**
 * POST /api/admin/my-account/password
 * Body: { currentPassword, newPassword }
 * Requires the current password (re-auth) before setting the new one.
 */
export async function POST(req: NextRequest) {
  const admin = await getCurrentAdmin()
  if (!admin) return Response.json({ ok: false, error: 'غير مصرّح' }, { status: 401 })

  const body = await req.json().catch(() => ({}))
  const parsed = z.object({
    currentPassword: z.string().min(1),
    newPassword: z.string().min(8, 'كلمة المرور الجديدة 8 أحرف على الأقل'),
  }).safeParse(body)
  if (!parsed.success) {
    const fe: Record<string, string> = {}
    for (const e of parsed.error.issues) fe[e.path.join('.')] = e.message
    return Response.json({ ok: false, error: 'بيانات غير صالحة', fieldErrors: fe }, { status: 422 })
  }

  // re-auth: verify current password
  const valid = await verifyPassword(parsed.data.currentPassword, admin.passwordHash)
  if (!valid) {
    return Response.json({ ok: false, error: 'كلمة المرور الحالية غير صحيحة', fieldErrors: { currentPassword: 'غير صحيحة' } }, { status: 403 })
  }

  const newHash = await hashPassword(parsed.data.newPassword)
  await db.adminUser.update({ where: { id: admin.id }, data: { passwordHash: newHash } })
  // Revoke other sessions (force re-login on other devices)
  await db.adminSession.deleteMany({ where: { adminUserId: admin.id } }).catch(() => {})

  await audit(admin.id, 'my_account.password_change', 'admin_user', admin.id, {}, clientMeta(req))
  return Response.json({ ok: true })
}
