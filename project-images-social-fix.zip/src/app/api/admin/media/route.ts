import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { requireAdmin, jsonError } from '@/lib/admin-api'

export const dynamic = 'force-dynamic'

/**
 * GET /api/admin/media?take=50
 * Returns the most recent media assets (images uploaded via Cloudinary, external, or placeholder).
 */
export async function GET(req: NextRequest) {
  const admin = await requireAdmin()
  if (!admin) return jsonError('غير مصرّح', 401)

  const take = Math.min(200, Math.max(1, Number(req.nextUrl.searchParams.get('take') || 50)))
  const assets = await db.mediaAsset.findMany({
    orderBy: { createdAt: 'desc' },
    take,
  })

  return Response.json({
    ok: true,
    assets: assets.map((a) => ({
      id: a.id,
      sourceType: a.sourceType,
      publicId: a.publicId,
      externalUrl: a.externalUrl,
      secureUrl: a.secureUrl,
      url: a.url,
      width: a.width,
      height: a.height,
      format: a.format,
      bytes: a.bytes,
      resourceType: a.resourceType,
      altText: a.altText,
      tags: a.tags,
      uploadedByAdminId: a.uploadedByAdminId,
      createdAt: a.createdAt,
    })),
  })
}
