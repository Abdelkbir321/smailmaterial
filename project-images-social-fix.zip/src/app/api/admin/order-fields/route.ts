import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { requireAdmin, audit, clientMeta, jsonError } from '@/lib/admin-api'
import { revalidateTag } from 'next/cache'

export const dynamic = 'force-dynamic'

/** GET /api/admin/order-fields — admin list (all fields, incl inactive) */
export async function GET() {
  const admin = await requireAdmin()
  if (!admin) return jsonError('غير مصرّح', 401)
  const fields = await db.orderField.findMany({ orderBy: { sortOrder: 'asc' } })
  return Response.json({ ok: true, fields })
}

/**
 * POST /api/admin/order-fields — create
 * Body: { key, type, labelAr, labelFr, labelEn, required, isActive, sortOrder, width, ... }
 */
export async function POST(req: NextRequest) {
  const admin = await requireAdmin()
  if (!admin) return jsonError('غير مصرّح', 401)
  const b = await req.json().catch(() => ({}))

  // Trim string values before validation — whitespace-only values
  // are treated as empty (prevents "filled but fails validation" bug)
  const key = typeof b.key === 'string' ? b.key.trim() : ''
  const labelAr = typeof b.labelAr === 'string' ? b.labelAr.trim() : ''
  const labelFr = typeof b.labelFr === 'string' ? b.labelFr.trim() : ''
  const labelEn = typeof b.labelEn === 'string' ? b.labelEn.trim() : ''

  if (!key || !labelAr || !labelFr || !labelEn) {
    return jsonError('key و labelAr و labelFr و labelEn مطلوبين.', 422)
  }
  if (await db.orderField.findUnique({ where: { key } })) {
    return jsonError('key موجود من قبل.', 409, { key: 'موجود' })
  }

  // ─── Validation for length bounds + country codes ───────────────────
  // minLength / maxLength: optional integers ≥ 0. Accept null, "", or
  // numeric strings (HTML number inputs always send strings). Normalize
  // to `number | null` for Prisma.
  const parseOptionalInt = (v: unknown): number | null => {
    if (v === null || v === undefined || v === '') return null
    const n = typeof v === 'number' ? v : Number(v)
    if (!Number.isFinite(n) || n < 0) return null
    return Math.floor(n)
  }
  const minLength = parseOptionalInt(b.minLength)
  const maxLength = parseOptionalInt(b.maxLength)

  // countryCodes: array of ISO 3166-1 alpha-2 codes (uppercase, 2 letters).
  // Accept either ["MA","DZ"] or comma-separated string "MA,DZ". Filter
  // out invalid entries. Empty array = visible in all countries.
  const parseCountryCodes = (v: unknown): string[] => {
    if (Array.isArray(v)) {
      return v
        .map((x) => (typeof x === 'string' ? x.trim().toUpperCase() : ''))
        .filter((x) => /^[A-Z]{2}$/.test(x))
    }
    if (typeof v === 'string' && v.trim()) {
      return v
        .split(/[\s,]+/)
        .map((x) => x.trim().toUpperCase())
        .filter((x) => /^[A-Z]{2}$/.test(x))
    }
    return []
  }
  const countryCodes = parseCountryCodes(b.countryCodes)

  // Cross-field validation: if both bounds are set, minLength ≤ maxLength.
  if (minLength !== null && maxLength !== null && minLength > maxLength) {
    return jsonError('الحد الأدنى يجب أن يكون ≤ الحد الأقصى.', 422, { field: 'minLength' })
  }

  const f = await db.orderField.create({
    data: {
      key,
      type: b.type || 'text',
      labelAr,
      labelFr,
      labelEn,
      placeholderAr: b.placeholderAr || null,
      placeholderFr: b.placeholderFr || null,
      placeholderEn: b.placeholderEn || null,
      helpTextAr: b.helpTextAr || null,
      helpTextFr: b.helpTextFr || null,
      helpTextEn: b.helpTextEn || null,
      options: b.options || [],
      required: !!b.required,
      isActive: b.isActive !== false,
      sortOrder: b.sortOrder ?? 0,
      width: b.width || 'full',
      defaultValue: b.defaultValue || null,
      minLength,
      maxLength,
      countryCodes,
    },
  })
  revalidateTag('settings')
  await audit(admin.id, 'order_field.create', 'order_field', f.id, { key: f.key }, clientMeta(req))
  return Response.json({ ok: true, field: f }, { status: 201 })
}
