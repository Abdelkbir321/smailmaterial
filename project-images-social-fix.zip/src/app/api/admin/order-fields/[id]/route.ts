import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { requireAdmin, audit, clientMeta, jsonError } from '@/lib/admin-api'
import { revalidateTag } from 'next/cache'

export const dynamic = 'force-dynamic'

/** PUT /api/admin/order-fields/[id] — update (preserves old order data: key is immutable) */
export async function PUT(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const admin = await requireAdmin()
  if (!admin) return jsonError('غير مصرّح', 401)
  const { id } = await params
  const existing = await db.orderField.findUnique({ where: { id } })
  if (!existing) return jsonError('الحقل غير موجود.', 404)
  const b = await req.json().catch(() => ({}))

  // Trim label values if provided — prevents whitespace-only saves
  const trimIfStr = (v: unknown) => (typeof v === 'string' ? v.trim() : v)
  const labelAr = trimIfStr(b.labelAr)
  const labelFr = trimIfStr(b.labelFr)
  const labelEn = trimIfStr(b.labelEn)

  // If labels are provided, they must not be empty after trimming
  if (b.labelAr !== undefined && !labelAr) {
    return jsonError('labelAr لا يمكن أن يكون فارغاً.', 422)
  }
  if (b.labelFr !== undefined && !labelFr) {
    return jsonError('labelFr لا يمكن أن يكون فارغاً.', 422)
  }
  if (b.labelEn !== undefined && !labelEn) {
    return jsonError('labelEn لا يمكن أن يكون فارغاً.', 422)
  }

  // ─── Length bounds + country codes ──────────────────────────────────
  // Same normalization as POST — accept number, "", or numeric string.
  // Returns `null` for missing/invalid → nulls the bound in DB.
  const parseOptionalInt = (v: unknown): number | null => {
    if (v === null || v === undefined || v === '') return null
    const n = typeof v === 'number' ? v : Number(v)
    if (!Number.isFinite(n) || n < 0) return null
    return Math.floor(n)
  }
  const parseCountryCodes = (v: unknown): string[] => {
    if (Array.isArray(v)) {
      return v
        .map((x) => (typeof x === 'string' ? x.trim().toUpperCase() : ''))
        .filter((x) => /^[A-Z]{2}$/.test(x))
    }
    if (typeof v === 'string' && v.trim()) {
      return v
        .split(/[\s,]+/)
        .map((x) => x.trim().toUpperCase())
        .filter((x) => /^[A-Z]{2}$/.test(x))
    }
    return []
  }

  // Build the update payload conditionally — only fields that were
  // actually provided in the request body are touched. This lets the
  // admin UI do partial updates (e.g. just toggle `isActive`) without
  // wiping out `minLength` etc.
  const updateData: Record<string, unknown> = {}
  if (b.type !== undefined) updateData.type = b.type
  if (b.labelAr !== undefined) updateData.labelAr = labelAr
  if (b.labelFr !== undefined) updateData.labelFr = labelFr
  if (b.labelEn !== undefined) updateData.labelEn = labelEn
  if (b.placeholderAr !== undefined) updateData.placeholderAr = b.placeholderAr || null
  if (b.placeholderFr !== undefined) updateData.placeholderFr = b.placeholderFr || null
  if (b.placeholderEn !== undefined) updateData.placeholderEn = b.placeholderEn || null
  if (b.helpTextAr !== undefined) updateData.helpTextAr = b.helpTextAr || null
  if (b.helpTextFr !== undefined) updateData.helpTextFr = b.helpTextFr || null
  if (b.helpTextEn !== undefined) updateData.helpTextEn = b.helpTextEn || null
  if (b.options !== undefined) updateData.options = b.options
  if (b.required !== undefined) updateData.required = !!b.required
  if (b.isActive !== undefined) updateData.isActive = !!b.isActive
  if (b.sortOrder !== undefined) updateData.sortOrder = Number(b.sortOrder) || 0
  if (b.width !== undefined) updateData.width = b.width
  if (b.defaultValue !== undefined) updateData.defaultValue = b.defaultValue || null
  if (b.minLength !== undefined) {
    updateData.minLength = parseOptionalInt(b.minLength)
  }
  if (b.maxLength !== undefined) {
    updateData.maxLength = parseOptionalInt(b.maxLength)
  }
  if (b.countryCodes !== undefined) {
    updateData.countryCodes = parseCountryCodes(b.countryCodes)
  }

  // Cross-field validation: if both bounds are present in the merged
  // payload (existing + update), minLength ≤ maxLength.
  const mergedMin = updateData.minLength !== undefined ? updateData.minLength : existing.minLength
  const mergedMax = updateData.maxLength !== undefined ? updateData.maxLength : existing.maxLength
  if (
    mergedMin !== null && mergedMin !== undefined &&
    mergedMax !== null && mergedMax !== undefined &&
    mergedMin > mergedMax
  ) {
    return jsonError('الحد الأدنى يجب أن يكون ≤ الحد الأقصى.', 422, { field: 'minLength' })
  }

  // key is NOT updatable — changing it would break old orders' customFields
  const f = await db.orderField.update({
    where: { id },
    data: updateData as any,
  })
  revalidateTag('settings')
  await audit(admin.id, 'order_field.update', 'order_field', id, { changed: Object.keys(b) }, clientMeta(req))
  return Response.json({ ok: true, field: f })
}

/** DELETE — soft delete (isActive=false). Hard delete only if no orders reference it. */
export async function DELETE(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const admin = await requireAdmin()
  if (!admin) return jsonError('غير مصرّح', 401)
  const { id } = await params
  const existing = await db.orderField.findUnique({ where: { id } })
  if (!existing) return jsonError('الحقل غير موجود.', 404)
  // Check if any order uses this field's key in customFields
  const orders = await db.order.findMany({ where: { customFields: { path: [existing.key], not: { equals: null } } } })
  if (orders.length > 0) {
    // Soft-delete: hide it instead, preserve old order data
    await db.orderField.update({ where: { id }, data: { isActive: false } })
    revalidateTag('settings')
    await audit(admin.id, 'order_field.deactivate', 'order_field', id, { key: existing.key, ordersUsing: orders.length }, clientMeta(req))
    return Response.json({ ok: true, deactivated: true, message: `تم إخفاء الحقل (${orders.length} طلبات قديمة كيستعملونه).` })
  }
  await db.orderField.delete({ where: { id } })
  revalidateTag('settings')
  await audit(admin.id, 'order_field.delete', 'order_field', id, { key: existing.key }, clientMeta(req))
  return Response.json({ ok: true })
}
