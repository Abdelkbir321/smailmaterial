import { NextRequest } from 'next/server'
import { logoutAdmin, getCurrentAdmin } from '@/lib/auth'
import { SESSION_COOKIE } from '@/lib/auth'
import { audit, clientMeta } from '@/lib/admin-api'

export const dynamic = 'force-dynamic'

export async function POST(req: NextRequest) {
  const admin = await getCurrentAdmin()
  if (admin) await audit(admin.id, 'auth.logout', 'admin_user', admin.id, {}, clientMeta(req))
  await logoutAdmin()
  const res = Response.json({ ok: true })
  res.headers.set('Set-Cookie', `${SESSION_COOKIE}=; Path=/; HttpOnly; SameSite=lax; Max-Age=0`)
  return res
}
