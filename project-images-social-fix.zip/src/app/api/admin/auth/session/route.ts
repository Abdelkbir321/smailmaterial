import { getCurrentAdmin } from '@/lib/auth'
export const dynamic = 'force-dynamic'
export async function GET() {
  const admin = await getCurrentAdmin()
  if (!admin) return Response.json({ ok: false }, { status: 401 })
  return Response.json({
    ok: true,
    admin: {
      id: admin.id,
      email: admin.email,
      fullName: admin.fullName,
      lastLoginAt: admin.lastLoginAt,
      role: { id: admin.role.id, slug: admin.role.slug, name: admin.role.name, permissions: admin.role.permissions },
    },
  })
}
