import { NextRequest } from 'next/server'
import { adminLoginSchema } from '@/validations'
import { loginAdmin, setSessionCookie } from '@/lib/auth'
import { clientMeta, audit } from '@/lib/admin-api'
import { rateLimitByIp } from '@/lib/rate-limit'

export const dynamic = 'force-dynamic'

export async function POST(req: NextRequest) {
  // Rate limit: 10 login attempts per 15 min per IP (brute-force protection)
  const meta = clientMeta(req)
  const rl = rateLimitByIp(meta.ip, 'login', 10, 15 * 60 * 1000)
  if (!rl.ok) {
    return Response.json(
      { ok: false, error: 'محاولات كثيرة. حاول لاحقاً.' },
      { status: 429, headers: { 'Retry-After': String(rl.retryAfter) } },
    )
  }
  let body: unknown
  try {
    body = await req.json()
  } catch {
    return Response.json({ ok: false, error: 'Requête invalide.' }, { status: 400 })
  }
  const parsed = adminLoginSchema.safeParse(body)
  if (!parsed.success) {
    return Response.json(
      { ok: false, error: 'Email ou mot de passe invalide.' },
      { status: 422 },
    )
  }
  const result = await loginAdmin(parsed.data.email, parsed.data.password, meta)
  if (!result.ok || !result.token || !result.admin) {
    return Response.json({ ok: false, error: result.error ?? 'Échec de connexion.' }, { status: 401 })
  }
  // set cookie
  const cookie = setSessionCookie(result.token)
  const res = Response.json({
    ok: true,
    admin: {
      id: result.admin.id,
      email: result.admin.email,
      fullName: result.admin.fullName,
      role: { id: result.admin.role.id, slug: result.admin.role.slug, name: result.admin.role.name },
    },
  })
  res.headers.set(
    'Set-Cookie',
    `${cookie.name}=${cookie.value}; Path=${cookie.path}; HttpOnly; SameSite=${cookie.sameSite}; Max-Age=${cookie.maxAge}${cookie.secure ? '; Secure' : ''}`,
  )
  await audit(result.admin.id, 'auth.login', 'admin_user', result.admin.id, {}, meta)
  return res
}
