import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { requireAdmin, jsonError, audit, clientMeta } from '@/lib/admin-api'
import { requirePermission } from '@/lib/permissions'
import { revalidateTag } from 'next/cache'
import { z } from 'zod'

export const dynamic = 'force-dynamic'

const bulkSchema = z.object({
  ids: z.array(z.string()).min(1).max(500),
  action: z.enum(['enable', 'disable', 'setCurrency']),
  currencyCode: z.string().max(3).optional(),
  currencySymbol: z.string().max(8).optional(),
})

export async function POST(req: NextRequest) {
  const admin = await requireAdmin()
  if (!admin) return jsonError('غير مصرّح', 401)

  const check = await requirePermission('countries', 'edit')
  if (check instanceof Response) return check

  let body: z.infer<typeof bulkSchema>
  try {
    body = bulkSchema.parse(await req.json())
  } catch (e) {
    return jsonError('بيانات غير صالحة', 400)
  }

  const { ids, action } = body

  if (action === 'enable') {
    await db.country.updateMany({
      where: { id: { in: ids } },
      data: { isEnabled: true },
    })
    revalidateTag('catalog')
    await audit(admin.id, 'country.bulk_enable', 'country', null, { count: ids.length }, clientMeta(req))
    return Response.json({ ok: true, updated: ids.length })
  }

  if (action === 'disable') {
    // Don't disable the default country
    const defaultCountry = await db.country.findFirst({ where: { isDefault: true } })
    const safeIds = defaultCountry ? ids.filter(id => id !== defaultCountry.id) : ids

    if (safeIds.length === 0) {
      return jsonError('لا يمكن إيقاف الدولة الافتراضية. غيّر الدولة الافتراضية أولاً.', 422)
    }

    await db.country.updateMany({
      where: { id: { in: safeIds } },
      data: { isEnabled: false },
    })
    revalidateTag('catalog')
    await audit(admin.id, 'country.bulk_disable', 'country', null, { count: safeIds.length }, clientMeta(req))
    return Response.json({ ok: true, updated: safeIds.length })
  }

  if (action === 'setCurrency') {
    if (!body.currencyCode) {
      return jsonError('رمز العملة مطلوب', 400)
    }
    await db.country.updateMany({
      where: { id: { in: ids } },
      data: {
        currencyCode: body.currencyCode,
        ...(body.currencySymbol ? { currencySymbol: body.currencySymbol } : {}),
      },
    })
    revalidateTag('catalog')
    await audit(admin.id, 'country.bulk_currency', 'country', null, { count: ids.length, currency: body.currencyCode }, clientMeta(req))
    return Response.json({ ok: true, updated: ids.length })
  }

  return jsonError('إجراء غير معروف', 400)
}
