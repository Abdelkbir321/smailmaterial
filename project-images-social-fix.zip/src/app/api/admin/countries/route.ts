import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { requireAdmin, jsonError } from '@/lib/admin-api'
import { countryInputSchema } from '@/validations'
import { revalidateTag } from 'next/cache'

export const dynamic = 'force-dynamic'
export async function GET() {
  const admin = await requireAdmin()
  if (!admin) return jsonError('Unauthorized', 401)
  const countries = await db.country.findMany({ orderBy: [{ sortOrder: 'asc' }] })
  return Response.json({ ok: true, countries })
}
export async function POST(req: NextRequest) {
  const admin = await requireAdmin()
  if (!admin) return jsonError('Unauthorized', 401)
  const parsed = countryInputSchema.safeParse(await req.json().catch(() => ({})))
  if (!parsed.success) return jsonError('Champs invalides', 422)
  const d = parsed.data
  if (await db.country.findUnique({ where: { code: d.code } })) return jsonError('Code pays existe', 409)
  if (d.isDefault) await db.country.updateMany({ data: { isDefault: false } })
  const country = await db.country.create({
    data: {
      code: d.code, name: d.name, nameAr: d.nameAr || null,
      currencyCode: d.currencyCode, currencySymbol: d.currencySymbol,
      phonePrefix: d.phonePrefix, locale: d.locale,
      isEnabled: d.isEnabled, isDefault: d.isDefault, sortOrder: d.sortOrder,
      shippingBase: d.shippingBase, shippingPerKg: d.shippingPerKg, taxRate: d.taxRate,
    },
  })
  revalidateTag('catalog')
  return Response.json({ ok: true, country }, { status: 201 })
}
export async function PATCH(req: NextRequest) {
  const admin = await requireAdmin()
  if (!admin) return jsonError('Unauthorized', 401)
  const body = await req.json().catch(() => ({}))
  const { id, ...data } = body
  if (!id) return jsonError('ID requis')
  if (data.isDefault === true) await db.country.updateMany({ data: { isDefault: false } })
  const country = await db.country.update({ where: { id }, data })
  revalidateTag('catalog')
  return Response.json({ ok: true, country })
}
