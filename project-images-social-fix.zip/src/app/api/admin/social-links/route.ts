import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { requireAdmin, jsonError, audit, clientMeta } from '@/lib/admin-api'
import { requirePermission } from '@/lib/permissions'
import { revalidateTag } from 'next/cache'
import { z } from 'zod'

export const dynamic = 'force-dynamic'

// GET — list all social links (admin only)
export async function GET() {
  const admin = await requireAdmin()
  if (!admin) return jsonError('Unauthorized', 401)
  const rows = await db.socialLink.findMany({ orderBy: { order: 'asc' } })
  return Response.json({ ok: true, links: rows })
}

const createSchema = z.object({
  platform: z.string().min(1).max(50),
  label: z.string().max(100).optional().nullable(),
  url: z.string().url().max(500),
  iconKey: z.string().max(50).optional().default(''),
  order: z.number().int().min(0).max(9999).default(0),
  isEnabled: z.boolean().default(true),
  showInHeader: z.boolean().default(false),
  showInFooter: z.boolean().default(true),
  showInContact: z.boolean().default(false),
})

// POST — create a new social link
export async function POST(req: NextRequest) {
  const admin = await requireAdmin()
  if (!admin) return jsonError('Unauthorized', 401)
  const check = await requirePermission('store_settings', 'manage_settings')
  if (check instanceof Response) return check

  let body: z.infer<typeof createSchema>
  try {
    body = createSchema.parse(await req.json())
  } catch (e) {
    return jsonError('Invalid data', 400, { error: e instanceof Error ? e.message : 'parse error' })
  }

  // Validate URL is http/https
  try {
    const u = new URL(body.url)
    if (u.protocol !== 'https:' && u.protocol !== 'http:') {
      return jsonError('URL must start with http:// or https://', 400)
    }
  } catch {
    return jsonError('Invalid URL', 400)
  }

  const link = await db.socialLink.create({
    data: {
      platform: body.platform,
      label: body.label || null,
      url: body.url,
      iconKey: body.iconKey || body.platform,
      order: body.order,
      isEnabled: body.isEnabled,
      showInHeader: body.showInHeader,
      showInFooter: body.showInFooter,
      showInContact: body.showInContact,
    },
  })

  revalidateTag('settings')
  revalidateTag('social-links')
  await audit(admin.id, 'social_link.create', 'social_link', link.id, { platform: body.platform }, clientMeta(req))
  return Response.json({ ok: true, link })
}
