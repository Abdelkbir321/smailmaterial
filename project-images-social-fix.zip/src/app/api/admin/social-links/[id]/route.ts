import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { requireAdmin, jsonError, audit, clientMeta } from '@/lib/admin-api'
import { requirePermission } from '@/lib/permissions'
import { revalidateTag } from 'next/cache'
import { z } from 'zod'

export const dynamic = 'force-dynamic'

const updateSchema = z.object({
  platform: z.string().min(1).max(50).optional(),
  label: z.string().max(100).optional().nullable(),
  url: z.string().url().max(500).optional(),
  iconKey: z.string().max(50).optional(),
  order: z.number().int().min(0).max(9999).optional(),
  isEnabled: z.boolean().optional(),
  showInHeader: z.boolean().optional(),
  showInFooter: z.boolean().optional(),
  showInContact: z.boolean().optional(),
})

// PATCH — update a social link
export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const admin = await requireAdmin()
  if (!admin) return jsonError('Unauthorized', 401)
  const check = await requirePermission('store_settings', 'manage_settings')
  if (check instanceof Response) return check

  const { id } = await params
  let body: z.infer<typeof updateSchema>
  try {
    body = updateSchema.parse(await req.json())
  } catch (e) {
    return jsonError('Invalid data', 400, { error: e instanceof Error ? e.message : 'parse error' })
  }

  if (body.url) {
    try {
      const u = new URL(body.url)
      if (u.protocol !== 'https:' && u.protocol !== 'http:') {
        return jsonError('URL must start with http:// or https://', 400)
      }
    } catch {
      return jsonError('Invalid URL', 400)
    }
  }

  const link = await db.socialLink.update({
    where: { id },
    data: body,
  })

  revalidateTag('settings')
  revalidateTag('social-links')
  await audit(admin.id, 'social_link.update', 'social_link', id, body, clientMeta(req))
  return Response.json({ ok: true, link })
}

// DELETE — remove a social link
export async function DELETE(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const admin = await requireAdmin()
  if (!admin) return jsonError('Unauthorized', 401)
  const check = await requirePermission('store_settings', 'manage_settings')
  if (check instanceof Response) return check

  const { id } = await params
  await db.socialLink.delete({ where: { id } })

  revalidateTag('settings')
  revalidateTag('social-links')
  await audit(admin.id, 'social_link.delete', 'social_link', id, {}, clientMeta(req))
  return Response.json({ ok: true })
}
