import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { requireAdmin, audit, clientMeta, jsonError } from '@/lib/admin-api'
import { productInputSchema } from '@/validations'
import { sanitizeHtml, htmlToPlainText } from '@/lib/sanitize'
import { revalidateTag } from 'next/cache'

export const dynamic = 'force-dynamic'

export async function GET(req: NextRequest) {
  const admin = await requireAdmin()
  if (!admin) return jsonError('Unauthorized', 401)

  const { searchParams } = req.nextUrl
  const page = Math.max(1, Number(searchParams.get('page')) || 1)
  const pageSize = Math.min(50, Number(searchParams.get('pageSize')) || 20)
  const status = searchParams.get('status')
  const q = searchParams.get('q')
  const categoryId = searchParams.get('categoryId')

  const where = {
    ...(status ? { status } : {}),
    ...(categoryId ? { categoryId } : {}),
    ...(q
      ? {
          OR: [
            { name: { contains: q, mode: 'insensitive' as const } },
            { sku: { contains: q, mode: 'insensitive' as const } },
            { slug: { contains: q, mode: 'insensitive' as const } },
          ],
        }
      : {}),
  }
  const [items, total] = await Promise.all([
    db.product.findMany({
      where,
      orderBy: { createdAt: 'desc' },
      take: pageSize,
      skip: (page - 1) * pageSize,
      include: {
        category: { select: { name: true } },
        brand: { select: { name: true } },
        images: { where: { isMain: true }, take: 1, select: { secureUrl: true } },
      },
    }),
    db.product.count({ where }),
  ])

  return Response.json({
    ok: true,
    items: items.map((p) => ({
      id: p.id,
      slug: p.slug,
      name: p.name,
      sku: p.sku,
      price: Number(p.price),
      compareAtPrice: p.compareAtPrice ? Number(p.compareAtPrice) : null,
      stockQuantity: p.stockQuantity,
      status: p.status,
      categoryName: p.category?.name ?? null,
      brandName: p.brand?.name ?? null,
      isFeatured: p.isFeatured,
      mainImage: p.images[0]?.secureUrl ?? null,
      createdAt: p.createdAt,
    })),
    total,
    page,
    pageSize,
  })
}

export async function POST(req: NextRequest) {
  const admin = await requireAdmin()
  if (!admin) return jsonError('Unauthorized', 401)
  let body: unknown
  try {
    body = await req.json()
  } catch {
    return jsonError('Requête invalide.')
  }
  const parsed = productInputSchema.safeParse(body)
  if (!parsed.success) {
    const fieldErrors: Record<string, string> = {}
    for (const e of parsed.error.issues) fieldErrors[e.path.join('.')] = e.message
    return Response.json({ ok: false, error: 'Champs invalides', fieldErrors }, { status: 422 })
  }
  const d = parsed.data
  // uniqueness checks
  if (await db.product.findUnique({ where: { slug: d.slug } }))
    return jsonError('Slug déjà utilisé', 409, { slug: 'Slug déjà utilisé' })
  if (await db.product.findUnique({ where: { sku: d.sku } }))
    return jsonError('SKU déjà utilisé', 409, { sku: 'SKU déjà utilisé' })

  // Sanitize user-supplied HTML fields (defense-in-depth against XSS even
  // from a compromised admin account — never trust HTML).
  const description = d.description ? sanitizeHtml(d.description) : null
  const shortDescription = d.shortDescription ? htmlToPlainText(d.shortDescription, 500) : null
  const seoTitle = d.seoTitle ? htmlToPlainText(d.seoTitle, 200) : null
  const seoDescription = d.seoDescription ? htmlToPlainText(d.seoDescription, 300) : null
  const canonicalUrl = d.canonicalUrl || null
  if (canonicalUrl) {
    try {
      const u = new URL(canonicalUrl)
      if (u.protocol !== 'https:' && u.protocol !== 'http:') throw new Error('bad proto')
    } catch {
      return jsonError('Canonical URL غير صالح', 422, { canonicalUrl: 'invalid' })
    }
  }
  if (d.ogImage) {
    try {
      const u = new URL(d.ogImage)
      if (u.protocol !== 'https:' && u.protocol !== 'http:') throw new Error('bad proto')
    } catch {
      return jsonError('OG image URL غير صالح', 422, { ogImage: 'invalid' })
    }
  }

  const product = await db.product.create({
    data: {
      name: d.name,
      slug: d.slug,
      nameAr: d.nameAr || null,
      shortDescription,
      description,
      specifications: d.specifications as any,
      sku: d.sku,
      barcode: d.barcode || null,
      brandId: d.brandId || null,
      categoryId: d.categoryId,
      status: d.status,
      price: d.price,
      compareAtPrice: d.compareAtPrice ?? null,
      costPrice: d.costPrice ?? null,
      currencyCode: d.currencyCode,
      taxRate: d.taxRate ?? null,
      weightKg: d.weightKg ?? null,
      stockQuantity: d.stockQuantity,
      lowStockThreshold: d.lowStockThreshold,
      allowBackorder: d.allowBackorder,
      trackInventory: d.trackInventory,
      isFeatured: d.isFeatured,
      isNewArrival: d.isNewArrival,
      isBestSeller: d.isBestSeller,
      faq: d.faq as any,
      relatedIds: d.relatedIds as any,
      seoTitle,
      seoDescription,
      ogImage: d.ogImage || null,
      canonicalUrl,
      noindex: d.noindex,
      publishedAt: d.status === 'PUBLISHED' ? new Date() : null,
    },
  })
  const meta = clientMeta(req)
  await audit(admin.id, 'product.create', 'product', product.id, { name: product.name, sku: product.sku }, meta)
  revalidateTag('catalog')
  revalidateTag('sitemap')
  return Response.json({ ok: true, product }, { status: 201 })
}
