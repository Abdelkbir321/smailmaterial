import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { requireAdmin, jsonError, audit, clientMeta } from '@/lib/admin-api'
import { requirePermission } from '@/lib/permissions'
import { revalidateTag } from 'next/cache'
import { z } from 'zod'

export const dynamic = 'force-dynamic'

// =========================================================================
// Video URL parser — detects YouTube, Vimeo, and direct video files
// =========================================================================

interface ParsedVideo {
  url: string
  sourceType: 'direct' | 'youtube' | 'vimeo' | 'external'
  embedId: string | null
  valid: boolean
  error?: string
}

function parseVideoUrl(rawUrl: string): ParsedVideo {
  const url = rawUrl.trim()
  if (!url) return { url: '', sourceType: 'external', embedId: null, valid: false, error: 'رابط فارغ' }

  let parsed: URL
  try {
    parsed = new URL(url)
  } catch {
    return { url, sourceType: 'external', embedId: null, valid: false, error: 'رابط غير صالح' }
  }

  if (parsed.protocol !== 'https:' && parsed.protocol !== 'http:') {
    return { url, sourceType: 'external', embedId: null, valid: false, error: 'الرابط لازم يبدأ بـ http(s)://' }
  }

  const host = parsed.hostname.toLowerCase().replace(/^www\./, '')

  // YouTube detection
  if (host === 'youtube.com' || host === 'm.youtube.com' || host === 'youtu.be') {
    let videoId: string | null = null
    if (host === 'youtu.be') {
      videoId = parsed.pathname.slice(1)
    } else if (parsed.pathname === '/watch') {
      videoId = parsed.searchParams.get('v')
    } else if (parsed.pathname.startsWith('/embed/')) {
      videoId = parsed.pathname.slice(7)
    } else if (parsed.pathname.startsWith('/shorts/')) {
      videoId = parsed.pathname.slice(8).split('/')[0]
    }
    if (videoId && /^[a-zA-Z0-9_-]{11}$/.test(videoId)) {
      return { url, sourceType: 'youtube', embedId: videoId, valid: true }
    }
    return { url, sourceType: 'youtube', embedId: null, valid: false, error: 'رابط YouTube غير صالح' }
  }

  // Vimeo detection
  if (host === 'vimeo.com' || host === 'player.vimeo.com') {
    const match = parsed.pathname.match(/\/(\d+)/)
    if (match) {
      return { url, sourceType: 'vimeo', embedId: match[1], valid: true }
    }
    return { url, sourceType: 'vimeo', embedId: null, valid: false, error: 'رابط Vimeo غير صالح' }
  }

  // Direct video file detection
  const path = parsed.pathname.toLowerCase()
  if (path.endsWith('.mp4') || path.endsWith('.webm') || path.endsWith('.ogg') || path.endsWith('.mov') || path.endsWith('.m4v')) {
    return { url, sourceType: 'direct', embedId: null, valid: true }
  }

  // Unknown — treat as external but mark as potentially not playable
  return { url, sourceType: 'external', embedId: null, valid: true }
}

// =========================================================================
// GET — list all images + videos for a product
// =========================================================================

export async function GET(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const admin = await requireAdmin()
  if (!admin) return jsonError('Unauthorized', 401)
  const { id } = await params

  const [images, videos] = await Promise.all([
    db.productImage.findMany({
      where: { productId: id },
      orderBy: { sortOrder: 'asc' },
    }),
    db.productVideo.findMany({
      where: { productId: id },
      orderBy: { sortOrder: 'asc' },
    }),
  ])

  return Response.json({ ok: true, images, videos })
}

// =========================================================================
// PUT — bulk operations: add images, add videos, reorder, set main
// =========================================================================

const putSchema = z.object({
  // Bulk add images from URLs (one per line in the textarea, split by client)
  addImages: z.array(z.object({
    url: z.string().min(1),
    altText: z.string().optional().default(''),
  })).optional(),
  // Bulk add videos from URLs
  addVideos: z.array(z.object({
    url: z.string().min(1),
    title: z.string().optional().default(''),
  })).optional(),
  // Reorder images: array of {id, sortOrder, isMain}
  reorderImages: z.array(z.object({
    id: z.string(),
    sortOrder: z.number().int(),
    isMain: z.boolean(),
  })).optional(),
  // Reorder videos: array of {id, sortOrder}
  reorderVideos: z.array(z.object({
    id: z.string(),
    sortOrder: z.number().int(),
  })).optional(),
  // Delete image by id
  deleteImage: z.string().optional(),
  // Delete video by id
  deleteVideo: z.string().optional(),
  // Update video title
  updateVideoTitle: z.object({
    id: z.string(),
    title: z.string(),
  }).optional(),
})

export async function PUT(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const admin = await requireAdmin()
  if (!admin) return jsonError('Unauthorized', 401)
  const check = await requirePermission('products', 'edit')
  if (check instanceof Response) return check

  const { id } = await params
  const product = await db.product.findUnique({ where: { id } })
  if (!product) return jsonError('المنتج غير موجود', 404)

  let body: z.infer<typeof putSchema>
  try {
    body = putSchema.parse(await req.json())
  } catch (e) {
    return jsonError('بيانات غير صالحة', 400, { error: e instanceof Error ? e.message : 'parse error' })
  }

  const results: { addedImages?: number; addedVideos?: number; errors?: string[] } = {}
  const errors: string[] = []

  // --- Bulk add images ---
  if (body.addImages && body.addImages.length > 0) {
    const existingCount = await db.productImage.count({ where: { productId: id } })
    let added = 0
    for (let i = 0; i < body.addImages.length; i++) {
      const item = body.addImages[i]
      const url = item.url.trim()
      if (!url) continue

      // Validate URL
      try {
        const u = new URL(url)
        if (u.protocol !== 'https:' && u.protocol !== 'http:') {
          errors.push(`صورة ${i + 1}: البروتوكول غير صالح`)
          continue
        }
      } catch {
        errors.push(`صورة ${i + 1}: رابط غير صالح`)
        continue
      }

      // Determine if it's a Cloudinary URL or external
      const isCloudinary = url.includes('res.cloudinary.com')
      const sourceType = isCloudinary ? 'cloudinary' : 'external'

      // First image becomes main if no images exist
      const isMain = existingCount === 0 && added === 0

      await db.productImage.create({
        data: {
          productId: id,
          url,
          secureUrl: url,
          externalUrl: sourceType === 'external' ? url : null,
          sourceType,
          altText: item.altText || null,
          sortOrder: existingCount + added,
          isMain,
        },
      })
      added++
    }
    results.addedImages = added
  }

  // --- Bulk add videos ---
  if (body.addVideos && body.addVideos.length > 0) {
    const existingCount = await db.productVideo.count({ where: { productId: id } })
    let added = 0
    for (let i = 0; i < body.addVideos.length; i++) {
      const item = body.addVideos[i]
      const parsed = parseVideoUrl(item.url)
      if (!parsed.valid) {
        errors.push(`فيديو ${i + 1}: ${parsed.error || 'رابط غير صالح'}`)
        continue
      }

      await db.productVideo.create({
        data: {
          productId: id,
          url: parsed.url,
          sourceType: parsed.sourceType,
          embedId: parsed.embedId,
          title: item.title || null,
          sortOrder: existingCount + added,
        },
      })
      added++
    }
    results.addedVideos = added
  }

  // --- Reorder images ---
  if (body.reorderImages && body.reorderImages.length > 0) {
    // Use a transaction to update all at once
    await db.$transaction(
      body.reorderImages.map((item) =>
        db.productImage.update({
          where: { id: item.id, productId: id },
          data: { sortOrder: item.sortOrder, isMain: item.isMain },
        }),
      ),
    )
  }

  // --- Reorder videos ---
  if (body.reorderVideos && body.reorderVideos.length > 0) {
    await db.$transaction(
      body.reorderVideos.map((item) =>
        db.productVideo.update({
          where: { id: item.id, productId: id },
          data: { sortOrder: item.sortOrder },
        }),
      ),
    )
  }

  // --- Delete image ---
  if (body.deleteImage) {
    await db.productImage.delete({ where: { id: body.deleteImage, productId: id } })
    // If we deleted the main image, make the first remaining image main
    const remaining = await db.productImage.findMany({
      where: { productId: id },
      orderBy: { sortOrder: 'asc' },
    })
    if (remaining.length > 0 && !remaining.some((img) => img.isMain)) {
      await db.productImage.update({
        where: { id: remaining[0].id },
        data: { isMain: true },
      })
    }
  }

  // --- Delete video ---
  if (body.deleteVideo) {
    await db.productVideo.delete({ where: { id: body.deleteVideo, productId: id } })
  }

  // --- Update video title ---
  if (body.updateVideoTitle) {
    await db.productVideo.update({
      where: { id: body.updateVideoTitle.id, productId: id },
      data: { title: body.updateVideoTitle.title || null },
    })
  }

  if (errors.length > 0) results.errors = errors

  revalidateTag('catalog')
  await audit(admin.id, 'product.media_update', 'product', id, results, clientMeta(req))

  return Response.json({ ok: true, ...results })
}
