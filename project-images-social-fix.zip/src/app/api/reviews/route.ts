import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { clientMeta } from '@/lib/admin-api'
import { rateLimitByIp } from '@/lib/rate-limit'
import { revalidateTag } from 'next/cache'
import { getShippingReturnSettings } from '@/services/site-settings'
import { z } from 'zod'

export const dynamic = 'force-dynamic'

/**
 * GET /api/reviews?productId=xxx
 * Returns APPROVED reviews for a product (public list, no PII).
 *
 * The response includes only:
 *   - customerName (display name, not phone/email)
 *   - rating, title, body, createdAt
 *   - isVerified (the "Verified Purchase" badge)
 *   - adminReply (if the admin responded)
 *
 * It does NOT include customerId, orderId, IP, or any other PII.
 */
export async function GET(req: NextRequest) {
  const productId = req.nextUrl.searchParams.get('productId')
  if (!productId) {
    return Response.json({ ok: false, error: 'productId مطلوب.' }, { status: 400 })
  }
  const reviews = await db.review.findMany({
    where: { productId, status: 'APPROVED' },
    orderBy: [{ isVerified: 'desc' }, { createdAt: 'desc' }],
    select: {
      id: true,
      customerName: true,
      rating: true,
      title: true,
      body: true,
      isVerified: true,
      adminReply: true,
      createdAt: true,
    },
    take: 100,
  })
  // Compute the aggregate from the APPROVED reviews only (matches what
  // the Product Schema's aggregateRating will show — single source of truth).
  const ratings = reviews.map((r) => r.rating).filter((r) => r >= 1 && r <= 5)
  const avg = ratings.length > 0 ? ratings.reduce((a, b) => a + b, 0) / ratings.length : 0
  return Response.json({
    ok: true,
    reviews,
    aggregate: {
      ratingValue: Number(avg.toFixed(1)),
      reviewCount: ratings.length,
    },
  })
}

/**
 * POST /api/reviews
 * Submit a new review. Public endpoint (no auth required).
 *
 * Anti-spam measures:
 *   - Rate limit: 3 reviews / 10 min / IP
 *   - Honeypot field: a hidden `website` field that bots fill but humans don't.
 *     If present, we silently drop the submission (return 200 to not tip off the bot).
 *   - Server-side validation: rating 1-5, body 10-2000 chars, name 2-60 chars.
 *
 * Verified Purchase logic:
 *   - If the customer provides an `orderPhone` field, we look up delivered orders
 *     matching that phone + this product. If found → isVerified = true.
 *   - This is OPTIONAL — customers without a verified order can still submit
 *     a review (it just won't have the badge).
 *   - We never store the orderPhone — only use it for the lookup.
 *
 * The review is created with status=PENDING (or APPROVED if the admin disabled
 * `reviewsRequireApproval` in the settings). It will appear on the site only
 * after approval.
 */
const reviewSchema = z.object({
  productId: z.string().min(1),
  customerName: z.string().min(2, 'الاسم قصير جداً').max(60, 'الاسم طويل جداً'),
  rating: z.number().int().min(1, 'التقييم يجب أن يكون بين 1 و 5').max(5, 'التقييم يجب أن يكون بين 1 و 5'),
  title: z.string().max(120).optional().or(z.literal('')),
  body: z.string().min(10, 'التعليق قصير جداً (10 أحرف على الأقل)').max(2000, 'التعليق طويل جداً'),
  // Honeypot — must be empty for a human submission
  website: z.string().optional(),
  // Optional: phone number to verify a delivered order (Verified Purchase badge)
  orderPhone: z.string().max(30).optional().or(z.literal('')),
})

export async function POST(req: NextRequest) {
  // Rate limit: 3 reviews / 10 min / IP
  const meta = clientMeta(req)
  const rl = rateLimitByIp(meta.ip, 'review-submit', 3, 10 * 60 * 1000)
  if (!rl.ok) {
    return Response.json(
      { ok: false, error: 'طلبات كثيرة. حاول بعد قليل.' },
      { status: 429, headers: { 'Retry-After': String(rl.retryAfter) } },
    )
  }

  let body: unknown
  try {
    body = await req.json()
  } catch {
    return Response.json({ ok: false, error: 'JSON غير صالح.' }, { status: 400 })
  }

  const parsed = reviewSchema.safeParse(body)
  if (!parsed.success) {
    const fieldErrors: Record<string, string> = {}
    for (const issue of parsed.error.issues) {
      const key = issue.path.join('.')
      if (!fieldErrors[key]) fieldErrors[key] = issue.message
    }
    return Response.json(
      { ok: false, error: 'تحقق من الحقول.', fieldErrors },
      { status: 422 },
    )
  }
  const data = parsed.data

  // Honeypot — silent drop for bots
  if (data.website && data.website.trim() !== '') {
    // Pretend success so the bot doesn't know it was caught
    return Response.json({ ok: true, reviewId: 'honeypot-caught' }, { status: 201 })
  }

  // Verify the product exists and is PUBLISHED
  const product = await db.product.findUnique({
    where: { id: data.productId },
    select: { id: true, status: true, slug: true },
  })
  if (!product || product.status !== 'PUBLISHED') {
    return Response.json({ ok: false, error: 'المنتج غير موجود.' }, { status: 404 })
  }

  // Check if reviews are enabled
  const settings = await getShippingReturnSettings()
  if (!settings.reviewsEnabled) {
    return Response.json({ ok: false, error: 'التقييمات غير مفعّلة.' }, { status: 403 })
  }

  // Verified Purchase check — optional phone lookup
  let isVerified = false
  let orderId: string | null = null
  let customerId: string | null = null
  if (data.orderPhone && data.orderPhone.trim().length >= 6) {
    const phone = data.orderPhone.trim()
    // Look for a DELIVERED order with this phone that contains this product
    const matchingOrder = await db.order.findFirst({
      where: {
        customerPhone: phone,
        status: 'DELIVERED',
        items: { some: { productId: data.productId } },
      },
      select: { id: true, customerId: true },
      orderBy: { placedAt: 'desc' },
    })
    if (matchingOrder) {
      isVerified = true
      orderId = matchingOrder.id
      customerId = matchingOrder.customerId
    }
  }

  // If no customer was linked via order, try to find/create a customer by name
  // (so we have a stable reference). We do NOT store the phone unless it was
  // used for verification (in which case it's already on the order).
  if (!customerId) {
    const existingCustomer = await db.customer.findFirst({
      where: { fullName: data.customerName },
      select: { id: true },
    })
    if (existingCustomer) {
      customerId = existingCustomer.id
    } else {
      // Create a lightweight customer record (no phone/email — those come from
      // actual orders). This keeps the Review ↔ Customer relation intact.
      const newCustomer = await db.customer.create({
        data: { fullName: data.customerName },
      })
      customerId = newCustomer.id
    }
  }

  // Determine the initial status based on the admin setting
  const initialStatus = settings.reviewsRequireApproval ? 'PENDING' : 'APPROVED'

  // Sanitize free-text inputs (basic XSS prevention — the admin dashboard
  // renders these as text, but defense-in-depth)
  const sanitize = (s: string) => s.replace(/</g, '&lt;').replace(/>/g, '&gt;').slice(0, 2000)

  const review = await db.review.create({
    data: {
      productId: data.productId,
      customerId,
      customerName: data.customerName.trim().slice(0, 60),
      rating: data.rating,
      title: data.title ? sanitize(data.title).slice(0, 120) : null,
      body: sanitize(data.body),
      status: initialStatus,
      isVerified,
      orderId,
    },
  })

  // If the review is auto-approved, update the product's aggregate counters
  if (initialStatus === 'APPROVED') {
    await updateProductRating(data.productId)
  }

  revalidateTag('catalog')

  return Response.json({
    ok: true,
    reviewId: review.id,
    status: review.status,
    isVerified: review.isVerified,
    message: review.status === 'PENDING'
      ? 'شكراً! تقييمك في انتظار المراجعة وسيظهر بعد الموافقة.'
      : 'شكراً! تم نشر تقييمك.',
  }, { status: 201 })
}

/**
 * Recompute and persist the product's aggregate rating + review count.
 * Called after a review is APPROVED or REJECTED (or after deletion).
 *
 * This keeps the Product.rating and Product.reviewCount columns in sync
 * with the actual APPROVED reviews — so the storefront product card can
 * show the average without doing a JOIN on every list page.
 */
export async function updateProductRating(productId: string): Promise<void> {
  const result = await db.review.aggregate({
    where: { productId, status: 'APPROVED' },
    _avg: { rating: true },
    _count: true,
  })
  const avg = result._avg.rating ? Number(result._avg.rating.toFixed(2)) : null
  const count = result._count
  await db.product.update({
    where: { id: productId },
    data: {
      rating: avg,
      reviewCount: count,
    },
  })
}
