import { db } from '@/lib/db'
import { unstable_cache } from 'next/cache'

/**
 * GET /api/redirects — PUBLIC list of active redirects (no auth, no sensitive data).
 * Used by: the admin UI, future edge-function enforcement, and sitemap tools.
 * The data is just {fromPath, toPath, statusCode} — no secrets.
 */
export const revalidate = 60

const getActiveRedirects = unstable_cache(
  async () => {
    try {
      return await db.redirect.findMany({
        where: { isActive: true },
        select: { fromPath: true, toPath: true, statusCode: true },
      })
    } catch {
      return []
    }
  },
  ['redirects-public'],
  { revalidate: 60, tags: ['redirects'] },
)

export async function GET() {
  const redirects = await getActiveRedirects()
  return Response.json({ ok: true, redirects })
}
