import { NextRequest } from 'next/server'
import { resolveCartLines } from '@/services/orders'

export const dynamic = 'force-dynamic'

export async function POST(req: NextRequest) {
  let body: { items?: any[] }
  try {
    body = await req.json()
  } catch {
    return Response.json({ ok: false, error: 'Requête invalide.' }, { status: 400 })
  }
  if (!body.items || !Array.isArray(body.items)) {
    return Response.json({ ok: false, error: 'Panier vide.' }, { status: 400 })
  }
  const resolved = await resolveCartLines(body.items)
  if (!resolved.ok) return Response.json(resolved, { status: 400 })
  const subtotal = resolved.lines.reduce((s, l) => s + l.lineTotal, 0)
  const totalItems = resolved.lines.reduce((s, l) => s + l.quantity, 0)
  return Response.json({
    ok: true,
    lines: resolved.lines,
    subtotal,
    totalItems,
    currencyCode: resolved.lines[0]?.currencyCode ?? 'MAD',
  })
}
