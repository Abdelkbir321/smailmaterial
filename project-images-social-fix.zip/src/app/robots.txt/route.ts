import { NextRequest } from 'next/server'
import { getProductionDomain } from '@/services/settings'

/**
 * Static Route Handler for /robots.txt
 * ====================================
 *
 * Same reasoning as sitemap.xml/route.ts — the Next.js metadata-based
 * robots.ts generates /robots.txt with Vary headers and cache-control
 * that can confuse Google's crawlers.
 *
 * This Route Handler returns clean text/plain with explicit headers.
 */

export const revalidate = 60
export const dynamic = 'force-static'

export async function GET(_req: NextRequest) {
  const siteUrl = await getProductionDomain()
  const sitemapUrl = siteUrl ? `${siteUrl}/sitemap.xml` : null

  // Robots policy
  // -------------
  // ALLOW: storefront pages (/, /produits, /categories, /contact, /aide,
  //         /page/*, product + category detail pages)
  // DISALLOW: admin, API, cart, checkout, confirmation (these are either
  //           private, transactional, or generate session-specific URLs).
  //
  // We do NOT disallow /recherche for Googlebot-Image because Google's image
  // crawler benefits from finding product images via search result pages.
  // For the main Googlebot, /recherche is disallowed to prevent low-value
  // search-result URLs from being indexed.
  //
  // The Host directive is only honored by Yandex (Russian search engine)
  // but it's harmless for other crawlers. We include it for completeness.
  const body = `User-Agent: *
Allow: /
Disallow: /admin
Disallow: /admin/*
Disallow: /api
Disallow: /api/*
Disallow: /cart
Disallow: /cart/*
Disallow: /checkout
Disallow: /checkout/*
Disallow: /confirmation
Disallow: /confirmation/*
Disallow: /recherche
Disallow: /recherche/*
Disallow: /*?*q=
Disallow: /*?*page=

User-Agent: Googlebot
Allow: /
Allow: /produits
Allow: /categories
Allow: /produits/
Allow: /categories/
Disallow: /admin
Disallow: /admin/*
Disallow: /api
Disallow: /api/*
Disallow: /cart
Disallow: /checkout
Disallow: /confirmation
Disallow: /recherche

User-Agent: Googlebot-Image
Allow: /
Allow: /produits
Allow: /categories
Allow: /_next/static/
Allow: /products/
Disallow: /admin
Disallow: /api
${siteUrl ? `Host: ${siteUrl}\n` : ''}${sitemapUrl ? `Sitemap: ${sitemapUrl}\n` : ''}`

  return new Response(body, {
    status: 200,
    headers: {
      'Content-Type': 'text/plain; charset=utf-8',
      'Cache-Control': 'public, max-age=60, s-maxage=60',
      'X-Content-Type-Options': 'nosniff',
    },
  })
}
