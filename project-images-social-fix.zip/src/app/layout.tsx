import type { Metadata, Viewport } from 'next'
import { Geist, Bricolage_Grotesque } from 'next/font/google'
import './globals.css'
import { Toaster } from '@/components/ui/sonner'
import { siteConfig } from '@/config/site'
import { getBranding, getGscVerificationToken } from '@/services/branding'
import { getProductionDomain } from '@/services/settings'
import { getTypography, getDesignSettings, getSocialLinks } from '@/services/site-settings'
import { buildOrganizationSchema, buildWebSiteSchema } from '@/lib/seo-schemas'
import { GoogleAnalytics } from '@/components/analytics/google-analytics'

// Force dynamic rendering so generateMetadata reads fresh branding from DB
// on every request. Without this, the metadata (including favicon, site name,
// OG image) would be computed once at build time and cached — so admin
// changes to favicon/site identity would NOT propagate to the HTML <head>
// until the next rebuild.
export const dynamic = 'force-dynamic'

const geistSans = Geist({
  variable: '--font-geist-sans',
  subsets: ['latin'],
})

// Bricolage Grotesque — display typeface for headlines. Distinctive
// optical sizing (variable font) gives editorial character without
// being a generic system font. Used for h1-h6 via the CSS layer.
const bricolage = Bricolage_Grotesque({
  variable: '--font-display',
  subsets: ['latin'],
  weight: ['400', '500', '600', '700', '800'],
})

/**
 * Async metadata — reads branding & SEO defaults from the DB.
 *
 * ==========================================================================
 * IDENTITY UPGRADE (this version)
 * --------------------------------------------------------------------------
 * - Site name: "Ismail Material" (matches the Z logo + product category)
 * - Tagline: clearer & action-oriented
 * - Description: keyword-rich, still truthful to the actual catalog
 * - Favicon: now references real PNG/ICO files generated from the existing
 *   `public/logo.svg` — covers all major browsers + iOS + Android:
 *     • favicon.ico (multi-resolution 16/32/48)
 *     • favicon-16x16.png, favicon-32x32.png, favicon-48x48.png
 *     • apple-touch-icon.png (180×180, for iOS home screen)
 *     • android-chrome-192x192.png + android-chrome-512x512.png
 *     • icon-192x192.png + icon-512x512.png (referenced from manifest.json)
 * - manifest.json (PWA manifest, links the icon-192/512 PNGs)
 * - OG image: defaults to /og-image.png (1200×630 PNG generated from the logo)
 * - Twitter: summary_large_image card, same image as OG
 *
 * The admin can still override `site_name`, `site_tagline`,
 * `site_description`, `site_logo_url`, `favicon_url`, `og_default_image`
 * from the DB (`site_settings` table, set via /admin/seo and
 * /admin/visual-identity). DB values win over these defaults.
 *
 * ==========================================================================
 * IMPORTANT
 * --------------------------------------------------------------------------
 * When the production domain is NOT configured (preview deployment with
 * no env var, or production with no DB value), `metadataBase` is set to
 * `null` and absolute URLs in OG/canonical fall back to relative paths.
 * We NEVER fabricate a wrong domain.
 */
export async function generateMetadata(): Promise<Metadata> {
  const branding = await getBranding()
  const siteUrl = await getProductionDomain()
  const gscToken = await getGscVerificationToken()

  const title = `${branding.siteName} — ${branding.tagline}`
  const description = branding.description
  // OG image priority:
  //   1. DB-configured og_default_image (admin upload, e.g. branded OG)
  //   2. DB-configured site_logo_url (admin upload of the logo)
  //   3. Static /og-image.png (1200×630 PNG generated from /logo.svg)
  // We always have a value here now — the static file is committed to public/.
  const ogImage = branding.raw.og_default_image || branding.raw.site_logo_url || '/og-image.png'

  const verification: Metadata['verification'] = gscToken
    ? { google: gscToken }
    : undefined

  return {
    metadataBase: siteUrl ? new URL(siteUrl) : null,
    title: {
      default: title,
      template: `%s | ${branding.siteName}`,
    },
    description,
    applicationName: branding.siteName,
    keywords: [
      'outillage',
      'outillage électroportatif',
      'visseuse',
      'perceuse',
      'meuleuse',
      'niveau laser',
      'Maroc',
      'Casablanca',
      'COD',
      'paiement à la livraison',
      'livraison Maroc',
      'INGCO',
      'Total Tools',
      'Crown',
      'Würth',
    ],
    authors: [{ name: branding.siteName }],
    creator: branding.siteName,
    publisher: branding.siteName,
    alternates: { canonical: '/' },
    openGraph: {
      title: branding.raw.og_default_title || title,
      description,
      url: siteUrl ? '/' : undefined,
      siteName: branding.siteName,
      locale: 'fr_MA',
      alternateLocale: ['ar_MA', 'en_US'],
      type: 'website',
      images: [
        {
          url: ogImage,
          width: 1200,
          height: 630,
          alt: branding.siteName,
        },
      ],
    },
    twitter: {
      card: 'summary_large_image',
      title: branding.raw.og_default_title || branding.siteName,
      description,
      images: [ogImage],
    },
    robots: {
      index: true,
      follow: true,
      googleBot: {
        index: true,
        follow: true,
        'max-image-preview': 'large',
        'max-snippet': -1,
        'max-video-preview': -1,
      },
    },
    // === FAVICON + APP ICONS — admin-configurable ===
    // --------------------------------------------------------------------------
    // When the admin uploads a custom favicon via /admin/visual-identity
    // (stored as `favicon_url` in site_settings), we use it as the PRIMARY
    // icon. The `favicon_cache_bust` setting (a timestamp) is appended as
    // ?v=... to bust the browser cache — browsers cache favicons
    // aggressively, so without this the user would see the OLD favicon
    // even after changing it.
    //
    // When NO admin-configured favicon is set, we fall back to the static
    // PNG/ICO files generated from public/logo.svg (see
    // scripts/generate-icons.ts).
    //
    // When admin sets a custom favicon, we use it as the ONLY icon source
    // (no /logo.svg fallback) — some browsers prefer SVG over JPG, which
    // would show the old logo instead of the admin's choice.
    // --------------------------------------------------------------------------
    icons: branding.faviconUrl
      ? (() => {
          // Admin-configured favicon — append cache-bust query param
          const cacheBust = branding.faviconCacheBust
            ? `?v=${branding.faviconCacheBust}`
            : ''
          const favUrl = branding.faviconUrl.includes('?')
            ? branding.faviconUrl
            : `${branding.faviconUrl}${cacheBust}`
          return {
            // Use the admin URL for ALL icon types — no /logo.svg fallback.
            // This ensures the admin's chosen icon shows in every browser.
            icon: [{ url: favUrl, sizes: 'any' }],
            shortcut: favUrl,
            apple: [{ url: favUrl, sizes: '180x180' }],
          }
        })()
      : {
          // Static fallback — admin hasn't configured a custom favicon
          icon: [
            { url: '/favicon.ico', sizes: 'any' },
            { url: '/favicon-16x16.png', sizes: '16x16', type: 'image/png' },
            { url: '/favicon-32x32.png', sizes: '32x32', type: 'image/png' },
            { url: '/favicon-48x48.png', sizes: '48x48', type: 'image/png' },
            { url: '/logo.svg', type: 'image/svg+xml' },
          ],
          shortcut: '/favicon.ico',
          apple: [
            { url: '/apple-touch-icon.png', sizes: '180x180', type: 'image/png' },
          ],
          other: [
            { url: '/android-chrome-192x192.png', sizes: '192x192', type: 'image/png' },
            { url: '/android-chrome-512x512.png', sizes: '512x512', type: 'image/png' },
          ],
        },
    // PWA manifest — enables "Add to home screen" on Android + iOS Safari
    manifest: '/manifest.json',
    appleWebApp: {
      capable: true,
      title: branding.siteName,
      statusBarStyle: 'default',
    },
    // Format detection — disable auto-detection of phone/email/address
    // so the browser doesn't break long phone numbers or emails with
    // unwanted links in the storefront UI.
    formatDetection: {
      telephone: false,
      email: false,
      address: false,
    },
    verification,
  }
}

export const viewport: Viewport = {
  themeColor: '#2D2D2D',
  width: 'device-width',
  initialScale: 1,
  maximumScale: 5,
}

export default async function RootLayout({ children }: { children: React.ReactNode }) {
  const branding = await getBranding()
  const siteUrl = await getProductionDomain()
  const gscToken = await getGscVerificationToken()
  const typography = await getTypography()
  const design = await getDesignSettings()

  // Fetch social links from the SocialLink table (not the legacy flat keys)
  // for use in structured data (orgSchema.sameAs[])
  const allSocialLinks = await getSocialLinks()
  const socialLinksForSchema = allSocialLinks.map((sl) => sl.url).filter(Boolean)

  // Structured data: Organization + WebSite (only when production domain is set).
  // These are rendered ONCE per page here in the root layout. Individual pages
  // (product, category, homepage) render their own schemas (Product,
  // BreadcrumbList, etc.) but MUST NOT re-render Store/WebSite — that would
  // produce duplicate structured data, which Google flags as a parsing error.
  const orgSchema = buildOrganizationSchema(siteUrl, {
    siteName: branding.siteName,
    description: branding.description,
    supportPhone: branding.supportPhone || undefined,
    supportEmail: branding.supportEmail || undefined,
    address: branding.address || undefined,
    logoUrl: branding.logoUrl,
    ogImage: branding.raw.og_default_image || branding.logoUrl,
    sameAs: socialLinksForSchema,
  })

  const websiteSchema = buildWebSiteSchema(siteUrl, {
    siteName: branding.siteName,
    description: branding.description,
  })

  // Build dynamic CSS for typography + design overrides
  const dynamicCss = `
    :root {
      --primary: ${design.primaryColor};
      --primary-hover: ${design.primaryHoverColor};
      --accent: ${design.accentColor};
      --background: ${design.backgroundColor};
      --background-subtle: ${design.backgroundSubtleColor};
      --foreground: ${design.textColor};
      --card: ${design.cardColor};
      --border: ${design.borderColor};
      --radius: ${design.borderRadius}px;
      --font-sans: ${typography.bodyFontLatin};
      --font-display: ${typography.headingFont};
      --btn-px: ${design.buttonPaddingX}px;
      --btn-py: ${design.buttonPaddingY}px;
      --btn-font-size: ${design.buttonFontSize}rem;
      --content-max-width: ${design.contentMaxWidth}px;
      --section-spacing: ${design.sectionSpacing}px;
    }
    body {
      font-family: var(--font-sans);
      font-size: ${typography.bodyFontSize}rem;
      font-weight: ${typography.bodyFontWeight};
      line-height: ${typography.bodyLineHeight};
      letter-spacing: ${typography.bodyLetterSpacing}em;
    }
    h1, h2, h3, h4, h5, h6 {
      font-family: var(--font-display);
      font-weight: ${typography.headingFontWeight};
      line-height: ${typography.headingLineHeight};
      letter-spacing: ${typography.headingLetterSpacing}em;
    }
    [dir="rtl"], [lang="ar"], .font-arabic {
      font-family: ${typography.bodyFontArabic};
    }
    [dir="rtl"] h1, [dir="rtl"] h2, [dir="rtl"] h3, [dir="rtl"] h4, [dir="rtl"] h5, [dir="rtl"] h6 {
      font-family: ${typography.bodyFontArabic};
    }
    button, .btn-primary-cta, .btn-secondary-cta, [data-slot="button"] {
      font-family: ${typography.buttonFont};
    }
    .btn-primary-cta, .btn-secondary-cta {
      padding: var(--btn-py) var(--btn-px);
      font-size: var(--btn-font-size);
    }
  `

  return (
    <html lang="fr" suppressHydrationWarning>
      <body className={`${geistSans.variable} ${bricolage.variable} antialiased bg-background text-foreground font-sans`}>
        {/* Google Fonts (dynamic, loaded with display=swap for performance) */}
        {typography.googleFontsUrl && (
          <link rel="stylesheet" href={typography.googleFontsUrl} />
        )}
        {/* Dynamic CSS overrides for typography + design */}
        <style dangerouslySetInnerHTML={{ __html: dynamicCss }} />
        {orgSchema && (
          <script
            type="application/ld+json"
            dangerouslySetInnerHTML={{ __html: JSON.stringify(orgSchema) }}
          />
        )}
        {websiteSchema && (
          <script
            type="application/ld+json"
            dangerouslySetInnerHTML={{ __html: JSON.stringify(websiteSchema) }}
          />
        )}
        {children}
        <Toaster position="top-center" richColors />
        <GoogleAnalytics />
      </body>
    </html>
  )
}
