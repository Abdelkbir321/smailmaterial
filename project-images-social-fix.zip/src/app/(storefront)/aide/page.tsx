import Link from 'next/link'
import {
  ShoppingCart, Phone, Truck, CreditCard, RotateCcw,
  ChevronRight, ChevronDown, HelpCircle,
} from 'lucide-react'
import { getBranding } from '@/services/branding'
import { getProductionDomain } from '@/services/settings'
import { buildBreadcrumbSchema } from '@/lib/seo-schemas'
import type { Metadata } from 'next'

export const dynamic = 'force-dynamic'

export async function generateMetadata(): Promise<Metadata> {
  const b = await getBranding()
  return {
    title: "Centre d'aide",
    description: `Aide et FAQ — comment commander, paiement, livraison, retours chez ${b.siteName}.`,
    alternates: { canonical: '/aide' },
    robots: { index: true, follow: true },
  }
}

const SECTIONS = [
  {
    title: 'Comment commander',
    icon: ShoppingCart,
    items: [
      { q: 'Comment passer une commande ?', a: "Ajoutez les produits au panier, remplissez le formulaire de commande (nom, téléphone, adresse), puis cliquez sur « Confirmer la commande ». Aucun compte n'est nécessaire." },
      { q: 'Dois-je créer un compte ?', a: 'Non. La commande se fait sans inscription. Indiquez simplement vos coordonnées de livraison.' },
      { q: 'Puis-je modifier ma commande après validation ?', a: "Contactez-nous rapidement par téléphone ou WhatsApp. Tant que la commande n'est pas expédiée, nous pouvons l'ajuster." },
    ],
  },
  {
    title: 'Paiement',
    icon: CreditCard,
    items: [
      { q: 'Quels modes de paiement acceptez-vous ?', a: 'Paiement à la livraison (Cash on Delivery). Vous payez en espèces au livreur à la réception de votre colis.' },
      { q: 'Le paiement en ligne est-il disponible ?', a: 'Le paiement par carte sera disponible prochainement. Actuellement, seul le paiement à la livraison est proposé.' },
    ],
  },
  {
    title: 'Livraison & Suivi',
    icon: Truck,
    items: [
      { q: 'Quels sont les délais de livraison ?', a: 'Livraison sous 24–72h dans les grandes villes, 2–5 jours en zone rurale. Les frais démarrent à 30 DH et la livraison est gratuite à partir de 500 DH.' },
      { q: 'Comment suivre ma commande ?', a: 'Après confirmation, vous recevrez un appel de notre équipe. Vous pouvez aussi nous contacter avec votre numéro de commande.' },
      { q: 'Livrez-vous partout au Maroc ?', a: 'Oui, nous livrons dans toutes les villes du Maroc. Les délais peuvent varier selon votre région.' },
    ],
  },
  {
    title: 'Retours & Remboursement',
    icon: RotateCcw,
    items: [
      { q: 'Puis-je retourner un produit ?', a: "Oui, sous 7 jours après réception, si le produit est intact et dans son emballage d'origine. Contactez-nous pour initier le retour." },
      { q: 'Comment se fait le remboursement ?', a: "Le remboursement s'effectue en espèces ou par virement, selon le cas, après réception et vérification du produit retourné." },
    ],
  },
]

export default async function HelpPage() {
  const b = await getBranding()
  const phoneHref = b.supportPhone.replace(/[\s()-]/g, '')

  const siteUrl = await getProductionDomain()
  const breadcrumbSchema = buildBreadcrumbSchema(siteUrl, [
    { name: 'Accueil', path: '/' },
    { name: 'Aide', path: '/aide' },
  ])

  return (
    <div className="mx-auto max-w-4xl px-4 py-10 sm:py-14">
      {breadcrumbSchema && (
        <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbSchema) }} />
      )}
      {/* Breadcrumb */}
      <nav className="flex items-center gap-1.5 text-xs text-muted-foreground">
        <Link href="/" className="transition-colors hover:text-foreground">Accueil</Link>
        <ChevronRight className="h-3 w-3" />
        <span className="text-foreground">Aide</span>
      </nav>

      {/* Header */}
      <header className="mt-4 border-b border-border pb-8">
        <span className="kicker">Centre d'aide</span>
        <h1 className="mt-3 font-display text-3xl font-bold tracking-tight sm:text-4xl">
          Centre d'aide
        </h1>
        <p className="mt-2 text-sm text-muted-foreground">
          Tout ce que vous devez savoir pour commander en toute confiance.
        </p>
      </header>

      {/* Quick links — 3 cards */}
      <div className="mt-8 grid gap-4 sm:grid-cols-3">
        <Link
          href="/produits"
          className="card-hover group flex flex-col items-center rounded-3xl border border-border bg-card p-6 text-center shadow-[var(--shadow-xs)]"
        >
          <span className="grid size-12 place-items-center rounded-2xl bg-muted text-primary transition-transform duration-300 group-hover:scale-110">
            <ShoppingCart className="h-5 w-5" strokeWidth={1.5} />
          </span>
          <p className="mt-3 font-display text-sm font-semibold tracking-tight">Voir le catalogue</p>
        </Link>
        {phoneHref && (
          <a
            href={`tel:${phoneHref}`}
            className="card-hover group flex flex-col items-center rounded-3xl border border-border bg-card p-6 text-center shadow-[var(--shadow-xs)]"
          >
            <span className="grid size-12 place-items-center rounded-2xl bg-muted text-primary transition-transform duration-300 group-hover:scale-110">
              <Phone className="h-5 w-5" strokeWidth={1.5} />
            </span>
            <p className="mt-3 font-display text-sm font-semibold tracking-tight">Appeler le support</p>
          </a>
        )}
        <Link
          href="/contact"
          className="card-hover group flex flex-col items-center rounded-3xl border border-border bg-card p-6 text-center shadow-[var(--shadow-xs)]"
        >
          <span className="grid size-12 place-items-center rounded-2xl bg-muted text-primary transition-transform duration-300 group-hover:scale-110">
            <HelpCircle className="h-5 w-5" strokeWidth={1.5} />
          </span>
          <p className="mt-3 font-display text-sm font-semibold tracking-tight">Nous contacter</p>
        </Link>
      </div>

      {/* FAQ sections */}
      <div className="mt-10 space-y-8">
        {SECTIONS.map((section) => (
          <section key={section.title}>
            <div className="mb-3 flex items-center gap-3">
              <span className="grid size-9 place-items-center rounded-full bg-muted text-primary">
                <section.icon className="h-4 w-4" strokeWidth={1.6} />
              </span>
              <h2 className="font-display text-lg font-bold tracking-tight">{section.title}</h2>
            </div>
            <div className="divide-y divide-border border-y border-border">
              {section.items.map((item) => (
                <details key={item.q} className="group py-4">
                  <summary className="flex cursor-pointer list-none items-center justify-between font-display text-sm font-medium text-foreground">
                    {item.q}
                    <ChevronDown className="h-4 w-4 text-muted-foreground transition-transform group-open:rotate-180" />
                  </summary>
                  <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{item.a}</p>
                </details>
              ))}
            </div>
          </section>
        ))}
      </div>

      {/* CTA */}
      <div className="mt-10 rounded-3xl border border-border bg-secondary p-6 text-center">
        <p className="font-display text-sm font-semibold text-secondary-foreground">
          Vous ne trouvez pas la réponse à votre question ?
        </p>
        <Link
          href="/contact"
          className="mt-2 inline-flex items-center gap-1 text-sm font-medium text-accent transition-colors hover:text-primary"
        >
          Contactez notre équipe <ChevronRight className="h-4 w-4" />
        </Link>
      </div>
    </div>
  )
}
