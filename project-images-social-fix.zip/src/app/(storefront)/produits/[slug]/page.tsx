import Link from 'next/link'
import { notFound } from 'next/navigation'
import {
  Check, ChevronRight, ShieldCheck, Truck, CreditCard, Star,
  ChevronDown, Package,
} from 'lucide-react'
import { getProductBySlug, getRelatedProducts, getCategories } from '@/services/catalog'
import { ProductGallery } from '@/components/storefront/product-gallery'
import { ProductCard } from '@/components/storefront/product-card'
import { AddToCartSection } from '@/components/storefront/add-to-cart-section'
import { ViewItemTracker } from '@/components/storefront/view-item-tracker'
import { ProductReviews } from '@/components/storefront/product-reviews'
import { formatPrice, discountPercent } from '@/lib/format'
import { siteConfig } from '@/config/site'
import { getProductionDomain } from '@/services/settings'
import { getShippingInfoForSchema, getReturnPolicyForSchema, getFallbackBrandSetting } from '@/services/site-settings'
import { getBranding } from '@/services/branding'
import {
  buildProductSchema,
  buildBreadcrumbSchema,
} from '@/lib/seo-schemas'
import type { Metadata } from 'next'

export const revalidate = 60

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> {
  const { slug } = await params
  const product = await getProductBySlug(slug)
  if (!product) return { title: 'Produit introuvable' }
  const title = product.seoTitle || product.name
  const description = product.seoDescription || product.shortDescription || siteConfig.description
  const image = product.ogImage || product.images[0]?.secureUrl || product.images[0]?.url
  const siteUrl = await getProductionDomain()
  const url = siteUrl ? `${siteUrl}/produits/${product.slug}` : undefined
  return {
    title,
    description,
    alternates: { canonical: product.canonicalUrl || url || `/produits/${product.slug}` },
    robots: product.noindex ? { index: false, follow: false } : { index: true, follow: true },
    openGraph: {
      title,
      description,
      url,
      images: image ? [{ url: image, width: 800, height: 800, alt: product.name }] : undefined,
      type: 'website',
    },
    twitter: { card: 'summary_large_image', title, description, images: image ? [image] : undefined },
  }
}

/**
 * Product detail page — immersive editorial layout.
 *
 * DESIGN INTENT
 * -------------
 * - Two-column hero: gallery LEFT, info RIGHT (sticky on desktop).
 * - Brand name as "kicker" eyebrow above title
 * - Big display headline for the product name
 * - Price + compareAt + discount badge all on one row, clear hierarchy
 * - Stock status as a refined pill (not bright red/yellow)
 * - COD info as a 3-column "trust band" below the add-to-cart
 * - Description + Specs as a 2-column section, specs in a clean dl
 * - FAQ accordion
 * - Related products at the bottom
 *
 * The redesigned ProductGallery (already in the project) handles the
 * image carousel — we keep it intact, just styled to match.
 */
export default async function ProductPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params
  const product = await getProductBySlug(slug)
  if (!product) notFound()
  const related = await getRelatedProducts(product.id, 4)

  const price = Number(product.price)
  const compare = product.compareAtPrice ? Number(product.compareAtPrice) : null
  const discount = discountPercent(price, compare)
  const outOfStock = product.trackInventory && !product.allowBackorder && product.stockQuantity <= 0
  const lowStock = product.trackInventory && !outOfStock && product.stockQuantity <= product.lowStockThreshold
  const currency = { code: product.currencyCode, symbol: 'DH', locale: 'fr-MA' }

  const specs = Array.isArray(product.specifications) ? product.specifications : []
  const faq = Array.isArray(product.faq) ? product.faq : []

  const siteUrl = await getProductionDomain()
  const productUrl = siteUrl ? `${siteUrl}/produits/${product.slug}` : ''

  // ─── Shipping + return policy (DB-backed, single source of truth) ────
  // These come from /admin/settings (checkout tab) and are stored in the
  // `shipping_return_settings` site_settings key. They MUST match the
  // policy published on /page/livraison-retours — and they do, because
  // that page reads from the same settings.
  //
  // When the admin changes these, the structured data on EVERY product
  // page updates automatically (60s revalidate on the settings cache).
  const shippingInfo = await getShippingInfoForSchema()
  const returnPolicy = await getReturnPolicyForSchema()

  // ─── Fallback brand setting ────────────────────────────────────────
  // When a product has no real brand AND the admin enabled the fallback,
  // use the store name as the brand. This addresses Google's "Missing
  // brand identifier" warning without fabricating a manufacturer brand.
  const useFallbackBrand = await getFallbackBrandSetting()
  const branding = useFallbackBrand ? await getBranding() : null
  const fallbackBrandName = branding?.siteName

  // ─── Build schemas via the central helper ────────────────────────
  // `visibleReviews` = APPROVED reviews rendered on the page. We pass
  // this to the helper so it only emits `aggregateRating` when there
  // are real, visible reviews (Google policy: ratings must be visible).
  const visibleReviews = product.reviews || []
  const productSchema = buildProductSchema(
    product,
    siteUrl,
    shippingInfo,
    returnPolicy,
    visibleReviews,
    fallbackBrandName,
  )

  const breadcrumbSchema = buildBreadcrumbSchema(siteUrl, [
    { name: 'Accueil', path: '/' },
    { name: 'Produits', path: '/produits' },
    ...(product.category
      ? [{ name: product.category.name, path: `/categories/${product.category.slug}` }]
      : []),
    { name: product.name, path: `/produits/${product.slug}` },
  ])

  const faqSchema = faq.length
    ? {
        '@context': 'https://schema.org',
        '@type': 'FAQPage',
        mainEntity: faq.map((f: any) => ({
          '@type': 'Question',
          name: f.q,
          acceptedAnswer: { '@type': 'Answer', text: f.a },
        })),
      }
    : null

  return (
    <>
      <ViewItemTracker
        productSlug={product.slug}
        productName={product.name}
        price={price}
        productId={product.id}
        currency={product.currencyCode}
      />
      {productSchema && (
        <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(productSchema) }} />
      )}
      {breadcrumbSchema && (
        <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbSchema) }} />
      )}
      {faqSchema && <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(faqSchema) }} />}

      <div className="mx-auto max-w-7xl px-4 py-8">
        {/* Breadcrumbs */}
        <nav className="flex flex-wrap items-center gap-1.5 text-xs text-muted-foreground" aria-label="Fil d'Ariane">
          <Link href="/" className="transition-colors hover:text-foreground">Accueil</Link>
          <ChevronRight className="h-3 w-3" />
          <Link href="/produits" className="transition-colors hover:text-foreground">Produits</Link>
          {product.category && (
            <>
              <ChevronRight className="h-3 w-3" />
              <Link href={`/categories/${product.category.slug}`} className="transition-colors hover:text-foreground">
                {product.category.name}
              </Link>
            </>
          )}
          <ChevronRight className="h-3 w-3" />
          <span className="text-foreground">{product.name}</span>
        </nav>

        {/* Hero — gallery LEFT, info RIGHT (sticky) */}
        <div className="mt-6 grid gap-8 lg:grid-cols-2 lg:gap-12">
          <div className="lg:sticky lg:top-32 lg:self-start">
            <ProductGallery images={product.images} videos={product.videos || []} name={product.name} />
          </div>

          <div className="fade-in">
            {/* Brand kicker */}
            {product.brand && (
              <Link
                href={`/categories?brand=${product.brand.slug}`}
                className="kicker transition-colors hover:text-primary"
              >
                {product.brand.name}
              </Link>
            )}

            {/* Product title */}
            <h1 className="mt-3 font-display font-bold leading-tight tracking-tight text-foreground"
              style={{ fontSize: 'var(--text-2xl)' }}
            >
              {product.name}
            </h1>

            {/* Rating */}
            {product.rating && product.reviewCount > 0 && (
              <div className="mt-3 flex items-center gap-2 text-sm">
                <span className="flex">
                  {Array.from({ length: 5 }).map((_, i) => (
                    <Star key={i} className={cnStar(i, Number(product.rating))} />
                  ))}
                </span>
                <span className="text-muted-foreground">
                  {product.rating.toFixed(1)} · {product.reviewCount} avis
                </span>
              </div>
            )}

            {/* Price + SKU + discount */}
            <div className="mt-5 flex flex-wrap items-end gap-3">
              <span className="font-display price-display font-bold tracking-tight text-foreground"
                style={{ fontSize: 'var(--text-xl)' }}
              >
                {formatPrice(price, currency)}
              </span>
              {compare && (
                <span className="text-muted-foreground/60 line-through"
                  style={{ fontSize: 'var(--text-base)' }}
                >
                  {formatPrice(compare, currency)}
                </span>
              )}
              {discount && (
                <span className="rounded-full bg-primary px-2.5 py-1 text-xs font-bold text-primary-foreground shadow-[var(--shadow-xs)]">
                  −{discount}%
                </span>
              )}
            </div>
            <p className="mt-1.5 text-xs text-muted-foreground">
              <span className="font-mono">Réf: {product.sku}</span>
            </p>

            {/* Stock status pill */}
            <div className="mt-5">
              {outOfStock ? (
                <span className="inline-flex items-center gap-1.5 rounded-full border border-destructive/30 bg-destructive/5 px-3 py-1 text-sm font-medium text-destructive">
                  Rupture de stock
                </span>
              ) : lowStock ? (
                <span className="inline-flex items-center gap-1.5 rounded-full border border-accent/30 bg-accent/10 px-3 py-1 text-sm font-medium text-accent">
                  Stock limité — {product.stockQuantity} restant
                </span>
              ) : (
                <span className="inline-flex items-center gap-1.5 rounded-full border border-success/30 bg-success/10 px-3 py-1 text-sm font-medium text-success">
                  <Check className="h-3.5 w-3.5" /> En stock
                </span>
              )}
            </div>

            {/* Short description */}
            {product.shortDescription && (
              <p className="product-short-desc mt-5">
                {product.shortDescription}
              </p>
            )}

            {/* Add to cart */}
            <div className="mt-7">
              <AddToCartSection
                product={{
                  id: product.id,
                  slug: product.slug,
                  name: product.name,
                  sku: product.sku,
                  price: Number(product.price),
                  currencyCode: product.currencyCode,
                  stockQuantity: product.stockQuantity,
                  lowStockThreshold: product.lowStockThreshold,
                  trackInventory: product.trackInventory,
                  allowBackorder: product.allowBackorder,
                  images: product.images.map((i) => ({
                    secureUrl: i.secureUrl,
                    url: i.url,
                  })),
                }}
              />
            </div>

            {/* Trust band — COD info */}
            <div className="mt-6 grid grid-cols-3 divide-x divide-border rounded-2xl border border-border bg-card/40 p-4">
              {[
                { icon: CreditCard, t: 'COD', s: 'Paiement à la livraison' },
                { icon: Truck, t: 'Livraison', s: '24–72h au Maroc' },
                { icon: ShieldCheck, t: 'Garantie', s: 'Produit authentique' },
              ].map((c) => (
                <div key={c.t} className="flex flex-col items-center gap-1 px-2 text-center">
                  <c.icon className="h-5 w-5 text-accent" strokeWidth={1.5} />
                  <span className="font-display text-sm font-semibold tracking-tight">{c.t}</span>
                  <span className="text-[11px] text-muted-foreground">{c.s}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Description + Specs section */}
        <div className="mt-12 grid gap-8 border-t border-border pt-8 sm:mt-16 sm:gap-10 sm:pt-12 lg:grid-cols-3">
          <div className="lg:col-span-2">
            <span className="section-label">Description</span>
            <h2 className="mt-3 font-display font-bold tracking-tight"
              style={{ fontSize: 'var(--text-xl)' }}
            >
              Détails du produit
            </h2>
            {product.description ? (
              <div className="product-description mt-5 whitespace-pre-line">
                {product.description}
              </div>
            ) : (
              <p className="mt-5 text-sm text-muted-foreground/60">Aucune description disponible.</p>
            )}
          </div>
          <div>
            <span className="section-label">Spécifications</span>
            <h2 className="mt-3 font-display font-bold tracking-tight"
              style={{ fontSize: 'var(--text-xl)' }}
            >
              Caractéristiques
            </h2>
            {specs.length > 0 ? (
              <dl className="mt-5 divide-y divide-border rounded-2xl border border-border bg-card overflow-hidden">
                {specs.map((s: any, i: number) => (
                  <div key={i} className="flex justify-between gap-4 px-4 py-3">
                    <dt className="text-xs uppercase tracking-wider text-muted-foreground">{s.key}</dt>
                    <dd className="text-right font-mono font-medium text-foreground" style={{ fontSize: 'var(--text-sm)' }}>{s.value}</dd>
                  </div>
                ))}
              </dl>
            ) : (
              <p className="mt-5 text-sm text-muted-foreground/60">Aucune spécification.</p>
            )}
          </div>
        </div>

        {/* FAQ */}
        {faq.length > 0 && (
          <div className="mt-12 border-t border-border pt-8 sm:mt-16 sm:pt-12">
            <div className="mb-6">
              <span className="section-label">FAQ</span>
              <h2 className="mt-3 font-display font-bold tracking-tight"
                style={{ fontSize: 'var(--text-xl)' }}
              >
                Questions fréquentes
              </h2>
            </div>
            <div className="divide-y divide-border border-y border-border">
              {faq.map((f: any, i: number) => (
                <details key={i} className="group py-5">
                  <summary className="flex cursor-pointer list-none items-center justify-between font-display font-medium text-foreground" style={{ fontSize: 'var(--text-base)' }}>
                    {f.q}
                    <ChevronDown className="h-4 w-4 text-muted-foreground transition-transform group-open:rotate-180" />
                  </summary>
                  <p className="mt-3 leading-relaxed text-muted-foreground" style={{ fontSize: 'var(--text-sm)' }}>{f.a}</p>
                </details>
              ))}
            </div>
          </div>
        )}

        {/* Reviews — server-rendered APPROVED reviews + client-side submission form.
            The ProductReviews component receives the initial APPROVED reviews
            (server-side) for SEO and fast first paint, then takes over for
            interactive submission + list refresh. */}
        <ProductReviews
          productId={product.id}
          productName={product.name}
          initialReviews={product.reviews.map((r) => ({
            id: r.id,
            customerName: r.customerName,
            rating: r.rating,
            title: r.title,
            body: r.body,
            isVerified: r.isVerified,
            adminReply: r.adminReply,
            createdAt: r.createdAt.toISOString(),
          }))}
          initialAggregate={{
            ratingValue: product.rating ? Number(product.rating) : 0,
            reviewCount: product.reviewCount || 0,
          }}
        />

        {/* Related products */}
        {related.length > 0 && (
          <div className="mt-12 border-t border-border pt-8 sm:mt-16 sm:pt-12">
            <div className="mb-6 flex items-end justify-between">
              <div>
                <span className="section-label">Suggestions</span>
                <h2 className="mt-3 font-display font-bold tracking-tight"
                  style={{ fontSize: 'var(--text-xl)' }}
                >
                  Produits similaires
                </h2>
              </div>
              <Link
                href="/produits"
                className="inline-flex items-center gap-1.5 text-sm font-medium text-muted-foreground transition-colors hover:text-primary"
              >
                <Package className="h-4 w-4" strokeWidth={1.6} /> Voir tout
              </Link>
            </div>
            <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
              {related.map((p) => <ProductCard key={p.id} product={p} />)}
            </div>
          </div>
        )}
      </div>
    </>
  )
}

function cnStar(i: number, rating: number): string {
  const full = Math.floor(rating)
  return i < full ? 'h-4 w-4 text-accent fill-accent' : 'h-4 w-4 text-muted-foreground/40'
}
