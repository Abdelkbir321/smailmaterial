import Link from 'next/link'
import { notFound } from 'next/navigation'
import { CheckCircle2, Truck, Phone, ArrowRight, MessageCircle, Package, Clock } from 'lucide-react'
import { db } from '@/lib/db'
import { formatPrice } from '@/lib/format'
import { Button } from '@/components/ui/button'
import { getBranding } from '@/services/branding'
import { getPublicSettings } from '@/services/settings'
import type { Metadata } from 'next'

/**
 * Order confirmation page — "Thank you" experience.
 *
 * All text content is admin-configurable via /admin/thank-you-settings.
 * Settings are stored in site_settings table and read server-side.
 * WhatsApp number + message are also configurable, with variable
 * substitution ({order_id}, {customer_name}, {customer_phone}, {order_total}).
 *
 * SECURITY: requires idempotencyKey matching the order's stored key.
 */

export const metadata: Metadata = {
  robots: { index: false, follow: false, googleBot: { index: false, follow: false } },
  title: 'تأكيد الطلب',
}
export const dynamic = 'force-dynamic'

interface ThankYouConfig {
  title: string
  message: string
  successText: string
  tips: string
  whatsappButtonText: string
  storeButtonText: string
  showWhatsappButton: boolean
  showStoreButton: boolean
  showTips: boolean
  whatsappNumber: string
  whatsappMessage: string
  bgColor: string
  accentColor: string
}

const DEFAULT_CONFIG: ThankYouConfig = {
  title: 'شكراً على ثقتكم بنا!',
  message: 'تم تسجيل طلبكم بنجاح. غادي يتاصل بكم فريق خدمة العملاء خلال 24 ساعة لتأكيد الطلب ومراجعة معلومات التوصيل معكم.',
  successText: 'تم التسجيل',
  tips: '• سيتصل بك فريقنا خلال 24 ساعة لتأكيد الطلب.\n• سيتم تجهيز الطلب بعد تأكيد المعلومات.\n• التوصيل عادةً خلال 24–72 ساعة بعد التأكيد.',
  whatsappButtonText: 'تواصل عبر واتساب',
  storeButtonText: 'العودة إلى التسوق',
  showWhatsappButton: true,
  showStoreButton: true,
  showTips: true,
  whatsappNumber: '',
  whatsappMessage: 'السلام عليكم، بغيت نتأكد من الطلب ديالي من موقع Ismail Material.\nرقم الطلب: {order_id}\nالاسم: {customer_name}',
  bgColor: '',
  accentColor: '',
}

function loadThankYouConfig(settings: Record<string, string>): ThankYouConfig {
  return {
    title: settings.thank_you_title || DEFAULT_CONFIG.title,
    message: settings.thank_you_message || DEFAULT_CONFIG.message,
    successText: settings.thank_you_success_text || DEFAULT_CONFIG.successText,
    tips: settings.thank_you_tips || DEFAULT_CONFIG.tips,
    whatsappButtonText: settings.thank_you_whatsapp_button_text || DEFAULT_CONFIG.whatsappButtonText,
    storeButtonText: settings.thank_you_store_button_text || DEFAULT_CONFIG.storeButtonText,
    showWhatsappButton: settings.thank_you_show_whatsapp_button !== 'false',
    showStoreButton: settings.thank_you_show_store_button !== 'false',
    showTips: settings.thank_you_show_tips !== 'false',
    whatsappNumber: settings.thank_you_whatsapp_number || '',
    whatsappMessage: settings.thank_you_whatsapp_message || DEFAULT_CONFIG.whatsappMessage,
    bgColor: settings.thank_you_bg_color || '',
    accentColor: settings.thank_you_accent_color || '',
  }
}

/**
 * Substitute order variables in the WhatsApp message.
 * {order_id}, {customer_name}, {customer_phone}, {order_total}
 * If a value is not available, the variable is removed (not shown literally).
 */
function substituteVariables(
  text: string,
  order: { number: string; customerFullName: string; customerPhone: string; total: string; currencyCode: string }
): string {
  const currencySymbol = order.currencyCode === 'MAD' ? 'درهم' : order.currencyCode
  return text
    .replace(/\{order_id\}/g, order.number)
    .replace(/\{customer_name\}/g, order.customerFullName || '')
    .replace(/\{customer_phone\}/g, order.customerPhone || '')
    .replace(/\{order_total\}/g, `${order.total} ${currencySymbol}`)
    // Clean up empty lines that might result from missing values
    .replace(/\n\s*\n\s*\n/g, '\n\n')
    .trim()
}

export default async function ConfirmationPage({
  params,
  searchParams,
}: {
  params: Promise<{ number: string }>
  searchParams: Promise<{ key?: string }>
}) {
  const { number } = await params
  const { key } = await searchParams

  // Fetch the order with items + country
  const order = await db.order.findUnique({
    where: { number },
    include: { items: true, country: true },
  })

  // Security: require matching idempotency key
  if (!order || !key || (order.idempotencyKey && order.idempotencyKey !== key)) {
    notFound()
  }

  // Legacy orders (null idempotencyKey) — allow viewing within 1 hour
  if (!order.idempotencyKey) {
    const placedAt = new Date(order.placedAt).getTime()
    const oneHour = 60 * 60 * 1000
    if (Date.now() - placedAt > oneHour) {
      notFound()
    }
  }

  // Fetch branding + thank you settings
  const [branding, publicSettings] = await Promise.all([
    getBranding(),
    getPublicSettings().catch(() => ({}) as Record<string, string>),
  ])
  const config = loadThankYouConfig(publicSettings)

  const currency = {
    code: order.currencyCode,
    symbol: order.country.currencySymbol,
    locale: 'fr-MA',
  }

  // Build WhatsApp URL
  // Priority: thank_you_whatsapp_number > branding.whatsapp > branding.supportPhone
  const waNumberRaw = config.whatsappNumber || branding.whatsapp || branding.supportPhone || ''
  const waNumber = waNumberRaw.replace(/[^\d]/g, '')

  // Substitute order variables in the WhatsApp message
  const personalizedMessage = substituteVariables(
    config.whatsappMessage,
    {
      number: order.number,
      customerFullName: order.customerFullName,
      customerPhone: order.customerPhone,
      total: Number(order.total).toString(),
      currencyCode: order.currencyCode,
    }
  )

  const waUrl = (config.showWhatsappButton && waNumber)
    ? `https://wa.me/${waNumber}?text=${encodeURIComponent(personalizedMessage)}`
    : null

  // Inline styles for custom colors (if set)
  const pageStyle: React.CSSProperties = {}
  if (config.bgColor && /^#([0-9a-fA-F]{3}|[0-9a-fA-F]{6})$/.test(config.bgColor)) {
    pageStyle.backgroundColor = config.bgColor
  }
  const accentStyle: React.CSSProperties = {}
  if (config.accentColor && /^#([0-9a-fA-F]{3}|[0-9a-fA-F]{6})$/.test(config.accentColor)) {
    accentStyle.color = config.accentColor
    accentStyle.borderColor = config.accentColor
  }

  // Parse tips into lines
  const tipsLines = config.tips.split('\n').filter((l) => l.trim())

  return (
    <div className="mx-auto max-w-2xl px-4 py-10 sm:py-14" dir="rtl" style={pageStyle}>
      {/* Success header */}
      <div className="text-center">
        <div className="mx-auto grid size-20 place-items-center rounded-full bg-success/10 text-success shadow-[var(--shadow-md)]">
          <CheckCircle2 className="h-12 w-12" strokeWidth={1.4} />
        </div>
        <h1 className="mt-5 font-display text-2xl font-bold tracking-tight text-foreground sm:text-3xl">
          {config.title}
        </h1>
        <p className="mt-3 text-sm leading-relaxed text-muted-foreground sm:text-base whitespace-pre-line">
          {config.message}
        </p>
        <div className="mt-5 inline-flex items-center gap-2 rounded-full border border-border bg-card px-4 py-2 shadow-[var(--shadow-xs)]">
          <Package className="h-4 w-4 text-accent" strokeWidth={1.5} style={accentStyle} />
          <span className="text-sm text-muted-foreground">رقم الطلب:</span>
          <span className="font-mono font-bold text-foreground" dir="ltr">{order.number}</span>
        </div>
      </div>

      {/* Order summary card */}
      <div className="mt-8 rounded-3xl border border-border bg-card p-5 shadow-[var(--shadow-sm)] sm:p-6">
        <div className="flex items-center justify-between border-b border-border pb-3">
          <h2 className="font-display text-base font-bold tracking-tight">ملخص الطلب</h2>
          <span className="rounded-full bg-success/10 px-2.5 py-0.5 text-xs font-medium text-success">
            {config.successText}
          </span>
        </div>

        {/* Items */}
        <div className="mt-4 divide-y divide-border">
          {order.items.map((it) => (
            <div key={it.id} className="flex items-start gap-3 py-3">
              <div className="size-14 flex-shrink-0 overflow-hidden rounded-xl bg-muted">
                {it.productImage && (
                  <img src={it.productImage} alt={it.productName} className="h-full w-full object-cover" />
                )}
              </div>
              <div className="flex-1 min-w-0">
                <p className="font-display text-sm font-medium text-foreground line-clamp-2">{it.productName}</p>
                {it.variantName && (
                  <p className="mt-0.5 text-xs text-muted-foreground">{it.variantName}</p>
                )}
                <p className="mt-0.5 text-xs text-muted-foreground">الكمية: {it.quantity}</p>
              </div>
              <p className="price-display text-sm font-medium text-foreground whitespace-nowrap">
                {formatPrice(Number(it.lineTotal), currency)}
              </p>
            </div>
          ))}
        </div>

        {/* Totals */}
        <dl className="mt-4 space-y-1.5 border-t border-border pt-4 text-sm">
          <div className="flex justify-between">
            <dt className="text-muted-foreground">المجموع الفرعي</dt>
            <dd className="price-display tabular-nums">{formatPrice(Number(order.subtotal), currency)}</dd>
          </div>
          <div className="flex justify-between">
            <dt className="text-muted-foreground">الشحن</dt>
            <dd className="price-display tabular-nums">
              {Number(order.shippingCost) === 0 ? 'مجاني' : formatPrice(Number(order.shippingCost), currency)}
            </dd>
          </div>
          {Number(order.discountTotal) > 0 && (
            <div className="flex justify-between text-success">
              <dt>الخصم</dt>
              <dd className="price-display tabular-nums">-{formatPrice(Number(order.discountTotal), currency)}</dd>
            </div>
          )}
          <div className="flex justify-between border-t border-border pt-2 font-display text-base font-bold">
            <dt>الإجمالي</dt>
            <dd className="price-display tabular-nums">{formatPrice(Number(order.total), currency)}</dd>
          </div>
        </dl>

        {/* Shipping info */}
        <div className="mt-4 rounded-2xl border border-border bg-muted/30 p-3">
          <div className="flex items-start gap-2 text-sm">
            <Truck className="mt-0.5 h-4 w-4 flex-shrink-0 text-accent" strokeWidth={1.6} style={accentStyle} />
            <div>
              <p className="font-display font-medium text-foreground">عنوان التوصيل</p>
              <p className="mt-0.5 text-muted-foreground">{order.customerFullName}</p>
              <p className="text-muted-foreground">{order.shippingAddress}</p>
              <p className="text-muted-foreground">
                {order.shippingCity}
                {order.shippingPostalCode ? `، ${order.shippingPostalCode}` : ''}
              </p>
              <p className="text-muted-foreground">{order.country.name}</p>
            </div>
          </div>
        </div>

        {/* Payment + status note */}
        <div className="mt-3 flex items-center justify-between rounded-2xl border border-border px-3 py-2 text-xs">
          <span className="text-muted-foreground">طريقة الدفع</span>
          <span className="font-display font-medium text-foreground">
            {order.paymentMethod === 'COD' ? 'الدفع عند الاستلام (نقداً)' : order.paymentMethod}
          </span>
        </div>
      </div>

      {/* Tips (optional, admin-controlled) */}
      {config.showTips && tipsLines.length > 0 && (
        <div className="mt-5 rounded-3xl border border-accent/30 bg-accent/5 p-4" style={accentStyle.borderColor ? { borderColor: `${config.accentColor}30`, backgroundColor: `${config.accentColor}05` } : undefined}>
          <div className="flex items-start gap-2">
            <Clock className="mt-0.5 h-4 w-4 flex-shrink-0 text-accent" strokeWidth={1.6} style={accentStyle} />
            <div className="text-sm">
              <p className="font-display font-medium text-foreground">الخطوات التالية</p>
              <ul className="mt-1.5 space-y-1 text-foreground/80">
                {tipsLines.map((line, i) => (
                  <li key={i}>{line}</li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      )}

      {/* Actions */}
      <div className="mt-6 flex flex-col gap-3 sm:flex-row sm:justify-center">
        {config.showStoreButton && (
          <Button asChild size="lg" className="btn-secondary-cta h-12 rounded-full px-7 text-base font-semibold">
            <Link href="/produits">
              <ArrowRight className="ml-2 h-4 w-4" /> {config.storeButtonText}
            </Link>
          </Button>
        )}
        {waUrl && (
          <Button asChild size="lg" className="btn-primary-cta h-12 rounded-full px-7 text-base font-semibold">
            <a href={waUrl} target="_blank" rel="noopener noreferrer">
              <MessageCircle className="ml-2 h-4 w-4" /> {config.whatsappButtonText}
            </a>
          </Button>
        )}
        <Button asChild size="lg" variant="outline" className="h-12 rounded-full px-7">
          <Link href="/contact">
            <Phone className="ml-2 h-4 w-4" /> اتصل بنا
          </Link>
        </Button>
      </div>

      {/* Reference footer */}
      <p className="mt-6 text-center text-xs text-muted-foreground">
        احتفظ برقم الطلب{' '}
        <span className="font-mono font-semibold text-foreground" dir="ltr">{order.number}</span>{' '}
        لأي استفسار.
      </p>

      <meta name="robots" content="noindex, nofollow, nosnippet, noarchive" />
    </div>
  )
}
