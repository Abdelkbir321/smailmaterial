import Link from 'next/link'
import { Phone, Mail, MapPin, MessageCircle, Clock, ChevronRight, LifeBuoy } from 'lucide-react'
import { getBranding } from '@/services/branding'
import { getProductionDomain } from '@/services/settings'
import { getSocialLinks } from '@/services/site-settings'
import { buildBreadcrumbSchema } from '@/lib/seo-schemas'
import { SocialIcons } from '@/components/storefront/social-icons'
import { Button } from '@/components/ui/button'
import type { Metadata } from 'next'

export const dynamic = 'force-dynamic'

export async function generateMetadata(): Promise<Metadata> {
  const b = await getBranding()
  return {
    title: 'Contact',
    description: `Contactez ${b.siteName} — téléphone, WhatsApp, email, adresse.`,
    alternates: { canonical: '/contact' },
    robots: { index: true, follow: true },
  }
}

export default async function ContactPage() {
  const b = await getBranding()
  const wa = b.whatsapp.replace(/[^\d]/g, '')
  const phone = b.supportPhone.replace(/[\s()-]/g, '')
  const mapUrl = b.address ? `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(b.address)}` : null

  // ─── Social links — SAME source as the Footer ──────────────────────
  // Previously, this page used `b.social.facebook/instagram/youtube` (legacy
  // flat keys from site_settings). The Footer uses the `SocialLink` table via
  // `getSocialLinks()`. When the admin changed a social link in the admin
  // panel (which writes to SocialLink table), the Footer updated but this
  // page did NOT — causing the sync issue.
  //
  // Now we use the SAME `getSocialLinks('contact')` call. If the admin hasn't
  // marked any link as `showInContact: true`, we fall back to the footer links
  // (so the contact page is never empty when the footer has links).
  let socialLinks = await getSocialLinks('contact')
  if (socialLinks.length === 0) {
    // Fallback: use the footer's social links (same source, different filter)
    socialLinks = await getSocialLinks('footer')
  }

  const siteUrl = await getProductionDomain()
  const breadcrumbSchema = buildBreadcrumbSchema(siteUrl, [
    { name: 'Accueil', path: '/' },
    { name: 'Contact', path: '/contact' },
  ])

  const contactCards = [
    b.supportPhone && {
      icon: Phone,
      label: 'Téléphone',
      value: b.supportPhone,
      href: `tel:${phone}`,
      target: undefined as string | undefined,
    },
    wa && {
      icon: MessageCircle,
      label: 'WhatsApp',
      value: b.whatsapp,
      href: `https://wa.me/${wa}`,
      target: '_blank',
    },
    b.supportEmail && {
      icon: Mail,
      label: 'Email',
      value: b.supportEmail,
      href: `mailto:${b.supportEmail}`,
      target: undefined,
    },
    b.address && {
      icon: MapPin,
      label: 'Adresse',
      value: b.address,
      href: mapUrl || '#',
      target: '_blank',
    },
  ].filter(Boolean) as Array<{
    icon: typeof Phone
    label: string
    value: string
    href: string
    target?: string
  }>

  return (
    <div className="mx-auto max-w-5xl px-4 py-10 sm:py-14">
      {breadcrumbSchema && (
        <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbSchema) }} />
      )}
      {/* Breadcrumb */}
      <nav className="flex items-center gap-1.5 text-xs text-muted-foreground">
        <Link href="/" className="transition-colors hover:text-foreground">Accueil</Link>
        <ChevronRight className="h-3 w-3" />
        <span className="text-foreground">Contact</span>
      </nav>

      {/* Header */}
      <header className="mt-4 border-b border-border pb-8">
        <span className="kicker">Contact</span>
        <h1 className="mt-3 font-display text-3xl font-bold tracking-tight sm:text-4xl">
          Contactez-nous
        </h1>
        <p className="mt-2 text-sm text-muted-foreground">
          Une question ? Notre équipe vous répond rapidement.
        </p>
      </header>

      {/* Contact cards */}
      <div className="mt-8 grid gap-4 sm:grid-cols-2">
        {contactCards.map((c, i) => (
          <a
            key={i}
            href={c.href}
            target={c.target}
            rel={c.target === '_blank' ? 'noopener noreferrer' : undefined}
            className="card-hover group flex items-center gap-4 rounded-3xl border border-border bg-card p-5 shadow-[var(--shadow-xs)]"
          >
            <span className="grid size-12 place-items-center rounded-2xl bg-muted text-primary transition-transform duration-300 group-hover:scale-110">
              <c.icon className="h-5 w-5" strokeWidth={1.6} />
            </span>
            <div className="min-w-0 flex-1">
              <p className="text-[11px] font-medium uppercase tracking-wider text-muted-foreground">
                {c.label}
              </p>
              <p className="mt-0.5 font-display text-sm font-semibold tracking-tight text-foreground truncate">
                {c.value}
              </p>
            </div>
          </a>
        ))}

        {/* Working hours — not a link, just info */}
        <div className="flex items-center gap-4 rounded-3xl border border-border bg-card p-5 shadow-[var(--shadow-xs)]">
          <span className="grid size-12 place-items-center rounded-2xl bg-muted text-primary">
            <Clock className="h-5 w-5" strokeWidth={1.6} />
          </span>
          <div>
            <p className="text-[11px] font-medium uppercase tracking-wider text-muted-foreground">
              Heures d'ouverture
            </p>
            <p className="mt-0.5 font-display text-sm font-semibold tracking-tight">
              {b.workingHours}
            </p>
          </div>
        </div>
      </div>

      {/* Social — uses the SAME SocialLink table as the Footer.
          When the admin changes a social link in /admin/settings → Social tab,
          it updates here AND in the Footer automatically. */}
      {socialLinks.length > 0 && (
        <div className="mt-10">
          <h2 className="font-display text-base font-bold tracking-tight">Suivez-nous</h2>
          <div className="mt-3">
            <SocialIcons links={socialLinks} size="lg" />
          </div>
        </div>
      )}

      {/* Help CTA */}
      <div className="mt-10 flex flex-col items-center gap-4 rounded-3xl border border-border bg-secondary p-8 text-center">
        <div className="grid size-12 place-items-center rounded-2xl bg-card text-accent">
          <LifeBuoy className="h-5 w-5" strokeWidth={1.6} />
        </div>
        <div>
          <p className="font-display text-lg font-bold tracking-tight text-secondary-foreground">
            Besoin d'aide pour commander ?
          </p>
          <p className="mt-1 text-sm text-secondary-foreground/70">
            Consultez notre centre d'aide — réponses aux questions fréquentes, guides d'achat, et plus.
          </p>
        </div>
        <Button asChild className="btn-secondary-cta rounded-full bg-card text-secondary hover:bg-card/90">
          <Link href="/aide">Consulter le centre d'aide</Link>
        </Button>
      </div>
    </div>
  )
}
