import Link from 'next/link'
import { getCategories } from '@/services/catalog'
import { Wrench, ChevronRight, ArrowRight } from 'lucide-react'
import { getProductionDomain } from '@/services/settings'
import { buildBreadcrumbSchema } from '@/lib/seo-schemas'
import type { Metadata } from 'next'

export const metadata: Metadata = {
  title: 'Catégories',
  description: 'Parcourez toutes nos catégories d\'outillage et équipement professionnel.',
  alternates: { canonical: '/categories' },
}

export const revalidate = 60

export default async function CategoriesIndexPage() {
  let categories: Awaited<ReturnType<typeof getCategories>> = []
  try {
    categories = await getCategories()
  } catch {
    // DB unreachable at runtime
  }
  const siteUrl = await getProductionDomain()
  const breadcrumbSchema = buildBreadcrumbSchema(siteUrl, [
    { name: 'Accueil', path: '/' },
    { name: 'Catégories', path: '/categories' },
  ])
  return (
    <div className="mx-auto max-w-7xl px-4 py-10 sm:py-14">
      {breadcrumbSchema && (
        <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbSchema) }} />
      )}
      {/* Breadcrumb */}
      <nav className="flex items-center gap-1.5 text-xs text-muted-foreground">
        <Link href="/" className="transition-colors hover:text-foreground">Accueil</Link>
        <ChevronRight className="h-3 w-3" />
        <span className="text-foreground">Catégories</span>
      </nav>

      {/* Header */}
      <header className="mt-4 border-b border-border pb-8">
        <span className="kicker">Catalogue</span>
        <h1 className="mt-3 font-display text-3xl font-bold tracking-tight sm:text-4xl">
          Toutes les catégories
        </h1>
        <p className="mt-2 text-sm text-muted-foreground">
          {categories.length} {categories.length > 1 ? 'catégories d\'outillage' : 'catégorie'}
          {' '}— explorez par usage
        </p>
      </header>

      {/* Grid */}
      <div className="mt-8 grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
        {categories.map((c) => (
          <Link
            key={c.id}
            href={`/categories/${c.slug}`}
            className="group relative flex flex-col items-center justify-center rounded-3xl border border-border bg-card p-8 text-center shadow-[var(--shadow-xs)] transition-all hover:shadow-[var(--shadow-md)] hover:-translate-y-0.5"
          >
            {/* Decorative dot pattern background */}
            <div
              className="pointer-events-none absolute inset-0 opacity-0 transition-opacity duration-300 group-hover:opacity-[0.04]"
              style={{
                backgroundImage:
                  'radial-gradient(circle, #1A1410 1px, transparent 1px)',
                backgroundSize: '20px 20px',
              }}
              aria-hidden
            />
            <div className="relative grid size-14 place-items-center rounded-2xl bg-muted text-primary transition-transform duration-300 group-hover:scale-110">
              <Wrench className="h-6 w-6" strokeWidth={1.5} />
            </div>
            <div className="relative mt-4 font-display text-sm font-semibold tracking-tight">
              {c.name}
            </div>
            {c._count?.products !== undefined && (
              <div className="relative mt-1 text-xs text-muted-foreground">
                {c._count.products} {c._count.products > 1 ? 'articles' : 'article'}
              </div>
            )}
            <ArrowRight className="relative mt-3 h-3.5 w-3.5 text-muted-foreground opacity-0 transition-all duration-300 group-hover:opacity-100" />
          </Link>
        ))}
      </div>
    </div>
  )
}
