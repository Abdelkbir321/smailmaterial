import Link from 'next/link'
import { Truck, RotateCcw, CreditCard, Clock, ChevronRight } from 'lucide-react'
import { getBranding } from '@/services/branding'
import { getProductionDomain } from '@/services/settings'
import { getShippingReturnSettings } from '@/services/site-settings'
import { buildBreadcrumbSchema } from '@/lib/seo-schemas'
import type { Metadata } from 'next'

export const dynamic = 'force-dynamic'

export const metadata: Metadata = {
  title: 'Livraison & Retours',
  description: 'Délais de livraison, frais, suivi de commande, politique de retour et remboursement.',
  alternates: { canonical: '/page/livraison-retours' },
  robots: { index: true, follow: true },
}

export default async function Page() {
  const b = await getBranding()
  const siteUrl = await getProductionDomain()
  const shipping = await getShippingReturnSettings()
  const breadcrumbSchema = buildBreadcrumbSchema(siteUrl, [
    { name: 'Accueil', path: '/' },
    { name: 'Livraison & Retours', path: '/page/livraison-retours' },
  ])

  // Build the dynamic policy text from the DB-backed settings so the page
  // ALWAYS matches the structured data on product pages. Single source of
  // truth — no drift between the policy page and the JSON-LD.
  const deliveryTimeText = `${shipping.deliveryTimeMinDays}–${shipping.deliveryTimeMaxDays} jours ouvrables`
  const shippingRateText = shipping.shippingRate === 0
    ? 'Livraison gratuite'
    : shipping.freeShippingThreshold > 0
      ? `À partir de ${shipping.shippingRate} ${shipping.shippingCurrency} · Gratuit dès ${shipping.freeShippingThreshold} ${shipping.shippingCurrency}`
      : `À partir de ${shipping.shippingRate} ${shipping.shippingCurrency}`
  const returnsText = shipping.returnsEnabled
    ? `${shipping.returnPolicyDays} jours après réception, produit intact dans son emballage`
    : 'Retours non acceptés'

  return (
    <div className="mx-auto max-w-3xl px-4 py-10 sm:py-14">
      {breadcrumbSchema && (
        <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbSchema) }} />
      )}
      {/* Breadcrumb */}
      <nav className="flex items-center gap-1.5 text-xs text-muted-foreground">
        <Link href="/" className="transition-colors hover:text-foreground">Accueil</Link>
        <ChevronRight className="h-3 w-3" />
        <span className="text-foreground">Livraison & Retours</span>
      </nav>

      {/* Header */}
      <header className="mt-4 border-b border-border pb-8">
        <span className="kicker">Aide</span>
        <h1 className="mt-3 font-display text-3xl font-bold tracking-tight sm:text-4xl">
          Livraison & Retours
        </h1>
      </header>

      {/* Info cards — dynamic from DB settings */}
      <div className="mt-8 grid gap-4 sm:grid-cols-2">
        {[
          { icon: Truck, t: 'Délais de livraison', s: deliveryTimeText },
          { icon: CreditCard, t: 'Frais de livraison', s: shippingRateText },
          { icon: Clock, t: 'Suivi de commande', s: 'Vous recevez un appel de confirmation après votre commande' },
          { icon: RotateCcw, t: 'Retours', s: returnsText },
        ].map((c) => (
          <div
            key={c.t}
            className="rounded-3xl border border-border bg-card p-5 shadow-[var(--shadow-xs)]"
          >
            <div className="grid size-11 place-items-center rounded-2xl bg-muted text-primary">
              <c.icon className="h-5 w-5" strokeWidth={1.6} />
            </div>
            <h2 className="mt-3 font-display text-sm font-bold tracking-tight">{c.t}</h2>
            <p className="mt-1 text-sm text-muted-foreground">{c.s}</p>
          </div>
        ))}
      </div>

      {/* Long-form policy */}
      <div className="mt-10 space-y-6 text-sm leading-relaxed text-muted-foreground">
        <section>
          <h2 className="font-display text-lg font-bold tracking-tight text-foreground">
            Politique de livraison
          </h2>
          <p className="mt-2">
            {b.siteName} livre partout au Maroc. Les commandes sont traitées sous 24h.
            Un email ou un appel de confirmation précède l'expédition. Les délais
            indiqués ({deliveryTimeText}) sont estimatifs et dépendent du transporteur
            et de votre région.
          </p>
        </section>
        {shipping.returnsEnabled && (
          <section>
            <h2 className="font-display text-lg font-bold tracking-tight text-foreground">
              Politique de retour
            </h2>
            <p className="mt-2">
              Vous disposez de {shipping.returnPolicyDays} jours à compter de la réception
              pour retourner un produit. Le produit doit être intact, non utilisé et dans
              son emballage d'origine. Les frais de retour sont à la charge du client sauf
              en cas de produit défectueux ou d'erreur de notre part. Le remboursement
              s'effectue après réception et vérification du produit retourné.
            </p>
          </section>
        )}
        <section>
          <h2 className="font-display text-lg font-bold tracking-tight text-foreground">
            Produits non retournables
          </h2>
          <p className="mt-2">
            Pour des raisons d'hygiène, certains produits (EPI, consommables
            ouverts) ne peuvent pas être retournés une fois déballés.
          </p>
        </section>
      </div>
    </div>
  )
}
