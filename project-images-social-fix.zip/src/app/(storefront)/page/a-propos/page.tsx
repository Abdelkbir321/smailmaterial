import Link from 'next/link'
import { ChevronRight, Wrench, Truck, ShieldCheck, CreditCard, Star } from 'lucide-react'
import { getBranding } from '@/services/branding'
import { getProductionDomain } from '@/services/settings'
import { buildBreadcrumbSchema } from '@/lib/seo-schemas'
import type { Metadata } from 'next'

export const dynamic = 'force-dynamic'

export const metadata: Metadata = {
  title: 'À propos',
  description: 'Découvrez Ismail Material — boutique marocaine d\'outillage professionnel et matériel de construction.',
  alternates: { canonical: '/page/a-propos' },
  robots: { index: true, follow: true },
}

export default async function Page() {
  const b = await getBranding()
  const siteUrl = await getProductionDomain()
  const breadcrumbSchema = buildBreadcrumbSchema(siteUrl, [
    { name: 'Accueil', path: '/' },
    { name: 'À propos', path: '/page/a-propos' },
  ])

  return (
    <div className="mx-auto max-w-3xl px-4 py-10 sm:py-14">
      {breadcrumbSchema && (
        <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbSchema) }} />
      )}
      {/* Breadcrumb */}
      <nav className="flex items-center gap-1.5 text-xs text-muted-foreground">
        <Link href="/" className="transition-colors hover:text-foreground">Accueil</Link>
        <ChevronRight className="h-3 w-3" />
        <span className="text-foreground">À propos</span>
      </nav>

      {/* Header */}
      <header className="mt-4 border-b border-border pb-8">
        <span className="kicker">Notre histoire</span>
        <h1 className="mt-3 font-display text-3xl font-bold tracking-tight sm:text-4xl">
          À propos de {b.siteName}
        </h1>
        <p className="mt-3 max-w-2xl text-base leading-relaxed text-muted-foreground">
          {b.description}
        </p>
      </header>

      {/* Mission */}
      <section className="mt-10 space-y-4 text-sm leading-relaxed text-muted-foreground">
        <h2 className="font-display text-lg font-bold tracking-tight text-foreground">
          Notre mission
        </h2>
        <p>
          {b.siteName} est une boutique marocaine spécialisée dans la vente d'outillage
          électroportatif et d'équipement professionnel pour les artisans, les entrepreneurs et
          les bricoleurs exigeants. Nous proposons des marques reconnues pour leur fiabilité
          et leur rapport qualité-prix, avec un service pensé pour le marché marocain.
        </p>
        <p>
          Notre objectif est simple : mettre à votre disposition un matériel professionnel
          fiable, à des prix justes, avec une livraison rapide partout au Maroc et un paiement
          à la livraison qui vous protège.
        </p>
      </section>

      {/* Values — 4 cards */}
      <section className="mt-10 grid gap-4 sm:grid-cols-2">
        {[
          {
            icon: Wrench,
            title: 'Matériel professionnel',
            desc: 'Des marques reconnues (INGCO, Total Tools, Crown, Würth) sélectionnées pour leur fiabilité et leur durabilité.',
          },
          {
            icon: Truck,
            title: 'Livraison Maroc',
            desc: 'Expédition 24–72h dans les grandes villes, 2–5 jours en zone rurale. Suivi par téléphone à chaque étape.',
          },
          {
            icon: CreditCard,
            title: 'Paiement à la livraison',
            desc: 'Payez en espèces à la réception de votre colis. Aucun risque — vous voyez le produit avant de payer.',
          },
          {
            icon: ShieldCheck,
            title: 'Produits authentiques',
            desc: 'Tous nos produits sont authentiques et garantis contre les défauts de fabrication.',
          },
        ].map((v) => (
          <div
            key={v.title}
            className="rounded-3xl border border-border bg-card p-5 shadow-[var(--shadow-xs)]"
          >
            <div className="grid size-11 place-items-center rounded-2xl bg-muted text-primary">
              <v.icon className="h-5 w-5" strokeWidth={1.6} />
            </div>
            <h3 className="mt-3 font-display text-sm font-bold tracking-tight">{v.title}</h3>
            <p className="mt-1 text-sm text-muted-foreground">{v.desc}</p>
          </div>
        ))}
      </section>

      {/* Contact CTA */}
      <section className="mt-10 rounded-3xl border border-border bg-card p-6 text-center">
        <h2 className="font-display text-lg font-bold tracking-tight text-foreground">
          Une question ?
        </h2>
        <p className="mt-2 text-sm text-muted-foreground">
          Notre équipe est disponible pour vous conseiller et répondre à toutes vos questions.
        </p>
        <div className="mt-4 flex flex-wrap justify-center gap-3">
          <Link
            href="/contact"
            className="inline-flex items-center gap-1.5 rounded-full bg-primary px-5 py-2.5 text-sm font-semibold text-primary-foreground transition-colors hover:bg-primary/90"
          >
            Nous contacter <ChevronRight className="h-4 w-4" />
          </Link>
          <Link
            href="/produits"
            className="inline-flex items-center gap-1.5 rounded-full border border-border px-5 py-2.5 text-sm font-medium transition-colors hover:bg-muted"
          >
            Voir le catalogue
          </Link>
        </div>
        {b.workingHours && (
          <p className="mt-4 text-xs text-muted-foreground">
            {b.workingHours}
          </p>
        )}
      </section>
    </div>
  )
}
