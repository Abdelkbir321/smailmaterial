import Link from 'next/link'
import { ChevronRight, Shield, Database, Cookie, Eye, Mail } from 'lucide-react'
import { getBranding } from '@/services/branding'
import { getProductionDomain } from '@/services/settings'
import { buildBreadcrumbSchema } from '@/lib/seo-schemas'
import type { Metadata } from 'next'

export const dynamic = 'force-dynamic'

export const metadata: Metadata = {
  title: 'Politique de confidentialité',
  description: 'Comment Ismail Material collecte, utilise et protège vos données personnelles.',
  alternates: { canonical: '/page/politique-confidentialite' },
  robots: { index: true, follow: true },
}

export default async function Page() {
  const b = await getBranding()
  const siteUrl = await getProductionDomain()
  const breadcrumbSchema = buildBreadcrumbSchema(siteUrl, [
    { name: 'Accueil', path: '/' },
    { name: 'Politique de confidentialité', path: '/page/politique-confidentialite' },
  ])

  return (
    <div className="mx-auto max-w-3xl px-4 py-10 sm:py-14">
      {breadcrumbSchema && (
        <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbSchema) }} />
      )}
      {/* Breadcrumb */}
      <nav className="flex items-center gap-1.5 text-xs text-muted-foreground">
        <Link href="/" className="transition-colors hover:text-foreground">Accueil</Link>
        <ChevronRight className="h-3 w-3" />
        <span className="text-foreground">Politique de confidentialité</span>
      </nav>

      {/* Header */}
      <header className="mt-4 border-b border-border pb-8">
        <span className="kicker">Légal</span>
        <h1 className="mt-3 font-display text-3xl font-bold tracking-tight sm:text-4xl">
          Politique de confidentialité
        </h1>
        <p className="mt-2 text-sm text-muted-foreground">
          Dernière mise à jour : {new Date().toLocaleDateString('fr-FR', { year: 'numeric', month: 'long', day: 'numeric' })}
        </p>
      </header>

      {/* Sections */}
      <div className="mt-8 space-y-8 text-sm leading-relaxed text-muted-foreground">
        <section>
          <div className="flex items-center gap-2 mb-3">
            <Shield className="size-5 text-primary" />
            <h2 className="font-display text-lg font-bold tracking-tight text-foreground">
              1. Données que nous collectons
            </h2>
          </div>
          <p className="mt-2">
            Lorsque vous passez une commande chez {b.siteName}, nous collectons les informations
            nécessaires au traitement et à la livraison de votre commande :
          </p>
          <ul className="mt-3 space-y-1.5 list-disc list-inside">
            <li><strong>Nom complet</strong> — pour l'adresse de livraison</li>
            <li><strong>Numéro de téléphone</strong> — pour la confirmation et le suivi de la commande</li>
            <li><strong>Adresse de livraison</strong> — ville, adresse complète, code postal</li>
            <li><strong>Adresse e-mail</strong> — optionnelle, pour les communications de commande</li>
            <li><strong>Pays</strong> — pour calculer les frais de livraison</li>
          </ul>
          <p className="mt-3">
            Nous <strong>ne stockons pas</strong> de mots de passe (le checkout se fait sans création
            de compte). Nous ne demandons pas de données bancaires (paiement à la livraison uniquement).
          </p>
        </section>

        <section>
          <div className="flex items-center gap-2 mb-3">
            <Eye className="size-5 text-primary" />
            <h2 className="font-display text-lg font-bold tracking-tight text-foreground">
              2. Comment nous utilisons vos données
            </h2>
          </div>
          <p className="mt-2">Vos données servent exclusivement à :</p>
          <ul className="mt-3 space-y-1.5 list-disc list-inside">
            <li>Traiter et livrer votre commande</li>
            <li>Vous contacter pour confirmer la commande ou la livraison</li>
            <li>Gérer les retours et remboursements</li>
            <li>Répondre à vos questions (support client)</li>
            <li>Prévenir la fraude et les commandes abusives</li>
          </ul>
          <p className="mt-3">
            Nous <strong>ne vendons pas</strong> vos données à des tiers. Nous ne les partageons
            qu'avec le transporteur chargé de votre livraison.
          </p>
        </section>

        <section>
          <div className="flex items-center gap-2 mb-3">
            <Database className="size-5 text-primary" />
            <h2 className="font-display text-lg font-bold tracking-tight text-foreground">
              3. Stockage et conservation
            </h2>
          </div>
          <p className="mt-2">
            Vos données sont stockées sur une base de données hébergée chez un fournisseur cloud
            professionnel (Neon — PostgreSQL managé, infrastructure AWS aux États-Unis).
            Les communications sont chiffrées (HTTPS / TLS).
          </p>
          <p className="mt-3">
            <strong>Adresse IP :</strong> nous enregistrons une version <em>tronquée</em> de votre
            adresse IP (les 3 premiers octets uniquement, ex. <code>196.200.x.x</code>) avec chaque
            commande. Cette information sert uniquement à la prévention de fraude et à l'analyse
            statistique du trafic. Elle ne permet pas de vous identifier personnellement.
          </p>
          <p className="mt-3">
            <strong>Durée de conservation :</strong> les données de commande sont conservées
            indéfiniment pour permettre le suivi des commandes, la comptabilité et la gestion des
            retours. Vous pouvez demander la suppression de vos données à tout moment (voir section 6).
          </p>
        </section>

        <section>
          <div className="flex items-center gap-2 mb-3">
            <Cookie className="size-5 text-primary" />
            <h2 className="font-display text-lg font-bold tracking-tight text-foreground">
              4. Cookies et traceurs
            </h2>
          </div>
          <p className="mt-2">
            {b.siteName} utilise un minimum de cookies et de traceurs :
          </p>
          <ul className="mt-3 space-y-1.5 list-disc list-inside">
            <li>
              <strong>Panier (localStorage)</strong> — stocke le contenu de votre panier entre les
              pages. Stocké dans votre navigateur, jamais envoyé à nos serveurs.
            </li>
            <li>
              <strong>Session d'analyse (cookie first-party)</strong> — un identifiant aléatoire
              qui nous aide à compter les visites et comprendre l'utilisation du site. Pas de
              tracking cross-site, pas de publicité.
            </li>
          </ul>
          <p className="mt-3">
            Nous <strong>n'utilisons pas</strong> de cookies publicitaires, de suivi tiers
            (Google Analytics, Facebook Pixel, etc.) ni de technologies de fingerprinting.
            Vous pouvez désactiver les cookies dans votre navigateur — le panier fonctionnera
            toujours pendant la session.
          </p>
        </section>

        <section>
          <h2 className="font-display text-lg font-bold tracking-tight text-foreground">
            5. Vos droits (RGPD / loi 09-09)
          </h2>
          <p className="mt-2">
            Conformément à la loi marocaine 09-09 relative à la protection des personnes physiques
            à l'égard du traitement des données à caractère personnel et au Règlement Général sur
            la Protection des Données (RGPD) européen, vous disposez des droits suivants :
          </p>
          <ul className="mt-3 space-y-1.5 list-disc list-inside">
            <li><strong>Droit d'accès</strong> — obtenir une copie de vos données personnelles</li>
            <li><strong>Droit de rectification</strong> — corriger des données inexactes</li>
            <li><strong>Droit à l'effacement</strong> — demander la suppression de vos données</li>
            <li><strong>Droit à la limitation</strong> — restreindre certains traitements</li>
            <li><strong>Droit d'opposition</strong> — refuser certains usages</li>
            <li><strong>Droit à la portabilité</strong> — recevoir vos données dans un format lisible</li>
          </ul>
          <p className="mt-3">
            Pour exercer ces droits, contactez-nous (voir section 6). Nous répondons sous 30 jours maximum.
          </p>
        </section>

        <section>
          <div className="flex items-center gap-2 mb-3">
            <Mail className="size-5 text-primary" />
            <h2 className="font-display text-lg font-bold tracking-tight text-foreground">
              6. Nous contacter
            </h2>
          </div>
          <p className="mt-2">
            Pour toute question relative à vos données personnelles ou à cette politique :
          </p>
          <div className="mt-3 rounded-2xl border border-border bg-card p-4 text-sm">
            {b.supportPhone && (
              <p className="mb-1"><strong>Téléphone :</strong> <a href={`tel:${b.supportPhone}`} className="text-primary hover:underline" dir="ltr">{b.supportPhone}</a></p>
            )}
            {b.supportEmail && (
              <p className="mb-1"><strong>E-mail :</strong> <a href={`mailto:${b.supportEmail}`} className="text-primary hover:underline" dir="ltr">{b.supportEmail}</a></p>
            )}
            {b.address && (
              <p><strong>Adresse :</strong> {b.address}</p>
            )}
          </div>
        </section>

        <section>
          <h2 className="font-display text-lg font-bold tracking-tight text-foreground">
            7. Modifications de cette politique
          </h2>
          <p className="mt-2">
            Cette politique peut être mise à jour pour refléter les changements dans nos pratiques
            ou pour des raisons légales. La date de "dernière mise à jour" en haut de cette page
            indique la version actuelle. Nous vous encourageons à consulter cette page régulièrement.
          </p>
        </section>
      </div>

      {/* CTA */}
      <div className="mt-10 rounded-3xl border border-border bg-card p-6 text-center">
        <p className="font-display text-sm font-semibold">
          Une question sur vos données ?
        </p>
        <Link
          href="/contact"
          className="mt-2 inline-flex items-center gap-1 text-sm font-medium text-primary transition-colors hover:text-primary/80"
        >
          Contactez-nous <ChevronRight className="h-4 w-4" />
        </Link>
      </div>
    </div>
  )
}
