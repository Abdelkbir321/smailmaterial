import Link from 'next/link'
import { ChevronRight } from 'lucide-react'
import { getBranding } from '@/services/branding'
import { getProductionDomain } from '@/services/settings'
import { getShippingReturnSettings } from '@/services/site-settings'
import { buildBreadcrumbSchema } from '@/lib/seo-schemas'
import type { Metadata } from 'next'

export const dynamic = 'force-dynamic'

const META: { slug: string; title: string; description: string } = {
  slug: 'conditions-generales',
  title: 'Conditions générales de vente',
  description: 'Conditions générales de vente — commandes, paiements, livraison, retours.',
}

export const metadata: Metadata = {
  title: META.title,
  description: META.description,
  alternates: { canonical: `/page/${META.slug}` },
  robots: { index: true, follow: true },
}

export default async function Page() {
  const b = await getBranding()
  const siteUrl = await getProductionDomain()
  const shipping = await getShippingReturnSettings()
  const breadcrumbSchema = buildBreadcrumbSchema(siteUrl, [
    { name: 'Accueil', path: '/' },
    { name: 'Conditions générales', path: `/page/${META.slug}` },
  ])
  return (
    <div className="mx-auto max-w-3xl px-4 py-10 sm:py-14">
      {breadcrumbSchema && (
        <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbSchema) }} />
      )}
      {/* Breadcrumb */}
      <nav className="flex items-center gap-1.5 text-xs text-muted-foreground">
        <Link href="/" className="transition-colors hover:text-foreground">Accueil</Link>
        <ChevronRight className="h-3 w-3" />
        <span className="text-foreground">Conditions générales</span>
      </nav>

      {/* Header */}
      <header className="mt-4 border-b border-border pb-8">
        <span className="kicker">Légal</span>
        <h1 className="mt-3 font-display text-3xl font-bold tracking-tight sm:text-4xl">
          {META.title}
        </h1>
      </header>

      {/* Content — reads from the DB-backed shipping/return settings
          so the legal text always matches the structured data + policy page */}
      <div className="mt-8 space-y-6 text-sm leading-relaxed text-muted-foreground">
        <section>
          <h2 className="font-display text-lg font-bold tracking-tight text-foreground">1. Objet</h2>
          <p className="mt-2">
            Les présentes conditions générales régissent les ventes de produits par{' '}
            <strong className="text-foreground">{b.siteName}</strong> à travers son site web.
            Toute commande implique l'acceptation pleine et entière des présentes conditions.
          </p>
        </section>
        <section>
          <h2 className="font-display text-lg font-bold tracking-tight text-foreground">2. Commandes</h2>
          <p className="mt-2">
            Les commandes se font directement sur le site, sans obligation de création de compte.
            Les informations saisies (nom, téléphone, adresse) doivent être exactes.{' '}
            {b.siteName} se réserve le droit de refuser une commande pour des raisons légitimes.
          </p>
        </section>
        <section>
          <h2 className="font-display text-lg font-bold tracking-tight text-foreground">3. Prix & Paiement</h2>
          <p className="mt-2">
            Les prix sont indiqués en {shipping.shippingCurrency} et incluent les taxes
            applicables. Le paiement s'effectue à la livraison (Cash on Delivery). Le paiement
            en ligne sera proposé ultérieurement.
          </p>
        </section>
        <section>
          <h2 className="font-display text-lg font-bold tracking-tight text-foreground">4. Livraison</h2>
          <p className="mt-2">
            La livraison s'effectue dans tout le Maroc sous{' '}
            {shipping.deliveryTimeMinDays}–{shipping.deliveryTimeMaxDays} jours ouvrables selon
            votre région. Les frais de livraison sont indiqués au moment de la commande
            (à partir de {shipping.shippingRate} {shipping.shippingCurrency}
            {shipping.freeShippingThreshold > 0 && `, gratuit dès ${shipping.freeShippingThreshold} ${shipping.shippingCurrency}`}).{' '}
            {b.siteName} n'est pas responsable des retards imputables au transporteur.
          </p>
        </section>
        <section>
          <h2 className="font-display text-lg font-bold tracking-tight text-foreground">5. Retours & Remboursement</h2>
          {shipping.returnsEnabled ? (
            <p className="mt-2">
              Vous disposez de {shipping.returnPolicyDays} jours à compter de la réception pour
              retourner un produit non conforme ou défectueux, dans son emballage d'origine. Le
              remboursement intervient après vérification du produit retourné. Les frais de retour
              sont à la charge du client, sauf en cas de produit défectueux ou d'erreur de notre part.
            </p>
          ) : (
            <p className="mt-2">
              Conformément à nos conditions actuelles, les retours ne sont pas acceptés. Pour
              tout problème avec un produit reçu, contactez-nous immédiatement après la livraison.
            </p>
          )}
        </section>
        <section>
          <h2 className="font-display text-lg font-bold tracking-tight text-foreground">6. Garantie</h2>
          <p className="mt-2">
            Tous nos produits sont garantis contre les défauts de fabrication. La durée et les
            conditions de garantie varient selon le fabricant. Pour toute réclamation, contactez-nous
            avec votre numéro de commande et une description du problème.
          </p>
        </section>
        <section>
          <h2 className="font-display text-lg font-bold tracking-tight text-foreground">7. Protection des données</h2>
          <p className="mt-2">
            Vos données personnelles sont traitées conformément à notre{' '}
            <Link href="/page/politique-confidentialite" className="text-primary hover:underline">
              politique de confidentialité
            </Link>{' '}
            et à la loi marocaine 09-09.
          </p>
        </section>
        <section>
          <h2 className="font-display text-lg font-bold tracking-tight text-foreground">8. Contact</h2>
          <p className="mt-2">
            Pour toute question, contactez-nous :{' '}
            {b.supportPhone && <><span className="font-mono" dir="ltr">{b.supportPhone}</span> · </>}
            {b.supportEmail && <><span className="font-mono" dir="ltr">{b.supportEmail}</span> · </>}
            {b.address}
          </p>
        </section>
      </div>

      <p className="mt-10 border-t border-border pt-4 text-xs text-muted-foreground">
        Dernière mise à jour :{' '}
        <span className="font-mono">{new Date().toLocaleDateString('fr-MA')}</span>
      </p>
    </div>
  )
}
