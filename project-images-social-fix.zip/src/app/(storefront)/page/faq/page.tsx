import Link from 'next/link'
import { ChevronRight, ChevronDown, HelpCircle } from 'lucide-react'
import { getProductionDomain } from '@/services/settings'
import { buildBreadcrumbSchema } from '@/lib/seo-schemas'
import type { Metadata } from 'next'

export const dynamic = 'force-dynamic'

export const metadata: Metadata = {
  title: 'FAQ — Questions fréquentes',
  description: 'Réponses aux questions les plus fréquentes : commande, paiement, livraison, retours.',
  alternates: { canonical: '/page/faq' },
  robots: { index: true, follow: true },
}

const FAQ = [
  { q: 'Comment passer une commande ?', a: 'Ajoutez les produits au panier, remplissez le formulaire (nom, téléphone, adresse), cliquez sur « Confirmer la commande ». Aucun compte requis.' },
  { q: 'Comment payer ?', a: 'Paiement à la livraison (Cash on Delivery). Vous payez en espèces au livreur à la réception du colis.' },
  { q: 'Quels sont les délais de livraison ?', a: '24–72h dans les grandes villes, 2–5 jours en zone rurale. Frais à partir de 30 DH, gratuit dès 500 DH.' },
  { q: 'Puis-je retourner un produit ?', a: "Oui, sous 7 jours si le produit est intact et dans son emballage d'origine. Contactez-nous pour initier le retour." },
  { q: 'Livrez-vous partout au Maroc ?', a: 'Oui, toutes les villes du Maroc sont desservies. Les délais varient selon votre région.' },
  { q: 'Comment suivre ma commande ?', a: 'Après confirmation, vous recevrez un appel de notre équipe. Vous pouvez aussi nous contacter avec votre numéro de commande.' },
  { q: 'Les prix sont-ils en MAD ?', a: "Oui, les prix sont affichés en MAD (Dirham marocain). La devise peut changer selon le pays à l'avenir." },
]

export default async function Page() {
  const siteUrl = await getProductionDomain()
  const breadcrumbSchema = buildBreadcrumbSchema(siteUrl, [
    { name: 'Accueil', path: '/' },
    { name: 'FAQ', path: '/page/faq' },
  ])
  // FAQ schema — the same FAQ array is rendered visibly on the page, so
  // emitting the FAQPage structured data is fully compliant with Google's
  // policy (the content shown to users matches the structured data).
  const faqSchema = {
    '@context': 'https://schema.org',
    '@type': 'FAQPage',
    mainEntity: FAQ.map((f) => ({
      '@type': 'Question',
      name: f.q,
      acceptedAnswer: { '@type': 'Answer', text: f.a },
    })),
  }
  return (
    <div className="mx-auto max-w-3xl px-4 py-10 sm:py-14">
      {breadcrumbSchema && (
        <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbSchema) }} />
      )}
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(faqSchema) }} />
      {/* Breadcrumb */}
      <nav className="flex items-center gap-1.5 text-xs text-muted-foreground">
        <Link href="/" className="transition-colors hover:text-foreground">Accueil</Link>
        <ChevronRight className="h-3 w-3" />
        <span className="text-foreground">FAQ</span>
      </nav>

      {/* Header */}
      <header className="mt-4 border-b border-border pb-8 text-center">
        <div className="mx-auto mb-4 grid size-14 place-items-center rounded-full bg-muted text-primary">
          <HelpCircle className="h-6 w-6" strokeWidth={1.5} />
        </div>
        <span className="kicker justify-center">Aide</span>
        <h1 className="mt-3 font-display text-3xl font-bold tracking-tight sm:text-4xl">
          Questions fréquentes
        </h1>
        <p className="mt-2 text-sm text-muted-foreground">
          Les réponses aux questions les plus posées par nos clients.
        </p>
      </header>

      {/* FAQ accordion */}
      <div className="mt-8 divide-y divide-border border-y border-border">
        {FAQ.map((f) => (
          <details key={f.q} className="group py-5">
            <summary className="flex cursor-pointer list-none items-center justify-between font-display text-base font-medium text-foreground">
              {f.q}
              <ChevronDown className="h-4 w-4 text-muted-foreground transition-transform group-open:rotate-180" />
            </summary>
            <p className="mt-3 text-sm leading-relaxed text-muted-foreground">{f.a}</p>
          </details>
        ))}
      </div>

      {/* CTA */}
      <div className="mt-8 rounded-3xl border border-border bg-secondary p-6 text-center">
        <p className="font-display text-sm font-semibold text-secondary-foreground">
          Votre question n'est pas listée ?
        </p>
        <Link
          href="/contact"
          className="mt-2 inline-flex items-center gap-1 text-sm font-medium text-accent transition-colors hover:text-primary"
        >
          Contactez-nous <ChevronRight className="h-4 w-4" />
        </Link>
      </div>
    </div>
  )
}
