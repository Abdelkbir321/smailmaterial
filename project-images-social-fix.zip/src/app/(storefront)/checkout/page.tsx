'use client'

import { useEffect, useState, useRef } from 'react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import { ShoppingBag, Loader2, ShieldCheck, Truck, CreditCard, Check } from 'lucide-react'
import { useCart } from '@/lib/cart-store'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group'
import { Checkbox } from '@/components/ui/checkbox'
import { formatPrice } from '@/lib/format'
import { toast } from 'sonner'
import type { Country } from '@prisma/client'
import { DEFAULT_CHECKOUT_TEXTS, type CheckoutTexts } from '@/services/site-settings'

// Current locale — the storefront is French by default
const LANG: 'fr' | 'ar' | 'en' = 'fr'

interface OrderFieldDef {
  key: string
  type: string
  label: string
  placeholder: string | null
  helpText: string | null
  required: boolean
  width: string
  defaultValue: string | null
  minLength: number | null
  maxLength: number | null
  options: Array<{ value: string; label: string }>
}

// Known field keys map to the structured Order columns (so we keep
// customerFullName, customerPhone, etc. for SQL queries + dashboard).
//
// This map INCLUDES aliases (e.g. `name` → customerFullName, `adress` →
// shippingAddress) so that admin-created fields with non-canonical keys
// still route their value to the structured column instead of getting
// stored as a generic customField. Mirrors FIELD_KEY_TO_STRUCTURED in
// src/lib/order-schema.ts — kept in sync manually (frontend copy).
const FIELD_MAP: Record<string, string> = {
  // Canonical
  full_name: 'customerFullName',
  phone: 'customerPhone',
  email: 'customerEmail',
  country: 'countryId',
  city: 'shippingCity',
  address: 'shippingAddress',
  postal_code: 'shippingPostalCode',
  notes: 'notes',
  // Aliases (historical / typo)
  name: 'customerFullName',
  fullname: 'customerFullName',
  tel: 'customerPhone',
  country_name: 'countryId',
  adress: 'shippingAddress',
  addr: 'shippingAddress',
  postalcode: 'shippingPostalCode',
  zip: 'shippingPostalCode',
  comment: 'notes',
}

// Reverse map — used to translate server's structured column error keys
// BACK to the order field key (so the error appears next to the right input).
// Mirrors the same map in /api/orders/route.ts.
//
// NOTE: we map back to the CANONICAL key. If the form was rendered with
// an alias (e.g. `name`), the lookup below falls through and we use the
// alias itself. To handle this correctly, we ALSO accept the alias as
// the lookup value — see the on-error-mapping code in onSubmit.
const STRUCTURED_TO_FIELD_KEY: Record<string, string> = {
  customerFullName: 'full_name',
  customerPhone: 'phone',
  customerEmail: 'email',
  countryId: 'country',
  shippingCity: 'city',
  shippingAddress: 'address',
  shippingPostalCode: 'postal_code',
  notes: 'notes',
  items: 'items',
}

export default function CheckoutPage() {
  const router = useRouter()
  const { items, subtotal, clear } = useCart()
  const [countries, setCountries] = useState<Country[]>([])
  const [defaultCountryId, setDefaultCountryId] = useState<string | null>(null)
  const [fields, setFields] = useState<OrderFieldDef[]>([])
  const [values, setValues] = useState<Record<string, string>>({})
  const [submitting, setSubmitting] = useState(false)
  const [errors, setErrors] = useState<Record<string, string>>({})
  const [texts, setTexts] = useState<CheckoutTexts>(DEFAULT_CHECKOUT_TEXTS)
  // Shipping settings — fetched from the DB via /api/settings/shipping.
  // The client uses these to compute the display shipping cost; the server
  // re-validates with the same settings in createOrder (never trusts client).
  const [shippingSettings, setShippingSettings] = useState({
    rate: 30,
    currency: 'MAD',
    freeShippingThreshold: 500,
    deliveryTimeMinDays: 1,
    deliveryTimeMaxDays: 5,
    returnsEnabled: true,
    returnPolicyDays: 7,
  })

  // Fetch checkout texts + shipping settings on mount
  useEffect(() => {
    Promise.all([
      fetch('/api/settings/checkout-texts').then((r) => r.json()).catch(() => null),
      fetch('/api/settings/shipping').then((r) => r.json()).catch(() => null),
    ]).then(([textData, shipData]) => {
      if (textData?.ok && textData.texts) setTexts(textData.texts)
      if (shipData?.ok && shipData.shipping) setShippingSettings(shipData.shipping)
    })
  }, [])

  // Idempotency key — generated ONCE per checkout session. Survives the
  // lifetime of the page. Sent with the order request. If the user
  // double-clicks "Confirmer" or refreshes the confirmation page, the
  // server uses this key to return the SAME order instead of creating
  // a duplicate. Generated with crypto.randomUUID() (secure, browser-native).
  const [idempotencyKey] = useState(() => {
    if (typeof crypto !== 'undefined' && crypto.randomUUID) {
      return crypto.randomUUID()
    }
    // Fallback for older browsers
    return `ck-${Date.now()}-${Math.random().toString(36).slice(2, 11)}`
  })

  // Track in-flight request to prevent double-submission
  const inFlight = useRef<AbortController | null>(null)

  const currency = { code: shippingSettings.currency, symbol: shippingSettings.currency === 'MAD' ? 'DH' : shippingSettings.currency, locale: 'fr-MA' }
  // Compute shipping from DB-backed settings:
  //   - Free if total >= freeShippingThreshold (and threshold > 0)
  //   - Otherwise, the flat shippingRate
  // This is the DISPLAY value — the server recomputes the actual charge in
  // createOrder using the same settings, so a client-side tampering attempt
  // can't lower the shipping cost.
  const total = subtotal()
  const shipping = shippingSettings.freeShippingThreshold > 0 && total >= shippingSettings.freeShippingThreshold
    ? 0
    : shippingSettings.rate
  const grandTotal = total + shipping

  useEffect(() => {
    Promise.all([
      fetch('/api/countries').then((r) => r.json()),
      fetch('/api/order-fields?locale=fr').then((r) => r.json()),
    ]).then(([cData, fData]) => {
      setCountries(cData.countries || [])
      setDefaultCountryId(cData.defaultId ?? null)
      const fs: OrderFieldDef[] = fData.fields || []
      setFields(fs)
      // prefill defaults
      const init: Record<string, string> = {}
      for (const f of fs) {
        if (f.defaultValue) init[f.key] = f.defaultValue
        else if (f.key === 'country' && cData.defaultId) init[f.key] = cData.defaultId
      }
      setValues(init)
    }).catch(() => {})
  }, [])

  // when country changes, re-fetch fields filtered by country
  const onCountryChange = (countryId: string) => {
    setValues((v) => ({ ...v, country: countryId }))
    setErrors((e) => {
      const next = { ...e }
      delete next.country
      return next
    })
    const country = countries.find((c) => c.id === countryId)
    fetch(`/api/order-fields?locale=fr&countryCode=${country?.code || ''}`)
      .then((r) => r.json())
      .then((d) => setFields(d.fields || []))
      .catch(() => {})
  }

  const [hydrated, setHydrated] = useState(false)
  useEffect(() => {
    // eslint-disable-next-line react-hooks/set-state-in-effect
    setHydrated(true)
  }, [])
  useEffect(() => {
    if (hydrated && items.length === 0 && !submitting) {
      router.replace('/cart')
    }
  }, [hydrated, items.length, submitting, router])

  if (!hydrated || items.length === 0) {
    return (
      <div className="grid place-items-center py-24">
        <Loader2 className="h-6 w-6 animate-spin text-zinc-400" />
      </div>
    )
  }

  const onSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    // Block double-submit at the client level too (defense-in-depth
    // alongside the idempotency key on the server).
    if (submitting || inFlight.current) return
    setSubmitting(true)
    setErrors({})

    // Track begin_checkout event
    import('@/lib/track').then(({ trackEvent }) => {
      trackEvent('begin_checkout', {
        cartValue: total,
        itemCount: items.length,
      })
    })

    // Build the payload: known fields → structured columns, others → customFields
    const payload: Record<string, unknown> = {
      items: items.map((i) => ({
        productId: i.productId,
        variantId: i.variantId ?? null,
        quantity: i.quantity,
      })),
      idempotencyKey,
    }
    const customFields: Record<string, string> = {}
    for (const f of fields) {
      const val = (values[f.key] ?? '').trim()
      if (f.key === 'country') {
        payload.countryId = val
      } else if (FIELD_MAP[f.key]) {
        payload[FIELD_MAP[f.key]] = val
      } else if (val) {
        customFields[f.key] = val
      }
    }
    if (Object.keys(customFields).length) payload.customFields = customFields

    // Use AbortController so we can cancel if user navigates away
    const controller = new AbortController()
    inFlight.current = controller

    try {
      const res = await fetch('/api/orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
        signal: controller.signal,
      })
      const data = await res.json()
      if (!data.ok) {
        // Map server's structured-column error keys BACK to order field keys
        // so the error appears next to the right input.
        //
        // ALIAS HANDLING: the server returns errors keyed by structured
        // column (customerFullName, shippingAddress, ...). The canonical
        // reverse map gives us `full_name`, `address`, ... — but the form
        // may have been rendered with an alias like `name` or `adress`.
        // We need to find the field key that ACTUALLY exists in this
        // form's `fields` array, otherwise the error gets attached to a
        // non-existent input and the user sees no red highlight.
        if (data.fieldErrors) {
          // Build a per-column lookup: for each structured column, find
          // which field key (canonical OR alias) is actually present in
          // the current form. If neither is present, fall back to the
          // canonical key (the error just won't highlight anything).
          const columnToFormFieldKey: Record<string, string> = {}
          for (const f of fields) {
            const col = FIELD_MAP[f.key]
            if (col && !(col in columnToFormFieldKey)) {
              columnToFormFieldKey[col] = f.key
            }
          }
          const mapped: Record<string, string> = {}
          for (const [k, v] of Object.entries(data.fieldErrors as Record<string, string>)) {
            // Prefer the form's actual field key for this column; else
            // fall back to the canonical reverse mapping; else use the
            // raw server key as-is (e.g. for `items`).
            const fieldKey = columnToFormFieldKey[k] || STRUCTURED_TO_FIELD_KEY[k] || k
            mapped[fieldKey] = v
          }
          setErrors(mapped)
        }
        toast.error(data.error || texts.errorMessage[LANG])
        setSubmitting(false)
        inFlight.current = null
        return
      }
      // Order created successfully. Don't clear the cart yet — the
      // confirmation page will do that on successful render. (If we clear
      // here and the navigation fails, the user is stuck with an empty
      // cart and no order number.)
      // Actually clear here — the order is committed server-side.
      clear()
      toast.success(texts.successMessage[LANG])
      // Track purchase event
      import('@/lib/track').then(({ trackEvent }) => {
        trackEvent('purchase', {
          orderNumber: data.order.number,
          total: data.order.total,
          currency: data.order.currencyCode,
          itemCount: data.order.items.length,
        })
      })
      // GA4 purchase event (no-op when GA4 is not configured).
      // Uses transaction_id = order number for deduplication.
      // For COD: this records the ORDER, not the payment — payment happens
      // on delivery. GA4's `purchase` event = "order placed", not "paid".
      import('@/components/analytics/google-analytics').then(({ ga4Events }) => {
        ga4Events.purchase({
          transactionId: data.order.number,
          value: data.order.total,
          currency: data.order.currencyCode,
          items: data.order.items.map((it: any) => ({
            item_id: it.productId || it.name,
            item_name: it.name,
            price: it.lineTotal / it.quantity,
            quantity: it.quantity,
          })),
        })
      })
      // Use replace so the back button doesn't return to the checkout page
      router.replace(`/confirmation/${data.order.number}?key=${encodeURIComponent(idempotencyKey)}`)
    } catch (err: any) {
      if (err?.name === 'AbortError') return
      toast.error('خطأ في الشبكة. حاول مرة أخرى.')
      setSubmitting(false)
      inFlight.current = null
    }
  }

  const setVal = (key: string, val: string) => {
    setValues((v) => ({ ...v, [key]: val }))
    // Clear field error as the user types
    if (errors[key]) {
      setErrors((e) => {
        const next = { ...e }
        delete next[key]
        return next
      })
    }
  }

  return (
    <div className="mx-auto max-w-6xl px-4 py-10 sm:py-14">
      <h1 className="font-display text-3xl font-bold tracking-tight sm:text-4xl">
        {texts.pageTitle[LANG]}
      </h1>
      <p className="mt-2 text-sm text-muted-foreground">
        {texts.pageSubtitle[LANG]}
      </p>

      <form onSubmit={onSubmit} className="mt-8 grid gap-6 lg:grid-cols-3">
        <div className="space-y-6 lg:col-span-2">
          <section className="rounded-3xl border border-border bg-card p-6 shadow-[var(--shadow-xs)]">
            <div className="flex items-center justify-between">
              <h2 className="font-display text-base font-bold tracking-tight">{texts.buyerInfoTitle[LANG]}</h2>
              <span className="text-[11px] text-muted-foreground">{texts.buyerInfoHelper[LANG]}</span>
            </div>
            <div className="mt-5 grid gap-4 sm:grid-cols-2">
              {fields.map((f) => (
                <div key={f.key} className={f.width === 'half' ? 'sm:col-span-1' : 'sm:col-span-2'}>
                  <Label htmlFor={f.key} className={f.required ? 'after:content-["*"] after:ml-0.5 after:text-primary' : ''}>
                    {f.label}
                  </Label>
                  <div className="mt-1.5" data-error={errors[f.key] ? 'true' : 'false'}>
                    <FieldInput
                      field={f}
                      value={values[f.key] ?? ''}
                      onChange={(v) => setVal(f.key, v)}
                      countries={countries}
                      onCountryChange={onCountryChange}
                      invalid={!!errors[f.key]}
                    />
                  </div>
                  {f.helpText && <p className="mt-1 text-xs text-muted-foreground">{f.helpText}</p>}
                  {errors[f.key] && (
                    <p className="mt-1 flex items-center gap-1 text-xs font-medium text-destructive">
                      <span aria-hidden>⚠</span> {errors[f.key]}
                    </p>
                  )}
                </div>
              ))}
            </div>
          </section>
        </div>

        <aside className="lg:col-span-1">
          <div className="sticky top-32 rounded-3xl border border-border bg-card p-5 shadow-[var(--shadow-sm)]">
            <h2 className="font-display text-base font-bold tracking-tight">{texts.cartTitle[LANG]}</h2>
            <div className="mt-3 max-h-64 space-y-2 overflow-y-auto pr-1">
              {items.map((item) => (
                <div key={`${item.productId}-${item.variantId ?? 'x'}`} className="flex gap-2 text-sm">
                  <div className="relative h-12 w-12 flex-shrink-0 overflow-hidden rounded-xl bg-muted">
                    {item.image && <img src={item.image} alt={item.name} className="h-full w-full object-cover" />}
                    <span className="absolute -right-1 -top-1 grid h-4 min-w-4 place-items-center rounded-full bg-secondary px-1 text-[10px] font-bold text-secondary-foreground">{item.quantity}</span>
                  </div>
                  <div className="flex flex-1 flex-col">
                    <span className="line-clamp-1 text-foreground">{item.name}</span>
                    <span className="text-xs text-muted-foreground">{formatPrice(item.price, currency)}</span>
                  </div>
                  <span className="price-display font-medium">{formatPrice(item.price * item.quantity, currency)}</span>
                </div>
              ))}
            </div>
            <dl className="mt-3 space-y-1.5 border-t border-border pt-3 text-sm">
              <div className="flex justify-between"><dt className="text-muted-foreground">{texts.subtotalLabel[LANG]}</dt><dd className="price-display">{formatPrice(total, currency)}</dd></div>
              <div className="flex justify-between"><dt className="text-muted-foreground">{texts.shippingLabel[LANG]}</dt><dd className="price-display">{shipping === 0 ? texts.freeShippingLabel[LANG] : formatPrice(shipping, currency)}</dd></div>
              <div className="flex justify-between border-t border-border pt-2 font-display text-base font-bold"><dt>{texts.totalLabel[LANG]}</dt><dd className="price-display">{formatPrice(grandTotal, currency)}</dd></div>
            </dl>
            <div className="mt-3 space-y-2 rounded-2xl border border-border bg-muted/40 p-3 text-xs">
              <div className="flex items-center gap-2 text-foreground/80"><CreditCard className="h-4 w-4 text-accent" /> {texts.trustCod[LANG]}</div>
              <div className="flex items-center gap-2 text-foreground/80"><Truck className="h-4 w-4 text-accent" /> {texts.trustShipping[LANG]}</div>
              <div className="flex items-center gap-2 text-foreground/80"><ShieldCheck className="h-4 w-4 text-accent" /> {texts.trustPrivacy[LANG]}</div>
            </div>
            <Button
              type="submit"
              disabled={submitting}
              size="lg"
              className="btn-primary-cta mt-3 w-full rounded-full h-12 text-base font-semibold"
              aria-busy={submitting}
            >
              {submitting ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" /> {texts.processingMessage[LANG]}
                </>
              ) : (
                <>
                  <Check className="mr-2 h-4 w-4" /> {texts.submitButton[LANG]}
                </>
              )}
            </Button>
            <p className="mt-2 text-center text-[11px] text-muted-foreground">
              {texts.submitHelper[LANG]}
            </p>
          </div>
        </aside>
      </form>
    </div>
  )
}

function FieldInput({
  field,
  value,
  onChange,
  countries,
  onCountryChange,
  invalid,
}: {
  field: OrderFieldDef
  value: string
  onChange: (v: string) => void
  countries: Country[]
  onCountryChange: (id: string) => void
  invalid?: boolean
}) {
  const maxLength = field.maxLength ?? undefined
  // Apply error styling via aria-invalid + ring color when the field has an error
  const errorClass = invalid ? 'border-rose-500 focus-visible:ring-rose-500' : ''
  switch (field.type) {
    case 'textarea':
      return <Textarea id={field.key} value={value} onChange={(e) => onChange(e.target.value)} placeholder={field.placeholder || ''} maxLength={maxLength} rows={2} required={field.required} className={errorClass} />
    case 'phone':
      return <Input id={field.key} type="tel" value={value} onChange={(e) => onChange(e.target.value)} placeholder={field.placeholder || '+212 6XX XXX XXX'} maxLength={maxLength} required={field.required} className={errorClass} autoComplete="tel" inputMode="tel" />
    case 'email':
      return <Input id={field.key} type="email" value={value} onChange={(e) => onChange(e.target.value)} placeholder={field.placeholder || ''} maxLength={maxLength} required={field.required} className={errorClass} autoComplete="email" inputMode="email" />
    case 'number':
      return <Input id={field.key} type="number" value={value} onChange={(e) => onChange(e.target.value)} placeholder={field.placeholder || ''} required={field.required} className={errorClass} inputMode="numeric" />
    case 'date':
      return <Input id={field.key} type="date" value={value} onChange={(e) => onChange(e.target.value)} required={field.required} className={errorClass} />
    case 'select':
      if (field.key === 'country') {
        return (
          <Select value={value || undefined} onValueChange={onCountryChange} required={field.required}>
            <SelectTrigger className={errorClass}><SelectValue placeholder="Choisir le pays" /></SelectTrigger>
            <SelectContent>
              {countries.map((c) => (
                <SelectItem key={c.id} value={c.id}>{c.name} ({c.phonePrefix})</SelectItem>
              ))}
            </SelectContent>
          </Select>
        )
      }
      return (
        <Select value={value || undefined} onValueChange={onChange} required={field.required}>
          <SelectTrigger className={errorClass}><SelectValue placeholder={field.placeholder || 'Choisir…'} /></SelectTrigger>
          <SelectContent>
            {field.options.map((o) => (
              <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      )
    case 'radio':
      return (
        <RadioGroup value={value} onValueChange={onChange} required={field.required} className="flex flex-col gap-2 pt-1">
          {field.options.map((o) => (
            <div key={o.value} className="flex items-center gap-2">
              <RadioGroupItem value={o.value} id={`${field.key}-${o.value}`} />
              <Label htmlFor={`${field.key}-${o.value}`} className="text-sm font-normal">{o.label}</Label>
            </div>
          ))}
        </RadioGroup>
      )
    case 'checkbox':
      return (
        <div className="flex items-center gap-2 pt-1">
          <Checkbox id={field.key} checked={value === 'true'} onCheckedChange={(c) => onChange(c ? 'true' : '')} />
          <Label htmlFor={field.key} className="text-sm font-normal">{field.label}</Label>
        </div>
      )
    default:
      return <Input id={field.key} value={value} onChange={(e) => onChange(e.target.value)} placeholder={field.placeholder || ''} maxLength={maxLength} required={field.required} className={errorClass} />
  }
}

