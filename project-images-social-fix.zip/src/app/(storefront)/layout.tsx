import { StoreHeader } from '@/components/storefront/store-header'
import { StoreFooter } from '@/components/storefront/store-footer'
import { CartDrawer } from '@/components/storefront/cart-drawer'
import { AnalyticsTracker } from '@/components/storefront/analytics-tracker'
import { CookieConsent } from '@/components/storefront/cookie-consent'
import { getCategories } from '@/services/catalog'
import { getBranding } from '@/services/branding'
import { getSocialLinks, getHeaderTexts, getFooterTexts } from '@/services/site-settings'

export const dynamic = 'force-dynamic'

export default async function StorefrontLayout({ children }: { children: React.ReactNode }) {
  let categories: Array<{ slug: string; name: string; nameAr?: string | null }> = []
  let branding: Awaited<ReturnType<typeof getBranding>> | null = null
  let socialLinks: Awaited<ReturnType<typeof getSocialLinks>> = []
  let headerTexts: Awaited<ReturnType<typeof getHeaderTexts>> | null = null
  let footerTexts: Awaited<ReturnType<typeof getFooterTexts>> | null = null
  try {
    const [cats, b, sl, ht, ft] = await Promise.all([
      getCategories(),
      getBranding(),
      getSocialLinks('footer'),
      getHeaderTexts(),
      getFooterTexts(),
    ])
    categories = cats.map((c) => ({ slug: c.slug, name: c.name, nameAr: c.nameAr }))
    branding = b
    socialLinks = sl
    headerTexts = ht
    footerTexts = ft
  } catch {
    // DB unavailable — render with defaults
  }

  const LANG = 'fr' as const

  return (
    <div className="flex min-h-screen flex-col bg-background">
      <StoreHeader
        categories={categories}
        logoUrl={branding?.logoUrl ?? null}
        siteName={branding?.siteName ?? null}
        supportPhone={branding?.supportPhone ?? null}
        whatsapp={branding?.whatsapp ?? null}
        logoSize={branding?.logoSize ?? null}
        logoMotion={branding?.logoMotion ?? null}
        logoVisual={branding?.logoVisual ?? null}
        logoMobile={branding?.logoMobile ?? null}
        announcementText={headerTexts?.announcementText[LANG] ?? null}
        logoSubtitle={headerTexts?.logoSubtitle[LANG] ?? null}
        searchPlaceholder={headerTexts?.searchPlaceholder[LANG] ?? null}
        catalogueButton={headerTexts?.catalogueButton[LANG] ?? null}
        navHome={headerTexts?.navHome[LANG] ?? null}
        navProducts={headerTexts?.navProducts[LANG] ?? null}
        navAllCategories={headerTexts?.navAllCategories[LANG] ?? null}
      />
      <main className="flex-1">{children}</main>
      <StoreFooter
        branding={
          branding
            ? {
                ...branding,
                socialLinks,
                footerTexts: footerTexts
                  ? {
                      shippingTitle: footerTexts.shippingTitle[LANG],
                      shippingDesc: footerTexts.shippingDesc[LANG],
                      paymentTitle: footerTexts.paymentTitle[LANG],
                      paymentDesc: footerTexts.paymentDesc[LANG],
                      supportTitle: footerTexts.supportTitle[LANG],
                      supportDesc: footerTexts.supportDesc[LANG],
                      copyright: footerTexts.copyright[LANG],
                      codBadge: footerTexts.codBadge[LANG],
                      shippingBadge: footerTexts.shippingBadge[LANG],
                      brandsList: footerTexts.brandsList[LANG],
                      allProducts: footerTexts.allProducts[LANG],
                      categoriesTitle: footerTexts.categoriesTitle[LANG],
                      featuredProducts: footerTexts.featuredProducts[LANG],
                      bestSellers: footerTexts.bestSellers[LANG],
                      newArrivals: footerTexts.newArrivals[LANG],
                      helpTitle: footerTexts.helpTitle[LANG],
                      helpCenter: footerTexts.helpCenter[LANG],
                      contactUs: footerTexts.contactUs[LANG],
                      faq: footerTexts.faq[LANG],
                      shippingReturns: footerTexts.shippingReturns[LANG],
                      terms: footerTexts.terms[LANG],
                    }
                  : undefined,
              }
            : null
        }
      />
      <CartDrawer />
      <AnalyticsTracker />
      <CookieConsent />
    </div>
  )
}
