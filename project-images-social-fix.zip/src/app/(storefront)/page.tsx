import Link from 'next/link'
import {
  ArrowRight, ShieldCheck, Truck, CreditCard, Headphones,
  Wrench, ChevronRight, ChevronDown, Package, Star,
} from 'lucide-react'
import { getFeaturedProducts, getBestSellers, getNewArrivals, getCategories, getBrands } from '@/services/catalog'
import { ProductCard } from '@/components/storefront/product-card'
import { Button } from '@/components/ui/button'
import { siteConfig } from '@/config/site'
import { getPublicSettings } from '@/services/settings'
import { getBranding } from '@/services/branding'
import { getProductionDomain } from '@/services/settings'
import { buildBreadcrumbSchema } from '@/lib/seo-schemas'
import { HeroImage } from '@/components/storefront/hero-image'
import type { Metadata } from 'next'

export const metadata: Metadata = {
  title: `${siteConfig.name} — ${siteConfig.tagline}`,
  description: siteConfig.description,
  alternates: { canonical: '/' },
}

export const revalidate = 60

/**
 * Homepage — "Atelier Brut" composition.
 *
 * DESIGN INTENT
 * -------------
 * The homepage is NOT a stack of cards in a grid. It's an editorial layout:
 *
 *   1. HERO — asymmetric: text on the LEFT, 3D scene on the RIGHT
 *      (on desktop). Mobile flips vertically: text first, then a
 *      smaller 3D scene below.
 *
 *   2. STATS STRIP — minimal, large numbers in display font
 *
 *   3. CATEGORIES — featured tiles with imagery, asymmetric grid
 *
 *   4. FEATURED PRODUCTS — full-bleed band, products in a refined grid
 *      using the redesigned ProductCard (with depth + tilt)
 *
 *   5. PROMO — a single, bold, dark "Atelier" panel explaining COD flow
 *      in 3 steps (numbered, not card-grid)
 *
 *   6. BEST SELLERS — slim row, fewer items, more breathing room
 *
 *   7. NEW ARRIVALS — wider grid, looks editorial
 *
 *   8. BRANDS — minimalist pill row, with counts
 *
 *   9. FAQ — accordion, generous whitespace
 *
 * The page alternates light/cream backgrounds to give a sense of
 * "moving through rooms" — not one continuous scroll of cards.
 */
export default async function HomePage() {
  let settings: Record<string, string> = {}
  try {
    settings = await getPublicSettings()
  } catch {
    // ignore — use defaults
  }

  // Get branding (includes hero image URL from DB)
  let branding: Awaited<ReturnType<typeof getBranding>> | null = null
  try {
    branding = await getBranding()
  } catch {
    // ignore — use defaults
  }
  const heroImageUrl = branding?.raw?.hero_image_url || null
  // Check if hero image is visible (default: true when not set)
  // When admin hides the image, NOTHING renders in its place — no fallback,
  // no placeholder, no logo, no animation.
  const heroImageVisible = branding?.raw?.hero_image_visible !== 'false'

  const siteName = settings.site_name || siteConfig.name
  const heroBadge = settings.hero_badge || 'Outillage professionnel · Maroc'
  const heroTitle =
    settings.hero_title || "L'outillage pro,\nlivré chez vous."
  const heroSubtitle =
    settings.hero_subtitle ||
    "Perceuses, visseuses, meuleuses, niveaux laser — marques fiables (INGCO, Total Tools, Crown, Würth), paiement à la livraison, expédition 24–72h partout au Maroc."
  const heroCta1Label = settings.hero_cta1_label || 'Voir le catalogue'
  const heroCta1Href = settings.hero_cta1_href || '/produits'
  const heroCta2Label = settings.hero_cta2_label || 'Comment commander ?'
  const heroCta2Href = settings.hero_cta2_href || '/aide'

  const [featured, bestSellers, newArrivals, categories, brands] = await Promise.all([
    getFeaturedProducts(8),
    getBestSellers(4),
    getNewArrivals(4),
    getCategories(),
    getBrands(),
  ])

  const heroCategories = categories.slice(0, 4)

  // ─── Homepage schema ────────────────────────────────────────────
  // The root layout (src/app/layout.tsx) already renders `Store` +
  // `WebSite` schemas globally, so we do NOT duplicate them here.
  // The homepage only needs a BreadcrumbList with a single entry
  // (the home page itself), per Google's recommendation for the root URL.
  //
  // Reference: https://developers.google.com/search/docs/appearance/structured-data/breadcrumblist
  //   "While the homepage isn't typically shown with a breadcrumb trail,
  //    you can still include a BreadcrumbList with one entry pointing to
  //    the homepage itself."
  const siteUrl = await getProductionDomain()
  const breadcrumbSchema = buildBreadcrumbSchema(siteUrl, [
    { name: siteName, path: '/' },
  ])

  // Split hero title by newline (preserves multi-line display)
  const heroTitleLines = heroTitle.split('\n').filter(Boolean)

  return (
    <>
      {breadcrumbSchema && (
        <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbSchema) }} />
      )}

      {/* === HERO === */}
      <section className="relative overflow-hidden border-b border-neutral-200 bg-white">
        <div className="relative mx-auto grid max-w-7xl items-center gap-8 px-4 py-12 sm:py-16 lg:grid-cols-12 lg:py-20">
          {/* Left column — text content (7/12 on desktop) */}
          <div className="lg:col-span-7 fade-in">
            {heroBadge && (
              <span className="inline-flex items-center gap-1.5 rounded-full border border-neutral-200 bg-white px-3 py-1.5 text-xs font-semibold text-neutral-700">
                <Star className="h-3.5 w-3.5 fill-amber-500 text-amber-500" />
                {heroBadge}
              </span>
            )}

            <h1 className="mt-5 font-display text-4xl font-bold leading-[1.05] tracking-tight text-neutral-900 sm:text-5xl lg:text-6xl">
              {heroTitleLines.length > 1 ? (
                <>
                  <span className="block">{heroTitleLines[0]}</span>
                  <span className="block text-amber-700">
                    {heroTitleLines.slice(1).join(' ')}
                  </span>
                </>
              ) : (
                heroTitle
              )}
            </h1>

            <p className="mt-5 max-w-xl text-base leading-relaxed text-muted-foreground sm:text-lg">
              {heroSubtitle}
            </p>

            <div className="mt-7 flex flex-wrap items-center gap-3">
              <Button asChild size="lg" className="btn-primary-cta h-12 rounded-full px-7 text-base font-semibold">
                <Link href={heroCta1Href}>
                  {heroCta1Label}
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </Button>
              {heroCta2Label && heroCta2Href && (
                <Button
                  asChild
                  size="lg"
                  variant="outline"
                  className="h-12 rounded-full border-border bg-card/40 px-6 text-base font-medium backdrop-blur transition-colors hover:bg-card"
                >
                  <Link href={heroCta2Href}>{heroCta2Label}</Link>
                </Button>
              )}
            </div>

            {/* Stats — minimalist, big numbers */}
            <div className="mt-10 grid grid-cols-3 gap-4 border-t border-border pt-6 sm:max-w-md">
              {[
                { v: settings.stat1_value || '500+', l: settings.stat1_label || 'Produits' },
                { v: settings.stat2_value || '24h', l: settings.stat2_label || 'Livraison' },
                { v: settings.stat3_value || 'COD', l: settings.stat3_label || 'Paiement' },
              ].map((s) => (
                <div key={s.l}>
                  <div className="font-display text-2xl font-bold tracking-tight text-foreground">
                    {s.v}
                  </div>
                  <div className="mt-0.5 text-[10px] font-medium uppercase tracking-[0.12em] text-muted-foreground">
                    {s.l}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Right column — hero image (5/12 on desktop, full on mobile) */}
          <div className="lg:col-span-5 fade-in-delayed-2">
            {heroImageVisible && <HeroImage imageUrl={heroImageUrl} />}

            {/* Floating accent label below the hero image */}
            <div className="mt-4 flex flex-wrap justify-center gap-2">
              {heroCategories.slice(0, 3).map((c) => (
                <Link
                  key={c.id}
                  href={`/categories/${c.slug}`}
                  className="tag-pill transition-colors hover:border-primary hover:text-primary"
                >
                  {c.name}
                  {c._count?.products !== undefined && (
                    <span className="ml-1 text-[10px] opacity-60">{c._count.products}</span>
                  )}
                </Link>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* === BENEFITS — slim band === */}
      <section className="border-b border-border bg-card">
        <div className="mx-auto grid max-w-7xl grid-cols-2 divide-x divide-y divide-border sm:grid-cols-4 sm:divide-y-0">
          {[
            { icon: Truck, t: 'Livraison Maroc', s: '24–72h · dès 30 DH' },
            { icon: CreditCard, t: 'Paiement à la livraison', s: 'Cash à la réception' },
            { icon: ShieldCheck, t: 'Produits authentiques', s: 'Garantie constructeur' },
            { icon: Headphones, t: 'Support expert', s: settings.support_phone || 'Lun–Sam 9h–19h' },
          ].map((b) => (
            <div
              key={b.t}
              className="flex items-center gap-3 px-5 py-5"
            >
              <div className="grid size-10 place-items-center rounded-full bg-muted text-primary">
                <b.icon className="h-5 w-5" strokeWidth={1.6} />
              </div>
              <div className="min-w-0">
                <div className="truncate font-display text-sm font-semibold tracking-tight">
                  {b.t}
                </div>
                <div className="truncate text-xs text-muted-foreground">{b.s}</div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* === CATEGORIES — asymmetric tiles === */}
      {categories.length > 0 && (
        <section className="mx-auto max-w-7xl px-4 py-14 sm:py-16">
          <div className="mb-8 flex items-end justify-between">
            <div>
              <span className="section-label">Catégories</span>
              <h2 className="mt-3 font-display text-2xl font-bold tracking-tight sm:text-3xl">
                Explorez par usage
              </h2>
            </div>
            <Link
              href="/categories"
              className="inline-flex items-center gap-1.5 text-sm font-medium text-muted-foreground transition-colors hover:text-primary"
            >
              Toutes les catégories <ArrowRight className="h-4 w-4" />
            </Link>
          </div>

          {/* Asymmetric grid — first tile is large, then varied */}
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4 lg:grid-rows-2">
            {categories.slice(0, 5).map((c, i) => {
              // First tile spans 2 cols + 2 rows on desktop
              const isLarge = i === 0
              return (
                <Link
                  key={c.id}
                  href={`/categories/${c.slug}`}
                  className={`group relative overflow-hidden rounded-2xl border border-border bg-card shadow-[var(--shadow-xs)] transition-all hover:shadow-[var(--shadow-md)] ${
                    isLarge ? 'lg:col-span-2 lg:row-span-2' : ''
                  }`}
                >
                  <div className="flex h-full min-h-[180px] flex-col justify-between p-6">
                    <div className="flex items-start justify-between">
                      <div className="grid size-12 place-items-center rounded-xl bg-muted text-primary transition-transform duration-300 group-hover:scale-110">
                        <Wrench className="h-5 w-5" strokeWidth={1.6} />
                      </div>
                      <ArrowRight className="h-4 w-4 -translate-x-2 text-muted-foreground opacity-0 transition-all duration-300 group-hover:translate-x-0 group-hover:opacity-100" />
                    </div>
                    <div>
                      <div className={`font-display font-bold tracking-tight ${isLarge ? 'text-2xl' : 'text-lg'}`}>
                        {c.name}
                      </div>
                      {c._count?.products !== undefined && (
                        <div className="mt-1 text-xs text-muted-foreground">
                          {c._count.products} {c._count.products > 1 ? 'produits' : 'produit'}
                        </div>
                      )}
                    </div>
                  </div>
                  {/* Subtle gradient overlay on hover */}
                  <div
                    className="pointer-events-none absolute inset-0 opacity-0 transition-opacity duration-300 group-hover:opacity-100"
                    style={{
                      background:
                        'radial-gradient(ellipse at bottom right, rgba(178, 58, 14, 0.06) 0%, transparent 50%)',
                    }}
                  />
                </Link>
              )
            })}
          </div>
        </section>
      )}

      {/* === FEATURED PRODUCTS — full-bleed band === */}
      {featured.length > 0 && (
        <section className="border-y border-border bg-background-subtle">
          <div className="mx-auto max-w-7xl px-4 py-14 sm:py-16">
            <div className="mb-8 flex items-end justify-between">
              <div>
                <span className="section-label">Sélection</span>
                <h2 className="mt-3 font-display text-2xl font-bold tracking-tight sm:text-3xl">
                  Produits en vedette
                </h2>
              </div>
              <Link
                href="/produits?filter=featured"
                className="inline-flex items-center gap-1.5 text-sm font-medium text-muted-foreground transition-colors hover:text-primary"
              >
                Tout voir <ArrowRight className="h-4 w-4" />
              </Link>
            </div>
            <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
              {featured.map((p) => <ProductCard key={p.id} product={p} />)}
            </div>
          </div>
        </section>
      )}

      {/* === PROMO — "Atelier COD" panel === */}
      <section className="mx-auto max-w-7xl px-4 py-16">
        <div className="overflow-hidden rounded-2xl bg-neutral-900">
          <div className="grid gap-8 p-8 sm:p-12 lg:grid-cols-2 lg:items-center">
            <div>
              <span className="inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-wide text-amber-500">
                <span className="h-px w-6 bg-amber-500" /> Offre du moment
              </span>
              <h2 className="mt-4 font-display text-3xl font-bold leading-tight tracking-tight text-white sm:text-4xl">
                Paiement à la livraison
                <br />
                <span className="text-amber-500">partout au Maroc</span>
              </h2>
              <p className="mt-3 max-w-md text-sm leading-relaxed text-neutral-300">
                Commandez en 30 secondes, sans compte, sans carte bancaire.
                Payez en espèces à la réception du colis.
              </p>
              <Button
                asChild
                className="btn-secondary-cta mt-6 h-12 rounded-full bg-card px-7 text-base font-semibold text-secondary hover:bg-card/90"
              >
                <Link href="/produits">
                  Commander maintenant <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </Button>
            </div>

            {/* 3-step flow — numbered, not card grid */}
            <div className="relative grid grid-cols-3 gap-3 self-center">
              {[
                { n: '01', t: 'Ajoutez au panier', s: 'Parcourez le catalogue' },
                { n: '02', t: 'Remplissez le formulaire', s: 'Nom · Téléphone · Adresse' },
                { n: '03', t: 'Payez à la réception', s: 'En espèces, au livreur' },
              ].map((s) => (
                <div
                  key={s.n}
                  className="rounded-2xl border border-border-strong/20 bg-card/5 p-4 backdrop-blur-sm"
                >
                  <div className="font-mono text-xs font-bold text-accent">{s.n}</div>
                  <div className="mt-2 font-display text-sm font-semibold text-secondary-foreground">
                    {s.t}
                  </div>
                  <div className="mt-1 text-[11px] text-secondary-foreground/60">
                    {s.s}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* === BEST SELLERS — slim row === */}
      {bestSellers.length > 0 && (
        <section className="mx-auto max-w-7xl px-4 py-14 sm:py-16">
          <div className="mb-8 flex items-end justify-between">
            <div>
              <span className="section-label">Top ventes</span>
              <h2 className="mt-3 font-display text-2xl font-bold tracking-tight sm:text-3xl">
                Les plus demandés
              </h2>
            </div>
            <Link
              href="/produits?filter=best"
              className="inline-flex items-center gap-1.5 text-sm font-medium text-muted-foreground transition-colors hover:text-primary"
            >
              Tout voir <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
          <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
            {bestSellers.map((p) => <ProductCard key={p.id} product={p} />)}
          </div>
        </section>
      )}

      {/* === NEW ARRIVALS — wider grid === */}
      {newArrivals.length > 0 && (
        <section className="border-y border-border bg-background-subtle">
          <div className="mx-auto max-w-7xl px-4 py-14 sm:py-16">
            <div className="mb-8 flex items-end justify-between">
              <div>
                <span className="section-label">Nouveautés</span>
                <h2 className="mt-3 font-display text-2xl font-bold tracking-tight sm:text-3xl">
                  Dernières arrivées
                </h2>
              </div>
              <Link
                href="/produits?filter=new"
                className="inline-flex items-center gap-1.5 text-sm font-medium text-muted-foreground transition-colors hover:text-primary"
              >
                Tout voir <ArrowRight className="h-4 w-4" />
              </Link>
            </div>
            <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
              {newArrivals.map((p) => <ProductCard key={p.id} product={p} />)}
            </div>
          </div>
        </section>
      )}

      {/* === BRANDS — pill row === */}
      {brands.length > 0 && (
        <section className="mx-auto max-w-7xl px-4 py-14 sm:py-16">
          <div className="mb-8">
            <span className="section-label">Marques</span>
            <h2 className="mt-3 font-display text-2xl font-bold tracking-tight sm:text-3xl">
              Distributeurs officiels
            </h2>
          </div>
          <div className="flex flex-wrap gap-3">
            {brands.map((b) => (
              <Link
                key={b.id}
                href={`/categories?brand=${b.slug}`}
                className="group inline-flex items-center gap-2 rounded-full border border-border bg-card px-5 py-2.5 text-sm font-medium text-foreground transition-all hover:border-primary hover:text-primary hover:shadow-[var(--shadow-sm)]"
              >
                <Package className="h-3.5 w-3.5 text-muted-foreground transition-colors group-hover:text-primary" strokeWidth={1.6} />
                {b.name}
                <span className="ml-1 text-xs text-muted-foreground">({b._count.products})</span>
              </Link>
            ))}
          </div>
        </section>
      )}

      {/* === FAQ — accordion === */}
      <section className="border-t border-border bg-card">
        <div className="mx-auto max-w-3xl px-4 py-16 sm:py-20">
          <div className="text-center">
            <span className="kicker justify-center">Aide</span>
            <h2 className="mt-4 font-display text-2xl font-bold tracking-tight sm:text-3xl">
              Questions fréquentes
            </h2>
          </div>
          <div className="mt-8 divide-y divide-border border-y border-border">
            {[
              {
                q: 'Comment commander ?',
                a: "Ajoutez vos produits au panier, remplissez le formulaire de commande (nom, téléphone, adresse), confirmez. Pas besoin de créer un compte.",
              },
              {
                q: 'Comment payer ?',
                a: "Paiement à la livraison (Cash On Delivery). Vous payez en espèces au livreur à la réception de votre colis.",
              },
              {
                q: 'Quels sont les délais de livraison ?',
                a: "Livraison sous 24–72h dans les grandes villes, 2–5 jours en zone rurale. Frais à partir de 30 DH.",
              },
              {
                q: 'Puis-je retourner un produit ?',
                a: "Oui, sous 7 jours si le produit est intact et dans son emballage d'origine. Contactez notre support.",
              },
            ].map((f) => (
              <details key={f.q} className="group py-5">
                <summary className="flex cursor-pointer list-none items-center justify-between font-display text-base font-medium text-foreground">
                  {f.q}
                  <ChevronDown className="h-4 w-4 text-muted-foreground transition-transform group-open:rotate-180" />
                </summary>
                <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
                  {f.a}
                </p>
              </details>
            ))}
          </div>
        </div>
      </section>
    </>
  )
}
