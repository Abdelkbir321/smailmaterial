'use client'

import * as React from 'react'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { toast } from 'sonner'
import { Loader2, Store, ShieldCheck } from 'lucide-react'

import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Toaster as SonnerToaster } from '@/components/ui/sonner'

export default function AdminLoginPage() {
  const router = useRouter()
  const [email, setEmail] = React.useState('')
  const [password, setPassword] = React.useState('')
  const [loading, setLoading] = React.useState(false)
  const [errors, setErrors] = React.useState<{ email?: string; password?: string }>({})

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault()
    if (loading) return
    setErrors({})
    if (!email) {
      setErrors({ email: 'البريد الإلكتروني مطلوب' })
      return
    }
    if (!password) {
      setErrors({ password: 'كلمة المرور مطلوبة' })
      return
    }
    setLoading(true)
    try {
      const res = await fetch('/api/admin/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ email, password }),
      })
      const data = await res.json().catch(() => ({}))
      if (!res.ok || !data.ok) {
        toast.error(data.error || 'فشل تسجيل الدخول')
        return
      }
      toast.success(`مرحباً ${data.admin?.fullName ?? 'المدير'}`)
      router.push('/admin/dashboard')
      router.refresh()
    } catch {
      toast.error('خطأ في الاتصال بالشبكة. حاول مجدداً.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="bg-zinc-50 flex min-h-svh flex-col items-center justify-center px-4 py-12">
      <SonnerToaster richColors position="top-center" dir="rtl" />
      <div className="w-full max-w-sm">
        <div className="mb-6 flex flex-col items-center gap-2 text-center">
          <div className="bg-zinc-900 text-white rounded-xl size-12 flex items-center justify-center shadow-sm">
            <ShieldCheck className="size-6" />
          </div>
          <div className="space-y-0.5">
            <h1 className="text-xl font-semibold tracking-tight">لوحة تحكم أطلس</h1>
            <p className="text-muted-foreground text-xs">
              مساحة مخصصة للإدارة فقط
            </p>
          </div>
        </div>
        <Card className="shadow-sm">
          <CardHeader>
            <CardTitle className="text-base">تسجيل الدخول</CardTitle>
            <CardDescription>
              أدخل بياناتك للوصول إلى لوحة التحكم.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={onSubmit} className="space-y-4">
              <div className="space-y-1.5">
                <Label htmlFor="email">البريد الإلكتروني</Label>
                <Input
                  id="email"
                  type="email"
                  autoComplete="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  disabled={loading}
                  dir="ltr"
                  className="text-left"
                />
                {errors.email && (
                  <p className="text-destructive text-xs">{errors.email}</p>
                )}
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="password">كلمة المرور</Label>
                <Input
                  id="password"
                  type="password"
                  autoComplete="current-password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  disabled={loading}
                  dir="ltr"
                  className="text-left"
                />
                {errors.password && (
                  <p className="text-destructive text-xs">{errors.password}</p>
                )}
              </div>
              <Button
                type="submit"
                className="bg-zinc-900 hover:bg-zinc-800 w-full"
                disabled={loading}
              >
                {loading ? (
                  <>
                    <Loader2 className="size-4 animate-spin" />
                    جارٍ الدخول…
                  </>
                ) : (
                  'تسجيل الدخول'
                )}
              </Button>
            </form>
          </CardContent>
        </Card>
        <div className="mt-4 flex justify-center">
          <Button asChild variant="link" size="sm" className="text-muted-foreground">
            <Link href="/">
              <Store className="size-3.5" />
              العودة إلى المتجر
            </Link>
          </Button>
        </div>
      </div>
    </div>
  )
}
