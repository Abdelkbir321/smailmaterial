import { redirect } from 'next/navigation'
import { getCurrentAdmin } from '@/lib/auth'
import { AdminShell, type AdminInfo } from '@/components/admin/admin-shell'

export const dynamic = 'force-dynamic'

export default async function AdminDashboardLayout({
  children,
}: {
  children: React.ReactNode
}) {
  const admin = await getCurrentAdmin()
  if (!admin) redirect('/admin/login')

  const info: AdminInfo = {
    id: admin.id,
    email: admin.email,
    fullName: admin.fullName,
    role: { name: admin.role.name, slug: admin.role.slug },
    permissions: (admin.role.permissions as Record<string, string[]>) ?? {},
  }

  return (
    <AdminShell admin={info}>
      <div className="mx-auto w-full max-w-7xl space-y-6">{children}</div>
    </AdminShell>
  )
}
