'use client'

import * as React from 'react'
import Link from 'next/link'
import {
  AlertTriangle, CheckCircle2, XCircle, Loader2, RefreshCw,
  Package, ShoppingCart, Star, Database, Cloud, Globe,
  Activity, ChevronRight,
} from 'lucide-react'
import { toast } from 'sonner'

import { PageHeader, Spinner } from '@/components/admin/page-header'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'

interface DiagnosticsData {
  productIssues: {
    total: number
    published: number
    drafts: number
    noImages: number
    noDescription: number
    noCategory: number
    noSeoTitle: number
    noSeoDescription: number
    noBrand: number
    noPrice: number
  }
  incompleteProducts: Array<{
    id: string
    name: string
    slug: string
    sku: string
    status: string
    issues: string[]
  }>
  orderStats: { total: number; pending: number; today: number; cancelledThisWeek: number }
  reviewStats: { total: number; pending: number; approved: number }
  catalogStats: { totalCategories: number; totalBrands: number; totalProducts: number }
  systemHealth: {
    database: boolean
    cloudinaryConfigured: boolean
    siteUrlConfigured: boolean
    nodeEnv: string
    timestamp: string
  }
  recentAuditLogs: Array<{
    id: string
    action: string
    entity: string
    entityId: string | null
    createdAt: string
    adminName: string
    adminEmail: string | null
  }>
}

const ISSUE_LABELS: Record<string, string> = {
  no_images: 'بدون صور',
  no_description: 'بدون وصف',
  no_category: 'بدون تصنيف',
  no_seo_title: 'بدون عنوان SEO',
  no_seo_desc: 'بدون وصف SEO',
  no_brand: 'بدون علامة تجارية',
  no_price: 'بدون سعر',
}

const STATUS_LABEL: Record<string, string> = {
  PUBLISHED: 'منشور',
  DRAFT: 'مسودة',
  ARCHIVED: 'مؤرشف',
  OUT_OF_STOCK: 'غير متوفر',
}

export default function DiagnosticsPage() {
  const [data, setData] = React.useState<DiagnosticsData | null>(null)
  const [loading, setLoading] = React.useState(true)
  const [refreshing, setRefreshing] = React.useState(false)

  async function load() {
    setRefreshing(true)
    try {
      const res = await fetch('/api/admin/diagnostics', { credentials: 'include' })
      const json = await res.json()
      if (!res.ok || !json.ok) {
        toast.error(json.error || 'فشل تحميل التشخيص')
        return
      }
      setData(json)
    } catch {
      toast.error('خطأ في الشبكة')
    } finally {
      setLoading(false)
      setRefreshing(false)
    }
  }

  React.useEffect(() => {
    load()
  }, [])

  if (loading || !data) {
    return (
      <div className="space-y-6">
        <PageHeader
          title="تشخيص النظام"
          description="حالة المتجر والمنتجات والطلبات والأمان"
          breadcrumb={[{ label: 'الإدارة', href: '/admin/dashboard' }, { label: 'التشخيص' }]}
        />
        <Spinner />
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <PageHeader
        title="تشخيص النظام"
        description="حالة المتجر والمنتجات والطلبات والأمان"
        breadcrumb={[{ label: 'الإدارة', href: '/admin/dashboard' }, { label: 'التشخيص' }]}
        actions={
          <Button variant="outline" size="sm" onClick={load} disabled={refreshing}>
            {refreshing ? <Loader2 className="size-4 animate-spin" /> : <RefreshCw className="size-4" />}
            تحديث
          </Button>
        }
      />

      {/* ─── System Health ─── */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base">
            <Activity className="size-4" /> حالة النظام
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            <HealthItem
              icon={Database}
              label="قاعدة البيانات"
              ok={data.systemHealth.database}
              okLabel="متصل"
              failLabel="غير متصل"
            />
            <HealthItem
              icon={Globe}
              label="النطاق الرسمي"
              ok={data.systemHealth.siteUrlConfigured}
              okLabel="مُكون"
              failLabel="غير مُكون"
            />
            <HealthItem
              icon={Cloud}
              label="Cloudinary"
              ok={data.systemHealth.cloudinaryConfigured}
              okLabel="مُكون"
              failLabel="غير مُكون (رفع الصور معطل)"
            />
            <HealthItem
              icon={Activity}
              label="البيئة"
              ok={data.systemHealth.nodeEnv === 'production'}
              okLabel="Production"
              failLabel={data.systemHealth.nodeEnv}
              neutral={data.systemHealth.nodeEnv !== 'production'}
            />
          </div>
          <p className="mt-3 text-xs text-muted-foreground">
            آخر فحص: {new Date(data.systemHealth.timestamp).toLocaleString('ar-MA')}
          </p>
        </CardContent>
      </Card>

      {/* ─── Quick stats ─── */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard
          icon={Package}
          label="المنتجات"
          value={data.catalogStats.totalProducts}
          sub={`${data.productIssues.published} منشور · ${data.productIssues.drafts} مسودة`}
          color="text-blue-600"
        />
        <StatCard
          icon={ShoppingCart}
          label="الطلبات"
          value={data.orderStats.total}
          sub={`${data.orderStats.pending} في الانتظار · ${data.orderStats.today} اليوم`}
          color="text-emerald-600"
        />
        <StatCard
          icon={Star}
          label="التقييمات"
          value={data.reviewStats.total}
          sub={`${data.reviewStats.pending} في الانتظار · ${data.reviewStats.approved} منشور`}
          color="text-amber-600"
          alert={data.reviewStats.pending > 0}
        />
        <StatCard
          icon={AlertTriangle}
          label="منتجات ناقصة"
          value={data.incompleteProducts.length}
          sub={data.incompleteProducts.length === 0 ? 'كل المنتجات مكتملة' : 'تحتاج إصلاح'}
          color={data.incompleteProducts.length === 0 ? 'text-emerald-600' : 'text-rose-600'}
        />
      </div>

      {/* ─── Product completeness ─── */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base">
            <Package className="size-4" /> اكتمال المنتجات
          </CardTitle>
        </CardHeader>
        <CardContent>
          {data.incompleteProducts.length === 0 ? (
            <div className="flex items-center gap-2 rounded-lg bg-emerald-50 p-4 text-emerald-700">
              <CheckCircle2 className="size-5" />
              <p className="text-sm font-medium">كل المنتجات مكتملة — لا توجد حقول ناقصة.</p>
            </div>
          ) : (
            <>
              {/* Issue summary */}
              <div className="mb-4 flex flex-wrap gap-2">
                {data.productIssues.noImages > 0 && <Badge variant="outline" className="text-rose-600">بدون صور: {data.productIssues.noImages}</Badge>}
                {data.productIssues.noDescription > 0 && <Badge variant="outline" className="text-rose-600">بدون وصف: {data.productIssues.noDescription}</Badge>}
                {data.productIssues.noCategory > 0 && <Badge variant="outline" className="text-rose-600">بدون تصنيف: {data.productIssues.noCategory}</Badge>}
                {data.productIssues.noSeoTitle > 0 && <Badge variant="outline" className="text-amber-600">بدون عنوان SEO: {data.productIssues.noSeoTitle}</Badge>}
                {data.productIssues.noSeoDescription > 0 && <Badge variant="outline" className="text-amber-600">بدون وصف SEO: {data.productIssues.noSeoDescription}</Badge>}
                {data.productIssues.noBrand > 0 && <Badge variant="outline" className="text-amber-600">بدون علامة: {data.productIssues.noBrand}</Badge>}
                {data.productIssues.noPrice > 0 && <Badge variant="outline" className="text-rose-600">بدون سعر: {data.productIssues.noPrice}</Badge>}
              </div>

              {/* Incomplete products list */}
              <div className="space-y-2">
                {data.incompleteProducts.map((p) => (
                  <div key={p.id} className="flex items-center justify-between rounded-lg border p-3">
                    <div className="flex-1 min-w-0">
                      <Link href={`/admin/products/${p.id}`} className="font-medium text-sm hover:underline truncate block">
                        {p.name}
                      </Link>
                      <p className="text-xs text-muted-foreground font-mono" dir="ltr">{p.sku}</p>
                    </div>
                    <div className="flex flex-wrap items-center gap-1.5">
                      <Badge variant="outline" className="text-xs">{STATUS_LABEL[p.status] || p.status}</Badge>
                      {p.issues.map((issue) => (
                        <Badge key={issue} variant="outline" className="text-xs text-rose-600">
                          {ISSUE_LABELS[issue] || issue}
                        </Badge>
                      ))}
                      <Button asChild size="sm" variant="ghost">
                        <Link href={`/admin/products/${p.id}`}>
                          إصلاح <ChevronRight className="size-3" />
                        </Link>
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </>
          )}
        </CardContent>
      </Card>

      {/* ─── Recent audit log ─── */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between text-base">
            <span className="flex items-center gap-2">
              <Activity className="size-4" /> آخر العمليات
            </span>
            <Button asChild size="sm" variant="ghost">
              <Link href="/admin/audit-logs">عرض الكل</Link>
            </Button>
          </CardTitle>
        </CardHeader>
        <CardContent>
          {data.recentAuditLogs.length === 0 ? (
            <p className="text-sm text-muted-foreground">لا توجد عمليات مسجلة.</p>
          ) : (
            <div className="space-y-2">
              {data.recentAuditLogs.map((log) => (
                <div key={log.id} className="flex items-start gap-3 text-sm border-b last:border-0 pb-2 last:pb-0">
                  <div className="flex-1 min-w-0">
                    <p className="font-mono text-xs text-muted-foreground" dir="ltr">{log.action}</p>
                    <p className="text-xs text-muted-foreground">
                      {log.adminName} · {new Date(log.createdAt).toLocaleString('ar-MA')}
                    </p>
                  </div>
                  <Badge variant="outline" className="text-xs">{log.entity}</Badge>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}

function HealthItem({
  icon: Icon,
  label,
  ok,
  okLabel,
  failLabel,
  neutral,
}: {
  icon: React.ComponentType<{ className?: string }>
  label: string
  ok: boolean
  okLabel: string
  failLabel: string
  neutral?: boolean
}) {
  return (
    <div className="flex items-center gap-3 rounded-lg border p-3">
      <div className={`grid size-9 place-items-center rounded-lg ${ok ? 'bg-emerald-50 text-emerald-600' : neutral ? 'bg-amber-50 text-amber-600' : 'bg-rose-50 text-rose-600'}`}>
        <Icon className="size-4" />
      </div>
      <div className="flex-1 min-w-0">
        <p className="text-xs text-muted-foreground">{label}</p>
        <p className="text-sm font-medium flex items-center gap-1">
          {ok ? <CheckCircle2 className="size-3.5 text-emerald-600" /> : neutral ? <AlertTriangle className="size-3.5 text-amber-600" /> : <XCircle className="size-3.5 text-rose-600" />}
          {ok ? okLabel : failLabel}
        </p>
      </div>
    </div>
  )
}

function StatCard({
  icon: Icon,
  label,
  value,
  sub,
  color,
  alert,
}: {
  icon: React.ComponentType<{ className?: string }>
  label: string
  value: number
  sub: string
  color: string
  alert?: boolean
}) {
  return (
    <Card className={alert ? 'border-amber-300 bg-amber-50/50' : ''}>
      <CardContent className="p-4">
        <div className="flex items-center justify-between">
          <span className="text-xs text-muted-foreground">{label}</span>
          <Icon className={`size-4 ${color}`} />
        </div>
        <p className="mt-2 font-display text-2xl font-bold tracking-tight">{value}</p>
        <p className="mt-0.5 text-xs text-muted-foreground">{sub}</p>
      </CardContent>
    </Card>
  )
}
