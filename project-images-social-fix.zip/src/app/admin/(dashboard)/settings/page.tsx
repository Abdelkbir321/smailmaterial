import { SettingsTabs } from '@/components/admin/settings/settings-tabs'
import { getAllSettings, getFeatureFlags } from '@/services/settings'
import { getAllSocialLinksAdmin, getCheckoutTexts, getTypography, getDesignSettings, getHeaderTexts, getFooterTexts, getShippingReturnSettings } from '@/services/site-settings'

export const dynamic = 'force-dynamic'

export default async function SettingsPage() {
  // Fetch all data in parallel
  const [
    allSettings,
    featureFlags,
    socialLinks,
    checkoutTexts,
    typography,
    design,
    headerTexts,
    footerTexts,
    shippingReturn,
  ] = await Promise.all([
    getAllSettings(),
    getFeatureFlags(),
    getAllSocialLinksAdmin(),
    getCheckoutTexts(),
    getTypography(),
    getDesignSettings(),
    getHeaderTexts(),
    getFooterTexts(),
    getShippingReturnSettings(),
  ])

  return (
    <SettingsTabs
      socialLinks={socialLinks}
      typography={typography}
      design={design}
      checkoutTexts={checkoutTexts}
      headerTexts={headerTexts}
      footerTexts={footerTexts}
      generalSettings={allSettings}
      featureFlags={featureFlags}
      shippingReturn={shippingReturn}
    />
  )
}
