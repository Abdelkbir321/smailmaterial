'use client'

import * as React from 'react'
import Link from 'next/link'
import { toast } from 'sonner'
import {
  Package,
  Loader2,
  Save,
  AlertTriangle,
} from 'lucide-react'

import { PageHeader, EmptyState, Spinner } from '@/components/admin/page-header'
import { ProductStatusBadge } from '@/components/admin/status-badge'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'

interface InventoryItem {
  id: string
  name: string
  slug: string
  sku: string
  stockQuantity: number
  lowStockThreshold: number
  status: string
  trackInventory: boolean
  currencyCode: string
  mainImage: string | null
}

export default function InventoryPage() {
  const [items, setItems] = React.useState<InventoryItem[]>([])
  const [loading, setLoading] = React.useState(true)
  const [saving, setSaving] = React.useState<Record<string, boolean>>({})
  const [drafts, setDrafts] = React.useState<Record<string, string>>({})

  async function load() {
    setLoading(true)
    try {
      const res = await fetch('/api/admin/inventory', { credentials: 'include' })
      const json = await res.json()
      if (!res.ok || !json.ok) {
        toast.error(json.error || 'فشل التحميل')
        return
      }
      setItems(json.items)
      setDrafts(Object.fromEntries(json.items.map((i: InventoryItem) => [i.id, String(i.stockQuantity)])))
    } catch {
      toast.error('خطأ في الشبكة')
    } finally {
      setLoading(false)
    }
  }

  React.useEffect(() => {
    load()
  }, [])

  async function saveStock(item: InventoryItem, value: string) {
    const n = Number(value)
    if (Number.isNaN(n) || n < 0) {
      toast.error('قيمة غير صالحة')
      return
    }
    if (n === item.stockQuantity) return
    setSaving((s) => ({ ...s, [item.id]: true }))
    try {
      const res = await fetch(`/api/admin/products/${item.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ stockQuantity: n }),
        credentials: 'include',
      })
      const json = await res.json()
      if (!res.ok || !json.ok) {
        toast.error(json.error || 'فشل التحديث')
        return
      }
      toast.success('تم تحديث المخزون')
      // optimistic update
      setItems((prev) =>
        prev.map((i) => (i.id === item.id ? { ...i, stockQuantity: n } : i)),
      )
    } catch {
      toast.error('خطأ في الشبكة')
    } finally {
      setSaving((s) => ({ ...s, [item.id]: false }))
    }
  }

  const lowCount = items.filter((i) => i.stockQuantity > 0).length
  const outCount = items.filter((i) => i.stockQuantity === 0).length

  return (
    <div className="space-y-6">
      <PageHeader
        title="المخزون"
        description="إدارة كميات المنتجات والمخزون المنخفض."
        breadcrumb={[{ label: 'الإدارة', href: '/admin/dashboard' }, { label: 'المخزون' }]}
      />

      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
        <div className="bg-card border rounded-xl p-4 shadow-sm flex items-center justify-between">
          <div>
            <p className="text-muted-foreground text-xs uppercase tracking-wide">إجمالي العناصر</p>
            <p className="text-2xl font-semibold tabular-nums">{items.length}</p>
          </div>
          <Package className="size-5 text-muted-foreground" />
        </div>
        <div className="bg-card border rounded-xl p-4 shadow-sm flex items-center justify-between">
          <div>
            <p className="text-muted-foreground text-xs uppercase tracking-wide">مخزون منخفض</p>
            <p className="text-2xl font-semibold tabular-nums text-amber-600">{lowCount}</p>
          </div>
          <AlertTriangle className="size-5 text-amber-500" />
        </div>
        <div className="bg-card border rounded-xl p-4 shadow-sm flex items-center justify-between">
          <div>
            <p className="text-muted-foreground text-xs uppercase tracking-wide">نفذ المخزون</p>
            <p className="text-2xl font-semibold tabular-nums text-rose-600">{outCount}</p>
          </div>
          <AlertTriangle className="size-5 text-rose-500" />
        </div>
      </div>

      {loading ? (
        <Spinner />
      ) : items.length === 0 ? (
        <EmptyState
          title="لا توجد منتجات بمخزون منخفض"
          description="كل المنتجات المتتبعة لديها مخزون كافٍ."
          icon={<Package className="size-5" />}
        />
      ) : (
        <Card className="p-0 overflow-hidden">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-12"></TableHead>
                <TableHead>المنتج</TableHead>
                <TableHead>الرمز</TableHead>
                <TableHead className="text-left">المخزون</TableHead>
                <TableHead className="text-left">الحد</TableHead>
                <TableHead>الحالة</TableHead>
                <TableHead>إجراء</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {items.map((p) => {
                const out = p.stockQuantity === 0
                const low = !out && p.stockQuantity <= p.lowStockThreshold
                return (
                  <TableRow key={p.id}>
                    <TableCell>
                      <div className="bg-muted rounded-md size-10 shrink-0 overflow-hidden border">
                        {p.mainImage ? (
                          <img
                            src={p.mainImage}
                            alt={p.name}
                            className="size-full object-cover"
                          />
                        ) : (
                          <div className="size-full grid place-items-center text-muted-foreground">
                            <Package className="size-4" />
                          </div>
                        )}
                      </div>
                    </TableCell>
                    <TableCell>
                      <Link
                        href={`/admin/products/${p.id}`}
                        className="font-medium hover:underline"
                      >
                        {p.name}
                      </Link>
                    </TableCell>
                    <TableCell className="font-mono text-xs" dir="ltr">{p.sku}</TableCell>
                    <TableCell className="text-left">
                      <div className="flex items-center gap-2">
                        <Input
                          type="number"
                          value={drafts[p.id] ?? ''}
                          onChange={(e) =>
                            setDrafts((d) => ({ ...d, [p.id]: e.target.value }))
                          }
                          className={
                            out
                              ? 'h-8 w-24 text-left text-rose-600 font-medium'
                              : low
                                ? 'h-8 w-24 text-left text-amber-600 font-medium'
                                : 'h-8 w-24 text-left'
                          }
                          min={0}
                        />
                        <Button
                          size="icon"
                          variant="ghost"
                          className="size-7"
                          disabled={!!saving[p.id]}
                          onClick={() => saveStock(p, drafts[p.id] ?? '0')}
                        >
                          {saving[p.id] ? (
                            <Loader2 className="size-3.5 animate-spin" />
                          ) : (
                            <Save className="size-3.5" />
                          )}
                        </Button>
                      </div>
                    </TableCell>
                    <TableCell className="text-left tabular-nums text-muted-foreground">
                      {p.lowStockThreshold}
                    </TableCell>
                    <TableCell>
                      <ProductStatusBadge status={p.status} />
                      {out && (
                        <Badge className="bg-rose-100 text-rose-700 ml-1">
                          نفذ المخزون
                        </Badge>
                      )}
                      {low && !out && (
                        <Badge className="bg-amber-100 text-amber-700 ml-1">
                          مخزون منخفض
                        </Badge>
                      )}
                    </TableCell>
                    <TableCell>
                      <Button asChild variant="ghost" size="sm">
                        <Link href={`/admin/products/${p.id}`}>تعديل</Link>
                      </Button>
                    </TableCell>
                  </TableRow>
                )
              })}
            </TableBody>
          </Table>
        </Card>
      )}
    </div>
  )
}
