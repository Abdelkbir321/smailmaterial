'use client'

import * as React from 'react'
import { Loader2, Save, Upload, Globe, ImageIcon, AlertTriangle, RotateCcw, Check } from 'lucide-react'
import { toast } from 'sonner'

import { PageHeader, Spinner } from '@/components/admin/page-header'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'

const ALLOWED_FAVICON_TYPES = ['image/png', 'image/x-icon', 'image/vnd.microsoft.icon', 'image/svg+xml', 'image/webp', 'image/jpeg']
const MAX_FAVICON_SIZE = 2 * 1024 * 1024

interface SiteIdentitySettings {
  favicon_url: string | null
  site_name: string | null
  site_tagline: string | null
  site_description: string | null
}

export default function SiteIdentityPage() {
  const [loading, setLoading] = React.useState(true)
  const [saving, setSaving] = React.useState(false)
  const [settings, setSettings] = React.useState<SiteIdentitySettings>({
    favicon_url: null,
    site_name: null,
    site_tagline: null,
    site_description: null,
  })
  const [favUploading, setFavUploading] = React.useState(false)
  const [favExternalUrl, setFavExternalUrl] = React.useState('')
  const [favExternalPreview, setFavExternalPreview] = React.useState<string | null>(null)
  const [favExternalError, setFavExternalError] = React.useState<string | null>(null)
  const [cloudinaryConfigured, setCloudinaryConfigured] = React.useState(true)
  const favFileRef = React.useRef<HTMLInputElement>(null)

  async function load() {
    setLoading(true)
    try {
      const res = await fetch('/api/admin/visual-identity', { credentials: 'include' })
      const json = await res.json()
      if (!res.ok || !json.ok) {
        toast.error(json.error || 'فشل التحميل')
        return
      }
      const s = json.settings as SiteIdentitySettings
      setSettings({
        favicon_url: s.favicon_url,
        site_name: s.site_name,
        site_tagline: s.site_tagline,
        site_description: s.site_description,
      })
      setCloudinaryConfigured(!!json.cloudinaryConfigured)
    } catch {
      toast.error('خطأ في الشبكة')
    } finally {
      setLoading(false)
    }
  }

  React.useEffect(() => {
    load()
  }, [])

  async function uploadFavicon(file: File) {
    if (!ALLOWED_FAVICON_TYPES.includes(file.type)) {
      toast.error(`صيغة غير مدعومة. المسموح: ${ALLOWED_FAVICON_TYPES.join(', ')}`)
      return
    }
    if (file.size > MAX_FAVICON_SIZE) {
      toast.error(`حجم الملف كبير جداً. الحد الأقصى: ${MAX_FAVICON_SIZE / 1024 / 1024} MB`)
      return
    }
    setFavUploading(true)
    try {
      const formData = new FormData()
      formData.append('file', file)
      const res = await fetch('/api/admin/upload', {
        method: 'POST',
        body: formData,
        credentials: 'include',
      })
      const json = await res.json()
      if (!res.ok || !json.ok) {
        toast.error(json.error || 'فشل رفع الفافيكون')
        return
      }
      const secureUrl = json.asset?.secureUrl || json.image?.secureUrl
      if (!secureUrl) {
        toast.error('لم يرجع الخادم رابط الفافيكون')
        return
      }
      // Save favicon URL + site identity together
      const putRes = await fetch('/api/admin/visual-identity', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          settings: {
            favicon_url: secureUrl,
            site_name: settings.site_name || '',
            site_tagline: settings.site_tagline || '',
            site_description: settings.site_description || '',
          },
        }),
        credentials: 'include',
      })
      const putJson = await putRes.json()
      if (!putRes.ok || !putJson.ok) {
        toast.error(putJson.error || 'فشل حفظ الفافيكون')
        return
      }
      setSettings((s) => ({ ...s, favicon_url: secureUrl }))
      toast.success('تم رفع الفافيكون — سيظهر فالتاب بعد لحظات')
    } catch {
      toast.error('خطأ في الشبكة')
    } finally {
      setFavUploading(false)
      if (favFileRef.current) favFileRef.current.value = ''
    }
  }

  async function saveFaviconExternal() {
    const url = favExternalUrl.trim()
    if (!url) { toast.error('أدخل رابط الفافيكون'); return }
    if (!/^https?:\/\/[^\s]+$/.test(url) && !url.startsWith('/')) {
      setFavExternalError('الرابط غير صالح')
      return
    }
    setFavExternalError(null)
    setSaving(true)
    try {
      const res = await fetch('/api/admin/visual-identity', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ settings: { favicon_url: url } }),
        credentials: 'include',
      })
      const json = await res.json()
      if (!res.ok || !json.ok) { toast.error(json.error || 'فشل الحفظ'); return }
      setSettings((s) => ({ ...s, favicon_url: url }))
      setFavExternalUrl('')
      setFavExternalPreview(null)
      toast.success('تم حفظ الفافيكون')
    } catch {
      toast.error('خطأ في الشبكة')
    } finally {
      setSaving(false)
    }
  }

  async function resetFavicon() {
    if (!confirm('متأكد من حذف الفافيكون المخصص والرجوع إلى الافتراضي؟')) return
    setSaving(true)
    try {
      const res = await fetch('/api/admin/visual-identity', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ settings: { favicon_url: '' } }),
        credentials: 'include',
      })
      const json = await res.json()
      if (!res.ok || !json.ok) { toast.error(json.error || 'فشل'); return }
      setSettings((s) => ({ ...s, favicon_url: null }))
      toast.success('تم الرجوع إلى الفافيكون الافتراضي')
    } catch {
      toast.error('خطأ في الشبكة')
    } finally {
      setSaving(false)
    }
  }

  async function saveSiteIdentity() {
    setSaving(true)
    try {
      const res = await fetch('/api/admin/visual-identity', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          settings: {
            site_name: settings.site_name || '',
            site_tagline: settings.site_tagline || '',
            site_description: settings.site_description || '',
          },
        }),
        credentials: 'include',
      })
      const json = await res.json()
      if (!res.ok || !json.ok) { toast.error(json.error || 'فشل الحفظ'); return }
      toast.success('تم حفظ هوية الموقع')
    } catch {
      toast.error('خطأ في الشبكة')
    } finally {
      setSaving(false)
    }
  }

  if (loading) return <Spinner />

  return (
    <div className="space-y-6">
      <PageHeader
        title="هوية الموقع"
        description="أيقونة التبويب (Favicon) + اسم الموقع + الوصف — كلها في مكان واحد."
        breadcrumb={[{ label: 'الإدارة', href: '/admin/dashboard' }, { label: 'هوية الموقع' }]}
      />

      {!cloudinaryConfigured && (
        <div className="bg-amber-50 border border-amber-200 rounded-lg p-4 flex items-start gap-3">
          <AlertTriangle className="size-5 text-amber-700 mt-0.5 shrink-0" />
          <div className="space-y-1">
            <p className="text-sm font-medium text-amber-800">Cloudinary غير مهيأ</p>
            <p className="text-xs text-amber-700">
              عيّن CLOUDINARY_CLOUD_NAME، CLOUDINARY_API_KEY، CLOUDINARY_API_SECRET في Environment Variables لتفعيل رفع الصور.
              يمكنك مؤقتاً استعمال روابط خارجية.
            </p>
          </div>
        </div>
      )}

      {/* === Favicon === */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <ImageIcon className="size-4" /> أيقونة التبويب (Favicon)
          </CardTitle>
          <CardDescription>
            الأيقونة التي تظهر في تبويب المتصفح بجانب اسم الموقع. حالياً: {settings.favicon_url ? 'مخصص' : 'افتراضي'}.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-5">
          {/* Current preview */}
          <div className="flex items-center gap-4 rounded-lg border border-border p-4 bg-muted/30">
            <div className="relative grid size-12 place-items-center rounded-lg bg-card shadow-[var(--shadow-xs)]">
              {settings.favicon_url ? (
                <img src={settings.favicon_url} alt="Current favicon" className="size-8 object-contain" />
              ) : (
                <img src="/logo.svg" alt="Default favicon" className="size-8 object-contain" />
              )}
            </div>
            <div className="flex-1 min-w-0">
              <div className="text-xs font-medium uppercase tracking-wide text-muted-foreground">الحالي</div>
              {settings.favicon_url ? (
                <a href={settings.favicon_url} target="_blank" rel="noopener noreferrer" className="block truncate text-sm font-mono hover:underline">
                  {settings.favicon_url}
                </a>
              ) : (
                <div className="text-sm text-muted-foreground">الفافيكون الافتراضي (/logo.svg + ملفات PNG/ICO)</div>
              )}
            </div>
            {settings.favicon_url && (
              <Button variant="outline" size="sm" onClick={resetFavicon} disabled={saving}>
                <RotateCcw className="mr-1.5 size-3.5" /> رجوع للافتراضي
              </Button>
            )}
          </div>

          {/* Upload */}
          <div>
            <Label className="mb-1.5 block">الرفع من الجهاز</Label>
            <div
              onClick={() => favFileRef.current?.click()}
              className="border-2 border-dashed rounded-lg p-6 text-center cursor-pointer hover:bg-muted/50 transition-colors"
            >
              <input
                ref={favFileRef}
                type="file"
                accept={ALLOWED_FAVICON_TYPES.join(',')}
                className="hidden"
                onChange={(e) => {
                  const f = e.target.files?.[0]
                  if (f) uploadFavicon(f)
                }}
              />
              {favUploading ? (
                <div className="flex flex-col items-center gap-2 text-muted-foreground">
                  <Loader2 className="size-6 animate-spin" />
                  <p className="text-sm">جارٍ الرفع…</p>
                </div>
              ) : (
                <div className="flex flex-col items-center gap-2 text-muted-foreground">
                  <Upload className="size-6" />
                  <p className="text-sm font-medium">اضغط لاختيار ملف الفافيكون</p>
                  <p className="text-xs">PNG (16/32/48/180), ICO, SVG, WebP — حد أقصى 2 MB</p>
                </div>
              )}
            </div>
          </div>

          <Separator />

          {/* External URL */}
          <div>
            <Label className="mb-1.5 block">رابط مباشر لصورة الفافيكون</Label>
            <div className="grid gap-2 sm:grid-cols-2">
              <Input
                placeholder="https://example.com/favicon.png"
                value={favExternalUrl}
                onChange={(e) => {
                  setFavExternalUrl(e.target.value)
                  setFavExternalPreview(null)
                  setFavExternalError(null)
                }}
                dir="ltr"
                className="text-left"
              />
              <div className="flex gap-2">
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => setFavExternalPreview(favExternalUrl.trim())}
                  disabled={!favExternalUrl}
                >
                  <Globe className="size-4" /> معاينة
                </Button>
                <Button
                  type="button"
                  size="sm"
                  onClick={saveFaviconExternal}
                  disabled={saving || !favExternalUrl}
                  className="bg-zinc-900 hover:bg-zinc-800"
                >
                  {saving ? <Loader2 className="size-4 animate-spin" /> : <Save className="size-4" />} حفظ
                </Button>
              </div>
            </div>
            {favExternalError && <p className="mt-1.5 text-xs text-rose-600">{favExternalError}</p>}
            {favExternalPreview && (
              <div className="mt-2 inline-block bg-white border rounded-md p-2">
                {favExternalError ? (
                  <p className="text-rose-600 text-xs p-4">الرابط غير صالح.</p>
                ) : (
                  <img
                    src={favExternalPreview}
                    alt="معاينة"
                    className="size-16 object-contain"
                    onError={() => setFavExternalError('تعذر تحميل الصورة.')}
                  />
                )}
              </div>
            )}
          </div>

          <div className="rounded-md border border-blue-200 bg-blue-50 p-3 text-xs text-blue-800">
            <strong>ملاحظة:</strong> بعد تغيير الفافيكون، قد يحتاج المتصفح لإعادة تحميل قسري (Ctrl+Shift+R). النظام يضيف معامل عشوائي للرابط تلقائياً. لتغيير أيقونة z.ai، تأكد من رفع أيقونة Ismail Material الخاصة بك هنا.
          </div>
        </CardContent>
      </Card>

      {/* === Site Name + Description === */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">اسم الموقع والوصف</CardTitle>
          <CardDescription>تظهر هذه القيم في تبويب المتصفح وعلامات Open Graph وبيانات الـ SEO.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-1.5">
            <Label htmlFor="site_name">اسم الموقع</Label>
            <Input
              id="site_name"
              value={settings.site_name ?? ''}
              onChange={(e) => setSettings((s) => ({ ...s, site_name: e.target.value }))}
              placeholder="Ismail Material"
            />
            <p className="text-xs text-muted-foreground">يظهر في تبويب المتصفح: "اسم الموقع — الشعار النصي"</p>
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="site_tagline">الشعار النصي (Tagline)</Label>
            <Input
              id="site_tagline"
              value={settings.site_tagline ?? ''}
              onChange={(e) => setSettings((s) => ({ ...s, site_tagline: e.target.value }))}
              placeholder="Outillage & équipement pro pour le Maroc"
            />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="site_description">وصف الموقع</Label>
            <Textarea
              id="site_description"
              rows={3}
              value={settings.site_description ?? ''}
              onChange={(e) => setSettings((s) => ({ ...s, site_description: e.target.value }))}
              placeholder="Boutique d'outillage professionnel : perceuses, visseuses, meuleuses…"
            />
            <p className="text-xs text-muted-foreground">يظهر في وصف الميتا وعلامات Open Graph</p>
          </div>
          <div className="flex justify-end">
            <Button onClick={saveSiteIdentity} disabled={saving} className="bg-zinc-900 hover:bg-zinc-800">
              {saving ? <Loader2 className="mr-1.5 size-4 animate-spin" /> : <Save className="mr-1.5 size-4" />}
              حفظ هوية الموقع
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

function Separator({ className }: { className?: string }) {
  return <div className={className ?? 'h-px bg-border'} />
}
