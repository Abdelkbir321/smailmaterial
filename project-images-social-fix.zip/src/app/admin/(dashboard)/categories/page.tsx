'use client'

import * as React from 'react'
import { Plus, Loader2, Tag, Search, Trash2, Eye, EyeOff, Pencil, MoreHorizontal, X } from 'lucide-react'
import { toast } from 'sonner'

import { slugify, timeAgoAr } from '@/lib/format'
import { PageHeader, EmptyState, Spinner } from '@/components/admin/page-header'
import { TablePagination } from '@/components/admin/table-pagination'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Switch } from '@/components/ui/switch'
import { Card } from '@/components/ui/card'
import { Checkbox } from '@/components/ui/checkbox'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'

interface Category {
  id: string
  slug: string
  name: string
  nameAr: string | null
  description: string | null
  imageUrl: string | null
  isVisible: boolean
  sortOrder: number
  _count?: { products: number }
  createdAt?: string
}

const PAGE_SIZE = 20

export default function AdminCategoriesPage() {
  const [items, setItems] = React.useState<Category[]>([])
  const [loading, setLoading] = React.useState(true)
  const [searchInput, setSearchInput] = React.useState('')
  const [q, setQ] = React.useState('')
  const [page, setPage] = React.useState(1)
  const [total, setTotal] = React.useState(0)
  const [selected, setSelected] = React.useState<Set<string>>(new Set())

  // Dialog state
  const [createOpen, setCreateOpen] = React.useState(false)
  const [editTarget, setEditTarget] = React.useState<Category | null>(null)
  const [deleteTarget, setDeleteTarget] = React.useState<Category | null>(null)
  const [bulkDeleteOpen, setBulkDeleteOpen] = React.useState(false)
  const [saving, setSaving] = React.useState(false)

  // Form state
  const [name, setName] = React.useState('')
  const [slug, setSlug] = React.useState('')
  const [nameAr, setNameAr] = React.useState('')
  const [description, setDescription] = React.useState('')
  const [imageUrl, setImageUrl] = React.useState('')
  const [isVisible, setIsVisible] = React.useState(true)
  const [sortOrder, setSortOrder] = React.useState(0)
  const [slugTouched, setSlugTouched] = React.useState(false)

  // Delete with products state
  const [productAction, setProductAction] = React.useState<'move' | 'cancel'>('cancel')
  const [targetCategoryId, setTargetCategoryId] = React.useState('')

  const debounceRef = React.useRef<ReturnType<typeof setTimeout> | null>(null)

  async function load(query = q) {
    setLoading(true)
    try {
      const params = new URLSearchParams()
      if (query) params.set('q', query)
      const res = await fetch(`/api/admin/categories?${params.toString()}`, { credentials: 'include' })
      const json = await res.json()
      if (json.ok) {
        setItems(json.categories)
        setTotal(json.categories.length)
      }
    } catch {
      toast.error('خطأ في الشبكة')
    } finally {
      setLoading(false)
    }
  }

  React.useEffect(() => {
    load('')
  }, [])

  React.useEffect(() => {
    if (debounceRef.current) clearTimeout(debounceRef.current)
    debounceRef.current = setTimeout(() => {
      if (searchInput !== q) {
        setQ(searchInput)
        setPage(1)
        load(searchInput)
      }
    }, 300)
    return () => {
      if (debounceRef.current) clearTimeout(debounceRef.current)
    }
  }, [searchInput])

  // Filter items based on search
  const filtered = React.useMemo(() => {
    if (!q) return items
    const ql = q.toLowerCase()
    return items.filter((c) =>
      c.name.toLowerCase().includes(ql) ||
      c.slug.toLowerCase().includes(ql) ||
      (c.nameAr || '').includes(q)
    )
  }, [items, q])

  const paginated = React.useMemo(() => {
    const start = (page - 1) * PAGE_SIZE
    return filtered.slice(start, start + PAGE_SIZE)
  }, [filtered, page])

  // Selection
  function toggleSelect(id: string) {
    setSelected((prev) => {
      const next = new Set(prev)
      if (next.has(id)) next.delete(id)
      else next.add(id)
      return next
    })
  }

  function selectAllOnPage() {
    setSelected(new Set(paginated.map((c) => c.id)))
  }

  function clearSelection() {
    setSelected(new Set())
  }

  const allOnPageSelected = paginated.length > 0 && paginated.every((c) => selected.has(c.id))

  // Create
  function resetForm() {
    setName('')
    setSlug('')
    setNameAr('')
    setDescription('')
    setImageUrl('')
    setIsVisible(true)
    setSortOrder(0)
    setSlugTouched(false)
  }

  async function submitCreate(e: React.FormEvent) {
    e.preventDefault()
    if (saving) return
    setSaving(true)
    try {
      const res = await fetch('/api/admin/categories', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name,
          slug: slug || slugify(name),
          nameAr,
          description,
          imageUrl: imageUrl || null,
          isVisible,
          sortOrder,
        }),
        credentials: 'include',
      })
      const json = await res.json()
      if (!res.ok || !json.ok) {
        toast.error(json.error || 'فشل الإنشاء')
        return
      }
      toast.success('تم إنشاء الفئة')
      setCreateOpen(false)
      resetForm()
      load()
    } catch {
      toast.error('خطأ في الشبكة')
    } finally {
      setSaving(false)
    }
  }

  // Edit
  function openEdit(cat: Category) {
    setEditTarget(cat)
    setName(cat.name)
    setSlug(cat.slug)
    setNameAr(cat.nameAr || '')
    setDescription(cat.description || '')
    setImageUrl(cat.imageUrl || '')
    setIsVisible(cat.isVisible)
    setSortOrder(cat.sortOrder)
    setSlugTouched(true)
  }

  async function submitEdit(e: React.FormEvent) {
    e.preventDefault()
    if (!editTarget || saving) return
    setSaving(true)
    try {
      const res = await fetch(`/api/admin/categories/${editTarget.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name,
          slug,
          nameAr: nameAr || null,
          description: description || null,
          imageUrl: imageUrl || null,
          isVisible,
          sortOrder,
        }),
        credentials: 'include',
      })
      const json = await res.json()
      if (!res.ok || !json.ok) {
        toast.error(json.error || 'فشل التحديث')
        return
      }
      toast.success('تم تحديث الفئة')
      setEditTarget(null)
      load()
    } catch {
      toast.error('خطأ في الشبكة')
    } finally {
      setSaving(false)
    }
  }

  // Delete single
  async function confirmDelete() {
    if (!deleteTarget || saving) return
    setSaving(true)
    try {
      const res = await fetch(`/api/admin/categories/${deleteTarget.id}`, {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          productAction,
          targetCategoryId: productAction === 'move' ? targetCategoryId : undefined,
        }),
        credentials: 'include',
      })
      const json = await res.json()
      if (!res.ok) {
        if (json.requiresAction) {
          toast.error(json.error)
          return
        }
        toast.error(json.error || 'فشل الحذف')
        return
      }
      toast.success('تم حذف الفئة')
      setDeleteTarget(null)
      setProductAction('cancel')
      setTargetCategoryId('')
      load()
    } catch {
      toast.error('خطأ في الشبكة')
    } finally {
      setSaving(false)
    }
  }

  // Bulk delete
  async function confirmBulkDelete() {
    if (saving) return
    setSaving(true)
    try {
      const res = await fetch('/api/admin/categories/bulk', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ids: Array.from(selected),
          action: 'delete',
          productAction,
          targetCategoryId: productAction === 'move' ? targetCategoryId : undefined,
        }),
        credentials: 'include',
      })
      const json = await res.json()
      if (!res.ok) {
        if (json.requiresAction) {
          toast.error(json.error)
          return
        }
        toast.error(json.error || 'فشل الحذف')
        return
      }
      toast.success(`تم حذف ${json.deleted} فئة`)
      setBulkDeleteOpen(false)
      clearSelection()
      setProductAction('cancel')
      setTargetCategoryId('')
      load()
    } catch {
      toast.error('خطأ في الشبكة')
    } finally {
      setSaving(false)
    }
  }

  // Bulk visibility
  async function bulkVisibility(show: boolean) {
    if (selected.size === 0) return
    try {
      const res = await fetch('/api/admin/categories/bulk', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ids: Array.from(selected),
          action: show ? 'show' : 'hide',
        }),
        credentials: 'include',
      })
      const json = await res.json()
      if (!res.ok || !json.ok) {
        toast.error(json.error || 'فشل')
        return
      }
      toast.success(`تم تحديث ${json.updated} فئة`)
      clearSelection()
      load()
    } catch {
      toast.error('خطأ في الشبكة')
    }
  }

  // Toggle visibility inline
  async function toggleVisibility(cat: Category) {
    try {
      const res = await fetch(`/api/admin/categories/${cat.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ isVisible: !cat.isVisible }),
        credentials: 'include',
      })
      const json = await res.json()
      if (!res.ok || !json.ok) {
        toast.error(json.error || 'فشل')
        return
      }
      load()
    } catch {
      toast.error('خطأ في الشبكة')
    }
  }

  // Other categories for delete target
  const otherCategories = items.filter((c) => !selected.has(c.id) && (!deleteTarget || c.id !== deleteTarget.id))

  return (
    <div className="space-y-4 sm:space-y-6">
      <PageHeader
        title="الفئات"
        description="نظّم كتالوجك حسب الفئات."
        breadcrumb={[{ label: 'الإدارة', href: '/admin/dashboard' }, { label: 'الفئات' }]}
        actions={
          <Dialog open={createOpen} onOpenChange={setCreateOpen}>
            <DialogTrigger asChild>
              <Button className="bg-zinc-900 hover:bg-zinc-800">
                <Plus className="size-4" />
                <span className="hidden sm:inline">فئة جديدة</span>
                <span className="sm:hidden">جديدة</span>
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-lg">
              <DialogHeader>
                <DialogTitle>فئة جديدة</DialogTitle>
                <DialogDescription>الفئات تتيح تجميع منتجاتك.</DialogDescription>
              </DialogHeader>
              <form onSubmit={submitCreate} className="space-y-3">
                <CategoryFormFields
                  name={name} setName={(v) => { setName(v); if (!slugTouched) setSlug(slugify(v)) }}
                  slug={slug} setSlug={(v) => { setSlugTouched(true); setSlug(slugify(v)) }}
                  nameAr={nameAr} setNameAr={setNameAr}
                  description={description} setDescription={setDescription}
                  imageUrl={imageUrl} setImageUrl={setImageUrl}
                  isVisible={isVisible} setIsVisible={setIsVisible}
                  sortOrder={sortOrder} setSortOrder={setSortOrder}
                />
                <DialogFooter>
                  <Button type="submit" disabled={saving} className="bg-zinc-900 hover:bg-zinc-800">
                    {saving && <Loader2 className="size-4 animate-spin" />}
                    إنشاء
                  </Button>
                </DialogFooter>
              </form>
            </DialogContent>
          </Dialog>
        }
      />

      {/* Search */}
      <Card className="p-3">
        <div className="relative">
          <Search className="text-muted-foreground absolute right-2.5 top-1/2 size-4 -translate-y-1/2" />
          <Input
            placeholder="ابحث بالاسم أو الرابط…"
            value={searchInput}
            onChange={(e) => setSearchInput(e.target.value)}
            className="pr-8"
          />
        </div>
      </Card>

      {/* Bulk actions bar */}
      {selected.size > 0 && (
        <Card className="p-3 border-primary/30 bg-primary/5">
          <div className="flex flex-wrap items-center gap-2">
            <span className="text-sm font-medium">
              {selected.size} محدد
            </span>
            <div className="flex flex-wrap gap-2 mr-auto">
              <Button size="sm" variant="outline" onClick={() => bulkVisibility(true)}>
                <Eye className="size-4" /> إظهار
              </Button>
              <Button size="sm" variant="outline" onClick={() => bulkVisibility(false)}>
                <EyeOff className="size-4" /> إخفاء
              </Button>
              <Button size="sm" variant="destructive" onClick={() => setBulkDeleteOpen(true)}>
                <Trash2 className="size-4" /> حذف المحدد
              </Button>
              <Button size="sm" variant="ghost" onClick={clearSelection}>
                <X className="size-4" /> إلغاء
              </Button>
            </div>
          </div>
        </Card>
      )}

      {loading ? (
        <Spinner />
      ) : filtered.length === 0 ? (
        <EmptyState
          title="لا توجد فئات"
          description="أنشئ أول فئة."
          icon={<Tag className="size-5" />}
        />
      ) : (
        <>
          {/* Desktop table */}
          <Card className="hidden md:block p-0 overflow-hidden">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-10">
                    <Checkbox
                      checked={allOnPageSelected}
                      onCheckedChange={() => allOnPageSelected ? clearSelection() : selectAllOnPage()}
                    />
                  </TableHead>
                  <TableHead>الاسم</TableHead>
                  <TableHead>الرابط</TableHead>
                  <TableHead className="text-center">المنتجات</TableHead>
                  <TableHead className="text-center">ظاهرة</TableHead>
                  <TableHead>أُنشئت</TableHead>
                  <TableHead className="w-12"></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {paginated.map((c) => (
                  <TableRow key={c.id}>
                    <TableCell>
                      <Checkbox
                        checked={selected.has(c.id)}
                        onCheckedChange={() => toggleSelect(c.id)}
                      />
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        {c.imageUrl ? (
                          <img src={c.imageUrl} alt={c.name} className="size-8 rounded object-cover" />
                        ) : (
                          <div className="bg-muted rounded size-8 flex items-center justify-center">
                            <Tag className="size-3 text-muted-foreground" />
                          </div>
                        )}
                        <span className="font-medium">{c.name}</span>
                      </div>
                    </TableCell>
                    <TableCell className="font-mono text-xs" dir="ltr">/{c.slug}</TableCell>
                    <TableCell className="text-center tabular-nums">{c._count?.products ?? 0}</TableCell>
                    <TableCell className="text-center">
                      <button onClick={() => toggleVisibility(c)}>
                        {c.isVisible ? (
                          <span className="text-emerald-700 text-xs font-medium">نعم</span>
                        ) : (
                          <span className="text-muted-foreground text-xs">لا</span>
                        )}
                      </button>
                    </TableCell>
                    <TableCell className="text-xs text-muted-foreground">
                      {c.createdAt ? timeAgoAr(c.createdAt) : '—'}
                    </TableCell>
                    <TableCell>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon" className="size-8">
                            <MoreHorizontal className="size-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="start">
                          <DropdownMenuLabel>إجراءات</DropdownMenuLabel>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem onClick={() => openEdit(c)}>
                            <Pencil className="size-4" /> تعديل
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => toggleVisibility(c)}>
                            {c.isVisible ? <EyeOff className="size-4" /> : <Eye className="size-4" />}
                            {c.isVisible ? 'إخفاء' : 'إظهار'}
                          </DropdownMenuItem>
                          <DropdownMenuItem
                            onClick={() => { setDeleteTarget(c); setProductAction('cancel'); setTargetCategoryId('') }}
                            className="text-rose-600 focus:text-rose-700"
                          >
                            <Trash2 className="size-4" /> حذف
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </Card>

          {/* Mobile cards */}
          <div className="md:hidden space-y-3">
            {paginated.map((c) => (
              <Card key={c.id} className="p-3">
                <div className="flex items-start gap-3">
                  <Checkbox
                    checked={selected.has(c.id)}
                    onCheckedChange={() => toggleSelect(c.id)}
                  />
                  {c.imageUrl ? (
                    <img src={c.imageUrl} alt={c.name} className="size-12 rounded object-cover" />
                  ) : (
                    <div className="bg-muted rounded size-12 flex items-center justify-center">
                      <Tag className="size-4 text-muted-foreground" />
                    </div>
                  )}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <p className="font-medium truncate">{c.name}</p>
                      <span className={`text-[10px] font-medium ${c.isVisible ? 'text-emerald-700' : 'text-muted-foreground'}`}>
                        {c.isVisible ? 'ظاهرة' : 'مخفية'}
                      </span>
                    </div>
                    <p className="font-mono text-xs text-muted-foreground truncate" dir="ltr">/{c.slug}</p>
                    <p className="text-xs text-muted-foreground mt-1">
                      {c._count?.products ?? 0} منتج · {c.createdAt ? timeAgoAr(c.createdAt) : '—'}
                    </p>
                  </div>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="icon" className="size-8">
                        <MoreHorizontal className="size-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="start">
                      <DropdownMenuItem onClick={() => openEdit(c)}>
                        <Pencil className="size-4" /> تعديل
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => toggleVisibility(c)}>
                        {c.isVisible ? <EyeOff className="size-4" /> : <Eye className="size-4" />}
                        {c.isVisible ? 'إخفاء' : 'إظهار'}
                      </DropdownMenuItem>
                      <DropdownMenuItem
                        onClick={() => { setDeleteTarget(c); setProductAction('cancel'); setTargetCategoryId('') }}
                        className="text-rose-600 focus:text-rose-700"
                      >
                        <Trash2 className="size-4" /> حذف
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
              </Card>
            ))}
          </div>

          {total > PAGE_SIZE && (
            <TablePagination
              page={page}
              pageSize={PAGE_SIZE}
              total={total}
              onPage={setPage}
            />
          )}
        </>
      )}

      {/* Edit Dialog */}
      <Dialog open={!!editTarget} onOpenChange={(o) => !o && setEditTarget(null)}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>تعديل الفئة</DialogTitle>
          </DialogHeader>
          <form onSubmit={submitEdit} className="space-y-3">
            <CategoryFormFields
              name={name} setName={setName}
              slug={slug} setSlug={(v) => { setSlugTouched(true); setSlug(slugify(v)) }}
              nameAr={nameAr} setNameAr={setNameAr}
              description={description} setDescription={setDescription}
              imageUrl={imageUrl} setImageUrl={setImageUrl}
              isVisible={isVisible} setIsVisible={setIsVisible}
              sortOrder={sortOrder} setSortOrder={setSortOrder}
            />
            <DialogFooter>
              <Button type="submit" disabled={saving} className="bg-zinc-900 hover:bg-zinc-800">
                {saving && <Loader2 className="size-4 animate-spin" />}
                حفظ
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Delete Single Dialog */}
      <Dialog open={!!deleteTarget} onOpenChange={(o) => !o && setDeleteTarget(null)}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>حذف الفئة</DialogTitle>
            <DialogDescription>
              هل أنت متأكد من حذف "{deleteTarget?.name}"؟
              {(deleteTarget?._count?.products ?? 0) > 0 && (
                <span className="block mt-2 text-amber-700 font-medium">
                  هذه الفئة تحتوي على {deleteTarget?._count?.products} منتج.
                </span>
              )}
            </DialogDescription>
          </DialogHeader>
          {(deleteTarget?._count?.products ?? 0) > 0 && (
            <div className="space-y-3 py-2">
              <Label>كيف نتعامل مع المنتجات؟</Label>
              <Select value={productAction} onValueChange={(v) => setProductAction(v as 'move' | 'cancel')}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="cancel">إلغاء العملية</SelectItem>
                  <SelectItem value="move">نقل المنتجات لفئة أخرى</SelectItem>
                </SelectContent>
              </Select>
              {productAction === 'move' && (
                <Select value={targetCategoryId} onValueChange={setTargetCategoryId}>
                  <SelectTrigger>
                    <SelectValue placeholder="اختر الفئة الهدف" />
                  </SelectTrigger>
                  <SelectContent>
                    {otherCategories.map((c) => (
                      <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              )}
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setDeleteTarget(null)}>إلغاء</Button>
            <Button
              variant="destructive"
              onClick={confirmDelete}
              disabled={saving || (productAction === 'move' && !targetCategoryId)}
            >
              {saving && <Loader2 className="size-4 animate-spin" />}
              حذف
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Bulk Delete Dialog */}
      <Dialog open={bulkDeleteOpen} onOpenChange={setBulkDeleteOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>حذف {selected.size} فئة</DialogTitle>
            <DialogDescription>
              هل أنت متأكد من حذف {selected.size} فئة محددة؟ لا يمكن التراجع عن هذا الإجراء.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-3 py-2">
            <Label>كيف نتعامل مع المنتجات المرتبطة؟</Label>
            <Select value={productAction} onValueChange={(v) => setProductAction(v as 'move' | 'cancel')}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="cancel">إلغاء العملية</SelectItem>
                <SelectItem value="move">نقل المنتجات لفئة أخرى</SelectItem>
              </SelectContent>
            </Select>
            {productAction === 'move' && (
              <Select value={targetCategoryId} onValueChange={setTargetCategoryId}>
                <SelectTrigger>
                  <SelectValue placeholder="اختر الفئة الهدف" />
                </SelectTrigger>
                <SelectContent>
                  {otherCategories.map((c) => (
                    <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setBulkDeleteOpen(false)}>إلغاء</Button>
            <Button
              variant="destructive"
              onClick={confirmBulkDelete}
              disabled={saving || (productAction === 'move' && !targetCategoryId)}
            >
              {saving && <Loader2 className="size-4 animate-spin" />}
              حذف {selected.size} فئة
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

// Reusable form fields
function CategoryFormFields({
  name, setName, slug, setSlug, nameAr, setNameAr,
  description, setDescription, imageUrl, setImageUrl,
  isVisible, setIsVisible, sortOrder, setSortOrder,
}: {
  name: string; setName: (v: string) => void
  slug: string; setSlug: (v: string) => void
  nameAr: string; setNameAr: (v: string) => void
  description: string; setDescription: (v: string) => void
  imageUrl: string; setImageUrl: (v: string) => void
  isVisible: boolean; setIsVisible: (v: boolean) => void
  sortOrder: number; setSortOrder: (v: number) => void
}) {
  return (
    <>
      <div className="space-y-1.5">
        <Label>الاسم *</Label>
        <Input value={name} onChange={(e) => setName(e.target.value)} required />
      </div>
      <div className="space-y-1.5">
        <Label>الرابط (Slug)</Label>
        <Input value={slug} onChange={(e) => setSlug(e.target.value)} dir="ltr" className="text-left" />
      </div>
      <div className="space-y-1.5">
        <Label>الاسم بالعربية</Label>
        <Input value={nameAr} onChange={(e) => setNameAr(e.target.value)} />
      </div>
      <div className="space-y-1.5">
        <Label>الوصف</Label>
        <Textarea value={description} onChange={(e) => setDescription(e.target.value)} rows={2} />
      </div>
      <div className="space-y-1.5">
        <Label>رابط الصورة</Label>
        <Input value={imageUrl} onChange={(e) => setImageUrl(e.target.value)} dir="ltr" className="text-left" placeholder="https://..." />
      </div>
      <div className="grid grid-cols-2 gap-3">
        <div className="flex items-center justify-between rounded-lg border p-3">
          <span className="text-sm font-medium">ظاهرة</span>
          <Switch checked={isVisible} onCheckedChange={setIsVisible} />
        </div>
        <div className="space-y-1.5">
          <Label>الترتيب</Label>
          <Input type="number" value={sortOrder} onChange={(e) => setSortOrder(parseInt(e.target.value) || 0)} />
        </div>
      </div>
    </>
  )
}
