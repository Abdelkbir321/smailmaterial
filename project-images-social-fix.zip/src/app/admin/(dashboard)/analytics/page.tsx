'use client'

import * as React from 'react'
import { BarChart3, TrendingUp, TrendingDown, Minus, Download, Loader2, Eye, Users, ShoppingCart, Search, Package, Monitor, Smartphone, Tablet } from 'lucide-react'
import {
  ResponsiveContainer, LineChart, Line, BarChart, Bar, XAxis, YAxis,
  Tooltip, CartesianGrid, Cell, PieChart, Pie, Legend, AreaChart, Area,
} from 'recharts'
import { PageHeader, EmptyState, Spinner, CardStat } from '@/components/admin/page-header'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { toast } from 'sonner'

const PERIODS = [
  { value: 'today', label: 'اليوم' },
  { value: 'yesterday', label: 'البارح' },
  { value: '7d', label: 'آخر 7 أيام' },
  { value: '14d', label: 'آخر 14 يوم' },
  { value: '30d', label: 'آخر 30 يوم' },
  { value: '90d', label: 'آخر 90 يوم' },
  { value: 'this_month', label: 'هاد الشهر' },
  { value: 'last_month', label: 'الشهر اللي فات' },
  { value: '12m', label: 'آخر 12 شهر' },
]

const SOURCE_LABELS: Record<string, string> = {
  direct: 'مباشر',
  organic_search: 'بحث عضوي',
  paid_search: 'بحث مدفوع',
  organic_social: 'سوشيال عضوي',
  paid_social: 'سوشيال مدفوع',
  referral: 'إحالة',
  email: 'بريد',
  other: 'أخرى',
  unknown: 'غير معروف',
}

const SOURCE_COLORS: Record<string, string> = {
  direct: '#3f3f46',
  organic_search: '#10b981',
  paid_search: '#f59e0b',
  organic_social: '#3b82f6',
  paid_social: '#8b5cf6',
  referral: '#06b6d4',
  email: '#ec4899',
  other: '#a3a3a3',
  unknown: '#d4d4d8',
}

const DEVICE_LABELS: Record<string, string> = {
  desktop: 'كمبيوتر',
  mobile: 'هاتف',
  tablet: 'تابليت',
  bot: 'بوت',
  unknown: 'غير معروف',
}

interface AnalyticsData {
  ok: boolean
  period: { from: string; to: string; preset: string }
  hasData: boolean
  kpis: {
    pageViews: { current: number; previous: number; change: number | null }
    uniqueVisitors: { current: number; previous: number; change: number | null }
    sessions: { current: number; previous: number; change: number | null }
    newVisitors: { current: number; previous: number; change: number | null }
    returningVisitors: { current: number; previous: number; change: number | null }
    orders: { current: number; previous: number; change: number | null }
    newOrders: { current: number; previous: number; change: number | null }
    confirmedOrders: { current: number; previous: number; change: number | null }
    deliveredOrders: { current: number; previous: number; change: number | null }
    revenue: { current: number; previous: number; change: number | null }
    conversionRate: { current: string; previous: string }
    addToCart: { current: number; previous: number; change: number | null }
    beginCheckout: { current: number; previous: number; change: number | null }
    searches: { current: number; previous: number; change: number | null }
    viewItem: { current: number; previous: number; change: number | null }
  }
  dailySeries: Array<{ date: string; views: number; visitors: number }>
  funnel: Array<{ stage: string; count: number; icon: string }>
  trafficSources: Array<{ source: string; count: number }>
  devices: Array<{ device: string; count: number }>
  browsers: Array<{ browser: string; count: number }>
  operatingSystems: Array<{ os: string; count: number }>
  topPages: Array<{ path: string; views: number }>
  topProducts: Array<{ slug: string; views: number }>
}

export default function AnalyticsPage() {
  const [data, setData] = React.useState<AnalyticsData | null>(null)
  const [loading, setLoading] = React.useState(true)
  const [period, setPeriod] = React.useState('30d')
  const [customFrom, setCustomFrom] = React.useState('')
  const [customTo, setCustomTo] = React.useState('')
  const [useCustom, setUseCustom] = React.useState(false)

  async function load() {
    setLoading(true)
    try {
      let url = '/api/admin/analytics?'
      if (useCustom && customFrom && customTo) {
        url += `from=${customFrom}&to=${customTo}`
      } else {
        url += `period=${period}`
      }
      const res = await fetch(url, { credentials: 'include' })
      const json = await res.json()
      if (!res.ok || !json.ok) {
        toast.error(json.error || 'فشل التحميل')
        return
      }
      setData(json)
    } catch {
      toast.error('خطأ في الشبكة')
    } finally {
      setLoading(false)
    }
  }

  React.useEffect(() => {
    load()
  }, [period, useCustom, customFrom, customTo])

  return (
    <div className="space-y-4 sm:space-y-6">
      <PageHeader
        title="التحليلات"
        description="إحصائيات الزيارات والطلبات والأداء."
        breadcrumb={[{ label: 'الإدارة', href: '/admin/dashboard' }, { label: 'التحليلات' }]}
      />

      {/* Period selector */}
      <Card className="p-3 sm:p-4">
        <div className="flex flex-col gap-3 sm:flex-row sm:items-end">
          <div className="flex-1 space-y-1.5">
            <Label className="text-xs">الفترة الزمنية</Label>
            <Select
              value={useCustom ? 'custom' : period}
              onValueChange={(v) => {
                if (v === 'custom') {
                  setUseCustom(true)
                } else {
                  setUseCustom(false)
                  setPeriod(v)
                }
              }}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {PERIODS.map((p) => (
                  <SelectItem key={p.value} value={p.value}>{p.label}</SelectItem>
                ))}
                <SelectItem value="custom">فترة مخصصة</SelectItem>
              </SelectContent>
            </Select>
          </div>
          {useCustom && (
            <>
              <div className="space-y-1.5">
                <Label className="text-xs">من</Label>
                <Input
                  type="date"
                  value={customFrom}
                  onChange={(e) => setCustomFrom(e.target.value)}
                  className="w-full sm:w-40"
                />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs">إلى</Label>
                <Input
                  type="date"
                  value={customTo}
                  onChange={(e) => setCustomTo(e.target.value)}
                  className="w-full sm:w-40"
                />
              </div>
            </>
          )}
        </div>
      </Card>

      {loading ? (
        <Spinner />
      ) : !data || !data.hasData ? (
        <EmptyState
          title="بدأ جمع البيانات"
          description="سيظهر هنا تحليل الزيارات والأحداث بعد أن يبدأ الزوار في تصفح الموقع. البيانات تُجمع تلقائياً من الآن فصاعداً."
          icon={<BarChart3 className="size-5" />}
        />
      ) : (
        <>
          {/* KPI Cards */}
          <div className="grid grid-cols-2 gap-3 sm:gap-4 lg:grid-cols-4">
            <KpiCard
              label="الزيارات"
              value={data.kpis.pageViews.current}
              change={data.kpis.pageViews.change}
              icon={<Eye className="size-5" />}
              accent="zinc"
            />
            <KpiCard
              label="زوار فريدون"
              value={data.kpis.uniqueVisitors.current}
              change={data.kpis.uniqueVisitors.change}
              icon={<Users className="size-5" />}
              accent="teal"
            />
            <KpiCard
              label="جلسات"
              value={data.kpis.sessions.current}
              change={data.kpis.sessions.change}
              icon={<BarChart3 className="size-5" />}
              accent="emerald"
            />
            <KpiCard
              label="معدل التحويل"
              value={data.kpis.conversionRate.current}
              icon={<TrendingUp className="size-5" />}
              accent="amber"
            />
          </div>

          <div className="grid grid-cols-2 gap-3 sm:gap-4 lg:grid-cols-4">
            <KpiCard
              label="طلبات جديدة"
              value={data.kpis.newOrders.current}
              icon={<ShoppingCart className="size-5" />}
              accent="zinc"
            />
            <KpiCard
              label="طلبات مؤكدة"
              value={data.kpis.confirmedOrders.current}
              icon={<Package className="size-5" />}
              accent="emerald"
            />
            <KpiCard
              label="المداخيل"
              value={`${data.kpis.revenue.current.toFixed(0)} DH`}
              change={data.kpis.revenue.change}
              icon={<TrendingUp className="size-5" />}
              accent="emerald"
            />
            <KpiCard
              label="عمليات بحث"
              value={data.kpis.searches.current}
              icon={<Search className="size-5" />}
              accent="teal"
            />
          </div>

          {/* Charts row 1: Views + Visitors over time */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base">الزيارات والزوار عبر الوقت</CardTitle>
              <CardDescription>المقارنة بين عدد المشاهدات والزوار الفريدين يومياً.</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-64 sm:h-80 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={data.dailySeries} margin={{ top: 10, right: 10, bottom: 0, left: -20 }}>
                    <defs>
                      <linearGradient id="colorViews" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#3f3f46" stopOpacity={0.3} />
                        <stop offset="95%" stopColor="#3f3f46" stopOpacity={0} />
                      </linearGradient>
                      <linearGradient id="colorVisitors" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#10b981" stopOpacity={0.3} />
                        <stop offset="95%" stopColor="#10b981" stopOpacity={0} />
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e4e4e7" />
                    <XAxis
                      dataKey="date"
                      tick={{ fontSize: 10 }}
                      stroke="#71717a"
                      tickFormatter={(d) => d.slice(5)}
                    />
                    <YAxis allowDecimals={false} tick={{ fontSize: 10 }} stroke="#71717a" />
                    <Tooltip
                      contentStyle={{ borderRadius: 8, border: '1px solid #e4e4e7', fontSize: 12 }}
                      labelStyle={{ fontWeight: 600 }}
                    />
                    <Area type="monotone" dataKey="views" name="مشاهدات" stroke="#3f3f46" fillOpacity={1} fill="url(#colorViews)" strokeWidth={2} />
                    <Area type="monotone" dataKey="visitors" name="زوار" stroke="#10b981" fillOpacity={1} fill="url(#colorVisitors)" strokeWidth={2} />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>

          {/* Charts row 2: Funnel + Traffic Sources */}
          <div className="grid gap-4 lg:grid-cols-2">
            {/* Funnel */}
            <Card>
              <CardHeader>
                <CardTitle className="text-base">قمع الشراء</CardTitle>
                <CardDescription>من مشاهدة المنتج إلى تأكيد الطلب.</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-64 w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart
                      data={data.funnel}
                      layout="vertical"
                      margin={{ top: 5, right: 10, bottom: 5, left: 60 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#e4e4e7" />
                      <XAxis type="number" allowDecimals={false} tick={{ fontSize: 10 }} stroke="#71717a" />
                      <YAxis type="category" dataKey="stage" tick={{ fontSize: 11 }} stroke="#71717a" width={80} />
                      <Tooltip
                        contentStyle={{ borderRadius: 8, border: '1px solid #e4e4e7', fontSize: 12 }}
                        cursor={{ fill: 'rgba(0,0,0,0.04)' }}
                      />
                      <Bar dataKey="count" name="عدد" radius={[0, 6, 6, 0]}>
                        {data.funnel.map((_, i) => (
                          <Cell key={i} fill={['#3f3f46', '#06b6d4', '#f59e0b', '#10b981', '#15803d'][i] || '#3f3f46'} />
                        ))}
                      </Bar>
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            {/* Traffic Sources */}
            <Card>
              <CardHeader>
                <CardTitle className="text-base">مصادر الزيارات</CardTitle>
                <CardDescription>من أين يأتي الزوار.</CardDescription>
              </CardHeader>
              <CardContent>
                {data.trafficSources.length > 0 ? (
                  <div className="h-64 w-full">
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={data.trafficSources.map((s) => ({
                            name: SOURCE_LABELS[s.source] || s.source,
                            value: s.count,
                            fill: SOURCE_COLORS[s.source] || '#a3a3a3',
                          }))}
                          dataKey="value"
                          nameKey="name"
                          cx="50%"
                          cy="50%"
                          outerRadius={70}
                          innerRadius={40}
                          label={({ name, percent }) => `${name} ${((percent || 0) * 100).toFixed(0)}%`}
                          labelLine={false}
                          style={{ fontSize: 10 }}
                        >
                          {data.trafficSources.map((s, i) => (
                            <Cell key={i} fill={SOURCE_COLORS[s.source] || '#a3a3a3'} />
                          ))}
                        </Pie>
                        <Tooltip
                          contentStyle={{ borderRadius: 8, border: '1px solid #e4e4e7', fontSize: 12 }}
                        />
                      </PieChart>
                    </ResponsiveContainer>
                  </div>
                ) : (
                  <p className="text-center text-muted-foreground text-sm py-12">بيانات غير كافية</p>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Charts row 3: Devices + Browsers */}
          <div className="grid gap-4 lg:grid-cols-3">
            {/* Devices */}
            <Card>
              <CardHeader>
                <CardTitle className="text-base">الأجهزة</CardTitle>
              </CardHeader>
              <CardContent>
                {data.devices.length > 0 ? (
                  <div className="space-y-2">
                    {data.devices.map((d) => {
                      const total = data.devices.reduce((s, x) => s + x.count, 0)
                      const pct = total > 0 ? (d.count / total) * 100 : 0
                      const Icon = d.device === 'mobile' ? Smartphone : d.device === 'tablet' ? Tablet : d.device === 'desktop' ? Monitor : BarChart3
                      return (
                        <div key={d.device} className="flex items-center gap-2">
                          <Icon className="size-4 text-muted-foreground shrink-0" />
                          <span className="text-sm w-16">{DEVICE_LABELS[d.device] || d.device}</span>
                          <div className="flex-1 bg-muted rounded-full h-2 overflow-hidden">
                            <div className="bg-zinc-900 h-full rounded-full" style={{ width: `${pct}%` }} />
                          </div>
                          <span className="text-xs font-medium tabular-nums w-12 text-left">{d.count}</span>
                        </div>
                      )
                    })}
                  </div>
                ) : (
                  <p className="text-center text-muted-foreground text-sm py-8">بيانات غير كافية</p>
                )}
              </CardContent>
            </Card>

            {/* Browsers */}
            <Card>
              <CardHeader>
                <CardTitle className="text-base">المتصفحات</CardTitle>
              </CardHeader>
              <CardContent>
                {data.browsers.length > 0 ? (
                  <div className="space-y-2">
                    {data.browsers.slice(0, 6).map((b) => {
                      const total = data.browsers.reduce((s, x) => s + x.count, 0)
                      const pct = total > 0 ? (b.count / total) * 100 : 0
                      return (
                        <div key={b.browser} className="flex items-center gap-2">
                          <span className="text-sm w-20">{b.browser || 'غير معروف'}</span>
                          <div className="flex-1 bg-muted rounded-full h-2 overflow-hidden">
                            <div className="bg-blue-500 h-full rounded-full" style={{ width: `${pct}%` }} />
                          </div>
                          <span className="text-xs font-medium tabular-nums w-12 text-left">{b.count}</span>
                        </div>
                      )
                    })}
                  </div>
                ) : (
                  <p className="text-center text-muted-foreground text-sm py-8">بيانات غير كافية</p>
                )}
              </CardContent>
            </Card>

            {/* OS */}
            <Card>
              <CardHeader>
                <CardTitle className="text-base">أنظمة التشغيل</CardTitle>
              </CardHeader>
              <CardContent>
                {data.operatingSystems.length > 0 ? (
                  <div className="space-y-2">
                    {data.operatingSystems.slice(0, 6).map((o) => {
                      const total = data.operatingSystems.reduce((s, x) => s + x.count, 0)
                      const pct = total > 0 ? (o.count / total) * 100 : 0
                      return (
                        <div key={o.os} className="flex items-center gap-2">
                          <span className="text-sm w-20">{o.os || 'غير معروف'}</span>
                          <div className="flex-1 bg-muted rounded-full h-2 overflow-hidden">
                            <div className="bg-emerald-500 h-full rounded-full" style={{ width: `${pct}%` }} />
                          </div>
                          <span className="text-xs font-medium tabular-nums w-12 text-left">{o.count}</span>
                        </div>
                      )
                    })}
                  </div>
                ) : (
                  <p className="text-center text-muted-foreground text-sm py-8">بيانات غير كافية</p>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Charts row 4: Top Pages + Top Products */}
          <div className="grid gap-4 lg:grid-cols-2">
            {/* Top Pages */}
            <Card>
              <CardHeader>
                <CardTitle className="text-base">أكثر الصفحات زيارة</CardTitle>
              </CardHeader>
              <CardContent>
                {data.topPages.length > 0 ? (
                  <div className="space-y-1.5">
                    {data.topPages.slice(0, 10).map((p, i) => (
                      <div key={p.path} className="flex items-center gap-2 text-sm">
                        <span className="text-muted-foreground text-xs font-mono w-4">{i + 1}</span>
                        <span className="font-mono text-xs flex-1 truncate" dir="ltr">{p.path}</span>
                        <span className="font-medium tabular-nums text-xs">{p.views}</span>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-center text-muted-foreground text-sm py-8">بيانات غير كافية</p>
                )}
              </CardContent>
            </Card>

            {/* Top Products */}
            <Card>
              <CardHeader>
                <CardTitle className="text-base">المنتجات الأكثر مشاهدة</CardTitle>
              </CardHeader>
              <CardContent>
                {data.topProducts.length > 0 ? (
                  <div className="space-y-1.5">
                    {data.topProducts.slice(0, 10).map((p, i) => (
                      <div key={p.slug} className="flex items-center gap-2 text-sm">
                        <span className="text-muted-foreground text-xs font-mono w-4">{i + 1}</span>
                        <Link href={`/produits/${p.slug}`} className="text-xs flex-1 truncate hover:underline" dir="ltr">
                          {p.slug}
                        </Link>
                        <span className="font-medium tabular-nums text-xs">{p.views}</span>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-center text-muted-foreground text-sm py-8">بيانات غير كافية</p>
                )}
              </CardContent>
            </Card>
          </div>

          {/* E-commerce KPIs */}
          <div className="grid grid-cols-2 gap-3 sm:gap-4 lg:grid-cols-4">
            <KpiCard
              label="إضافات للسلة"
              value={data.kpis.addToCart.current}
              change={data.kpis.addToCart.change}
              icon={<ShoppingCart className="size-5" />}
              accent="zinc"
            />
            <KpiCard
              label="بداية الدفع"
              value={data.kpis.beginCheckout.current}
              change={data.kpis.beginCheckout.change}
              icon={<Package className="size-5" />}
              accent="teal"
            />
            <KpiCard
              label="مشاهدات منتج"
              value={data.kpis.viewItem.current}
              icon={<Eye className="size-5" />}
              accent="zinc"
            />
            <KpiCard
              label="طلبات مكتملة"
              value={data.kpis.deliveredOrders.current}
              icon={<Package className="size-5" />}
              accent="emerald"
            />
          </div>
        </>
      )}
    </div>
  )
}

// KPI Card with change indicator
function KpiCard({
  label, value, change, icon, accent,
}: {
  label: string
  value: number | string
  change?: number | null
  icon: React.ReactNode
  accent: 'emerald' | 'amber' | 'rose' | 'zinc' | 'teal'
}) {
  const changeIcon = change === null || change === undefined ? null :
    change > 0 ? <TrendingUp className="size-3 text-emerald-600" /> :
    change < 0 ? <TrendingDown className="size-3 text-rose-600" /> :
    <Minus className="size-3 text-muted-foreground" />

  const changeColor = change === null || change === undefined ? '' :
    change > 0 ? 'text-emerald-600' :
    change < 0 ? 'text-rose-600' : 'text-muted-foreground'

  return (
    <CardStat
      label={label}
      value={value}
      hint={change !== null && change !== undefined ? (
        <span className={`flex items-center gap-1 ${changeColor}`}>
          {changeIcon}
          {change > 0 ? '+' : ''}{change}%
        </span>
      ) : undefined}
      icon={icon}
      accent={accent}
    />
  )
}

import Link from 'next/link'
