'use client'

import * as React from 'react'
import Link from 'next/link'
import {
  Search, ShoppingCart, MoreHorizontal, Trash2, X, CheckSquare,
  Loader2,
} from 'lucide-react'

import { formatPrice, timeAgoAr } from '@/lib/format'
import { PageHeader, EmptyState, Spinner } from '@/components/admin/page-header'
import { OrderStatusBadge, PaymentStatusBadge } from '@/components/admin/status-badge'
import { TablePagination } from '@/components/admin/table-pagination'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Checkbox } from '@/components/ui/checkbox'
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select'
import { Card } from '@/components/ui/card'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import {
  Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle,
} from '@/components/ui/dialog'
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { toast } from 'sonner'

interface OrderItem {
  id: string
  number: string
  customerFullName: string
  customerPhone: string
  status: string
  paymentMethod: string
  paymentStatus: string
  total: number
  currencyCode: string
  currencySymbol: string
  itemCount: number
  placedAt: string
  countryName: string
}

const PAGE_SIZE = 20

const STATUSES = [
  { value: 'all', label: 'الكل' },
  { value: 'NEW', label: 'جديدة' },
  { value: 'CONTACTED', label: 'تم التواصل' },
  { value: 'CONFIRMED', label: 'مؤكدة' },
  { value: 'PROCESSING', label: 'قيد التحضير' },
  { value: 'SHIPPED', label: 'تم الشحن' },
  { value: 'DELIVERED', label: 'تم التسليم' },
  { value: 'CANCELLED', label: 'ملغاة' },
  { value: 'RETURNED', label: 'مُعادة' },
  { value: 'UNREACHABLE', label: 'غير قابلة للوصول' },
]

const STATUS_LABELS: Record<string, string> = {
  NEW: 'جديدة', CONTACTED: 'تم التواصل', CONFIRMED: 'مؤكدة', PROCESSING: 'قيد التحضير',
  SHIPPED: 'تم الشحن', DELIVERED: 'تم التسليم', CANCELLED: 'ملغاة', RETURNED: 'مُعادة', UNREACHABLE: 'غير قابلة للوصول',
}

export default function AdminOrdersPage() {
  const [items, setItems] = React.useState<OrderItem[]>([])
  const [total, setTotal] = React.useState(0)
  const [page, setPage] = React.useState(1)
  const [q, setQ] = React.useState('')
  const [status, setStatus] = React.useState('all')
  const [loading, setLoading] = React.useState(true)
  const [searchInput, setSearchInput] = React.useState('')
  const [selected, setSelected] = React.useState<Set<string>>(new Set())
  const debounceRef = React.useRef<ReturnType<typeof setTimeout> | null>(null)

  // Bulk action dialogs
  const [bulkDeleteOpen, setBulkDeleteOpen] = React.useState(false)
  const [bulkStatusOpen, setBulkStatusOpen] = React.useState(false)
  const [bulkStatus, setBulkStatus] = React.useState('CONFIRMED')
  const [saving, setSaving] = React.useState(false)

  async function load(p = page, query = q, st = status) {
    setLoading(true)
    try {
      const params = new URLSearchParams({ page: String(p), pageSize: String(PAGE_SIZE) })
      if (query) params.set('q', query)
      if (st && st !== 'all') params.set('status', st)
      const res = await fetch(`/api/admin/orders?${params.toString()}`, { credentials: 'include' })
      const json = await res.json()
      if (!res.ok || !json.ok) { toast.error(json.error || 'خطأ'); return }
      setItems(json.items)
      setTotal(json.total)
    } catch {
      toast.error('خطأ في الشبكة')
    } finally {
      setLoading(false)
    }
  }

  React.useEffect(() => { load(1, '', 'all') }, [])

  React.useEffect(() => {
    if (debounceRef.current) clearTimeout(debounceRef.current)
    debounceRef.current = setTimeout(() => {
      if (searchInput !== q) {
        setQ(searchInput)
        setPage(1)
        load(1, searchInput, status)
      }
    }, 350)
    return () => { if (debounceRef.current) clearTimeout(debounceRef.current) }
  }, [searchInput])

  function onStatusChange(s: string) {
    setStatus(s)
    setPage(1)
    load(1, q, s)
  }

  // Selection
  function toggleSelect(id: string) {
    setSelected((prev) => {
      const next = new Set(prev)
      if (next.has(id)) next.delete(id)
      else next.add(id)
      return next
    })
  }

  function selectAllOnPage() {
    setSelected(new Set(items.map((o) => o.id)))
  }

  function clearSelection() {
    setSelected(new Set())
  }

  const allOnPageSelected = items.length > 0 && items.every((o) => selected.has(o.id))

  // Bulk delete
  async function confirmBulkDelete() {
    if (saving) return
    setSaving(true)
    try {
      const res = await fetch('/api/admin/orders/bulk', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ids: Array.from(selected), action: 'delete' }),
        credentials: 'include',
      })
      const json = await res.json()
      if (!res.ok || !json.ok) { toast.error(json.error || 'فشل الحذف'); return }
      toast.success(`تم حذف ${json.deleted} طلب`)
      setBulkDeleteOpen(false)
      clearSelection()
      load()
    } catch {
      toast.error('خطأ في الشبكة')
    } finally {
      setSaving(false)
    }
  }

  // Bulk status change
  async function confirmBulkStatus() {
    if (saving) return
    setSaving(true)
    try {
      const res = await fetch('/api/admin/orders/bulk', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ids: Array.from(selected), action: 'status', status: bulkStatus }),
        credentials: 'include',
      })
      const json = await res.json()
      if (!res.ok || !json.ok) { toast.error(json.error || 'فشل'); return }
      toast.success(`تم تحديث ${json.updated} طلب`)
      setBulkStatusOpen(false)
      clearSelection()
      load()
    } catch {
      toast.error('خطأ في الشبكة')
    } finally {
      setSaving(false)
    }
  }

  return (
    <div className="space-y-4 sm:space-y-6">
      <PageHeader
        title="الطلبات"
        description="قائمة ومتابعة طلبات الزبائن."
        breadcrumb={[{ label: 'الإدارة', href: '/admin/dashboard' }, { label: 'الطلبات' }]}
      />

      {/* Search + Filter */}
      <Card className="p-3">
        <div className="flex flex-col gap-2 sm:flex-row sm:items-center">
          <div className="relative flex-1">
            <Search className="text-muted-foreground absolute right-2.5 top-1/2 size-4 -translate-y-1/2" />
            <Input
              placeholder="رقم الطلب، الاسم، الهاتف…"
              value={searchInput}
              onChange={(e) => setSearchInput(e.target.value)}
              className="pr-8"
            />
          </div>
          <Select value={status} onValueChange={onStatusChange}>
            <SelectTrigger className="w-full sm:w-48">
              <SelectValue placeholder="كل الحالات" />
            </SelectTrigger>
            <SelectContent>
              {STATUSES.map((s) => (
                <SelectItem key={s.value} value={s.value}>{s.label}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </Card>

      {/* Bulk actions bar */}
      {selected.size > 0 && (
        <Card className="p-3 border-primary/30 bg-primary/5">
          <div className="flex flex-wrap items-center gap-2">
            <span className="text-sm font-medium">{selected.size} محدد</span>
            <div className="flex flex-wrap gap-2 mr-auto">
              <Button size="sm" variant="outline" onClick={() => setBulkStatusOpen(true)}>
                <CheckSquare className="size-4" /> تغيير الحالة
              </Button>
              <Button size="sm" variant="destructive" onClick={() => setBulkDeleteOpen(true)}>
                <Trash2 className="size-4" /> حذف المحدد
              </Button>
              <Button size="sm" variant="ghost" onClick={clearSelection}>
                <X className="size-4" /> إلغاء
              </Button>
            </div>
          </div>
        </Card>
      )}

      {loading ? (
        <Spinner />
      ) : items.length === 0 ? (
        <EmptyState
          title="لا توجد طلبات"
          description="ستظهر هنا الطلبات التي يقدمها الزبائن."
          icon={<ShoppingCart className="size-5" />}
        />
      ) : (
        <>
          {/* Desktop table */}
          <Card className="hidden lg:block p-0 overflow-hidden">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-10">
                    <Checkbox
                      checked={allOnPageSelected}
                      onCheckedChange={() => allOnPageSelected ? clearSelection() : selectAllOnPage()}
                    />
                  </TableHead>
                  <TableHead>الرقم</TableHead>
                  <TableHead>العميل</TableHead>
                  <TableHead>الحالة</TableHead>
                  <TableHead>الدفع</TableHead>
                  <TableHead className="text-center">العناصر</TableHead>
                  <TableHead className="text-left">الإجمالي</TableHead>
                  <TableHead>الدولة</TableHead>
                  <TableHead className="text-left">التاريخ</TableHead>
                  <TableHead className="w-12"></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {items.map((o) => (
                  <TableRow key={o.id}>
                    <TableCell>
                      <Checkbox
                        checked={selected.has(o.id)}
                        onCheckedChange={() => toggleSelect(o.id)}
                      />
                    </TableCell>
                    <TableCell className="font-mono text-xs" dir="ltr">
                      <Link href={`/admin/orders/${o.id}`} className="hover:underline text-zinc-900">
                        {o.number}
                      </Link>
                    </TableCell>
                    <TableCell>
                      <div className="flex flex-col">
                        <span className="font-medium">{o.customerFullName}</span>
                        <span className="text-muted-foreground text-xs" dir="ltr">{o.customerPhone}</span>
                      </div>
                    </TableCell>
                    <TableCell><OrderStatusBadge status={o.status} /></TableCell>
                    <TableCell>
                      <div className="flex flex-col gap-0.5">
                        <span className="text-xs">{o.paymentMethod}</span>
                        <PaymentStatusBadge status={o.paymentStatus} />
                      </div>
                    </TableCell>
                    <TableCell className="text-center tabular-nums">{o.itemCount}</TableCell>
                    <TableCell className="text-left font-medium tabular-nums">
                      {formatPrice(o.total, { code: o.currencyCode, symbol: o.currencySymbol })}
                    </TableCell>
                    <TableCell className="text-sm">{o.countryName}</TableCell>
                    <TableCell className="text-left text-xs text-muted-foreground">{timeAgoAr(o.placedAt)}</TableCell>
                    <TableCell>
                      <Button asChild variant="ghost" size="icon" className="size-8">
                        <Link href={`/admin/orders/${o.id}`}>
                          <MoreHorizontal className="size-4" />
                        </Link>
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </Card>

          {/* Mobile/Tablet cards */}
          <div className="lg:hidden space-y-3">
            {items.map((o) => (
              <Card key={o.id} className="p-3">
                <div className="flex items-start gap-3">
                  <Checkbox
                    checked={selected.has(o.id)}
                    onCheckedChange={() => toggleSelect(o.id)}
                  />
                  <div className="flex-1 min-w-0 space-y-1">
                    <div className="flex items-center justify-between gap-2">
                      <Link href={`/admin/orders/${o.id}`} className="font-mono text-xs hover:underline" dir="ltr">
                        {o.number}
                      </Link>
                      <OrderStatusBadge status={o.status} />
                    </div>
                    <p className="font-medium text-sm truncate">{o.customerFullName}</p>
                    <p className="text-xs text-muted-foreground" dir="ltr">{o.customerPhone}</p>
                    <div className="flex items-center justify-between gap-2 pt-1">
                      <span className="font-medium tabular-nums text-sm">
                        {formatPrice(o.total, { code: o.currencyCode, symbol: o.currencySymbol })}
                      </span>
                      <span className="text-xs text-muted-foreground">
                        {o.itemCount} عنصر · {timeAgoAr(o.placedAt)}
                      </span>
                    </div>
                  </div>
                </div>
              </Card>
            ))}
          </div>

          <TablePagination
            page={page}
            pageSize={PAGE_SIZE}
            total={total}
            onPage={(p) => { setPage(p); load(p, q, status) }}
          />
        </>
      )}

      {/* Bulk Delete Dialog */}
      <Dialog open={bulkDeleteOpen} onOpenChange={setBulkDeleteOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>حذف {selected.size} طلب</DialogTitle>
            <DialogDescription>
              هل أنت متأكد من حذف {selected.size} طلب نهائياً؟ سيتم حذف الطلبات وتفاصيلها وسجل الحالات من قاعدة البيانات. لا يمكن التراجع.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setBulkDeleteOpen(false)}>إلغاء</Button>
            <Button variant="destructive" onClick={confirmBulkDelete} disabled={saving}>
              {saving && <Loader2 className="size-4 animate-spin" />}
              حذف {selected.size} طلب
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Bulk Status Dialog */}
      <Dialog open={bulkStatusOpen} onOpenChange={setBulkStatusOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>تغيير حالة {selected.size} طلب</DialogTitle>
            <DialogDescription>اختر الحالة الجديدة للطلبات المحددة.</DialogDescription>
          </DialogHeader>
          <div className="py-3">
            <Select value={bulkStatus} onValueChange={setBulkStatus}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {STATUSES.filter((s) => s.value !== 'all').map((s) => (
                  <SelectItem key={s.value} value={s.value}>{s.label}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setBulkStatusOpen(false)}>إلغاء</Button>
            <Button onClick={confirmBulkStatus} disabled={saving} className="bg-zinc-900 hover:bg-zinc-800">
              {saving && <Loader2 className="size-4 animate-spin" />}
              تطبيق
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
