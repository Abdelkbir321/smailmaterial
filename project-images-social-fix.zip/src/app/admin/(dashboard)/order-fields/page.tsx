'use client'

import * as React from 'react'
import { toast } from 'sonner'
import {
  Plus,
  Loader2,
  Trash2,
  Pencil,
  Lock,
  FormInput,
  X,
  ArrowUp,
  ArrowDown,
} from 'lucide-react'

import { PageHeader, EmptyState, Spinner } from '@/components/admin/page-header'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Switch } from '@/components/ui/switch'
import { Card } from '@/components/ui/card'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog'
import { Badge } from '@/components/ui/badge'

interface Option {
  value: string
  labelAr: string
  labelFr: string
  labelEn: string
}

interface OrderField {
  id: string
  key: string
  type: string
  labelAr: string
  labelFr: string
  labelEn: string
  placeholderAr: string | null
  placeholderFr: string | null
  placeholderEn: string | null
  helpTextAr: string | null
  helpTextFr: string | null
  helpTextEn: string | null
  options: Option[]
  required: boolean
  isActive: boolean
  sortOrder: number
  defaultValue: string | null
  width: string // full | half
  // Validation bounds (nullable in DB)
  minLength: number | null
  maxLength: number | null
  // Visibility: empty array = all countries; else ISO codes (MA, DZ, ...)
  countryCodes: string[]
}

const FIELD_TYPES = [
  { value: 'text', label: 'نص (text)' },
  { value: 'phone', label: 'هاتف (phone)' },
  { value: 'email', label: 'بريد إلكتروني (email)' },
  { value: 'textarea', label: 'منطقة نص (textarea)' },
  { value: 'number', label: 'رقم (number)' },
  { value: 'select', label: 'قائمة منسدلة (select)' },
  { value: 'checkbox', label: 'صندوق اختيار (checkbox)' },
]

const TYPE_LABEL: Record<string, string> = Object.fromEntries(
  FIELD_TYPES.map((f) => [f.value, f.label]),
)

interface FormState {
  id?: string
  key: string
  type: string
  labelAr: string
  labelFr: string
  labelEn: string
  placeholderAr: string
  placeholderFr: string
  placeholderEn: string
  helpTextAr: string
  helpTextFr: string
  helpTextEn: string
  options: Option[]
  required: boolean
  isActive: boolean
  sortOrder: number
  width: string
  defaultValue: string
  // Length bounds — empty string = null (no bound)
  minLength: string
  maxLength: string
  // Country codes — comma-separated string in the UI, parsed to string[] on submit
  countryCodes: string
}

const EMPTY_FORM: FormState = {
  key: '',
  type: 'text',
  labelAr: '',
  labelFr: '',
  labelEn: '',
  placeholderAr: '',
  placeholderFr: '',
  placeholderEn: '',
  helpTextAr: '',
  helpTextFr: '',
  helpTextEn: '',
  options: [],
  required: false,
  isActive: true,
  sortOrder: 0,
  width: 'full',
  defaultValue: '',
  minLength: '',
  maxLength: '',
  countryCodes: '',
}

export default function OrderFieldsPage() {
  const [fields, setFields] = React.useState<OrderField[]>([])
  const [loading, setLoading] = React.useState(true)
  const [open, setOpen] = React.useState(false)
  const [saving, setSaving] = React.useState(false)
  const [form, setForm] = React.useState<FormState>(EMPTY_FORM)
  const [editMode, setEditMode] = React.useState(false)
  const [deleteTarget, setDeleteTarget] = React.useState<OrderField | null>(null)

  async function load() {
    setLoading(true)
    try {
      const res = await fetch('/api/admin/order-fields', { credentials: 'include' })
      const json = await res.json()
      if (!res.ok || !json.ok) {
        toast.error(json.error || 'فشل التحميل')
        return
      }
      setFields(json.fields)
    } catch {
      toast.error('خطأ في الشبكة')
    } finally {
      setLoading(false)
    }
  }

  React.useEffect(() => {
    load()
  }, [])

  function openCreate() {
    setEditMode(false)
    setForm({
      ...EMPTY_FORM,
      sortOrder: fields.length,
    })
    setOpen(true)
  }

  function openEdit(f: OrderField) {
    setEditMode(true)
    setForm({
      id: f.id,
      key: f.key,
      type: f.type,
      labelAr: f.labelAr,
      labelFr: f.labelFr,
      labelEn: f.labelEn,
      placeholderAr: f.placeholderAr || '',
      placeholderFr: f.placeholderFr || '',
      placeholderEn: f.placeholderEn || '',
      helpTextAr: f.helpTextAr || '',
      helpTextFr: f.helpTextFr || '',
      helpTextEn: f.helpTextEn || '',
      options: Array.isArray(f.options) ? (f.options as Option[]) : [],
      required: f.required,
      isActive: f.isActive,
      sortOrder: f.sortOrder,
      width: f.width || 'full',
      defaultValue: f.defaultValue || '',
      // nullable → empty string in UI
      minLength: f.minLength != null ? String(f.minLength) : '',
      maxLength: f.maxLength != null ? String(f.maxLength) : '',
      // string[] → comma-separated string in UI
      countryCodes: Array.isArray(f.countryCodes) ? f.countryCodes.join(', ') : '',
    })
    setOpen(true)
  }

  function set<K extends keyof FormState>(k: K, v: FormState[K]) {
    setForm((s) => ({ ...s, [k]: v }))
  }

  function addOption() {
    setForm((s) => ({
      ...s,
      options: [...s.options, { value: '', labelAr: '', labelFr: '', labelEn: '' }],
    }))
  }

  function updateOption(i: number, key: keyof Option, v: string) {
    setForm((s) => {
      const next = [...s.options]
      next[i] = { ...next[i], [key]: v }
      return { ...s, options: next }
    })
  }

  function removeOption(i: number) {
    setForm((s) => ({
      ...s,
      options: s.options.filter((_, idx) => idx !== i),
    }))
  }

  async function submit(e: React.FormEvent) {
    e.preventDefault()
    if (saving) return

    // Trim all label values before checking — whitespace-only values
    // should be treated as empty (the user might paste spaces accidentally)
    const trimmedKey = form.key.trim()
    const trimmedAr = form.labelAr.trim()
    const trimmedFr = form.labelFr.trim()
    const trimmedEn = form.labelEn.trim()

    if (!trimmedKey || !trimmedAr || !trimmedFr || !trimmedEn) {
      // Identify which field is missing for a more helpful error message
      const missing: string[] = []
      if (!trimmedKey) missing.push('المفتاح')
      if (!trimmedAr) missing.push('الوسم بالعربية')
      if (!trimmedFr) missing.push('الوسم بالفرنسية')
      if (!trimmedEn) missing.push('الوسم بالإنجليزية')
      toast.error(`حقول مطلوبة: ${missing.join('، ')}`)
      return
    }
    if (!editMode && !/^[a-z0-9_]+$/.test(trimmedKey)) {
      toast.error('المفتاح يجب أن يكون أحرف صغيرة + شرطة سفلية فقط (مثال: city).')
      return
    }
    setSaving(true)
    try {
      const payload = {
        key: trimmedKey,
        type: form.type,
        labelAr: trimmedAr,
        labelFr: trimmedFr,
        labelEn: trimmedEn,
        placeholderAr: form.placeholderAr || null,
        placeholderFr: form.placeholderFr || null,
        placeholderEn: form.placeholderEn || null,
        helpTextAr: form.helpTextAr || null,
        helpTextFr: form.helpTextFr || null,
        helpTextEn: form.helpTextEn || null,
        options: form.options.filter((o) => o.value),
        required: form.required,
        isActive: form.isActive,
        sortOrder: form.sortOrder,
        width: form.width,
        defaultValue: form.defaultValue || null,
        // Empty string → null (no bound). The server parses these again,
        // but we send the typed values to be explicit.
        minLength: form.minLength === '' ? null : Number(form.minLength),
        maxLength: form.maxLength === '' ? null : Number(form.maxLength),
        // Comma-separated string → string[] on the server (it accepts both).
        // We send the raw string so partial updates work cleanly.
        countryCodes: form.countryCodes.trim(),
      }
      const res = await fetch(
        editMode ? `/api/admin/order-fields/${form.id}` : '/api/admin/order-fields',
        {
          method: editMode ? 'PUT' : 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload),
          credentials: 'include',
        },
      )
      const json = await res.json()
      if (!res.ok || !json.ok) {
        toast.error(json.error || 'فشل الحفظ')
        return
      }
      toast.success(editMode ? 'تم تحديث الحقل' : 'تم إنشاء الحقل')
      setOpen(false)
      load()
    } catch {
      toast.error('خطأ في الشبكة')
    } finally {
      setSaving(false)
    }
  }

  async function confirmDelete() {
    if (!deleteTarget) return
    try {
      const res = await fetch(`/api/admin/order-fields/${deleteTarget.id}`, {
        method: 'DELETE',
        credentials: 'include',
      })
      const json = await res.json()
      if (!res.ok || !json.ok) {
        toast.error(json.error || 'فشل الحذف')
        return
      }
      if (json.deactivated) {
        toast.info(
          json.message ||
            `تم إخفاء الحقل لأن طلبات قديمة تستعمله.`,
        )
      } else {
        toast.success('تم حذف الحقل')
      }
      setDeleteTarget(null)
      load()
    } catch {
      toast.error('خطأ في الشبكة')
    }
  }

  async function toggleActive(f: OrderField, value: boolean) {
    try {
      const res = await fetch(`/api/admin/order-fields/${f.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ isActive: value }),
        credentials: 'include',
      })
      const json = await res.json()
      if (!res.ok || !json.ok) {
        toast.error(json.error || 'فشل التحديث')
        return
      }
      toast.success('تم التحديث')
      load()
    } catch {
      toast.error('خطأ في الشبكة')
    }
  }

  function moveField(i: number, dir: -1 | 1) {
    // Optimistic local reorder — applies new sortOrder via PUT on save (simplified)
    const next = [...fields]
    const j = i + dir
    if (j < 0 || j >= next.length) return
    ;[next[i], next[j]] = [next[j], next[i]]
    // Reassign sortOrder
    next.forEach((f, idx) => {
      // fire-and-forget PUT
      fetch(`/api/admin/order-fields/${f.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ sortOrder: idx }),
        credentials: 'include',
      })
    })
    setFields(next)
    toast.success('تم تحديث ترتيب الحقول')
  }

  return (
    <div className="space-y-6">
      <PageHeader
        title="حقول الطلب"
        description="إدارة الحقول الديناميكية في استمارة الطلب."
        breadcrumb={[{ label: 'الإدارة', href: '/admin/dashboard' }, { label: 'حقول الطلب' }]}
        actions={
          <Button onClick={openCreate} className="bg-zinc-900 hover:bg-zinc-800">
            <Plus className="size-4" />
            إضافة حقل
          </Button>
        }
      />

      {loading ? (
        <Spinner />
      ) : fields.length === 0 ? (
        <EmptyState
          title="لا توجد حقول"
          description="أضف أول حقل لاستمارة الطلب."
          icon={<FormInput className="size-5" />}
          action={
            <Button onClick={openCreate} className="bg-zinc-900 hover:bg-zinc-800">
              <Plus className="size-4" />
              إضافة حقل
            </Button>
          }
        />
      ) : (
        <Card className="p-0 overflow-hidden">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-12">#</TableHead>
                <TableHead>المفتاح</TableHead>
                <TableHead>النوع</TableHead>
                <TableHead>الوسم (عربي)</TableHead>
                <TableHead>إلزامي</TableHead>
                <TableHead>الحالة</TableHead>
                <TableHead>العرض</TableHead>
                <TableHead className="w-24">إجراءات</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {fields.map((f, i) => (
                <TableRow key={f.id}>
                  <TableCell className="text-xs tabular-nums">{f.sortOrder + 1}</TableCell>
                  <TableCell>
                    <div className="flex items-center gap-1.5">
                      <Lock className="size-3 text-muted-foreground" />
                      <span className="font-mono text-xs" dir="ltr">{f.key}</span>
                    </div>
                  </TableCell>
                  <TableCell>
                    <span className="font-mono text-xs">{TYPE_LABEL[f.type] ?? f.type}</span>
                  </TableCell>
                  <TableCell className="text-sm">{f.labelAr}</TableCell>
                  <TableCell>
                    {f.required ? (
                      <Badge className="bg-amber-100 text-amber-700">نعم</Badge>
                    ) : (
                      <span className="text-muted-foreground text-xs">لا</span>
                    )}
                  </TableCell>
                  <TableCell>
                    <Switch
                      checked={f.isActive}
                      onCheckedChange={(v) => toggleActive(f, v)}
                    />
                  </TableCell>
                  <TableCell>
                    <span className="text-xs">{f.width === 'half' ? 'نصف' : 'كامل'}</span>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-1">
                      <Button
                        size="icon"
                        variant="ghost"
                        className="size-7"
                        disabled={i === 0}
                        onClick={() => moveField(i, -1)}
                      >
                        <ArrowUp className="size-3" />
                      </Button>
                      <Button
                        size="icon"
                        variant="ghost"
                        className="size-7"
                        disabled={i === fields.length - 1}
                        onClick={() => moveField(i, 1)}
                      >
                        <ArrowDown className="size-3" />
                      </Button>
                      <Button
                        size="icon"
                        variant="ghost"
                        className="size-7"
                        onClick={() => openEdit(f)}
                      >
                        <Pencil className="size-3" />
                      </Button>
                      <Button
                        size="icon"
                        variant="ghost"
                        className="size-7 text-rose-600"
                        onClick={() => setDeleteTarget(f)}
                      >
                        <Trash2 className="size-3" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </Card>
      )}

      {/* Create / Edit dialog */}
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              {editMode ? 'تعديل الحقل' : 'حقل جديد'}
            </DialogTitle>
            <DialogDescription>
              الحقول الديناميكية تظهر في استمارة الطلب. لا يمكن تغيير المفتاح بعد الإنشاء.
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={submit} className="space-y-3">
            <div className="grid gap-3 sm:grid-cols-2">
              <div className="space-y-1.5">
                <Label htmlFor="key">المفتاح (key) *</Label>
                <div className="flex items-center gap-2">
                  <Input
                    id="key"
                    value={form.key}
                    onChange={(e) => set('key', e.target.value)}
                    placeholder="city"
                    disabled={editMode}
                    dir="ltr"
                    className="text-left"
                  />
                  {editMode && <Lock className="size-4 text-muted-foreground" />}
                </div>
                <p className="text-xs text-muted-foreground">
                  أحرف صغيرة وشرطة سفلية فقط. ثابت بعد الإنشاء.
                </p>
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="type">النوع *</Label>
                <Select value={form.type} onValueChange={(v) => set('type', v)}>
                  <SelectTrigger id="type" className="w-full">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {FIELD_TYPES.map((t) => (
                      <SelectItem key={t.value} value={t.value}>
                        {t.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="grid gap-3 sm:grid-cols-3">
              <div className="space-y-1.5">
                <Label htmlFor="labelAr">الوسم (عربي) *</Label>
                <Input
                  id="labelAr"
                  value={form.labelAr}
                  onChange={(e) => set('labelAr', e.target.value)}
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="labelFr">الوسم (فرنسي) *</Label>
                <Input
                  id="labelFr"
                  value={form.labelFr}
                  onChange={(e) => set('labelFr', e.target.value)}
                  dir="ltr"
                  className="text-left"
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="labelEn">الوسم (إنجليزي) *</Label>
                <Input
                  id="labelEn"
                  value={form.labelEn}
                  onChange={(e) => set('labelEn', e.target.value)}
                  dir="ltr"
                  className="text-left"
                />
              </div>
            </div>

            <div className="grid gap-3 sm:grid-cols-3">
              <div className="space-y-1.5">
                <Label htmlFor="phAr">Placeholder (عربي)</Label>
                <Input
                  id="phAr"
                  value={form.placeholderAr}
                  onChange={(e) => set('placeholderAr', e.target.value)}
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="phFr">Placeholder (فرنسي)</Label>
                <Input
                  id="phFr"
                  value={form.placeholderFr}
                  onChange={(e) => set('placeholderFr', e.target.value)}
                  dir="ltr"
                  className="text-left"
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="phEn">Placeholder (إنجليزي)</Label>
                <Input
                  id="phEn"
                  value={form.placeholderEn}
                  onChange={(e) => set('placeholderEn', e.target.value)}
                  dir="ltr"
                  className="text-left"
                />
              </div>
            </div>

            <div className="grid gap-3 sm:grid-cols-3">
              <div className="space-y-1.5">
                <Label htmlFor="helpAr">نص مساعد (عربي)</Label>
                <Input
                  id="helpAr"
                  value={form.helpTextAr}
                  onChange={(e) => set('helpTextAr', e.target.value)}
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="helpFr">نص مساعد (فرنسي)</Label>
                <Input
                  id="helpFr"
                  value={form.helpTextFr}
                  onChange={(e) => set('helpTextFr', e.target.value)}
                  dir="ltr"
                  className="text-left"
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="helpEn">نص مساعد (إنجليزي)</Label>
                <Input
                  id="helpEn"
                  value={form.helpTextEn}
                  onChange={(e) => set('helpTextEn', e.target.value)}
                  dir="ltr"
                  className="text-left"
                />
              </div>
            </div>

            <div className="grid gap-3 sm:grid-cols-3">
              <div className="space-y-1.5">
                <Label htmlFor="width">العرض</Label>
                <Select value={form.width} onValueChange={(v) => set('width', v)}>
                  <SelectTrigger id="width" className="w-full">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="full">كامل</SelectItem>
                    <SelectItem value="half">نصف</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="sortOrder">الترتيب</Label>
                <Input
                  id="sortOrder"
                  type="number"
                  value={form.sortOrder}
                  onChange={(e) => set('sortOrder', Number(e.target.value) || 0)}
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="defaultValue">قيمة افتراضية</Label>
                <Input
                  id="defaultValue"
                  value={form.defaultValue}
                  onChange={(e) => set('defaultValue', e.target.value)}
                />
              </div>
            </div>

            {/* ─── Length bounds + country-scoped visibility ──────────────
                These map directly to the OrderField table's minLength /
                maxLength / countryCodes columns. The admin can leave any
                of these empty → no bound (or visible in all countries). */}
            <div className="grid gap-3 sm:grid-cols-3">
              <div className="space-y-1.5">
                <Label htmlFor="minLength">الحد الأدنى للأحرف</Label>
                <Input
                  id="minLength"
                  type="number"
                  min={0}
                  value={form.minLength}
                  onChange={(e) => set('minLength', e.target.value)}
                  placeholder="بدون حد"
                  dir="ltr"
                  className="text-left"
                />
                <p className="text-xs text-muted-foreground">
                  فارغ = بدون حد أدنى.
                </p>
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="maxLength">الحد الأقصى للأحرف</Label>
                <Input
                  id="maxLength"
                  type="number"
                  min={0}
                  value={form.maxLength}
                  onChange={(e) => set('maxLength', e.target.value)}
                  placeholder="بدون حد"
                  dir="ltr"
                  className="text-left"
                />
                <p className="text-xs text-muted-foreground">
                  فارغ = بدون حد أقصى.
                </p>
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="countryCodes">الدول المسموحة</Label>
                <Input
                  id="countryCodes"
                  value={form.countryCodes}
                  onChange={(e) => set('countryCodes', e.target.value)}
                  placeholder="مثال: MA, DZ, TN"
                  dir="ltr"
                  className="text-left"
                />
                <p className="text-xs text-muted-foreground">
                  فارغ = يظهر في كل الدول. وإلا، أكواد ISO مفصولة بفواصل.
                </p>
              </div>
            </div>

            <div className="flex items-center justify-between rounded-lg border p-3">
              <div>
                <p className="text-sm font-medium">إلزامي</p>
                <p className="text-xs text-muted-foreground">يجب على العميل ملؤه.</p>
              </div>
              <Switch
                checked={form.required}
                onCheckedChange={(v) => set('required', v)}
              />
            </div>

            <div className="flex items-center justify-between rounded-lg border p-3">
              <div>
                <p className="text-sm font-medium">مُفعّل</p>
                <p className="text-xs text-muted-foreground">يظهر في الاستمارة.</p>
              </div>
              <Switch
                checked={form.isActive}
                onCheckedChange={(v) => set('isActive', v)}
              />
            </div>

            {/* Options (for select type) */}
            {form.type === 'select' && (
              <div className="space-y-2 rounded-lg border p-3">
                <div className="flex items-center justify-between">
                  <Label>خيارات القائمة</Label>
                  <Button type="button" variant="outline" size="sm" onClick={addOption}>
                    <Plus className="size-4" />
                    إضافة خيار
                  </Button>
                </div>
                {form.options.length === 0 && (
                  <p className="text-xs text-muted-foreground">
                    أضف خياراً واحداً على الأقل.
                  </p>
                )}
                {form.options.map((o, i) => (
                  <div key={i} className="grid grid-cols-4 gap-2">
                    <Input
                      placeholder="value"
                      value={o.value}
                      onChange={(e) => updateOption(i, 'value', e.target.value)}
                      dir="ltr"
                      className="text-left text-xs"
                    />
                    <Input
                      placeholder="عربي"
                      value={o.labelAr}
                      onChange={(e) => updateOption(i, 'labelAr', e.target.value)}
                      className="text-xs"
                    />
                    <Input
                      placeholder="فرنسي"
                      value={o.labelFr}
                      onChange={(e) => updateOption(i, 'labelFr', e.target.value)}
                      dir="ltr"
                      className="text-left text-xs"
                    />
                    <div className="flex gap-1">
                      <Input
                        placeholder="إنجليزي"
                        value={o.labelEn}
                        onChange={(e) => updateOption(i, 'labelEn', e.target.value)}
                        dir="ltr"
                        className="text-left text-xs"
                      />
                      <Button
                        type="button"
                        size="icon"
                        variant="ghost"
                        className="text-rose-600 size-7"
                        onClick={() => removeOption(i)}
                      >
                        <X className="size-3" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            )}

            <DialogFooter>
              <Button type="submit" disabled={saving} className="bg-zinc-900 hover:bg-zinc-800">
                {saving ? <Loader2 className="size-4 animate-spin" /> : null}
                {editMode ? 'حفظ التغييرات' : 'إنشاء'}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Delete confirmation */}
      <AlertDialog open={!!deleteTarget} onOpenChange={(o) => !o && setDeleteTarget(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>حذف الحقل «{deleteTarget?.key}»؟</AlertDialogTitle>
            <AlertDialogDescription>
              إذا كانت طلبات قديمة تستعمل هذا الحقل، سيتم إخفاؤه فقط للحفاظ على بيانات الطلبات.
              لن يمكن للطلبات الجديدة رؤيته.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>إلغاء</AlertDialogCancel>
            <AlertDialogAction
              onClick={confirmDelete}
              className="bg-rose-600 hover:bg-rose-700 text-white"
            >
              حذف
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}
