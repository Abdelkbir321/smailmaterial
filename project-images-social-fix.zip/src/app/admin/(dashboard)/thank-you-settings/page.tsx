'use client'

import * as React from 'react'
import { Loader2, Save, RotateCcw, Eye, MessageCircle, Palette } from 'lucide-react'
import { toast } from 'sonner'

import { PageHeader, Spinner } from '@/components/admin/page-header'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Switch } from '@/components/ui/switch'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Separator } from '@/components/ui/separator'

interface ThankYouSettings {
  thank_you_title: string
  thank_you_message: string
  thank_you_success_text: string
  thank_you_tips: string
  thank_you_whatsapp_button_text: string
  thank_you_store_button_text: string
  thank_you_show_whatsapp_button: boolean
  thank_you_show_store_button: boolean
  thank_you_show_tips: boolean
  thank_you_whatsapp_number: string
  thank_you_whatsapp_message: string
  thank_you_bg_color: string
  thank_you_accent_color: string
}

const DEFAULTS: ThankYouSettings = {
  thank_you_title: 'شكراً على ثقتكم بنا!',
  thank_you_message: 'تم تسجيل طلبكم بنجاح. غادي يتاصل بكم فريق خدمة العملاء خلال 24 ساعة لتأكيد الطلب ومراجعة معلومات التوصيل معكم.',
  thank_you_success_text: 'تم التسجيل',
  thank_you_tips: '• سيتصل بك فريقنا خلال 24 ساعة لتأكيد الطلب.\n• سيتم تجهيز الطلب بعد تأكيد المعلومات.\n• التوصيل عادةً خلال 24–72 ساعة بعد التأكيد.',
  thank_you_whatsapp_button_text: 'تواصل عبر واتساب',
  thank_you_store_button_text: 'العودة إلى التسوق',
  thank_you_show_whatsapp_button: true,
  thank_you_show_store_button: true,
  thank_you_show_tips: true,
  thank_you_whatsapp_number: '',
  thank_you_whatsapp_message: 'السلام عليكم، بغيت نتأكد من الطلب ديالي من موقع Ismail Material.\nرقم الطلب: {order_id}\nالاسم: {customer_name}',
  thank_you_bg_color: '',
  thank_you_accent_color: '',
}

function isValidHex(v: string): boolean {
  if (!v) return true // empty = use default
  return /^#([0-9a-fA-F]{3}|[0-9a-fA-F]{6})$/.test(v)
}

export default function ThankYouSettingsPage() {
  const [loading, setLoading] = React.useState(true)
  const [saving, setSaving] = React.useState(false)
  const [settings, setSettings] = React.useState<ThankYouSettings>(DEFAULTS)

  async function load() {
    setLoading(true)
    try {
      const res = await fetch('/api/admin/visual-identity', { credentials: 'include' })
      const json = await res.json()
      if (!res.ok || !json.ok) {
        toast.error(json.error || 'فشل التحميل')
        return
      }
      const s = json.settings || {}
      setSettings({
        thank_you_title: s.thank_you_title || DEFAULTS.thank_you_title,
        thank_you_message: s.thank_you_message || DEFAULTS.thank_you_message,
        thank_you_success_text: s.thank_you_success_text || DEFAULTS.thank_you_success_text,
        thank_you_tips: s.thank_you_tips || DEFAULTS.thank_you_tips,
        thank_you_whatsapp_button_text: s.thank_you_whatsapp_button_text || DEFAULTS.thank_you_whatsapp_button_text,
        thank_you_store_button_text: s.thank_you_store_button_text || DEFAULTS.thank_you_store_button_text,
        thank_you_show_whatsapp_button: s.thank_you_show_whatsapp_button !== 'false',
        thank_you_show_store_button: s.thank_you_show_store_button !== 'false',
        thank_you_show_tips: s.thank_you_show_tips !== 'false',
        thank_you_whatsapp_number: s.thank_you_whatsapp_number || '',
        thank_you_whatsapp_message: s.thank_you_whatsapp_message || DEFAULTS.thank_you_whatsapp_message,
        thank_you_bg_color: s.thank_you_bg_color || '',
        thank_you_accent_color: s.thank_you_accent_color || '',
      })
    } catch {
      toast.error('خطأ في الشبكة')
    } finally {
      setLoading(false)
    }
  }

  React.useEffect(() => {
    load()
  }, [])

  function update<K extends keyof ThankYouSettings>(key: K, value: ThankYouSettings[K]) {
    setSettings((s) => ({ ...s, [key]: value }))
  }

  async function save() {
    // Validate colors
    if (settings.thank_you_bg_color && !isValidHex(settings.thank_you_bg_color)) {
      toast.error('لون الخلفية ليس HEX صالح')
      return
    }
    if (settings.thank_you_accent_color && !isValidHex(settings.thank_you_accent_color)) {
      toast.error('لون التمييز ليس HEX صالح')
      return
    }
    setSaving(true)
    try {
      const res = await fetch('/api/admin/visual-identity', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ settings }),
        credentials: 'include',
      })
      const json = await res.json()
      if (!res.ok || !json.ok) {
        toast.error(json.error || 'فشل الحفظ')
        return
      }
      toast.success('تم حفظ إعدادات واجهة الشكر')
    } catch {
      toast.error('خطأ في الشبكة')
    } finally {
      setSaving(false)
    }
  }

  async function reset() {
    if (!confirm('متأكد من استرجاع الإعدادات الافتراضية؟')) return
    setSettings(DEFAULTS)
    await save()
  }

  if (loading) return <Spinner />

  // Build preview WhatsApp URL
  const cleanNumber = settings.thank_you_whatsapp_number.replace(/[^\d]/g, '')
  const previewMessage = settings.thank_you_whatsapp_message
    .replace(/\{order_id\}/g, 'ORD-2026-00001')
    .replace(/\{customer_name\}/g, 'محمد العلوي')
    .replace(/\{customer_phone\}/g, '0655112233')
    .replace(/\{order_total\}/g, '175 درهم')
  const previewWaUrl = cleanNumber
    ? `https://wa.me/${cleanNumber}?text=${encodeURIComponent(previewMessage)}`
    : null

  return (
    <div className="space-y-6">
      <PageHeader
        title="إعدادات واجهة الشكر"
        description="تحكم كامل في محتوى صفحة الشكر اللي كتشوف للزبون بعد إتمام الطلب."
        breadcrumb={[{ label: 'الإدارة', href: '/admin/dashboard' }, { label: 'إعدادات واجهة الشكر' }]}
      />

      <div className="grid gap-6 lg:grid-cols-3">
        {/* === LEFT: Settings forms === */}
        <div className="lg:col-span-2 space-y-6">
          {/* Text content */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base">النصوص الرئيسية</CardTitle>
              <CardDescription>العنوان والرسالة وتأكيد النجاح.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-1.5">
                <Label htmlFor="title">العنوان الرئيسي</Label>
                <Input
                  id="title"
                  value={settings.thank_you_title}
                  onChange={(e) => update('thank_you_title', e.target.value)}
                  placeholder="شكراً على ثقتكم بنا!"
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="message">الرسالة تحت العنوان</Label>
                <Textarea
                  id="message"
                  rows={3}
                  value={settings.thank_you_message}
                  onChange={(e) => update('thank_you_message', e.target.value)}
                  placeholder="تم تسجيل طلبكم بنجاح..."
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="success_text">نص تأكيد النجاح (شارة بجانب رقم الطلب)</Label>
                <Input
                  id="success_text"
                  value={settings.thank_you_success_text}
                  onChange={(e) => update('thank_you_success_text', e.target.value)}
                  placeholder="تم التسجيل"
                />
              </div>
            </CardContent>
          </Card>

          {/* Tips */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="text-base">النصائح والتعليمات</CardTitle>
                  <CardDescription>الخطوات التالية اللي كتشوف للزبون.</CardDescription>
                </div>
                <div className="flex items-center gap-2">
                  <Label className="text-xs">إظهار</Label>
                  <Switch
                    checked={settings.thank_you_show_tips}
                    onCheckedChange={(v) => update('thank_you_show_tips', v)}
                  />
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <Textarea
                rows={5}
                value={settings.thank_you_tips}
                onChange={(e) => update('thank_you_tips', e.target.value)}
                placeholder="• سيتصل بك فريقنا خلال 24 ساعة..."
                dir="rtl"
              />
              <p className="mt-1.5 text-xs text-muted-foreground">كل سطر يبدأ بـ • يظهر كعنصر قائمة.</p>
            </CardContent>
          </Card>

          {/* WhatsApp */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="text-base flex items-center gap-2">
                    <MessageCircle className="size-4" /> زر واتساب
                  </CardTitle>
                  <CardDescription>رقم واتساب والرسالة المسبقة.</CardDescription>
                </div>
                <div className="flex items-center gap-2">
                  <Label className="text-xs">إظهار الزر</Label>
                  <Switch
                    checked={settings.thank_you_show_whatsapp_button}
                    onCheckedChange={(v) => update('thank_you_show_whatsapp_button', v)}
                  />
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-1.5">
                <Label htmlFor="wa-number">رقم واتساب (صيغة دولية بدون +)</Label>
                <Input
                  id="wa-number"
                  value={settings.thank_you_whatsapp_number}
                  onChange={(e) => update('thank_you_whatsapp_number', e.target.value)}
                  placeholder="2126XXXXXXXX"
                  dir="ltr"
                  className="text-left"
                />
                <p className="text-xs text-muted-foreground">مثال: 212655112233. النظام ينظف المسافات والرموز تلقائياً.</p>
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="wa-button-text">نص زر واتساب</Label>
                <Input
                  id="wa-button-text"
                  value={settings.thank_you_whatsapp_button_text}
                  onChange={(e) => update('thank_you_whatsapp_button_text', e.target.value)}
                  placeholder="تواصل عبر واتساب"
                />
              </div>
              <Separator />
              <div className="space-y-1.5">
                <Label htmlFor="wa-message">الرسالة المسبقة (تفتح تلقائياً في واتساب)</Label>
                <Textarea
                  id="wa-message"
                  rows={6}
                  value={settings.thank_you_whatsapp_message}
                  onChange={(e) => update('thank_you_whatsapp_message', e.target.value)}
                  placeholder="السلام عليكم، بغيت نتأكد من الطلب ديالي..."
                  dir="rtl"
                />
                <div className="rounded-md border border-blue-200 bg-blue-50 p-2.5 text-xs text-blue-800">
                  <strong>المتغيرات المتاحة:</strong>{' '}
                  <code className="bg-white px-1 rounded">{`{order_id}`}</code>{' '}
                  <code className="bg-white px-1 rounded">{`{customer_name}`}</code>{' '}
                  <code className="bg-white px-1 rounded">{`{customer_phone}`}</code>{' '}
                  <code className="bg-white px-1 rounded">{`{order_total}`}</code>
                  <br />
                  كتتعوض بالمعلومات الحقيقية ديال الطلب. إلا ما كانتش متوفرة، كتتحذف من الرسالة.
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Store button */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="text-base">زر العودة للمتجر</CardTitle>
                  <CardDescription>الزر اللي كيرجع الزبون للتسوق.</CardDescription>
                </div>
                <div className="flex items-center gap-2">
                  <Label className="text-xs">إظهار الزر</Label>
                  <Switch
                    checked={settings.thank_you_show_store_button}
                    onCheckedChange={(v) => update('thank_you_show_store_button', v)}
                  />
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-1.5">
                <Label htmlFor="store-btn">نص الزر</Label>
                <Input
                  id="store-btn"
                  value={settings.thank_you_store_button_text}
                  onChange={(e) => update('thank_you_store_button_text', e.target.value)}
                  placeholder="العودة إلى التسوق"
                />
              </div>
            </CardContent>
          </Card>

          {/* Colors */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base flex items-center gap-2">
                <Palette className="size-4" /> الألوان (اختياري)
              </CardTitle>
              <CardDescription>ألوان مخصصة لصفحة الشكر. اترك فارغ لاستعمال ألوان الموقع.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid gap-4 sm:grid-cols-2">
                <div className="space-y-1.5">
                  <Label htmlFor="bg-color">لون الخلفية</Label>
                  <div className="flex items-center gap-2">
                    <Input
                      id="bg-color"
                      value={settings.thank_you_bg_color}
                      onChange={(e) => update('thank_you_bg_color', e.target.value)}
                      placeholder="#ffffff"
                      dir="ltr"
                      className="text-left"
                    />
                    <div
                      className="size-10 rounded-md border"
                      style={{ backgroundColor: isValidHex(settings.thank_you_bg_color) && settings.thank_you_bg_color ? settings.thank_you_bg_color : '#fff' }}
                    />
                  </div>
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="accent-color">لون التمييز</Label>
                  <div className="flex items-center gap-2">
                    <Input
                      id="accent-color"
                      value={settings.thank_you_accent_color}
                      onChange={(e) => update('thank_you_accent_color', e.target.value)}
                      placeholder="#ea580c"
                      dir="ltr"
                      className="text-left"
                    />
                    <div
                      className="size-10 rounded-md border"
                      style={{ backgroundColor: isValidHex(settings.thank_you_accent_color) && settings.thank_you_accent_color ? settings.thank_you_accent_color : '#fff' }}
                    />
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* === RIGHT: Live preview === */}
        <div className="lg:col-span-1">
          <div className="sticky top-24 space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="text-base flex items-center gap-2">
                  <Eye className="size-4" /> معاينة حية
                </CardTitle>
                <CardDescription>هكذا غادي تبان واجهة الشكر للزبون.</CardDescription>
              </CardHeader>
              <CardContent>
                <div
                  className="rounded-2xl border p-4 text-center"
                  style={{
                    backgroundColor: isValidHex(settings.thank_you_bg_color) && settings.thank_you_bg_color ? settings.thank_you_bg_color : 'var(--card)',
                    color: isValidHex(settings.thank_you_accent_color) && settings.thank_you_accent_color ? settings.thank_you_accent_color : undefined,
                  }}
                  dir="rtl"
                >
                  {/* Success icon */}
                  <div className="mx-auto grid size-14 place-items-center rounded-full bg-green-100 text-green-600">
                    <svg className="h-8 w-8" fill="none" stroke="currentColor" strokeWidth={1.5} viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" d="M9 12.75L11.25 15 15 9.75M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
                  </div>
                  {/* Title */}
                  <h3 className="mt-3 font-bold text-lg" style={{ color: 'var(--foreground)' }}>
                    {settings.thank_you_title || '...'}
                  </h3>
                  {/* Message */}
                  <p className="mt-2 text-xs text-muted-foreground leading-relaxed whitespace-pre-line">
                    {settings.thank_you_message || '...'}
                  </p>
                  {/* Order number */}
                  <div className="mt-3 inline-flex items-center gap-1.5 rounded-full border bg-card px-3 py-1.5 text-xs">
                    <span className="text-muted-foreground">رقم الطلب:</span>
                    <span className="font-mono font-bold" dir="ltr">ORD-2026-00001</span>
                  </div>
                  {/* Tips */}
                  {settings.thank_you_show_tips && settings.thank_you_tips && (
                    <div className="mt-3 rounded-lg border border-amber-200 bg-amber-50 p-2.5 text-right">
                      <p className="text-xs font-semibold mb-1">الخطوات التالية</p>
                      <div className="text-xs text-muted-foreground whitespace-pre-line">
                        {settings.thank_you_tips}
                      </div>
                    </div>
                  )}
                  {/* Buttons */}
                  <div className="mt-4 flex flex-col gap-2">
                    {settings.thank_you_show_store_button && (
                      <div className="rounded-full bg-zinc-900 px-4 py-2 text-xs font-semibold text-white">
                        {settings.thank_you_store_button_text || 'العودة إلى التسوق'}
                      </div>
                    )}
                    {settings.thank_you_show_whatsapp_button && cleanNumber && (
                      <div className="rounded-full bg-green-600 px-4 py-2 text-xs font-semibold text-white">
                        {settings.thank_you_whatsapp_button_text || 'تواصل عبر واتساب'}
                      </div>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* WhatsApp link preview */}
            {previewWaUrl && (
              <Card>
                <CardHeader>
                  <CardTitle className="text-base">رابط واتساب (معاينة)</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="rounded-md bg-muted p-2 text-xs font-mono break-all" dir="ltr">
                    {previewWaUrl.slice(0, 120)}...
                  </div>
                  <a
                    href={previewWaUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="mt-2 inline-block text-xs text-green-600 hover:underline"
                  >
                    افتح الرابط للتجربة ←
                  </a>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>

      {/* Save bar */}
      <div className="sticky bottom-4 flex items-center justify-between gap-3 rounded-lg border bg-background/80 p-3 backdrop-blur">
        <Button variant="outline" size="sm" onClick={reset} disabled={saving}>
          <RotateCcw className="mr-1.5 size-3.5" /> استرجاع الافتراضي
        </Button>
        <Button onClick={save} disabled={saving} className="bg-zinc-900 hover:bg-zinc-800">
          {saving ? <Loader2 className="mr-1.5 size-4 animate-spin" /> : <Save className="mr-1.5 size-4" />}
          حفظ التغييرات
        </Button>
      </div>
    </div>
  )
}
