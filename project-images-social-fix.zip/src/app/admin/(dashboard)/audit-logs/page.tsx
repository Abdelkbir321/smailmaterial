'use client'

import * as React from 'react'
import { ScrollText, Search, Download } from 'lucide-react'
import { toast } from 'sonner'

import { timeAgoAr } from '@/lib/format'
import { PageHeader, EmptyState, Spinner } from '@/components/admin/page-header'
import { TablePagination } from '@/components/admin/table-pagination'
import { Card } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Button } from '@/components/ui/button'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'

interface AuditLog {
  id: string
  action: string
  entity: string
  entityId: string | null
  metadata: any
  ip: string | null
  createdAt: string
  adminUser: { email: string; fullName: string } | null
}

const PAGE_SIZE = 25

const ENTITY_OPTIONS = [
  { value: 'all', label: 'الكل' },
  { value: 'product', label: 'منتج' },
  { value: 'order', label: 'طلب' },
  { value: 'category', label: 'فئة' },
  { value: 'setting', label: 'إعداد' },
  { value: 'admin_user', label: 'مسؤول' },
  { value: 'social_link', label: 'رابط اجتماعي' },
  { value: 'media', label: 'وسائط' },
]

export default function AuditLogsPage() {
  const [logs, setLogs] = React.useState<AuditLog[]>([])
  const [total, setTotal] = React.useState(0)
  const [page, setPage] = React.useState(1)
  const [loading, setLoading] = React.useState(true)
  const [searchInput, setSearchInput] = React.useState('')
  const [q, setQ] = React.useState('')
  const [entity, setEntity] = React.useState('all')
  const debounceRef = React.useRef<ReturnType<typeof setTimeout> | null>(null)

  async function load(p = page, query = q, ent = entity) {
    setLoading(true)
    try {
      const params = new URLSearchParams({
        take: String(PAGE_SIZE),
        page: String(p),
      })
      if (query) params.set('q', query)
      if (ent !== 'all') params.set('entity', ent)
      const res = await fetch(`/api/admin/audit-logs?${params.toString()}`, {
        credentials: 'include',
      })
      const json = await res.json()
      if (json.ok) {
        setLogs(json.logs)
        setTotal(json.total || json.logs.length)
      } else {
        toast.error(json.error || 'خطأ')
      }
    } catch {
      toast.error('خطأ في الشبكة')
    } finally {
      setLoading(false)
    }
  }

  React.useEffect(() => {
    load(1, '', 'all')
  }, [])

  React.useEffect(() => {
    if (debounceRef.current) clearTimeout(debounceRef.current)
    debounceRef.current = setTimeout(() => {
      if (searchInput !== q) {
        setQ(searchInput)
        setPage(1)
        load(1, searchInput, entity)
      }
    }, 350)
    return () => {
      if (debounceRef.current) clearTimeout(debounceRef.current)
    }
  }, [searchInput])

  function onEntityChange(e: string) {
    setEntity(e)
    setPage(1)
    load(1, q, e)
  }

  function exportCsv() {
    if (logs.length === 0) return
    const headers = ['التاريخ', 'المسؤول', 'العملية', 'الكيان', 'المعرّف', 'IP', 'البيانات']
    const rows = logs.map((l) => [
      new Date(l.createdAt).toLocaleString('ar-MA'),
      l.adminUser?.fullName || '—',
      l.action,
      l.entity,
      l.entityId || '—',
      l.ip || '—',
      JSON.stringify(l.metadata || {}),
    ])
    const csv = [headers, ...rows]
      .map((row) => row.map((cell) => `"${String(cell).replace(/"/g, '""')}"`).join(','))
      .join('\n')
    const blob = new Blob(['\ufeff' + csv], { type: 'text/csv;charset=utf-8' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `audit-logs-${new Date().toISOString().slice(0, 10)}.csv`
    a.click()
    URL.revokeObjectURL(url)
    toast.success('تم تصدير السجلات')
  }

  return (
    <div className="space-y-4 sm:space-y-6">
      <PageHeader
        title="سجل العمليات"
        description="سجل كامل لعمليات المسؤولين."
        breadcrumb={[{ label: 'الإدارة', href: '/admin/dashboard' }, { label: 'السجل' }]}
        actions={
          <Button variant="outline" size="sm" onClick={exportCsv} disabled={logs.length === 0}>
            <Download className="size-4" />
            <span className="hidden sm:inline">تصدير CSV</span>
          </Button>
        }
      />

      {/* Filters */}
      <Card className="p-3">
        <div className="flex flex-col gap-2 sm:flex-row sm:items-center">
          <div className="relative flex-1">
            <Search className="text-muted-foreground absolute right-2.5 top-1/2 size-4 -translate-y-1/2" />
            <Input
              placeholder="ابحث في العمليات أو المعرّفات…"
              value={searchInput}
              onChange={(e) => setSearchInput(e.target.value)}
              className="pr-8"
            />
          </div>
          <Select value={entity} onValueChange={onEntityChange}>
            <SelectTrigger className="w-full sm:w-48">
              <SelectValue placeholder="كل الكيانات" />
            </SelectTrigger>
            <SelectContent>
              {ENTITY_OPTIONS.map((e) => (
                <SelectItem key={e.value} value={e.value}>{e.label}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </Card>

      {loading ? (
        <Spinner />
      ) : logs.length === 0 ? (
        <EmptyState
          title="لا توجد سجلات"
          description="ستظهر هنا عمليات الإدارة."
          icon={<ScrollText className="size-5" />}
        />
      ) : (
        <>
          {/* Desktop table */}
          <Card className="hidden md:block p-0 overflow-hidden">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="whitespace-nowrap">متى</TableHead>
                  <TableHead>المدير</TableHead>
                  <TableHead>العملية</TableHead>
                  <TableHead>الكيان</TableHead>
                  <TableHead>المعرّف</TableHead>
                  <TableHead>IP</TableHead>
                  <TableHead>البيانات</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {logs.map((l) => (
                  <TableRow key={l.id}>
                    <TableCell className="text-xs text-muted-foreground whitespace-nowrap">
                      {timeAgoAr(l.createdAt)}
                    </TableCell>
                    <TableCell className="text-sm">
                      {l.adminUser ? (
                        <div className="flex flex-col">
                          <span className="font-medium">{l.adminUser.fullName}</span>
                          <span className="text-muted-foreground text-xs" dir="ltr">{l.adminUser.email}</span>
                        </div>
                      ) : (
                        <span className="text-muted-foreground text-xs">—</span>
                      )}
                    </TableCell>
                    <TableCell>
                      <span className="font-mono text-xs" dir="ltr">{l.action}</span>
                    </TableCell>
                    <TableCell>
                      <span className="font-mono text-xs" dir="ltr">{l.entity}</span>
                    </TableCell>
                    <TableCell className="font-mono text-xs text-muted-foreground" dir="ltr">
                      {l.entityId ? l.entityId.slice(0, 8) + '…' : '—'}
                    </TableCell>
                    <TableCell className="font-mono text-xs text-muted-foreground" dir="ltr">
                      {l.ip || '—'}
                    </TableCell>
                    <TableCell className="text-xs">
                      <pre className="bg-muted rounded p-1.5 max-w-xs overflow-x-auto max-h-24" dir="ltr">
                        {JSON.stringify(l.metadata ?? {}, null, 2)}
                      </pre>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </Card>

          {/* Mobile cards */}
          <div className="md:hidden space-y-3">
            {logs.map((l) => (
              <Card key={l.id} className="p-3 space-y-1">
                <div className="flex items-center justify-between gap-2">
                  <span className="font-mono text-xs" dir="ltr">{l.action}</span>
                  <span className="text-xs text-muted-foreground">{timeAgoAr(l.createdAt)}</span>
                </div>
                <p className="text-sm font-medium">{l.adminUser?.fullName || '—'}</p>
                <p className="text-xs text-muted-foreground">
                  {l.entity} · {l.ip || '—'}
                </p>
                {l.entityId && (
                  <p className="font-mono text-[10px] text-muted-foreground" dir="ltr">{l.entityId.slice(0, 12)}…</p>
                )}
              </Card>
            ))}
          </div>

          {total > PAGE_SIZE && (
            <TablePagination
              page={page}
              pageSize={PAGE_SIZE}
              total={total}
              onPage={(p) => { setPage(p); load(p, q, entity) }}
            />
          )}
        </>
      )}
    </div>
  )
}
