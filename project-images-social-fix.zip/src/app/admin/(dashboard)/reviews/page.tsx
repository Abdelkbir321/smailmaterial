'use client'

import * as React from 'react'
import Link from 'next/link'
import { Star, Check, X, Eye, EyeOff, Trash2, Loader2, BadgeCheck, MessageSquare } from 'lucide-react'
import { toast } from 'sonner'

import { PageHeader, EmptyState, Spinner } from '@/components/admin/page-header'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Card } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription,
} from '@/components/ui/dialog'
import { TablePagination } from '@/components/admin/table-pagination'

interface ReviewItem {
  id: string
  productId: string
  productName: string
  productSlug: string
  customerName: string
  rating: number
  title: string | null
  body: string
  status: 'PENDING' | 'APPROVED' | 'REJECTED' | 'HIDDEN'
  isVerified: boolean
  orderId: string | null
  adminReply: string | null
  createdAt: string
}

const STATUSES = [
  { value: 'all', label: 'الكل' },
  { value: 'PENDING', label: 'في الانتظار' },
  { value: 'APPROVED', label: 'منشور' },
  { value: 'REJECTED', label: 'مرفوض' },
  { value: 'HIDDEN', label: 'مخفي' },
]

const STATUS_LABEL: Record<string, string> = {
  PENDING: 'في الانتظار',
  APPROVED: 'منشور',
  REJECTED: 'مرفوض',
  HIDDEN: 'مخفي',
}

const STATUS_COLOR: Record<string, string> = {
  PENDING: 'bg-amber-100 text-amber-700',
  APPROVED: 'bg-emerald-100 text-emerald-700',
  REJECTED: 'bg-rose-100 text-rose-700',
  HIDDEN: 'bg-zinc-100 text-zinc-600',
}

const PAGE_SIZE = 20

export default function AdminReviewsPage() {
  const [items, setItems] = React.useState<ReviewItem[]>([])
  const [total, setTotal] = React.useState(0)
  const [page, setPage] = React.useState(1)
  const [status, setStatus] = React.useState('all')
  const [q, setQ] = React.useState('')
  const [searchInput, setSearchInput] = React.useState('')
  const [loading, setLoading] = React.useState(true)
  const [replyTarget, setReplyTarget] = React.useState<ReviewItem | null>(null)
  const [replyText, setReplyText] = React.useState('')
  const [savingReply, setSavingReply] = React.useState(false)
  const [deleteTarget, setDeleteTarget] = React.useState<ReviewItem | null>(null)
  const [deleting, setDeleting] = React.useState(false)
  const debounceRef = React.useRef<ReturnType<typeof setTimeout> | null>(null)

  async function load(p = page, query = q, st = status) {
    setLoading(true)
    try {
      const params = new URLSearchParams({ page: String(p), pageSize: String(PAGE_SIZE) })
      if (query) params.set('q', query)
      if (st && st !== 'all') params.set('status', st)
      const res = await fetch(`/api/admin/reviews?${params.toString()}`, { credentials: 'include' })
      const json = await res.json()
      if (!res.ok || !json.ok) {
        toast.error(json.error || 'خطأ')
        return
      }
      setItems(json.items)
      setTotal(json.total)
    } catch {
      toast.error('خطأ في الشبكة')
    } finally {
      setLoading(false)
    }
  }

  React.useEffect(() => {
    load(1, '', 'all')
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  React.useEffect(() => {
    if (debounceRef.current) clearTimeout(debounceRef.current)
    debounceRef.current = setTimeout(() => {
      if (searchInput !== q) {
        setQ(searchInput)
        setPage(1)
        load(1, searchInput, status)
      }
    }, 350)
    return () => {
      if (debounceRef.current) clearTimeout(debounceRef.current)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [searchInput])

  function onStatusChange(s: string) {
    setStatus(s)
    setPage(1)
    load(1, q, s)
  }

  async function updateStatus(review: ReviewItem, newStatus: 'PENDING' | 'APPROVED' | 'REJECTED' | 'HIDDEN') {
    try {
      const res = await fetch(`/api/admin/reviews/${review.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: newStatus }),
        credentials: 'include',
      })
      const json = await res.json()
      if (!res.ok || !json.ok) {
        toast.error(json.error || 'فشل التحديث')
        return
      }
      toast.success('تم تحديث حالة التقييم')
      load()
    } catch {
      toast.error('خطأ في الشبكة')
    }
  }

  async function toggleVerified(review: ReviewItem) {
    try {
      const res = await fetch(`/api/admin/reviews/${review.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ isVerified: !review.isVerified }),
        credentials: 'include',
      })
      const json = await res.json()
      if (!res.ok || !json.ok) {
        toast.error(json.error || 'فشل التحديث')
        return
      }
      toast.success('تم تحديث شارة الشراء الموثّق')
      load()
    } catch {
      toast.error('خطأ في الشبكة')
    }
  }

  function openReply(review: ReviewItem) {
    setReplyTarget(review)
    setReplyText(review.adminReply || '')
  }

  async function saveReply() {
    if (!replyTarget) return
    setSavingReply(true)
    try {
      const res = await fetch(`/api/admin/reviews/${replyTarget.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ adminReply: replyText || null }),
        credentials: 'include',
      })
      const json = await res.json()
      if (!res.ok || !json.ok) {
        toast.error(json.error || 'فشل الحفظ')
        return
      }
      toast.success('تم حفظ الرد')
      setReplyTarget(null)
      load()
    } catch {
      toast.error('خطأ في الشبكة')
    } finally {
      setSavingReply(false)
    }
  }

  async function confirmDelete() {
    if (!deleteTarget) return
    setDeleting(true)
    try {
      const res = await fetch(`/api/admin/reviews/${deleteTarget.id}`, {
        method: 'DELETE',
        credentials: 'include',
      })
      const json = await res.json()
      if (!res.ok || !json.ok) {
        toast.error(json.error || 'فشل الحذف')
        return
      }
      toast.success('تم حذف التقييم')
      setDeleteTarget(null)
      load()
    } catch {
      toast.error('خطأ في الشبكة')
    } finally {
      setDeleting(false)
    }
  }

  return (
    <div className="space-y-4 sm:space-y-6">
      <PageHeader
        title="التقييمات"
        description="مراجعة تقييمات العملاء والموافقة عليها أو رفضها."
        breadcrumb={[{ label: 'الإدارة', href: '/admin/dashboard' }, { label: 'التقييمات' }]}
      />

      <Card className="p-3">
        <div className="flex flex-col gap-2 sm:flex-row sm:items-center">
          <Input
            placeholder="ابحث بالاسم أو التعليق…"
            value={searchInput}
            onChange={(e) => setSearchInput(e.target.value)}
            className="flex-1"
          />
          <Select value={status} onValueChange={onStatusChange}>
            <SelectTrigger className="w-full sm:w-48">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {STATUSES.map((s) => (
                <SelectItem key={s.value} value={s.value}>
                  {s.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </Card>

      {loading ? (
        <Spinner />
      ) : items.length === 0 ? (
        <EmptyState
          title="لا توجد تقييمات"
          description="ستظهر هنا تقييمات العملاء فور إرسالها."
          icon={<Star className="size-5" />}
        />
      ) : (
        <div className="space-y-3">
          {items.map((r) => (
            <Card key={r.id} className="p-4">
              <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
                <div className="flex-1 min-w-0 space-y-1.5">
                  {/* Header row */}
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="flex items-center gap-0.5">
                      {Array.from({ length: 5 }).map((_, i) => (
                        <Star
                          key={i}
                          className={i < r.rating ? 'size-3.5 text-amber-500 fill-amber-500' : 'size-3.5 text-muted-foreground/30'}
                        />
                      ))}
                    </span>
                    <span className="font-medium text-sm">{r.customerName}</span>
                    {r.isVerified && (
                      <Badge className="bg-blue-100 text-blue-700 gap-1">
                        <BadgeCheck className="size-3" /> شراء موثّق
                      </Badge>
                    )}
                    <Badge className={STATUS_COLOR[r.status]}>
                      {STATUS_LABEL[r.status]}
                    </Badge>
                    <span className="text-xs text-muted-foreground">
                      {new Date(r.createdAt).toLocaleDateString('ar-MA')}
                    </span>
                  </div>

                  {/* Product link */}
                  <Link
                    href={`/produits/${r.productSlug}`}
                    className="text-xs text-muted-foreground hover:text-foreground hover:underline"
                    target="_blank"
                  >
                    {r.productName}
                  </Link>

                  {/* Review body */}
                  {r.title && <p className="font-medium text-sm">{r.title}</p>}
                  <p className="text-sm text-muted-foreground leading-relaxed">{r.body}</p>

                  {/* Admin reply (if any) */}
                  {r.adminReply && (
                    <div className="mt-2 rounded-md bg-muted/60 p-2 text-xs">
                      <p className="font-medium text-foreground mb-0.5">رد الإدارة:</p>
                      <p className="text-muted-foreground">{r.adminReply}</p>
                    </div>
                  )}
                </div>

                {/* Actions */}
                <div className="flex flex-wrap gap-1.5 sm:flex-col">
                  {r.status !== 'APPROVED' && (
                    <Button
                      size="sm"
                      variant="outline"
                      className="bg-emerald-50 hover:bg-emerald-100 text-emerald-700 border-emerald-200"
                      onClick={() => updateStatus(r, 'APPROVED')}
                    >
                      <Check className="size-3.5" /> نشر
                    </Button>
                  )}
                  {r.status !== 'REJECTED' && (
                    <Button
                      size="sm"
                      variant="outline"
                      className="bg-rose-50 hover:bg-rose-100 text-rose-700 border-rose-200"
                      onClick={() => updateStatus(r, 'REJECTED')}
                    >
                      <X className="size-3.5" /> رفض
                    </Button>
                  )}
                  {r.status !== 'HIDDEN' ? (
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => updateStatus(r, 'HIDDEN')}
                    >
                      <EyeOff className="size-3.5" /> إخفاء
                    </Button>
                  ) : (
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => updateStatus(r, 'PENDING')}
                    >
                      <Eye className="size-3.5" /> إظهار
                    </Button>
                  )}
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => toggleVerified(r)}
                  >
                    <BadgeCheck className="size-3.5" /> {r.isVerified ? 'إزالة الشارة' : 'توثيق'}
                  </Button>
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => openReply(r)}
                  >
                    <MessageSquare className="size-3.5" /> {r.adminReply ? 'تعديل الرد' : 'رد'}
                  </Button>
                  <Button
                    size="sm"
                    variant="ghost"
                    className="text-rose-600 hover:text-rose-700"
                    onClick={() => setDeleteTarget(r)}
                  >
                    <Trash2 className="size-3.5" /> حذف
                  </Button>
                </div>
              </div>
            </Card>
          ))}

          <TablePagination
            page={page}
            pageSize={PAGE_SIZE}
            total={total}
            onPage={(p) => {
              setPage(p)
              load(p, q, status)
            }}
          />
        </div>
      )}

      {/* Reply dialog */}
      <Dialog open={!!replyTarget} onOpenChange={(o) => !o && setReplyTarget(null)}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>الرد على التقييم</DialogTitle>
            <DialogDescription>
              سيظهر ردك publicly تحت التقييم بعد نشره.
            </DialogDescription>
          </DialogHeader>
          {replyTarget && (
            <div className="rounded-md bg-muted/50 p-3 text-xs space-y-1">
              <p className="font-medium">{replyTarget.customerName} — {replyTarget.rating}★</p>
              {replyTarget.title && <p className="font-medium">{replyTarget.title}</p>}
              <p className="text-muted-foreground">{replyTarget.body}</p>
            </div>
          )}
          <Textarea
            rows={4}
            value={replyText}
            onChange={(e) => setReplyText(e.target.value)}
            placeholder="اكتب رد الإدارة هنا…"
          />
          <DialogFooter>
            <Button variant="outline" onClick={() => setReplyTarget(null)}>إلغاء</Button>
            <Button
              onClick={saveReply}
              disabled={savingReply}
              className="bg-zinc-900 hover:bg-zinc-800"
            >
              {savingReply && <Loader2 className="size-4 animate-spin" />}
              حفظ الرد
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete confirmation */}
      <Dialog open={!!deleteTarget} onOpenChange={(o) => !o && setDeleteTarget(null)}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>حذف التقييم نهائياً؟</DialogTitle>
            <DialogDescription>
              لا يمكن التراجع. يُفضّل استعمال «إخفاء» للحفاظ على سجل التقييم.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDeleteTarget(null)}>إلغاء</Button>
            <Button
              variant="destructive"
              onClick={confirmDelete}
              disabled={deleting}
            >
              {deleting && <Loader2 className="size-4 animate-spin" />}
              حذف نهائي
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
