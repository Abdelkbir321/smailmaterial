'use client'

import * as React from 'react'
import { Globe, Search, Loader2, CheckCircle2, X } from 'lucide-react'
import { toast } from 'sonner'

import { PageHeader, EmptyState, Spinner } from '@/components/admin/page-header'
import { TablePagination } from '@/components/admin/table-pagination'
import { Input } from '@/components/ui/input'
import { Switch } from '@/components/ui/switch'
import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'
import { Checkbox } from '@/components/ui/checkbox'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select'
import {
  Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle,
} from '@/components/ui/dialog'

interface Country {
  id: string
  code: string
  name: string
  nameAr: string | null
  isEnabled: boolean
  isDefault: boolean
  currencyCode: string
  currencySymbol: string
  phonePrefix: string
  shippingBase: string | number
  shippingPerKg: string | number
  taxRate: string | number
  sortOrder: number
}

const PAGE_SIZE = 50

export default function AdminCountriesPage() {
  const [items, setItems] = React.useState<Country[]>([])
  const [loading, setLoading] = React.useState(true)
  const [searchInput, setSearchInput] = React.useState('')
  const [q, setQ] = React.useState('')
  const [filter, setFilter] = React.useState<'all' | 'enabled' | 'disabled'>('all')
  const [page, setPage] = React.useState(1)
  const [selected, setSelected] = React.useState<Set<string>>(new Set())
  const [bulkOpen, setBulkOpen] = React.useState(false)
  const [bulkAction, setBulkAction] = React.useState<'enable' | 'disable' | 'setCurrency'>('enable')
  const [bulkCurrency, setBulkCurrency] = React.useState('')
  const [bulkSaving, setBulkSaving] = React.useState(false)
  const debounceRef = React.useRef<ReturnType<typeof setTimeout> | null>(null)

  async function load() {
    setLoading(true)
    try {
      const res = await fetch('/api/admin/countries', { credentials: 'include' })
      const json = await res.json()
      if (json.ok) setItems(json.countries)
    } catch {
      toast.error('خطأ في الشبكة')
    } finally {
      setLoading(false)
    }
  }

  React.useEffect(() => { load() }, [])

  React.useEffect(() => {
    if (debounceRef.current) clearTimeout(debounceRef.current)
    debounceRef.current = setTimeout(() => {
      setQ(searchInput)
      setPage(1)
    }, 300)
    return () => { if (debounceRef.current) clearTimeout(debounceRef.current) }
  }, [searchInput])

  // Filter + search
  const filtered = React.useMemo(() => {
    let result = items
    if (filter === 'enabled') result = result.filter(c => c.isEnabled)
    if (filter === 'disabled') result = result.filter(c => !c.isEnabled)
    if (q) {
      const ql = q.toLowerCase()
      result = result.filter(c =>
        c.name.toLowerCase().includes(ql) ||
        c.code.toLowerCase().includes(ql) ||
        c.currencyCode.toLowerCase().includes(ql) ||
        (c.nameAr || '').includes(q)
      )
    }
    return result
  }, [items, q, filter])

  const paginated = React.useMemo(() => {
    const start = (page - 1) * PAGE_SIZE
    return filtered.slice(start, start + PAGE_SIZE)
  }, [filtered, page])

  const allOnPageSelected = paginated.length > 0 && paginated.every(c => selected.has(c.id))

  function toggleSelect(id: string) {
    setSelected(prev => {
      const next = new Set(prev)
      if (next.has(id)) next.delete(id)
      else next.add(id)
      return next
    })
  }

  function selectAllOnPage() {
    setSelected(new Set(paginated.map(c => c.id)))
  }

  function selectAllFiltered() {
    setSelected(new Set(filtered.map(c => c.id)))
  }

  function clearSelection() {
    setSelected(new Set())
  }

  async function patch(id: string, data: Partial<Country>) {
    try {
      const res = await fetch('/api/admin/countries', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id, ...data }),
        credentials: 'include',
      })
      const json = await res.json()
      if (!res.ok || !json.ok) {
        toast.error(json.error || 'فشل')
        return
      }
      toast.success('تم تحديث الدولة')
      load()
    } catch {
      toast.error('خطأ في الشبكة')
    }
  }

  async function confirmBulk() {
    if (selected.size === 0 || bulkSaving) return
    setBulkSaving(true)
    try {
      const res = await fetch('/api/admin/countries/bulk', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ids: Array.from(selected),
          action: bulkAction,
          currencyCode: bulkAction === 'setCurrency' ? bulkCurrency : undefined,
        }),
        credentials: 'include',
      })
      const json = await res.json()
      if (!res.ok || !json.ok) {
        toast.error(json.error || 'فشل')
        return
      }
      toast.success(`تم تحديث ${json.updated} دولة`)
      setBulkOpen(false)
      clearSelection()
      load()
    } catch {
      toast.error('خطأ في الشبكة')
    } finally {
      setBulkSaving(false)
    }
  }

  // Unique currencies for the bulk currency selector
  const currencies = React.useMemo(() => {
    const set = new Set(items.map(c => `${c.currencyCode}|${c.currencySymbol}`))
    return Array.from(set).map(s => {
      const [code, sym] = s.split('|')
      return { code, sym }
    }).sort((a, b) => a.code.localeCompare(b.code))
  }, [items])

  return (
    <div className="space-y-4 sm:space-y-6">
      <PageHeader
        title="الدول والعملات"
        description="فعّل الدول التي تشحن إليها."
        breadcrumb={[{ label: 'الإدارة', href: '/admin/dashboard' }, { label: 'الدول' }]}
      />

      {/* Search + Filter */}
      <Card className="p-3">
        <div className="flex flex-col gap-2 sm:flex-row sm:items-center">
          <div className="relative flex-1">
            <Search className="text-muted-foreground absolute right-2.5 top-1/2 size-4 -translate-y-1/2" />
            <Input
              placeholder="ابحث باسم الدولة أو الرمز أو العملة…"
              value={searchInput}
              onChange={(e) => setSearchInput(e.target.value)}
              className="pr-8"
            />
          </div>
          <Select value={filter} onValueChange={(v) => { setFilter(v as any); setPage(1) }}>
            <SelectTrigger className="w-full sm:w-40">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">الكل</SelectItem>
              <SelectItem value="enabled">مفعّلة</SelectItem>
              <SelectItem value="disabled">موقوفة</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </Card>

      {/* Bulk actions bar */}
      {selected.size > 0 && (
        <Card className="p-3 border-primary/30 bg-primary/5">
          <div className="flex flex-wrap items-center gap-2">
            <span className="text-sm font-medium">{selected.size} محدد</span>
            <div className="flex flex-wrap gap-2 mr-auto">
              <Button size="sm" variant="outline" onClick={() => { setBulkAction('enable'); setBulkOpen(true) }}>
                <CheckCircle2 className="size-4" /> تفعيل
              </Button>
              <Button size="sm" variant="outline" onClick={() => { setBulkAction('disable'); setBulkOpen(true) }}>
                <X className="size-4" /> إيقاف
              </Button>
              <Button size="sm" variant="outline" onClick={() => { setBulkAction('setCurrency'); setBulkOpen(true) }}>
                <Globe className="size-4" /> تغيير العملة
              </Button>
              <Button size="sm" variant="ghost" onClick={clearSelection}>
                <X className="size-4" /> إلغاء
              </Button>
            </div>
          </div>
        </Card>
      )}

      {loading ? (
        <Spinner />
      ) : filtered.length === 0 ? (
        <EmptyState
          title="لا توجد دول"
          description={q ? 'لا نتائج مطابقة.' : 'أضف دولاً من قاعدة البيانات.'}
          icon={<Globe className="size-5" />}
        />
      ) : (
        <>
          {/* Select all bar */}
          <div className="flex items-center gap-3 text-xs text-muted-foreground">
            <Checkbox
              checked={allOnPageSelected}
              onCheckedChange={() => allOnPageSelected ? clearSelection() : selectAllOnPage()}
            />
            <button onClick={selectAllOnPage} className="hover:text-foreground">
              تحديد الكل في هاد الصفحة ({paginated.length})
            </button>
            <span>·</span>
            <button onClick={selectAllFiltered} className="hover:text-foreground">
              تحديد جميع النتائج ({filtered.length})
            </button>
            {selected.size > 0 && (
              <>
                <span>·</span>
                <button onClick={clearSelection} className="hover:text-foreground text-rose-600">
                  إلغاء التحديد
                </button>
              </>
            )}
          </div>

          {/* Desktop table */}
          <Card className="hidden md:block p-0 overflow-hidden">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-10"></TableHead>
                  <TableHead>الدولة</TableHead>
                  <TableHead>الرمز</TableHead>
                  <TableHead>العملة</TableHead>
                  <TableHead>البادئة</TableHead>
                  <TableHead>الشحن</TableHead>
                  <TableHead>الضريبة (%)</TableHead>
                  <TableHead>مفعّل</TableHead>
                  <TableHead>افتراضي</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {paginated.map((c) => (
                  <TableRow key={c.id}>
                    <TableCell>
                      <Checkbox
                        checked={selected.has(c.id)}
                        onCheckedChange={() => toggleSelect(c.id)}
                      />
                    </TableCell>
                    <TableCell className="font-medium">
                      {c.name}
                      {c.nameAr && <span className="text-muted-foreground text-xs mr-2">({c.nameAr})</span>}
                    </TableCell>
                    <TableCell className="font-mono text-xs">{c.code}</TableCell>
                    <TableCell>{c.currencyCode} ({c.currencySymbol})</TableCell>
                    <TableCell className="text-sm" dir="ltr">{c.phonePrefix}</TableCell>
                    <TableCell>
                      <Input
                        defaultValue={String(c.shippingBase ?? '0')}
                        className="h-8 w-24"
                        onBlur={(e) => {
                          const v = Number(e.target.value)
                          if (!Number.isNaN(v) && v !== Number(c.shippingBase)) {
                            patch(c.id, { shippingBase: v as any })
                          }
                        }}
                      />
                    </TableCell>
                    <TableCell>
                      <Input
                        defaultValue={String(c.taxRate ?? '0')}
                        className="h-8 w-16"
                        onBlur={(e) => {
                          const v = Number(e.target.value)
                          if (!Number.isNaN(v) && v !== Number(c.taxRate)) {
                            patch(c.id, { taxRate: v as any })
                          }
                        }}
                      />
                    </TableCell>
                    <TableCell>
                      <Switch
                        checked={c.isEnabled}
                        onCheckedChange={(v) => patch(c.id, { isEnabled: v as any })}
                      />
                    </TableCell>
                    <TableCell>
                      <Switch
                        checked={c.isDefault}
                        onCheckedChange={(v) => { if (v) patch(c.id, { isDefault: true as any }) }}
                      />
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </Card>

          {/* Mobile cards */}
          <div className="md:hidden space-y-3">
            {paginated.map((c) => (
              <Card key={c.id} className="p-3">
                <div className="flex items-start gap-3">
                  <Checkbox
                    checked={selected.has(c.id)}
                    onCheckedChange={() => toggleSelect(c.id)}
                  />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-2">
                      <span className="font-medium truncate">{c.name}</span>
                      <span className="font-mono text-xs">{c.code}</span>
                    </div>
                    <p className="text-xs text-muted-foreground">
                      {c.currencyCode} ({c.currencySymbol}) · {c.phonePrefix}
                    </p>
                    <div className="flex items-center gap-3 mt-2">
                      <label className="flex items-center gap-1 text-xs">
                        <Switch
                          checked={c.isEnabled}
                          onCheckedChange={(v) => patch(c.id, { isEnabled: v as any })}
                        />
                        {c.isEnabled ? 'مفعّلة' : 'موقوفة'}
                      </label>
                      {c.isDefault && <span className="text-xs text-emerald-700 font-medium">افتراضية</span>}
                    </div>
                  </div>
                </div>
              </Card>
            ))}
          </div>

          {filtered.length > PAGE_SIZE && (
            <TablePagination
              page={page}
              pageSize={PAGE_SIZE}
              total={filtered.length}
              onPage={setPage}
            />
          )}
        </>
      )}

      {/* Bulk confirmation dialog */}
      <Dialog open={bulkOpen} onOpenChange={setBulkOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>
              {bulkAction === 'enable' && `تفعيل ${selected.size} دولة`}
              {bulkAction === 'disable' && `إيقاف ${selected.size} دولة`}
              {bulkAction === 'setCurrency' && `تغيير عملة ${selected.size} دولة`}
            </DialogTitle>
            <DialogDescription>
              {bulkAction === 'enable' && 'سيتم تفعيل الشحن لجميع الدول المحددة. يمكن للزبناء اختيار هذه الدول عند الطلب.'}
              {bulkAction === 'disable' && 'سيتم إيقاف الشحن لجميع الدول المحددة. لن يمكن للزبناء اختيار هذه الدول. الطلبات القديمة لن تتأثر.'}
              {bulkAction === 'setCurrency' && 'اختر العملة التي تريد تطبيقها على الدول المحددة.'}
            </DialogDescription>
          </DialogHeader>
          {bulkAction === 'setCurrency' && (
            <Select value={bulkCurrency} onValueChange={setBulkCurrency}>
              <SelectTrigger>
                <SelectValue placeholder="اختر العملة" />
              </SelectTrigger>
              <SelectContent>
                {currencies.map(cur => (
                  <SelectItem key={cur.code} value={cur.code}>
                    {cur.code} ({cur.sym})
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setBulkOpen(false)}>إلغاء</Button>
            <Button
              onClick={confirmBulk}
              disabled={bulkSaving || (bulkAction === 'setCurrency' && !bulkCurrency)}
              className="bg-zinc-900 hover:bg-zinc-800"
            >
              {bulkSaving && <Loader2 className="size-4 animate-spin" />}
              تأكيد
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
