'use client'

import * as React from 'react'
import { Loader2, Save, Upload, Globe, ImageIcon, AlertTriangle, RotateCcw, Check } from 'lucide-react'
import { toast } from 'sonner'

import { PageHeader, Spinner } from '@/components/admin/page-header'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'

const ALLOWED_FAVICON_TYPES = ['image/png', 'image/x-icon', 'image/vnd.microsoft.icon', 'image/svg+xml', 'image/webp', 'image/jpeg']
const MAX_FAVICON_SIZE = 2 * 1024 * 1024

export default function TabLogoPage() {
  const [loading, setLoading] = React.useState(true)
  const [saving, setSaving] = React.useState(false)
  const [faviconUrl, setFaviconUrl] = React.useState<string | null>(null)
  const [favUploading, setFavUploading] = React.useState(false)
  const [favExternalUrl, setFavExternalUrl] = React.useState('')
  const [favExternalPreview, setFavExternalPreview] = React.useState<string | null>(null)
  const [favExternalError, setFavExternalError] = React.useState<string | null>(null)
  const [cloudinaryConfigured, setCloudinaryConfigured] = React.useState(true)
  const favFileRef = React.useRef<HTMLInputElement>(null)

  async function load() {
    setLoading(true)
    try {
      const res = await fetch('/api/admin/visual-identity', { credentials: 'include' })
      const json = await res.json()
      if (!res.ok || !json.ok) {
        toast.error(json.error || 'فشل التحميل')
        return
      }
      setFaviconUrl(json.settings?.favicon_url || null)
      setCloudinaryConfigured(!!json.cloudinaryConfigured)
    } catch {
      toast.error('خطأ في الشبكة')
    } finally {
      setLoading(false)
    }
  }

  React.useEffect(() => {
    load()
  }, [])

  async function uploadFavicon(file: File) {
    if (!ALLOWED_FAVICON_TYPES.includes(file.type)) {
      toast.error(`صيغة غير مدعومة. المسموح: PNG, ICO, SVG, WebP, JPG`)
      return
    }
    if (file.size > MAX_FAVICON_SIZE) {
      toast.error(`حجم الملف كبير جداً. الحد الأقصى: ${MAX_FAVICON_SIZE / 1024 / 1024} MB`)
      return
    }
    setFavUploading(true)
    try {
      const formData = new FormData()
      formData.append('file', file)
      const res = await fetch('/api/admin/upload', {
        method: 'POST',
        body: formData,
        credentials: 'include',
      })
      const json = await res.json()
      if (!res.ok || !json.ok) {
        toast.error(json.error || 'فشل رفع الأيقونة')
        return
      }
      const secureUrl = json.asset?.secureUrl || json.image?.secureUrl
      if (!secureUrl) {
        toast.error('لم يرجع الخادم رابط الأيقونة')
        return
      }
      // Save favicon URL (auto-bumps favicon_cache_bust server-side)
      const putRes = await fetch('/api/admin/visual-identity', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ settings: { favicon_url: secureUrl } }),
        credentials: 'include',
      })
      const putJson = await putRes.json()
      if (!putRes.ok || !putJson.ok) {
        toast.error(putJson.error || 'فشل حفظ الأيقونة')
        return
      }
      setFaviconUrl(secureUrl)
      setFavExternalUrl('')
      setFavExternalPreview(null)
      setFavExternalError(null)
      toast.success('تم رفع أيقونة التبويب وحفظها — ستظهر في تبويب المتصفح')
    } catch {
      toast.error('خطأ في الشبكة')
    } finally {
      setFavUploading(false)
      if (favFileRef.current) favFileRef.current.value = ''
    }
  }

  async function saveFaviconExternal() {
    const url = favExternalUrl.trim()
    if (!url) { toast.error('أدخل رابط الأيقونة'); return }
    if (!/^https?:\/\/[^\s]+$/.test(url) && !url.startsWith('/')) {
      setFavExternalError('الرابط غير صالح (يجب أن يبدأ بـ http(s):// أو /)')
      return
    }
    setFavExternalError(null)
    setSaving(true)
    try {
      const res = await fetch('/api/admin/visual-identity', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ settings: { favicon_url: url } }),
        credentials: 'include',
      })
      const json = await res.json()
      if (!res.ok || !json.ok) { toast.error(json.error || 'فشل الحفظ'); return }
      setFaviconUrl(url)
      setFavExternalUrl('')
      setFavExternalPreview(null)
      toast.success('تم حفظ أيقونة التبويب — ستظهر في تبويب المتصفح')
    } catch {
      toast.error('خطأ في الشبكة')
    } finally {
      setSaving(false)
    }
  }

  async function removeFavicon() {
    if (!confirm('متأكد من إزالة أيقونة التبويب؟ ستعود الأيقونة الافتراضية.')) return
    setSaving(true)
    try {
      const res = await fetch('/api/admin/visual-identity', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ settings: { favicon_url: '' } }),
        credentials: 'include',
      })
      const json = await res.json()
      if (!res.ok || !json.ok) { toast.error(json.error || 'فشل الحذف'); return }
      setFaviconUrl(null)
      setFavExternalUrl('')
      setFavExternalPreview(null)
      toast.success('تم إزالة الأيقونة — ستعود الأيقونة الافتراضية')
    } catch {
      toast.error('خطأ في الشبكة')
    } finally {
      setSaving(false)
    }
  }

  if (loading) return <Spinner />

  return (
    <div className="space-y-6">
      <PageHeader
        title="لوغو التبويب"
        description="الأيقونة التي تظهر في تبويب المتصفح بجانب اسم الموقع. تتحكم فيها بشكل كامل من هنا — لا حاجة لتعديل الكود."
        breadcrumb={[{ label: 'الإدارة', href: '/admin/dashboard' }, { label: 'لوغو التبويب' }]}
      />

      {!cloudinaryConfigured && (
        <div className="bg-amber-50 border border-amber-200 rounded-lg p-4 flex items-start gap-3">
          <AlertTriangle className="size-5 text-amber-700 mt-0.5 shrink-0" />
          <div className="space-y-1">
            <p className="text-sm font-medium text-amber-800">Cloudinary غير مهيأ</p>
            <p className="text-xs text-amber-700">
              عيّن CLOUDINARY_CLOUD_NAME، CLOUDINARY_API_KEY، CLOUDINARY_API_SECRET في Environment Variables لتفعيل رفع الصور من الجهاز.
              يمكنك مؤقتاً استعمال روابط خارجية مباشرة.
            </p>
          </div>
        </div>
      )}

      {/* Current favicon preview */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <ImageIcon className="size-4" /> الأيقونة الحالية
          </CardTitle>
          <CardDescription>
            هذه الأيقونة تظهر في تبويب المتصفح للزوار. حالياً: {faviconUrl ? 'مخصصة' : 'افتراضية'}.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center gap-4 rounded-lg border border-border p-4 bg-muted/30">
            <div className="relative grid size-16 place-items-center rounded-lg bg-card shadow-[var(--shadow-xs)]">
              {faviconUrl ? (
                <img src={faviconUrl} alt="Current favicon" className="size-10 object-contain" />
              ) : (
                <img src="/logo.svg" alt="Default favicon" className="size-10 object-contain" />
              )}
            </div>
            <div className="flex-1 min-w-0">
              <div className="text-xs font-medium uppercase tracking-wide text-muted-foreground">الحالي</div>
              {faviconUrl ? (
                <a href={faviconUrl} target="_blank" rel="noopener noreferrer" className="block truncate text-sm font-mono hover:underline" dir="ltr">
                  {faviconUrl}
                </a>
              ) : (
                <div className="text-sm text-muted-foreground">الأيقونة الافتراضية (/logo.svg + ملفات PNG/ICO ثابتة)</div>
              )}
            </div>
            {faviconUrl && (
              <Button variant="outline" size="sm" onClick={removeFavicon} disabled={saving}>
                <RotateCcw className="mr-1.5 size-3.5" /> إزالة
              </Button>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Upload from computer */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">رفع أيقونة من الجهاز</CardTitle>
          <CardDescription>ارفع صورة مباشرة من حاسوبك. يُفضل PNG مربعة (16×16، 32×32، أو 180×180).</CardDescription>
        </CardHeader>
        <CardContent>
          <div
            onClick={() => favFileRef.current?.click()}
            className="border-2 border-dashed rounded-lg p-6 text-center cursor-pointer hover:bg-muted/50 transition-colors"
          >
            <input
              ref={favFileRef}
              type="file"
              accept={ALLOWED_FAVICON_TYPES.join(',')}
              className="hidden"
              onChange={(e) => {
                const f = e.target.files?.[0]
                if (f) uploadFavicon(f)
              }}
            />
            {favUploading ? (
              <div className="flex flex-col items-center gap-2 text-muted-foreground">
                <Loader2 className="size-6 animate-spin" />
                <p className="text-sm">جارٍ الرفع…</p>
              </div>
            ) : (
              <div className="flex flex-col items-center gap-2 text-muted-foreground">
                <Upload className="size-6" />
                <p className="text-sm font-medium">اضغط لاختيار ملف الأيقونة</p>
                <p className="text-xs">PNG, ICO, SVG, WebP, JPG — حد أقصى 2MB</p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* External URL */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">رابط مباشر للأيقونة</CardTitle>
          <CardDescription>أدخل رابط صورة مباشر من أي خدمة استضافة صور.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-1.5">
            <Label htmlFor="fav-url">رابط الأيقونة (Image URL)</Label>
            <div className="grid gap-2 sm:grid-cols-2">
              <Input
                id="fav-url"
                placeholder="https://example.com/favicon.png"
                value={favExternalUrl}
                onChange={(e) => {
                  setFavExternalUrl(e.target.value)
                  setFavExternalPreview(null)
                  setFavExternalError(null)
                }}
                dir="ltr"
                className="text-left"
              />
              <div className="flex gap-2">
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => {
                    const url = favExternalUrl.trim()
                    if (!url) { toast.error('أدخل رابط الأيقونة أولاً'); return }
                    if (!/^https?:\/\/[^\s]+$/.test(url) && !url.startsWith('/')) {
                      setFavExternalError('الرابط غير صالح')
                      return
                    }
                    setFavExternalError(null)
                    setFavExternalPreview(url)
                  }}
                  disabled={!favExternalUrl}
                >
                  <Globe className="size-4" /> معاينة
                </Button>
                <Button
                  type="button"
                  size="sm"
                  onClick={saveFaviconExternal}
                  disabled={saving || !favExternalUrl}
                  className="bg-zinc-900 hover:bg-zinc-800"
                >
                  {saving ? <Loader2 className="size-4 animate-spin" /> : <Save className="size-4" />} حفظ
                </Button>
              </div>
            </div>
            {favExternalError && <p className="mt-1.5 text-xs text-rose-600">{favExternalError}</p>}
            {favExternalPreview && (
              <div className="mt-2 inline-block bg-white border rounded-md p-3">
                {favExternalError ? (
                  <p className="text-rose-600 text-xs p-2">الرابط غير صالح أو تعذر تحميل الصورة.</p>
                ) : (
                  <img
                    src={favExternalPreview}
                    alt="معاينة الأيقونة"
                    className="size-16 object-contain"
                    onError={() => setFavExternalError('تعذر تحميل الصورة — تأكد من صحة الرابط وأن الصورة متاحة للوصول العام.')}
                  />
                )}
              </div>
            )}
          </div>

          <div className="rounded-md border border-blue-200 bg-blue-50 p-3 text-xs text-blue-800">
            <strong>ملاحظة حول التخزين المؤقت:</strong> المتصفحات تخزن الأيقونات بشراهة. عند حفظ أيقونة جديدة، يضيف النظام تلقائياً معامل عشوائي للرابط (cache busting) لإجبار المتصفح على تحميل النسخة الجديدة. إذا لم تتغير الأيقونة فوراً، اضغط Ctrl+Shift+R (أو Cmd+Shift+R على Mac) لتحديث قسري.
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
