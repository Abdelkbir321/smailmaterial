'use client'

import * as React from 'react'
import Link from 'next/link'
import {
  ShoppingCart, Package, AlertTriangle, Banknote, Clock, CheckCircle2,
  XCircle, Truck, Loader2, Users, Eye, TrendingUp, TrendingDown,
  Globe, Smartphone, Monitor, Tablet, RefreshCw, Activity, Star,
} from 'lucide-react'
import {
  ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip,
  CartesianGrid, Cell, PieChart, Pie, Legend,
} from 'recharts'

import { formatPrice, timeAgoAr } from '@/lib/format'
import { Spinner } from '@/components/admin/page-header'
import { OrderStatusBadge } from '@/components/admin/status-badge'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select'

// ─── Types ────────────────────────────────────────────────────────
interface Stat {
  current: number
  previous: number | null
  change: number | null
}

interface DashboardData {
  period: {
    current: { from: string; to: string; label: string }
    previous: { from: string; to: string; label: string }
  }
  lastUpdated: string
  stats: {
    orders: Stat
    newOrders: Stat
    confirmedOrders: Stat
    deliveredOrders: Stat
    cancelledOrders: Stat
    sales: Stat
    deliveredSales: Stat
    visitors: Stat
    sessions: Stat
    newVisitors: Stat
    returningVisitors: Stat
    productViews: Stat
    totalEvents: Stat
    conversionRate: Stat
  }
  breakdowns: {
    countries: Array<{ country: string; sessions: number; percentage: number }>
    trafficSources: Array<{ source: string; visits: number; percentage: number }>
    devices: Array<{ device: string; visits: number; percentage: number }>
    topViewedProducts: Array<{ name: string; slug: string; views: number }>
  }
  activity: {
    recentOrders: Array<{
      id: string; number: string; customerFullName: string; status: string
      total: number; placedAt: string; country: string | null
    }>
    bestSellers: Array<{
      id: string; name: string; slug: string; salesCount: number
      stockQuantity: number; price: number; mainImage: string | null
    }>
  }
  inventory: { totalProducts: number; lowStockProducts: number }
  integrations: {
    ga4: { connected: boolean; measurementId: string | null }
    gsc: { connected: boolean; siteUrl: string | null }
    pagespeed: { connected: boolean }
    cloudinary: { connected: boolean }
  }
}

const PERIOD_OPTIONS = [
  { value: 'today', label: "اليوم" },
  { value: 'yesterday', label: "البارح" },
  { value: '7d', label: "آخر 7 أيام" },
  { value: '30d', label: "آخر 30 يوم" },
  { value: 'this_month', label: "هاد الشهر" },
  { value: 'last_month', label: "الشهر الماضي" },
]

const STATUS_LABELS: Record<string, string> = {
  NEW: 'جديدة', CONTACTED: 'تم التواصل', CONFIRMED: 'مؤكدة',
  PROCESSING: 'قيد التحضير', SHIPPED: 'تم الشحن', DELIVERED: 'تم التسليم',
  CANCELLED: 'ملغاة', RETURNED: 'مُعادة', UNREACHABLE: 'غير قابلة للوصول',
}

const TRAFFIC_LABELS: Record<string, string> = {
  direct: 'مباشر', organic_search: 'بحث عضوي', paid_search: 'بحث مدفوع',
  organic_social: 'سوشيال عضوي', paid_social: 'سوشيال مدفوع',
  referral: 'محيل', email: 'إيميل', other: 'أخرى', unknown: 'غير معروف',
}

const DEVICE_LABELS: Record<string, string> = {
  desktop: 'كمبيوتر', mobile: 'هاتف', tablet: 'لوحية', bot: 'بوت', unknown: 'غير معروف',
}

const COUNTRY_NAMES: Record<string, string> = {
  MA: 'المغرب', DZ: 'الجزائر', TN: 'تونس', LY: 'ليبيا', FR: 'فرنسا',
  ES: 'إسبانيا', US: 'أمريكا', DE: 'ألمانيا', GB: 'بريطانيا', BE: 'بلجيكا',
  NL: 'هولندا', IT: 'إيطاليا', SA: 'السعودية', AE: 'الإمارات', QA: 'قطر',
}

// ─── Helpers ──────────────────────────────────────────────────────
function ChangeBadge({ change }: { change: number | null }) {
  if (change === null) return <span className="text-xs text-muted-foreground">—</span>
  const positive = change >= 0
  return (
    <span className={`inline-flex items-center gap-0.5 text-xs font-medium ${positive ? 'text-emerald-600' : 'text-rose-600'}`}>
      {positive ? <TrendingUp className="size-3" /> : <TrendingDown className="size-3" />}
      {positive ? '+' : ''}{change}%
    </span>
  )
}

function countryName(code: string): string {
  if (code === 'Inconnu' || code === 'Unknown' || !code) return 'غير معروف'
  return COUNTRY_NAMES[code] || code
}

const PIE_COLORS = ['#B23A0E', '#9A6A1E', '#15803D', '#1d4ed8', '#7c3aed', '#dc2626', '#0891b2', '#ca8a04']

export default function DashboardPage() {
  const [data, setData] = React.useState<DashboardData | null>(null)
  const [loading, setLoading] = React.useState(true)
  const [refreshing, setRefreshing] = React.useState(false)
  const [period, setPeriod] = React.useState('7d')

  async function load(p = period) {
    setRefreshing(true)
    try {
      const res = await fetch(`/api/admin/dashboard?period=${p}`, { credentials: 'include' })
      const json = await res.json()
      if (json.ok) setData(json)
    } catch {
      // ignore
    } finally {
      setLoading(false)
      setRefreshing(false)
    }
  }

  React.useEffect(() => {
    load()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  function onPeriodChange(p: string) {
    setPeriod(p)
    load(p)
  }

  if (loading || !data) {
    return (
      <div className="space-y-6">
        <h1 className="text-2xl font-semibold">الرئيسية</h1>
        <Spinner />
      </div>
    )
  }

  const s = data.stats
  const currency = { code: 'MAD', symbol: 'DH' }

  return (
    <div className="space-y-6">
      {/* ─── Header + period filter ─── */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight">لوحة التحكم</h1>
          <p className="text-sm text-muted-foreground mt-1">
            {data.period.current.label} · آخر تحديث: {new Date(data.lastUpdated).toLocaleString('ar-MA')}
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Select value={period} onValueChange={onPeriodChange}>
            <SelectTrigger className="w-[160px]">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {PERIOD_OPTIONS.map((p) => (
                <SelectItem key={p.value} value={p.value}>{p.label}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Button variant="outline" size="icon" onClick={() => load()} disabled={refreshing}>
            {refreshing ? <Loader2 className="size-4 animate-spin" /> : <RefreshCw className="size-4" />}
          </Button>
        </div>
      </div>

      {/* ─── Integration status badges ─── */}
      <div className="flex flex-wrap gap-2">
        <IntegrationBadge label="GA4" connected={data.integrations.ga4.connected} />
        <IntegrationBadge label="Search Console" connected={data.integrations.gsc.connected} />
        <IntegrationBadge label="PageSpeed" connected={data.integrations.pagespeed.connected} />
        <IntegrationBadge label="Cloudinary" connected={data.integrations.cloudinary.connected} />
      </div>

      {/* ─── KPI cards ─── */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <KpiCard
          icon={Banknote}
          label="المبيعات (مؤكدة)"
          value={formatPrice(s.sales.current, currency)}
          change={s.sales.change}
          sub="CONFIRMED+SHIPPED+DELIVERED"
          color="text-emerald-600"
        />
        <KpiCard
          icon={CheckCircle2}
          label="إيرادات مسلّمة"
          value={formatPrice(s.deliveredSales.current, currency)}
          change={s.deliveredSales.change}
          sub="DELIVERED فقط"
          color="text-blue-600"
        />
        <KpiCard
          icon={ShoppingCart}
          label="الطلبات"
          value={String(s.orders.current)}
          change={s.orders.change}
          sub={`vs ${s.orders.previous ?? '—'}`}
          color="text-amber-600"
        />
        <KpiCard
          icon={Users}
          label="الزوار"
          value={String(s.visitors.current)}
          change={s.visitors.change}
          sub={`${s.sessions.current} جلسة`}
          color="text-purple-600"
        />
      </div>

      {/* ─── Secondary KPIs ─── */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <MiniStat label="طلبات جديدة" value={s.newOrders.current} icon={Clock} color="text-blue-600" />
        <MiniStat label="مؤكدة" value={s.confirmedOrders.current} icon={CheckCircle2} color="text-emerald-600" />
        <MiniStat label="ملغاة" value={s.cancelledOrders.current} icon={XCircle} color="text-rose-600" />
        <MiniStat label="مسلّمة" value={s.deliveredOrders.current} icon={Truck} color="text-indigo-600" />
      </div>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <MiniStat label="مشاهدات المنتجات" value={s.productViews.current} change={s.productViews.change} icon={Eye} color="text-cyan-600" />
        <MiniStat label="زوار جدد" value={s.newVisitors.current} icon={Star} color="text-amber-600" />
        <MiniStat label="زوار عائدون" value={s.returningVisitors.current} icon={Users} color="text-purple-600" />
        <MiniStat label="معدل التحويل" value={`${s.conversionRate.current}%`} change={s.conversionRate.change} icon={TrendingUp} color="text-emerald-600" />
      </div>

      {/* ─── Conversion explanation ─── */}
      <div className="rounded-lg border border-blue-200 bg-blue-50 p-3 text-xs text-blue-800">
        <strong>طريقة حساب معدل التحويل:</strong> الطلبات ÷ الجلسات × 100.
        معدل التحويل الحالي = {s.orders.current} طلب ÷ {s.sessions.current} جلسة = <strong>{s.conversionRate.current}%</strong>.
        الفترة السابقة: {s.conversionRate.previous ?? '—'}%.
      </div>

      {/* ─── Charts row ─── */}
      <div className="grid gap-4 lg:grid-cols-2">
        {/* Traffic sources */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base">مصادر الزيارات</CardTitle>
            <CardDescription>من أين يأتي الزوار</CardDescription>
          </CardHeader>
          <CardContent>
            {data.breakdowns.trafficSources.length === 0 ? (
              <EmptyChart />
            ) : (
              <ResponsiveContainer width="100%" height={240}>
                <PieChart>
                  <Pie
                    data={data.breakdowns.trafficSources.map((t) => ({
                      name: TRAFFIC_LABELS[t.source] || t.source,
                      value: t.visits,
                    }))}
                    dataKey="value"
                    nameKey="name"
                    cx="50%" cy="50%"
                    outerRadius={80}
                    label={(e: any) => `${e.name}: ${e.value}`}
                  >
                    {data.breakdowns.trafficSources.map((_, i) => (
                      <Cell key={i} fill={PIE_COLORS[i % PIE_COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            )}
          </CardContent>
        </Card>

        {/* Devices */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base">الأجهزة</CardTitle>
            <CardDescription>هاتف / كمبيوتر / لوحية</CardDescription>
          </CardHeader>
          <CardContent>
            {data.breakdowns.devices.length === 0 ? (
              <EmptyChart />
            ) : (
              <div className="space-y-3">
                {data.breakdowns.devices.map((d, i) => {
                  const icon = d.device === 'mobile' ? Smartphone : d.device === 'desktop' ? Monitor : d.device === 'tablet' ? Tablet : Globe
                  const Icon = icon
                  return (
                    <div key={d.device} className="flex items-center gap-3">
                      <Icon className="size-4 text-muted-foreground" />
                      <span className="text-sm font-medium w-24">{DEVICE_LABELS[d.device] || d.device}</span>
                      <div className="flex-1 h-2 bg-muted rounded-full overflow-hidden">
                        <div
                          className="h-full rounded-full"
                          style={{ width: `${d.percentage}%`, backgroundColor: PIE_COLORS[i % PIE_COLORS.length] }}
                        />
                      </div>
                      <span className="text-xs text-muted-foreground w-16 text-left">{d.visits} ({d.percentage}%)</span>
                    </div>
                  )
                })}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* ─── Countries table ─── */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">الدول — أعلى 10</CardTitle>
          <CardDescription>من أي دولة يأتي الزوار (من بيانات Analytics الحقيقية)</CardDescription>
        </CardHeader>
        <CardContent>
          {data.breakdowns.countries.length === 0 ? (
            <EmptyChart />
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>الدولة</TableHead>
                  <TableHead className="text-left">الزيارات</TableHead>
                  <TableHead className="text-left">النسبة</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {data.breakdowns.countries.map((c, i) => (
                  <TableRow key={i}>
                    <TableCell className="font-medium">
                      <span className="inline-flex items-center gap-2">
                        <Globe className="size-3.5 text-muted-foreground" />
                        {countryName(c.country)}
                        <span className="text-xs text-muted-foreground font-mono" dir="ltr">({c.country})</span>
                      </span>
                    </TableCell>
                    <TableCell className="text-left tabular-nums">{c.sessions}</TableCell>
                    <TableCell className="text-left">
                      <div className="flex items-center gap-2">
                        <div className="w-20 h-1.5 bg-muted rounded-full overflow-hidden">
                          <div className="h-full bg-primary rounded-full" style={{ width: `${c.percentage}%` }} />
                        </div>
                        <span className="text-xs tabular-nums">{c.percentage}%</span>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      {/* ─── Top viewed products + recent orders ─── */}
      <div className="grid gap-4 lg:grid-cols-2">
        {/* Top viewed products */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base">المنتجات الأكثر مشاهدة</CardTitle>
            <CardDescription>{data.period.current.label}</CardDescription>
          </CardHeader>
          <CardContent>
            {data.breakdowns.topViewedProducts.length === 0 ? (
              <EmptyChart />
            ) : (
              <Table>
                <TableBody>
                  {data.breakdowns.topViewedProducts.map((p, i) => (
                    <TableRow key={p.slug}>
                      <TableCell className="w-8 text-muted-foreground">{i + 1}</TableCell>
                      <TableCell>
                        <Link href={`/produits/${p.slug}`} className="font-medium text-sm hover:underline" target="_blank">
                          {p.name}
                        </Link>
                      </TableCell>
                      <TableCell className="text-left tabular-nums">{p.views}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>

        {/* Recent orders */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base">آخر الطلبات</CardTitle>
            <CardDescription>أحدث 8 طلبات</CardDescription>
          </CardHeader>
          <CardContent>
            {data.activity.recentOrders.length === 0 ? (
              <p className="text-sm text-muted-foreground">لا توجد طلبات بعد.</p>
            ) : (
              <Table>
                <TableBody>
                  {data.activity.recentOrders.map((o) => (
                    <TableRow key={o.id}>
                      <TableCell>
                        <Link href={`/admin/orders/${o.id}`} className="font-mono text-xs hover:underline" dir="ltr">
                          {o.number}
                        </Link>
                      </TableCell>
                      <TableCell className="text-sm">{o.customerFullName}</TableCell>
                      <TableCell><OrderStatusBadge status={o.status} /></TableCell>
                      <TableCell className="text-left tabular-nums text-sm">{formatPrice(o.total, currency)}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>
      </div>

      {/* ─── Best sellers + inventory alerts ─── */}
      <div className="grid gap-4 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="text-base">الأكثر مبيعاً</CardTitle>
            <CardDescription>كل الوقت</CardDescription>
          </CardHeader>
          <CardContent>
            {data.activity.bestSellers.length === 0 ? (
              <p className="text-sm text-muted-foreground">لا توجد مبيعات بعد.</p>
            ) : (
              <Table>
                <TableBody>
                  {data.activity.bestSellers.map((p) => (
                    <TableRow key={p.id}>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          {p.mainImage && (
                            <img src={p.mainImage} alt={p.name} className="size-8 rounded object-cover" />
                          )}
                          <Link href={`/admin/products/${p.id}`} className="font-medium text-sm hover:underline">
                            {p.name}
                          </Link>
                        </div>
                      </TableCell>
                      <TableCell className="text-left text-sm tabular-nums">{p.salesCount}</TableCell>
                      <TableCell className="text-left">
                        {p.stockQuantity <= 5 ? (
                          <Badge variant="outline" className="text-rose-600">مخزون منخفض ({p.stockQuantity})</Badge>
                        ) : (
                          <span className="text-xs text-muted-foreground">{p.stockQuantity}</span>
                        )}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>

        {/* Inventory alerts */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <AlertTriangle className="size-4 text-amber-600" /> تنبيهات المخزون
            </CardTitle>
            <CardDescription>منتجات تحتاج اهتمام</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex items-center justify-between rounded-lg border p-3">
                <div className="flex items-center gap-2">
                  <Package className="size-4 text-blue-600" />
                  <span className="text-sm">إجمالي المنتجات</span>
                </div>
                <span className="font-bold tabular-nums">{data.inventory.totalProducts}</span>
              </div>
              <div className={`flex items-center justify-between rounded-lg border p-3 ${data.inventory.lowStockProducts > 0 ? 'border-amber-300 bg-amber-50' : ''}`}>
                <div className="flex items-center gap-2">
                  <AlertTriangle className={`size-4 ${data.inventory.lowStockProducts > 0 ? 'text-amber-600' : 'text-muted-foreground'}`} />
                  <span className="text-sm">مخزون منخفض (≤ 5)</span>
                </div>
                <span className={`font-bold tabular-nums ${data.inventory.lowStockProducts > 0 ? 'text-amber-600' : ''}`}>
                  {data.inventory.lowStockProducts}
                </span>
              </div>
              {data.inventory.lowStockProducts > 0 && (
                <Button asChild variant="outline" size="sm" className="w-full">
                  <Link href="/admin/inventory">إدارة المخزون</Link>
                </Button>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

// ─── Sub-components ───────────────────────────────────────────────

function IntegrationBadge({ label, connected }: { label: string; connected: boolean }) {
  return (
    <Badge
      variant="outline"
      className={connected
        ? 'border-emerald-300 bg-emerald-50 text-emerald-700'
        : 'border-zinc-300 bg-zinc-50 text-zinc-500'
      }
    >
      <span className={`size-1.5 rounded-full ${connected ? 'bg-emerald-500' : 'bg-zinc-400'}`} />
      {label}
      {connected ? ' مربوط' : ' غير مربوط'}
    </Badge>
  )
}

function KpiCard({
  icon: Icon, label, value, change, sub, color,
}: {
  icon: React.ComponentType<{ className?: string }>
  label: string
  value: string
  change: number | null
  sub: string
  color: string
}) {
  return (
    <Card>
      <CardContent className="p-5">
        <div className="flex items-center justify-between">
          <span className="text-xs text-muted-foreground">{label}</span>
          <Icon className={`size-4 ${color}`} />
        </div>
        <p className="mt-2 font-display text-2xl font-bold tracking-tight tabular-nums">{value}</p>
        <div className="mt-2 flex items-center gap-2">
          <ChangeBadge change={change} />
          <span className="text-xs text-muted-foreground">{sub}</span>
        </div>
      </CardContent>
    </Card>
  )
}

function MiniStat({
  label, value, change, icon: Icon, color,
}: {
  label: string
  value: string | number
  change?: number | null
  icon: React.ComponentType<{ className?: string }>
  color: string
}) {
  return (
    <Card>
      <CardContent className="p-4">
        <div className="flex items-center justify-between">
          <span className="text-xs text-muted-foreground">{label}</span>
          <Icon className={`size-3.5 ${color}`} />
        </div>
        <p className="mt-1.5 font-display text-xl font-bold tracking-tight tabular-nums">{value}</p>
        {change !== undefined && <ChangeBadge change={change} />}
      </CardContent>
    </Card>
  )
}

function EmptyChart() {
  return (
    <div className="grid place-items-center h-48 text-center">
      <div>
        <Activity className="size-8 text-muted-foreground/40 mx-auto" />
        <p className="mt-2 text-sm text-muted-foreground">لا توجد بيانات في هذه الفترة</p>
      </div>
    </div>
  )
}
