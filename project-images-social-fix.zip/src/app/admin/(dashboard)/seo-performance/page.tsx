'use client'

import * as React from 'react'
import Link from 'next/link'
import {
  Search, Globe, FileText, Smartphone, Monitor, Loader2, RefreshCw,
  TrendingUp, MousePointerClick, Eye, Gauge, AlertCircle, CheckCircle2,
  ExternalLink,
} from 'lucide-react'
import { toast } from 'sonner'

import { PageHeader, Spinner } from '@/components/admin/page-header'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Input } from '@/components/ui/input'

interface SeoData {
  connected: boolean
  setupSteps?: string[]
  data: {
    queries?: {
      totals: { clicks: number; impressions: number; ctr: number; position: number }
      top: Array<{ query: string; clicks: number; impressions: number; ctr: number; position: number }>
    } | null
    queriesError?: string
    pages?: {
      top: Array<{ url: string; clicks: number; impressions: number; ctr: number; position: number }>
    } | null
    pagesError?: string
    countries?: {
      top: Array<{ country: string; clicks: number; impressions: number; ctr: number; position: number }>
    } | null
    countriesError?: string
    devices?: {
      breakdown: Array<{ device: string; clicks: number; impressions: number; ctr: number }>
    } | null
    devicesError?: string
    sitemaps: Array<{ path: string; lastSubmitted?: string; status?: string; errors?: number }>
    sitemapsError?: string
  } | null
  period?: { start: string; end: string; days: number }
}

const COUNTRY_NAMES: Record<string, string> = {
  MAR: 'المغرب', DZA: 'الجزائر', TUN: 'تونس', FRA: 'فرنسا', ESP: 'إسبانيا',
  USA: 'أمريكا', DEU: 'ألمانيا', GBR: 'بريطانيا', BEL: 'بلجيكا',
}

const DEVICE_LABELS: Record<string, string> = {
  MOBILE: 'هاتف', DESKTOP: 'كمبيوتر', TABLET: 'لوحية',
}

export default function SeoPerformancePage() {
  const [data, setData] = React.useState<SeoData | null>(null)
  const [loading, setLoading] = React.useState(true)
  const [refreshing, setRefreshing] = React.useState(false)
  const [period, setPeriod] = React.useState('28d')

  async function load(p = period) {
    setRefreshing(true)
    try {
      const res = await fetch(`/api/admin/seo-performance?period=${p}`, { credentials: 'include' })
      const json = await res.json()
      if (json.ok) setData(json)
    } catch {
      toast.error('خطأ في الشبكة')
    } finally {
      setLoading(false)
      setRefreshing(false)
    }
  }

  React.useEffect(() => { load() }, [])

  function onPeriodChange(p: string) {
    setPeriod(p)
    load(p)
  }

  if (loading || !data) {
    return (
      <div className="space-y-6">
        <PageHeader title="أداء SEO" description="بيانات Google Search Console" breadcrumb={[{ label: 'الإدارة', href: '/admin/dashboard' }, { label: 'أداء SEO' }]} />
        <Spinner />
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <PageHeader
        title="أداء SEO"
        description="بيانات Google Search Console الحقيقية"
        breadcrumb={[{ label: 'الإدارة', href: '/admin/dashboard' }, { label: 'أداء SEO' }]}
        actions={
          <div className="flex items-center gap-2">
            <Select value={period} onValueChange={onPeriodChange}>
              <SelectTrigger className="w-[140px]"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="7d">7 أيام</SelectItem>
                <SelectItem value="28d">28 يوم</SelectItem>
                <SelectItem value="3m">3 أشهر</SelectItem>
                <SelectItem value="6m">6 أشهر</SelectItem>
                <SelectItem value="1y">سنة</SelectItem>
              </SelectContent>
            </Select>
            <Button variant="outline" size="icon" onClick={() => load()} disabled={refreshing}>
              {refreshing ? <Loader2 className="size-4 animate-spin" /> : <RefreshCw className="size-4" />}
            </Button>
          </div>
        }
      />

      {/* Connection status */}
      {!data.connected ? (
        <Card className="border-amber-300 bg-amber-50">
          <CardContent className="pt-6">
            <div className="flex items-start gap-3">
              <AlertCircle className="size-5 text-amber-600 flex-shrink-0 mt-0.5" />
              <div>
                <p className="font-medium text-amber-800">Google Search Console غير مربوط</p>
                <p className="mt-1 text-sm text-amber-700">
                  لتفعيل هذا القسم، اتبع الخطوات التالية:
                </p>
                <ol className="mt-2 space-y-1 text-sm text-amber-700 list-decimal list-inside">
                  {data.setupSteps?.map((step, i) => (
                    <li key={i}>{step}</li>
                  ))}
                </ol>
              </div>
            </div>
          </CardContent>
        </Card>
      ) : (
        <>
          {/* KPI cards */}
          {data.data?.queries && (
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
              <KpiCard icon={MousePointerClick} label="النقرات" value={String(data.data.queries.totals.clicks)} color="text-blue-600" />
              <KpiCard icon={Eye} label="مرات الظهور" value={String(data.data.queries.totals.impressions)} color="text-emerald-600" />
              <KpiCard icon={TrendingUp} label="CTR" value={`${data.data.queries.totals.ctr}%`} color="text-amber-600" />
              <KpiCard icon={Search} label="متوسط الترتيب" value={String(data.data.queries.totals.position)} color="text-purple-600" />
            </div>
          )}

          {/* Errors */}
          {(data.data?.queriesError || data.data?.pagesError || data.data?.countriesError) && (
            <Card className="border-rose-300 bg-rose-50">
              <CardContent className="pt-6">
                <div className="flex items-start gap-3">
                  <AlertCircle className="size-5 text-rose-600 flex-shrink-0 mt-0.5" />
                  <div className="space-y-1 text-sm text-rose-700">
                    <p className="font-medium">أخطاء في جلب بعض البيانات:</p>
                    {data.data?.queriesError && <p>• الكلمات المفتاحية: {data.data.queriesError}</p>}
                    {data.data?.pagesError && <p>• الصفحات: {data.data.pagesError}</p>}
                    {data.data?.countriesError && <p>• الدول: {data.data.countriesError}</p>}
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Top queries + Top pages */}
          <div className="grid gap-4 lg:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle className="text-base">الكلمات المفتاحية الأعلى</CardTitle>
              </CardHeader>
              <CardContent>
                {data.data?.queries?.top.length === 0 ? (
                  <p className="text-sm text-muted-foreground">لا توجد بيانات.</p>
                ) : (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>الكلمة</TableHead>
                        <TableHead className="text-left">نقرات</TableHead>
                        <TableHead className="text-left">ظهور</TableHead>
                        <TableHead className="text-left">ترتيب</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {data.data?.queries?.top.slice(0, 15).map((q, i) => (
                        <TableRow key={i}>
                          <TableCell className="font-medium text-sm">{q.query}</TableCell>
                          <TableCell className="text-left tabular-nums">{q.clicks}</TableCell>
                          <TableCell className="text-left tabular-nums">{q.impressions}</TableCell>
                          <TableCell className="text-left tabular-nums">{q.position}</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-base">الصفحات الأعلى</CardTitle>
              </CardHeader>
              <CardContent>
                {data.data?.pages?.top.length === 0 ? (
                  <p className="text-sm text-muted-foreground">لا توجد بيانات.</p>
                ) : (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>الرابط</TableHead>
                        <TableHead className="text-left">نقرات</TableHead>
                        <TableHead className="text-left">ظهور</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {data.data?.pages?.top.slice(0, 15).map((p, i) => (
                        <TableRow key={i}>
                          <TableCell className="font-mono text-xs truncate max-w-[200px]" dir="ltr">
                            {p.url.replace(/^https?:\/\/[^/]+/, '')}
                          </TableCell>
                          <TableCell className="text-left tabular-nums">{p.clicks}</TableCell>
                          <TableCell className="text-left tabular-nums">{p.impressions}</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Countries + Devices + Sitemaps */}
          <div className="grid gap-4 lg:grid-cols-3">
            <Card>
              <CardHeader>
                <CardTitle className="text-base">الدول</CardTitle>
              </CardHeader>
              <CardContent>
                {data.data?.countries?.top.length === 0 ? (
                  <p className="text-sm text-muted-foreground">لا توجد بيانات.</p>
                ) : (
                  <Table>
                    <TableBody>
                      {data.data?.countries?.top.slice(0, 8).map((c, i) => (
                        <TableRow key={i}>
                          <TableCell className="font-medium text-sm">{COUNTRY_NAMES[c.country] || c.country}</TableCell>
                          <TableCell className="text-left tabular-nums text-sm">{c.clicks}</TableCell>
                          <TableCell className="text-left text-xs text-muted-foreground">{c.impressions}</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-base">الأجهزة</CardTitle>
              </CardHeader>
              <CardContent>
                {data.data?.devices?.breakdown.length === 0 ? (
                  <p className="text-sm text-muted-foreground">لا توجد بيانات.</p>
                ) : (
                  <div className="space-y-3">
                    {data.data?.devices?.breakdown.map((d, i) => {
                      const icon = d.device === 'MOBILE' ? Smartphone : d.device === 'DESKTOP' ? Monitor : Globe
                      const Icon = icon
                      return (
                        <div key={i} className="flex items-center gap-2">
                          <Icon className="size-4 text-muted-foreground" />
                          <span className="text-sm flex-1">{DEVICE_LABELS[d.device] || d.device}</span>
                          <span className="text-sm tabular-nums">{d.clicks}</span>
                        </div>
                      )
                    })}
                  </div>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-base">Sitemaps</CardTitle>
              </CardHeader>
              <CardContent>
                {data.data?.sitemaps.length === 0 ? (
                  <p className="text-sm text-muted-foreground">لا توجد sitemaps مسجلة.</p>
                ) : (
                  <div className="space-y-2">
                    {data.data?.sitemaps.map((s, i) => (
                      <div key={i} className="flex items-center gap-2 text-sm">
                        <FileText className="size-3.5 text-muted-foreground" />
                        <span className="font-mono text-xs truncate flex-1" dir="ltr">{s.path.replace(/^https?:\/\/[^/]+/, '')}</span>
                        <Badge variant="outline" className={s.errors && s.errors > 0 ? 'text-rose-600' : 'text-emerald-600'}>
                          {s.errors && s.errors > 0 ? `${s.errors} خطأ` : 'OK'}
                        </Badge>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          <p className="text-xs text-muted-foreground text-center">
            الفترة: {data.period?.start} → {data.period?.end} ({data.period?.days} يوم)
          </p>
        </>
      )}

      {/* PageSpeed section */}
      <PageSpeedSection />
    </div>
  )
}

// ─── PageSpeed sub-component ──────────────────────────────────────

function PageSpeedSection() {
  const [url, setUrl] = React.useState('')
  const [strategy, setStrategy] = React.useState<'mobile' | 'desktop'>('mobile')
  const [loading, setLoading] = React.useState(false)
  const [result, setResult] = React.useState<any>(null)

  async function runTest() {
    setLoading(true)
    try {
      const params = new URLSearchParams({ strategy })
      if (url) params.set('url', url)
      const res = await fetch(`/api/admin/pagespeed?${params}`, { credentials: 'include' })
      const json = await res.json()
      setResult(json)
    } catch {
      toast.error('خطأ في الشبكة')
    } finally {
      setLoading(false)
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-base flex items-center gap-2">
          <Gauge className="size-4" /> PageSpeed Insights
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* URL + strategy input */}
        <div className="flex flex-col gap-2 sm:flex-row">
          <Input
            placeholder="https://ismailmaterial.ma/ (افتراضي: الصفحة الرئيسية)"
            value={url}
            onChange={(e) => setUrl(e.target.value)}
            dir="ltr"
            className="text-left flex-1"
          />
          <Select value={strategy} onValueChange={(v) => setStrategy(v as 'mobile' | 'desktop')}>
            <SelectTrigger className="w-full sm:w-[140px]">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="mobile">هاتف</SelectItem>
              <SelectItem value="desktop">كمبيوتر</SelectItem>
            </SelectContent>
          </Select>
          <Button onClick={runTest} disabled={loading}>
            {loading ? <Loader2 className="size-4 animate-spin" /> : <Gauge className="size-4" />}
            فحص
          </Button>
        </div>

        {/* Result */}
        {result && !result.connected && (
          <div className="rounded-lg border border-amber-300 bg-amber-50 p-3 text-sm text-amber-700">
            <p className="font-medium">PageSpeed API غير مُكون</p>
            <ol className="mt-1 list-decimal list-inside text-xs">
              {result.setupSteps?.map((s: string, i: number) => <li key={i}>{s}</li>)}
            </ol>
          </div>
        )}

        {result && result.connected && result.error && (
          <div className="rounded-lg border border-rose-300 bg-rose-50 p-3 text-sm text-rose-700">
            خطأ: {result.error}
          </div>
        )}

        {result && result.connected && result.data && (
          <div className="space-y-4">
            {/* Score + Core Web Vitals */}
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
              <ScoreCard label="Performance" value={result.data.performanceScore} max={100} unit="/100" />
              <MetricCard label="LCP" value={result.data.lcp} unit="ms" good={3000} />
              <MetricCard label="INP" value={result.data.inp} unit="ms" good={200} />
              <MetricCard label="CLS" value={result.data.cls} unit="" good={0.1} />
            </div>

            {/* Lab metrics */}
            <div className="grid gap-3 sm:grid-cols-3">
              <MiniMetric label="FCP" value={result.data.fcp} unit="ms" />
              <MiniMetric label="TBT" value={result.data.tbt} unit="ms" />
              <MiniMetric label="Speed Index" value={result.data.speedIndex} unit="ms" />
            </div>

            {/* Opportunities */}
            {result.data.opportunities?.length > 0 && (
              <div>
                <p className="text-sm font-medium mb-2">توصيات للتحسين:</p>
                <div className="space-y-2">
                  {result.data.opportunities.map((opp: any, i: number) => (
                    <div key={i} className="rounded-lg border p-3 text-sm">
                      <p className="font-medium">{opp.title}</p>
                      <p className="text-xs text-muted-foreground mt-0.5">توفير ~{Math.round(opp.savingsMs)}ms</p>
                    </div>
                  ))}
                </div>
              </div>
            )}

            <p className="text-xs text-muted-foreground">
              آخر فحص: {new Date(result.data.fetchedAt).toLocaleString('ar-MA')}
              {' · '}
              <a href={`https://pagespeed.web.dev/report?url=${encodeURIComponent(result.data.url)}`} target="_blank" rel="noopener noreferrer" className="text-primary hover:underline inline-flex items-center gap-0.5">
                فتح في PageSpeed <ExternalLink className="size-3" />
              </a>
            </p>
          </div>
        )}

        {loading && (
          <div className="grid place-items-center py-8">
            <Loader2 className="size-6 animate-spin text-muted-foreground" />
            <p className="mt-2 text-xs text-muted-foreground">قد يستغرق 10-30 ثانية...</p>
          </div>
        )}
      </CardContent>
    </Card>
  )
}

function ScoreCard({ label, value, max, unit }: { label: string; value: number | null; max: number; unit: string }) {
  if (value === null) return <EmptyMetric label={label} />
  const color = value >= 90 ? 'text-emerald-600' : value >= 50 ? 'text-amber-600' : 'text-rose-600'
  return (
    <Card>
      <CardContent className="p-4">
        <p className="text-xs text-muted-foreground">{label}</p>
        <p className={`mt-1 font-display text-2xl font-bold tabular-nums ${color}`}>{value}{unit}</p>
      </CardContent>
    </Card>
  )
}

function MetricCard({ label, value, unit, good }: { label: string; value: number | null; unit: string; good: number }) {
  if (value === null) return <EmptyMetric label={label} />
  const color = value <= good ? 'text-emerald-600' : value <= good * 2 ? 'text-amber-600' : 'text-rose-600'
  return (
    <Card>
      <CardContent className="p-4">
        <p className="text-xs text-muted-foreground">{label}</p>
        <p className={`mt-1 font-display text-2xl font-bold tabular-nums ${color}`}>
          {value < 1000 ? value : (value / 1000).toFixed(1)}
          <span className="text-sm font-normal text-muted-foreground ml-1">{value < 1000 ? unit : 's'}</span>
        </p>
      </CardContent>
    </Card>
  )
}

function MiniMetric({ label, value, unit }: { label: string; value: number | null; unit: string }) {
  if (value === null) return <EmptyMetric label={label} />
  return (
    <div className="rounded-lg border p-3">
      <p className="text-xs text-muted-foreground">{label}</p>
      <p className="mt-0.5 font-display text-lg font-bold tabular-nums">
        {value < 1000 ? value : (value / 1000).toFixed(1)}
        <span className="text-xs font-normal text-muted-foreground ml-1">{value < 1000 ? unit : 's'}</span>
      </p>
    </div>
  )
}

function EmptyMetric({ label }: { label: string }) {
  return (
    <Card>
      <CardContent className="p-4">
        <p className="text-xs text-muted-foreground">{label}</p>
        <p className="mt-1 font-display text-2xl font-bold text-muted-foreground/40">—</p>
      </CardContent>
    </Card>
  )
}

function KpiCard({ icon: Icon, label, value, color }: { icon: any; label: string; value: string; color: string }) {
  return (
    <Card>
      <CardContent className="p-4">
        <div className="flex items-center justify-between">
          <span className="text-xs text-muted-foreground">{label}</span>
          <Icon className={`size-3.5 ${color}`} />
        </div>
        <p className="mt-1.5 font-display text-xl font-bold tabular-nums">{value}</p>
      </CardContent>
    </Card>
  )
}
