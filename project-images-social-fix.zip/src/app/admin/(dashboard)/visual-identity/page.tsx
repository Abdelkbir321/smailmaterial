'use client'

import * as React from 'react'
import { toast } from 'sonner'
import {
  Loader2, Save, Upload, Globe, ImageIcon, AlertTriangle,
  Link as LinkIcon, Check, RotateCcw, Play, Pause, Square,
  ArrowUp, ArrowDown, Sparkles,
} from 'lucide-react'

import { PageHeader, Spinner } from '@/components/admin/page-header'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Separator } from '@/components/ui/separator'
import { Switch } from '@/components/ui/switch'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Logo } from '@/components/storefront/logo'
import type { LogoMotion, LogoMotionType, LogoSize, LogoVisual, LogoMobile } from '@/lib/logo-config'
import {
  DEFAULT_LOGO_MOTION,
  DEFAULT_LOGO_SIZE,
  DEFAULT_LOGO_VISUAL,
  DEFAULT_LOGO_MOBILE,
  LOGO_MOTION_OPTIONS,
  LOGO_MOTION_SPEED_OPTIONS,
  LOGO_MOTION_INTENSITY_OPTIONS,
  LOGO_TILT_DIRECTION_OPTIONS,
} from '@/lib/logo-config'

interface VisualIdentitySettings {
  site_logo_source: string | null
  site_logo_public_id: string | null
  site_logo_url: string | null
  site_logo_alt: string | null
  logo_light_url: string | null
  logo_dark_url: string | null
  logo_mobile_url: string | null
  favicon_url: string | null
  favicon_cache_bust: string | null
  primary_color: string | null
  accent_color: string | null
  logo_size: string | null
  logo_motion: string | null
  logo_visual: string | null
  logo_mobile: string | null
}

function isValidHex(v: string): boolean {
  return /^#([0-9a-fA-F]{3}|[0-9a-fA-F]{6})$/.test(v)
}

// Allowed favicon MIME types — we validate the file on the client
// before uploading, and the server's /api/admin/upload route also
// validates magic bytes (defense-in-depth).
const ALLOWED_FAVICON_TYPES = ['image/png', 'image/x-icon', 'image/vnd.microsoft.icon', 'image/svg+xml', 'image/webp', 'image/jpeg']
const MAX_FAVICON_SIZE = 2 * 1024 * 1024 // 2 MB
const ALLOWED_LOGO_TYPES = ['image/png', 'image/jpeg', 'image/svg+xml', 'image/webp', 'image/gif']
const MAX_LOGO_SIZE = 5 * 1024 * 1024 // 5 MB

export default function VisualIdentityPage() {
  const [loading, setLoading] = React.useState(true)
  const [saving, setSaving] = React.useState(false)
  const [settings, setSettings] = React.useState<VisualIdentitySettings>({
    site_logo_source: null,
    site_logo_public_id: null,
    site_logo_url: null,
    site_logo_alt: null,
    logo_light_url: null,
    logo_dark_url: null,
    logo_mobile_url: null,
    favicon_url: null,
    favicon_cache_bust: null,
    primary_color: null,
    accent_color: null,
    logo_size: null,
    logo_motion: null,
    logo_visual: null,
    logo_mobile: null,
  })

  // Logo size + motion — parsed from JSON settings, kept in state for live preview
  const [logoSize, setLogoSize] = React.useState<LogoSize>(DEFAULT_LOGO_SIZE)
  const [logoMotion, setLogoMotion] = React.useState<LogoMotion>(DEFAULT_LOGO_MOTION)
  const [logoVisual, setLogoVisual] = React.useState<LogoVisual>(DEFAULT_LOGO_VISUAL)
  const [logoMobile, setLogoMobile] = React.useState<LogoMobile>(DEFAULT_LOGO_MOBILE)

  const [cloudinaryConfigured, setCloudinaryConfigured] = React.useState(true)
  const [uploading, setUploading] = React.useState(false)
  const [uploadProgress, setUploadProgress] = React.useState(0)

  // Favicon upload state
  const [favUploading, setFavUploading] = React.useState(false)
  const [favExternalUrl, setFavExternalUrl] = React.useState('')
  const [favExternalPreview, setFavExternalPreview] = React.useState<string | null>(null)
  const [favExternalError, setFavExternalError] = React.useState<string | null>(null)

  const fileRef = React.useRef<HTMLInputElement>(null)
  const favFileRef = React.useRef<HTMLInputElement>(null)

  // External URL for main logo (preview before save)
  const [externalUrl, setExternalUrl] = React.useState('')
  const [externalPreview, setExternalPreview] = React.useState<string | null>(null)
  const [externalPreviewError, setExternalPreviewError] = React.useState(false)

  async function load() {
    setLoading(true)
    try {
      const res = await fetch('/api/admin/visual-identity', { credentials: 'include' })
      const json = await res.json()
      if (!res.ok || !json.ok) {
        toast.error(json.error || 'فشل التحميل')
        return
      }
      const s = json.settings as VisualIdentitySettings
      setSettings(s)
      setCloudinaryConfigured(!!json.cloudinaryConfigured)
      // Parse logo size + motion + visual + mobile
      try { if (s.logo_size) setLogoSize(JSON.parse(s.logo_size)) } catch {}
      try {
        if (s.logo_motion) {
          const m = JSON.parse(s.logo_motion)
          setLogoMotion({ ...DEFAULT_LOGO_MOTION, ...m })
        }
      } catch {}
      try {
        if (s.logo_visual) {
          const v = JSON.parse(s.logo_visual)
          setLogoVisual({ ...DEFAULT_LOGO_VISUAL, ...v })
        }
      } catch {}
      try {
        if (s.logo_mobile) {
          const m = JSON.parse(s.logo_mobile)
          setLogoMobile({ ...DEFAULT_LOGO_MOBILE, ...m })
        }
      } catch {}
    } catch {
      toast.error('خطأ في الشبكة')
    } finally {
      setLoading(false)
    }
  }

  React.useEffect(() => {
    load()
  }, [])

  // === LOGO upload (main site logo) ===
  async function uploadLogo(file: File) {
    if (!ALLOWED_LOGO_TYPES.includes(file.type)) {
      toast.error(`صيغة غير مدعومة. المسموح: ${ALLOWED_LOGO_TYPES.join(', ')}`)
      return
    }
    if (file.size > MAX_LOGO_SIZE) {
      toast.error(`حجم الملف كبير جداً. الحد الأقصى: ${MAX_LOGO_SIZE / 1024 / 1024} MB`)
      return
    }
    setUploading(true)
    setUploadProgress(10)
    try {
      await new Promise<void>((resolve, reject) => {
        const xhr = new XMLHttpRequest()
        xhr.open('POST', '/api/admin/upload')
        xhr.withCredentials = true
        xhr.upload.onprogress = (e) => {
          if (e.lengthComputable) setUploadProgress(Math.round((e.loaded / e.total) * 90) + 10)
        }
        xhr.onload = () => {
          setUploadProgress(100)
          try {
            const json = JSON.parse(xhr.responseText)
            if (xhr.status >= 200 && xhr.status < 300 && json.ok) {
              const secureUrl = json.asset?.secureUrl || json.image?.secureUrl
              const publicId = json.asset?.publicId
              if (!secureUrl) { reject(new Error('لم يرجع الخادم رابط الصورة')); return }
              ;(async () => {
                const putRes = await fetch('/api/admin/visual-identity', {
                  method: 'PUT',
                  headers: { 'Content-Type': 'application/json' },
                  body: JSON.stringify({
                    settings: {
                      site_logo_source: 'cloudinary',
                      site_logo_url: secureUrl,
                      site_logo_public_id: publicId || null,
                    },
                  }),
                  credentials: 'include',
                })
                const putJson = await putRes.json()
                if (!putRes.ok || !putJson.ok) {
                  reject(new Error(putJson.error || 'فشل حفظ الإعدادات'))
                  return
                }
                setSettings((s) => ({ ...s, site_logo_source: 'cloudinary', site_logo_url: secureUrl, site_logo_public_id: publicId || null }))
                resolve()
              })()
            } else {
              reject(new Error(json.error || 'فشل الرفع'))
            }
          } catch (e) { reject(e) }
        }
        xhr.onerror = () => reject(new Error('خطأ في الشبكة'))
        const formData = new FormData()
        formData.append('file', file)
        xhr.send(formData)
      })
      toast.success('تم رفع الشعار وحفظه')
    } catch (e: any) {
      toast.error(e?.message || 'فشل رفع الشعار')
    } finally {
      setUploading(false)
      setUploadProgress(0)
      if (fileRef.current) fileRef.current.value = ''
    }
  }

  // === FAVICON upload ===
  async function uploadFavicon(file: File) {
    if (!ALLOWED_FAVICON_TYPES.includes(file.type)) {
      toast.error(`صيغة غير مدعومة. المسموح: ${ALLOWED_FAVICON_TYPES.join(', ')}`)
      return
    }
    if (file.size > MAX_FAVICON_SIZE) {
      toast.error(`حجم الملف كبير جداً. الحد الأقصى: ${MAX_FAVICON_SIZE / 1024 / 1024} MB`)
      return
    }
    setFavUploading(true)
    try {
      // Use the upload endpoint, then save the URL as favicon_url
      const formData = new FormData()
      formData.append('file', file)
      const res = await fetch('/api/admin/upload', {
        method: 'POST',
        body: formData,
        credentials: 'include',
      })
      const json = await res.json()
      if (!res.ok || !json.ok) {
        toast.error(json.error || 'فشل رفع الفافيكون')
        return
      }
      const secureUrl = json.asset?.secureUrl || json.image?.secureUrl
      if (!secureUrl) {
        toast.error('لم يرجع الخادم رابط الفافيكون')
        return
      }
      // Save to favicon_url (this auto-bumps favicon_cache_bust server-side)
      const putRes = await fetch('/api/admin/visual-identity', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ settings: { favicon_url: secureUrl } }),
        credentials: 'include',
      })
      const putJson = await putRes.json()
      if (!putRes.ok || !putJson.ok) {
        toast.error(putJson.error || 'فشل حفظ الفافيكون')
        return
      }
      setSettings((s) => ({ ...s, favicon_url: secureUrl }))
      toast.success('تم رفع الفافيكون — سيظهر فالتاب بعد لحظات')
    } catch {
      toast.error('خطأ في الشبكة')
    } finally {
      setFavUploading(false)
      if (favFileRef.current) favFileRef.current.value = ''
    }
  }

  // Save favicon external URL
  async function saveFaviconExternal() {
    const url = favExternalUrl.trim()
    if (!url) { toast.error('أدخل رابط الفافيكون'); return }
    if (!/^https?:\/\/[^\s]+$/.test(url) && !url.startsWith('/')) {
      setFavExternalError('الرابط غير صالح (يجب أن يبدأ بـ http(s):// أو /)')
      return
    }
    setFavExternalError(null)
    setSaving(true)
    try {
      const res = await fetch('/api/admin/visual-identity', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ settings: { favicon_url: url } }),
        credentials: 'include',
      })
      const json = await res.json()
      if (!res.ok || !json.ok) { toast.error(json.error || 'فشل الحفظ'); return }
      setSettings((s) => ({ ...s, favicon_url: url }))
      setFavExternalUrl('')
      setFavExternalPreview(null)
      toast.success('تم حفظ الفافيكون')
    } catch {
      toast.error('خطأ في الشبكة')
    } finally {
      setSaving(false)
    }
  }

  // Reset favicon to default (null = use static files)
  async function resetFavicon() {
    if (!confirm('متأكد من حذف الفافيكون المخصص والرجوع إلى الافتراضي؟')) return
    setSaving(true)
    try {
      // Save empty string (server treats empty as "no custom favicon")
      const res = await fetch('/api/admin/visual-identity', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ settings: { favicon_url: '' } }),
        credentials: 'include',
      })
      const json = await res.json()
      if (!res.ok || !json.ok) { toast.error(json.error || 'فشل التصفير'); return }
      setSettings((s) => ({ ...s, favicon_url: null }))
      toast.success('تم الرجوع إلى الفافيكون الافتراضي')
    } catch {
      toast.error('خطأ في الشبكة')
    } finally {
      setSaving(false)
    }
  }

  // Save main logo external URL
  async function saveExternalLogo() {
    const url = externalUrl.trim()
    if (!url) { toast.error('أدخل رابط الشعار.'); return }
    if (!/^https?:\/\//i.test(url)) {
      toast.error('الرابط غير صالح (يجب أن يبدأ بـ http أو https).')
      return
    }
    setSaving(true)
    try {
      const res = await fetch('/api/admin/visual-identity', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          settings: {
            site_logo_source: 'external',
            site_logo_url: url,
            site_logo_public_id: null,
          },
        }),
        credentials: 'include',
      })
      const json = await res.json()
      if (!res.ok || !json.ok) { toast.error(json.error || 'فشل الحفظ'); return }
      setSettings((s) => ({ ...s, site_logo_source: 'external', site_logo_url: url, site_logo_public_id: null }))
      setExternalUrl('')
      setExternalPreview(null)
      setExternalPreviewError(false)
      toast.success('تم حفظ الشعار')
    } catch {
      toast.error('خطأ في الشبكة')
    } finally {
      setSaving(false)
    }
  }

  // Save logo size + motion + visual + mobile (combined)
  async function saveLogoConfig() {
    setSaving(true)
    try {
      const res = await fetch('/api/admin/visual-identity', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          settings: {
            logo_size: JSON.stringify(logoSize),
            logo_motion: JSON.stringify(logoMotion),
            logo_visual: JSON.stringify(logoVisual),
            logo_mobile: JSON.stringify(logoMobile),
          },
        }),
        credentials: 'include',
      })
      const json = await res.json()
      if (!res.ok || !json.ok) { toast.error(json.error || 'فشل الحفظ'); return }
      toast.success('تم حفظ إعدادات اللوغو والحركة')
    } catch {
      toast.error('خطأ في الشبكة')
    } finally {
      setSaving(false)
    }
  }

  // Reset logo config to defaults
  async function resetLogoConfig() {
    if (!confirm('متأكد من استرجاع الإعدادات الافتراضية للوغو؟')) return
    setLogoSize(DEFAULT_LOGO_SIZE)
    setLogoMotion(DEFAULT_LOGO_MOTION)
    setLogoVisual(DEFAULT_LOGO_VISUAL)
    setLogoMobile(DEFAULT_LOGO_MOBILE)
    await saveLogoConfig()
  }

  // Save colors
  async function saveColors() {
    if (settings.primary_color && !isValidHex(settings.primary_color)) {
      toast.error('اللون الأساسي ليس HEX صالح.'); return
    }
    if (settings.accent_color && !isValidHex(settings.accent_color)) {
      toast.error('لون التمييز ليس HEX صالح.'); return
    }
    setSaving(true)
    try {
      const res = await fetch('/api/admin/visual-identity', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          settings: {
            primary_color: settings.primary_color || '',
            accent_color: settings.accent_color || '',
          },
        }),
        credentials: 'include',
      })
      const json = await res.json()
      if (!res.ok || !json.ok) { toast.error(json.error || 'فشل الحفظ'); return }
      toast.success('تم حفظ الألوان')
    } catch {
      toast.error('خطأ في الشبكة')
    } finally {
      setSaving(false)
    }
  }

  // Save variant logos (light/dark/mobile)
  async function saveVariants() {
    setSaving(true)
    try {
      const res = await fetch('/api/admin/visual-identity', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          settings: {
            logo_light_url: settings.logo_light_url || '',
            logo_dark_url: settings.logo_dark_url || '',
            logo_mobile_url: settings.logo_mobile_url || '',
          },
        }),
        credentials: 'include',
      })
      const json = await res.json()
      if (!res.ok || !json.ok) { toast.error(json.error || 'فشل الحفظ'); return }
      toast.success('تم حفظ الشعارات الإضافية')
    } catch {
      toast.error('خطأ في الشبكة')
    } finally {
      setSaving(false)
    }
  }

  if (loading) return <Spinner />

  const currentLogo = settings.site_logo_url

  return (
    <div className="space-y-6">
      <PageHeader
        title="الهوية البصرية"
        description="الشعار، الفافيكون، الألوان، حجم الشعار، وحركته — كلها قابلة للتخصيص."
        breadcrumb={[{ label: 'الإدارة', href: '/admin/dashboard' }, { label: 'الهوية البصرية' }]}
      />

      {!cloudinaryConfigured && (
        <div className="bg-amber-50 border border-amber-200 rounded-lg p-4 flex items-start gap-3">
          <AlertTriangle className="size-5 text-amber-700 mt-0.5 shrink-0" />
          <div className="space-y-1">
            <p className="text-sm font-medium text-amber-800">Cloudinary غير مهيأ</p>
            <p className="text-xs text-amber-700">
              عيّن قيم CLOUDINARY_CLOUD_NAME، CLOUDINARY_API_KEY، CLOUDINARY_API_SECRET في Environment Variables لتفعيل رفع الصور.
              يمكنك مؤقتاً استعمال روابط خارجية.
            </p>
          </div>
        </div>
      )}

      <Tabs defaultValue="logo" className="w-full">
        <TabsList className="grid w-full grid-cols-2 md:grid-cols-6">
          <TabsTrigger value="logo">الشعار والحركة</TabsTrigger>
          <TabsTrigger value="effects">التأثيرات البصرية</TabsTrigger>
          <TabsTrigger value="mobile">الهاتف</TabsTrigger>
          <TabsTrigger value="favicon">الفافيكون</TabsTrigger>
          <TabsTrigger value="variants">شعارات إضافية</TabsTrigger>
          <TabsTrigger value="colors">الألوان</TabsTrigger>
        </TabsList>

        {/* ==================== LOGO + MOTION ==================== */}
        <TabsContent value="logo" className="space-y-4 mt-4">
          <div className="grid gap-6 lg:grid-cols-3">
            {/* === Live preview === */}
            <Card className="lg:col-span-1">
              <CardHeader>
                <CardTitle className="text-base">معاينة حية</CardTitle>
                <CardDescription>هكذا غادي يبان اللوغو فالـ Header.</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="relative grid place-items-center">
                  <Logo
                    logoUrl={settings.site_logo_url ?? null}
                    alt="Logo preview"
                    size={logoSize}
                    motion={logoMotion}
                    visual={logoVisual}
                    mobile={logoMobile}
                    className="relative z-10"
                  />
                </div>
                <div className="text-xs text-muted-foreground space-y-1">
                  <div>الحجم: <span className="font-mono">{logoSize.width}×{logoSize.height}px</span></div>
                  <div>الحركة: <span className="font-mono">{logoMotion.type}</span> · سرعة <span className="font-mono">{logoMotion.speed}×</span> · شدة <span className="font-mono">{logoMotion.intensity}</span></div>
                </div>
              </CardContent>
            </Card>

            {/* === Logo source === */}
            <Card className="lg:col-span-2">
              <CardHeader>
                <CardTitle className="text-base">رفع شعار جديد</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {/* File upload */}
                <div>
                  <Label className="mb-1.5 block">الرفع من الجهاز</Label>
                  <div
                    onClick={() => fileRef.current?.click()}
                    className="border-2 border-dashed rounded-lg p-6 text-center cursor-pointer hover:bg-muted/50 transition-colors"
                  >
                    <input
                      ref={fileRef}
                      type="file"
                      accept={ALLOWED_LOGO_TYPES.join(',')}
                      className="hidden"
                      onChange={(e) => {
                        const f = e.target.files?.[0]
                        if (f) uploadLogo(f)
                      }}
                    />
                    {uploading ? (
                      <div className="flex flex-col items-center gap-2 text-muted-foreground">
                        <Loader2 className="size-6 animate-spin" />
                        <p className="text-sm">جارٍ الرفع… {uploadProgress}%</p>
                        <div className="w-full max-w-xs h-1.5 bg-muted rounded overflow-hidden">
                          <div
                            className="h-full bg-emerald-600 transition-all"
                            style={{ width: `${uploadProgress}%` }}
                          />
                        </div>
                      </div>
                    ) : (
                      <div className="flex flex-col items-center gap-2 text-muted-foreground">
                        <Upload className="size-6" />
                        <p className="text-sm font-medium">اسحب صورة الشعار هنا أو اضغط لتصفح الملفات</p>
                        <p className="text-xs">PNG, SVG (يفضّل بشفافية) — حد أقصى 5 ميغابايت</p>
                      </div>
                    )}
                  </div>
                </div>

                <Separator />

                {/* External URL */}
                <div>
                  <Label className="mb-1.5 block">رابط صورة الشعار</Label>
                  <div className="grid gap-2 sm:grid-cols-2">
                    <Input
                      placeholder="https://example.com/logo.png"
                      value={externalUrl}
                      onChange={(e) => {
                        setExternalUrl(e.target.value)
                        setExternalPreview(null)
                        setExternalPreviewError(false)
                      }}
                      dir="ltr"
                      className="text-left"
                    />
                    <div className="flex gap-2">
                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        onClick={() => setExternalPreview(externalUrl.trim())}
                        disabled={!externalUrl}
                      >
                        <Globe className="size-4" /> معاينة
                      </Button>
                      <Button
                        type="button"
                        size="sm"
                        onClick={saveExternalLogo}
                        disabled={saving || !externalUrl}
                        className="bg-zinc-900 hover:bg-zinc-800"
                      >
                        {saving ? <Loader2 className="size-4 animate-spin" /> : <Save className="size-4" />} حفظ
                      </Button>
                    </div>
                  </div>
                  {externalPreview && (
                    <div className="mt-2 inline-block bg-white border rounded-md p-2">
                      {externalPreviewError ? (
                        <p className="text-rose-600 text-xs p-4">الرابط غير صالح أو تعذر تحميل الصورة.</p>
                      ) : (
                        <img
                          src={externalPreview}
                          alt="معاينة الشعار"
                          className="max-h-24 max-w-full object-contain"
                          onError={() => setExternalPreviewError(true)}
                        />
                      )}
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* === Logo size + motion controls === */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base flex items-center gap-2">
                <Sparkles className="size-4" /> حجم الشعار والحركة
              </CardTitle>
              <CardDescription>
                تحكم فحجم اللوغو + نوع الحركة + السرعة + الشدة. المعاينة حية فالأعلى.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Size controls */}
              <div>
                <Label className="mb-2 block">الحجم (بكسل)</Label>
                <div className="grid gap-4 sm:grid-cols-2">
                  <div>
                    <Label className="text-xs text-muted-foreground">العرض (8-200)</Label>
                    <div className="flex items-center gap-2 mt-1">
                      <Input
                        type="number"
                        min={8}
                        max={200}
                        value={logoSize.width}
                        onChange={(e) => setLogoSize((s) => ({ ...s, width: clamp(Number(e.target.value), 8, 200) }))}
                        className="w-24"
                      />
                      <input
                        type="range"
                        min={8}
                        max={200}
                        value={logoSize.width}
                        onChange={(e) => setLogoSize((s) => ({ ...s, width: Number(e.target.value) }))}
                        className="flex-1"
                      />
                    </div>
                  </div>
                  <div>
                    <Label className="text-xs text-muted-foreground">الارتفاع (8-200)</Label>
                    <div className="flex items-center gap-2 mt-1">
                      <Input
                        type="number"
                        min={8}
                        max={200}
                        value={logoSize.height}
                        onChange={(e) => setLogoSize((s) => ({ ...s, height: clamp(Number(e.target.value), 8, 200) }))}
                        className="w-24"
                      />
                      <input
                        type="range"
                        min={8}
                        max={200}
                        value={logoSize.height}
                        onChange={(e) => setLogoSize((s) => ({ ...s, height: Number(e.target.value) }))}
                        className="flex-1"
                      />
                    </div>
                  </div>
                </div>
                <label className="mt-3 flex items-center gap-2 text-sm text-muted-foreground">
                  <input
                    type="checkbox"
                    checked={logoSize.maintainAspectRatio}
                    onChange={(e) => setLogoSize((s) => ({ ...s, maintainAspectRatio: e.target.checked }))}
                  />
                  الحفاظ على تناسب الأبعاد
                </label>
              </div>

              <Separator />

              {/* Motion type */}
              <div>
                <Label className="mb-2 block">نوع الحركة</Label>
                <div className="grid gap-2 grid-cols-2 sm:grid-cols-5">
                  {LOGO_MOTION_OPTIONS.map((opt) => (
                    <button
                      key={opt.type}
                      onClick={() => setLogoMotion((m) => ({ ...m, type: opt.type }))}
                      className={`rounded-lg border p-2.5 text-left transition-colors ${
                        logoMotion.type === opt.type
                          ? 'border-primary bg-primary/5 ring-1 ring-primary'
                          : 'border-border hover:border-border-strong'
                      }`}
                    >
                      <div className="text-xs font-semibold">{opt.label}</div>
                      <div className="text-[10px] text-muted-foreground">{opt.desc}</div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Speed + Intensity (only when motion is not 'none') */}
              {logoMotion.type !== 'none' && (
                <div className="grid gap-4 sm:grid-cols-2">
                  <div>
                    <Label className="mb-2 block text-xs">السرعة</Label>
                    <div className="flex gap-2">
                      {LOGO_MOTION_SPEED_OPTIONS.map((opt) => (
                        <button
                          key={opt.v}
                          onClick={() => setLogoMotion((m) => ({ ...m, speed: opt.v }))}
                          className={`flex-1 rounded-md border px-3 py-2 text-xs font-medium transition-colors ${
                            logoMotion.speed === opt.v
                              ? 'border-primary bg-primary/5'
                              : 'border-border hover:border-border-strong'
                          }`}
                        >
                          {opt.label}
                        </button>
                      ))}
                    </div>
                  </div>
                  <div>
                    <Label className="mb-2 block text-xs">الشدة</Label>
                    <div className="flex gap-2">
                      {LOGO_MOTION_INTENSITY_OPTIONS.map((opt) => (
                        <button
                          key={opt.v}
                          onClick={() => setLogoMotion((m) => ({ ...m, intensity: opt.v }))}
                          className={`flex-1 rounded-md border px-3 py-2 text-xs font-medium transition-colors ${
                            logoMotion.intensity === opt.v
                              ? 'border-primary bg-primary/5'
                              : 'border-border hover:border-border-strong'
                          }`}
                        >
                          {opt.label}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {/* 3D rotation axis controls — only for rotate3d + tilt */}
              {(logoMotion.type === 'rotate3d' || logoMotion.type === 'tilt') && (
                <div className="rounded-lg border border-border p-4 space-y-4 bg-muted/20">
                  <div className="text-sm font-semibold">إعدادات ثلاثية الأبعاد</div>
                  {logoMotion.type === 'rotate3d' && (
                    <div className="grid gap-4 sm:grid-cols-3">
                      <div>
                        <Label className="text-xs">دوران X (درجة)</Label>
                        <Input
                          type="number"
                          min={0}
                          max={360}
                          value={logoMotion.rotateX ?? 0}
                          onChange={(e) => setLogoMotion((m) => ({ ...m, rotateX: Number(e.target.value) }))}
                          className="mt-1"
                        />
                      </div>
                      <div>
                        <Label className="text-xs">دوران Y (درجة)</Label>
                        <Input
                          type="number"
                          min={0}
                          max={360}
                          value={logoMotion.rotateY ?? 0}
                          onChange={(e) => setLogoMotion((m) => ({ ...m, rotateY: Number(e.target.value) }))}
                          className="mt-1"
                        />
                      </div>
                      <div>
                        <Label className="text-xs">دوران Z (درجة)</Label>
                        <Input
                          type="number"
                          min={0}
                          max={360}
                          value={logoMotion.rotateZ ?? 360}
                          onChange={(e) => setLogoMotion((m) => ({ ...m, rotateZ: Number(e.target.value) }))}
                          className="mt-1"
                        />
                      </div>
                    </div>
                  )}
                  {logoMotion.type === 'tilt' && (
                    <div>
                      <Label className="mb-2 block text-xs">اتجاه الإمالة</Label>
                      <div className="flex gap-2">
                        {LOGO_TILT_DIRECTION_OPTIONS.map((opt) => (
                          <button
                            key={opt.v}
                            onClick={() => setLogoMotion((m) => ({ ...m, tiltDirection: opt.v }))}
                            className={`flex-1 rounded-md border px-3 py-2 text-xs font-medium transition-colors ${
                              (logoMotion.tiltDirection ?? 'both') === opt.v
                                ? 'border-primary bg-primary/5'
                                : 'border-border hover:border-border-strong'
                            }`}
                          >
                            {opt.label}
                          </button>
                        ))}
                      </div>
                    </div>
                  )}
                  <div>
                    <Label className="text-xs">المنظور (Perspective, px)</Label>
                    <Input
                      type="number"
                      min={300}
                      max={2000}
                      value={logoMotion.perspective ?? 600}
                      onChange={(e) => setLogoMotion((m) => ({ ...m, perspective: Number(e.target.value) }))}
                      className="mt-1 w-32"
                    />
                    <p className="text-[10px] text-muted-foreground mt-1">قيمة أقل = تأثير ثلاثي الأبعاد أقوى. الافتراضي: 600</p>
                  </div>
                </div>
              )}

              <div className="flex items-center justify-between gap-3 pt-2">
                <Button variant="outline" size="sm" onClick={resetLogoConfig} disabled={saving}>
                  <RotateCcw className="mr-1.5 size-3.5" /> استرجاع الافتراضي
                </Button>
                <Button onClick={saveLogoConfig} disabled={saving} size="sm" className="bg-zinc-900 hover:bg-zinc-800">
                  {saving ? <Loader2 className="mr-1.5 size-4 animate-spin" /> : <Save className="mr-1.5 size-4" />}
                  حفظ الإعدادات
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* ==================== VISUAL EFFECTS ==================== */}
        <TabsContent value="effects" className="space-y-4 mt-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-base flex items-center gap-2">
                <Sparkles className="size-4" /> التأثيرات البصرية
              </CardTitle>
              <CardDescription>
                ظلال، توهج، حدود، خلفية، وزوايا مدورة حول اللوغو. مفيد لإخفاء الجوانب السوداء المحيطة باللوغو إذا كانت ناتجة عن عناصر CSS قابلة للتعديل.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Border radius + padding */}
              <div className="grid gap-4 sm:grid-cols-2">
                <div>
                  <Label className="text-xs">زوايا مدورة (px)</Label>
                  <Input
                    type="number"
                    min={0}
                    max={50}
                    value={logoVisual.borderRadius}
                    onChange={(e) => setLogoVisual((v) => ({ ...v, borderRadius: Number(e.target.value) }))}
                    className="mt-1"
                  />
                </div>
                <div>
                  <Label className="text-xs">مسافة داخلية (Padding, px)</Label>
                  <Input
                    type="number"
                    min={0}
                    max={20}
                    value={logoVisual.padding}
                    onChange={(e) => setLogoVisual((v) => ({ ...v, padding: Number(e.target.value) }))}
                    className="mt-1"
                  />
                </div>
              </div>

              <Separator />

              {/* Shadow */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <Label className="text-sm font-medium">الظل (Shadow)</Label>
                  <Switch
                    checked={!!logoVisual.shadow}
                    onCheckedChange={(on) => setLogoVisual((v) => ({
                      ...v,
                      shadow: on ? { color: 'rgba(0,0,0,0.15)', blur: 6, offsetX: 0, offsetY: 2 } : null,
                    }))}
                  />
                </div>
                {logoVisual.shadow && (
                  <div className="grid gap-3 sm:grid-cols-4">
                    <div>
                      <Label className="text-xs">اللون</Label>
                      <Input
                        value={logoVisual.shadow.color}
                        onChange={(e) => setLogoVisual((v) => v.shadow ? ({ ...v, shadow: { ...v.shadow, color: e.target.value } }) : v)}
                        className="mt-1"
                        dir="ltr"
                      />
                    </div>
                    <div>
                      <Label className="text-xs">الضبابية (Blur)</Label>
                      <Input
                        type="number"
                        min={0}
                        max={30}
                        value={logoVisual.shadow.blur}
                        onChange={(e) => setLogoVisual((v) => v.shadow ? ({ ...v, shadow: { ...v.shadow, blur: Number(e.target.value) } }) : v)}
                        className="mt-1"
                      />
                    </div>
                    <div>
                      <Label className="text-xs">إزاحة X</Label>
                      <Input
                        type="number"
                        min={-10}
                        max={10}
                        value={logoVisual.shadow.offsetX}
                        onChange={(e) => setLogoVisual((v) => v.shadow ? ({ ...v, shadow: { ...v.shadow, offsetX: Number(e.target.value) } }) : v)}
                        className="mt-1"
                      />
                    </div>
                    <div>
                      <Label className="text-xs">إزاحة Y</Label>
                      <Input
                        type="number"
                        min={-10}
                        max={10}
                        value={logoVisual.shadow.offsetY}
                        onChange={(e) => setLogoVisual((v) => v.shadow ? ({ ...v, shadow: { ...v.shadow, offsetY: Number(e.target.value) } }) : v)}
                        className="mt-1"
                      />
                    </div>
                  </div>
                )}
              </div>

              <Separator />

              {/* Glow */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <Label className="text-sm font-medium">التوهج (Glow)</Label>
                  <Switch
                    checked={!!logoVisual.glow}
                    onCheckedChange={(on) => setLogoVisual((v) => ({
                      ...v,
                      glow: on ? { color: '#EA580C', blur: 12, intensity: 0.5 } : null,
                    }))}
                  />
                </div>
                {logoVisual.glow && (
                  <div className="grid gap-3 sm:grid-cols-3">
                    <div>
                      <Label className="text-xs">اللون</Label>
                      <Input
                        value={logoVisual.glow.color}
                        onChange={(e) => setLogoVisual((v) => v.glow ? ({ ...v, glow: { ...v.glow, color: e.target.value } }) : v)}
                        className="mt-1"
                        dir="ltr"
                      />
                    </div>
                    <div>
                      <Label className="text-xs">الضبابية</Label>
                      <Input
                        type="number"
                        min={0}
                        max={40}
                        value={logoVisual.glow.blur}
                        onChange={(e) => setLogoVisual((v) => v.glow ? ({ ...v, glow: { ...v.glow, blur: Number(e.target.value) } }) : v)}
                        className="mt-1"
                      />
                    </div>
                    <div>
                      <Label className="text-xs">الشدة (0-1)</Label>
                      <Input
                        type="number"
                        min={0}
                        max={1}
                        step={0.1}
                        value={logoVisual.glow.intensity}
                        onChange={(e) => setLogoVisual((v) => v.glow ? ({ ...v, glow: { ...v.glow, intensity: Number(e.target.value) } }) : v)}
                        className="mt-1"
                      />
                    </div>
                  </div>
                )}
              </div>

              <Separator />

              {/* Border */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <Label className="text-sm font-medium">الحدود (Border)</Label>
                  <Switch
                    checked={!!logoVisual.border}
                    onCheckedChange={(on) => setLogoVisual((v) => ({
                      ...v,
                      border: on ? { color: '#E5E5E5', width: 1, style: 'solid' } : null,
                    }))}
                  />
                </div>
                {logoVisual.border && (
                  <div className="grid gap-3 sm:grid-cols-3">
                    <div>
                      <Label className="text-xs">اللون</Label>
                      <Input
                        value={logoVisual.border.color}
                        onChange={(e) => setLogoVisual((v) => v.border ? ({ ...v, border: { ...v.border, color: e.target.value } }) : v)}
                        className="mt-1"
                        dir="ltr"
                      />
                    </div>
                    <div>
                      <Label className="text-xs">السماكة (px)</Label>
                      <Input
                        type="number"
                        min={0}
                        max={5}
                        value={logoVisual.border.width}
                        onChange={(e) => setLogoVisual((v) => v.border ? ({ ...v, border: { ...v.border, width: Number(e.target.value) } }) : v)}
                        className="mt-1"
                      />
                    </div>
                    <div>
                      <Label className="text-xs">النمط</Label>
                      <select
                        value={logoVisual.border.style}
                        onChange={(e) => setLogoVisual((v) => v.border ? ({ ...v, border: { ...v.border, style: e.target.value as 'solid' | 'dashed' | 'dotted' } }) : v)}
                        className="mt-1 w-full rounded-md border border-border bg-card px-3 py-2 text-sm"
                      >
                        <option value="solid">مستمر</option>
                        <option value="dashed">متقطع</option>
                        <option value="dotted">منقط</option>
                      </select>
                    </div>
                  </div>
                )}
              </div>

              <Separator />

              {/* Background */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <Label className="text-sm font-medium">الخلفية (Background)</Label>
                  <Switch
                    checked={!!logoVisual.background}
                    onCheckedChange={(on) => setLogoVisual((v) => ({
                      ...v,
                      background: on ? { color: '#FFFFFF', opacity: 1 } : null,
                    }))}
                  />
                </div>
                {logoVisual.background && (
                  <div className="grid gap-3 sm:grid-cols-2">
                    <div>
                      <Label className="text-xs">اللون (hex أو transparent)</Label>
                      <Input
                        value={logoVisual.background.color}
                        onChange={(e) => setLogoVisual((v) => v.background ? ({ ...v, background: { ...v.background, color: e.target.value } }) : v)}
                        className="mt-1"
                        dir="ltr"
                      />
                    </div>
                    <div>
                      <Label className="text-xs">الشفافية (0-1)</Label>
                      <Input
                        type="number"
                        min={0}
                        max={1}
                        step={0.1}
                        value={logoVisual.background.opacity}
                        onChange={(e) => setLogoVisual((v) => v.background ? ({ ...v, background: { ...v.background, opacity: Number(e.target.value) } }) : v)}
                        className="mt-1"
                      />
                    </div>
                  </div>
                )}
              </div>

              <div className="rounded-md border border-amber-200 bg-amber-50 p-3 text-xs text-amber-800">
                <strong>ملاحظة حول الجوانب السوداء:</strong> إذا كانت الجوانب السوداء جزءاً من ملف الصورة نفسه (PNG)، لا يمكن لـ CSS إزالتها — يجب استبدال الصورة أو معالجتها. الإعدادات هنا تتحكم فقط في العناصر المحيطة باللوغو (الخلفية، الحدود، الظلال).
              </div>

              <div className="flex items-center justify-between gap-3 pt-2">
                <Button variant="outline" size="sm" onClick={resetLogoConfig} disabled={saving}>
                  <RotateCcw className="mr-1.5 size-3.5" /> استرجاع الافتراضي
                </Button>
                <Button onClick={saveLogoConfig} disabled={saving} size="sm" className="bg-zinc-900 hover:bg-zinc-800">
                  {saving ? <Loader2 className="mr-1.5 size-4 animate-spin" /> : <Save className="mr-1.5 size-4" />}
                  حفظ التأثيرات
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* ==================== MOBILE ==================== */}
        <TabsContent value="mobile" className="space-y-4 mt-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">إعدادات الهاتف</CardTitle>
              <CardDescription>
                تحكم مستقل في الأنيميشن على الهاتف. يمكن تعطيل الحركة على الهاتف دون الحاسوب، أو استخدام حجم مختلف.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium">تعطيل الأنيميشن على الهاتف</p>
                  <p className="text-muted-foreground text-xs">عند التفعيل، يبقى اللوغو ثابتاً على الهاتف (لأداء أفضل أو توفير البطارية)</p>
                </div>
                <Switch
                  checked={logoMobile.disableAnimation}
                  onCheckedChange={(v) => setLogoMobile((m) => ({ ...m, disableAnimation: v }))}
                />
              </div>

              <Separator />

              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <Label className="text-sm font-medium">حجم مختلف للهاتف</Label>
                  <Switch
                    checked={!!logoMobile.size}
                    onCheckedChange={(on) => setLogoMobile((m) => ({
                      ...m,
                      size: on ? { width: 32, height: 32, maintainAspectRatio: true } : null,
                    }))}
                  />
                </div>
                {logoMobile.size && (
                  <div className="grid gap-3 sm:grid-cols-2">
                    <div>
                      <Label className="text-xs">العرض (8-200)</Label>
                      <Input
                        type="number"
                        min={8}
                        max={200}
                        value={logoMobile.size.width}
                        onChange={(e) => setLogoMobile((m) => m.size ? ({ ...m, size: { ...m.size, width: Number(e.target.value) } }) : m)}
                        className="mt-1"
                      />
                    </div>
                    <div>
                      <Label className="text-xs">الارتفاع (8-200)</Label>
                      <Input
                        type="number"
                        min={8}
                        max={200}
                        value={logoMobile.size.height}
                        onChange={(e) => setLogoMobile((m) => m.size ? ({ ...m, size: { ...m.size, height: Number(e.target.value) } }) : m)}
                        className="mt-1"
                      />
                    </div>
                  </div>
                )}
              </div>

              <Separator />

              <div>
                <Label className="text-xs">نقطة الفصل (Breakpoint, px)</Label>
                <Input
                  type="number"
                  min={320}
                  max={1024}
                  value={logoMobile.breakpoint}
                  onChange={(e) => setLogoMobile((m) => ({ ...m, breakpoint: Number(e.target.value) }))}
                  className="mt-1 w-32"
                />
                <p className="text-[10px] text-muted-foreground mt-1">أقل من هذه القيمة = هاتف. الافتراضي: 768</p>
              </div>

              <div className="rounded-md border border-blue-200 bg-blue-50 p-3 text-xs text-blue-800">
                <strong>تقليل الحركة:</strong> النظام يحترم إعداد "تقليل الحركة" في نظام التشغيل تلقائياً — إذا فعّل المستخدم هذا الإعداد، يتوقف الأنيميشن على جميع الأجهزة بغض النظر عن الإعدادات هنا.
              </div>

              <div className="flex items-center justify-between gap-3 pt-2">
                <Button variant="outline" size="sm" onClick={resetLogoConfig} disabled={saving}>
                  <RotateCcw className="mr-1.5 size-3.5" /> استرجاع الافتراضي
                </Button>
                <Button onClick={saveLogoConfig} disabled={saving} size="sm" className="bg-zinc-900 hover:bg-zinc-800">
                  {saving ? <Loader2 className="mr-1.5 size-4 animate-spin" /> : <Save className="mr-1.5 size-4" />}
                  حفظ إعدادات الهاتف
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* ==================== FAVICON ==================== */}
        <TabsContent value="favicon" className="space-y-4 mt-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-base flex items-center gap-2">
                <ImageIcon className="size-4" /> الفافيكون (أيقونة التبويب)
              </CardTitle>
              <CardDescription>
                الصورة اللي غادي تبان فتبويب المتصفح بجانب اسم الموقع. حالياً: {settings.favicon_url ? 'مخصص' : 'افتراضي (Z mark)'}.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-5">
              {/* Current favicon preview */}
              <div className="flex items-center gap-4 rounded-lg border border-border p-4 bg-muted/30">
                <div className="relative grid size-12 place-items-center rounded-lg bg-card shadow-[var(--shadow-xs)]">
                  {settings.favicon_url ? (
                    <img src={settings.favicon_url} alt="Current favicon" className="size-8 object-contain" />
                  ) : (
                    <img src="/logo.svg" alt="Default favicon" className="size-8 object-contain" />
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="text-xs font-medium uppercase tracking-wide text-muted-foreground">الحالي</div>
                  {settings.favicon_url ? (
                    <a href={settings.favicon_url} target="_blank" rel="noopener noreferrer" className="block truncate text-sm font-mono hover:underline">
                      {settings.favicon_url}
                    </a>
                  ) : (
                    <div className="text-sm text-muted-foreground">الفافيكون الافتراضي (/logo.svg + ملفات PNG/ICO ثابتة)</div>
                  )}
                </div>
                {settings.favicon_url && (
                  <Button variant="outline" size="sm" onClick={resetFavicon} disabled={saving}>
                    <RotateCcw className="mr-1.5 size-3.5" /> رجوع للافتراضي
                  </Button>
                )}
              </div>

              {/* Upload from computer */}
              <div>
                <Label className="mb-1.5 block">الرفع من الجهاز</Label>
                <div
                  onClick={() => favFileRef.current?.click()}
                  className="border-2 border-dashed rounded-lg p-6 text-center cursor-pointer hover:bg-muted/50 transition-colors"
                >
                  <input
                    ref={favFileRef}
                    type="file"
                    accept={ALLOWED_FAVICON_TYPES.join(',')}
                    className="hidden"
                    onChange={(e) => {
                      const f = e.target.files?.[0]
                      if (f) uploadFavicon(f)
                    }}
                  />
                  {favUploading ? (
                    <div className="flex flex-col items-center gap-2 text-muted-foreground">
                      <Loader2 className="size-6 animate-spin" />
                      <p className="text-sm">جارٍ الرفع…</p>
                    </div>
                  ) : (
                    <div className="flex flex-col items-center gap-2 text-muted-foreground">
                      <Upload className="size-6" />
                      <p className="text-sm font-medium">اضغط لاختيار ملف الفافيكون</p>
                      <p className="text-xs">PNG (16/32/48/180), ICO, SVG, WebP — حد أقصى 2 MB</p>
                    </div>
                  )}
                </div>
              </div>

              <Separator />

              {/* External URL */}
              <div>
                <Label className="mb-1.5 block">رابط مباشر لصورة الفافيكون</Label>
                <div className="grid gap-2 sm:grid-cols-2">
                  <Input
                    placeholder="https://example.com/favicon.png"
                    value={favExternalUrl}
                    onChange={(e) => {
                      setFavExternalUrl(e.target.value)
                      setFavExternalPreview(null)
                      setFavExternalError(null)
                    }}
                    dir="ltr"
                    className="text-left"
                  />
                  <div className="flex gap-2">
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      onClick={() => setFavExternalPreview(favExternalUrl.trim())}
                      disabled={!favExternalUrl}
                    >
                      <Globe className="size-4" /> معاينة
                    </Button>
                    <Button
                      type="button"
                      size="sm"
                      onClick={saveFaviconExternal}
                      disabled={saving || !favExternalUrl}
                      className="bg-zinc-900 hover:bg-zinc-800"
                    >
                      {saving ? <Loader2 className="size-4 animate-spin" /> : <Save className="size-4" />} حفظ
                    </Button>
                  </div>
                </div>
                {favExternalError && <p className="mt-1.5 text-xs text-rose-600">{favExternalError}</p>}
                {favExternalPreview && (
                  <div className="mt-2 inline-block bg-white border rounded-md p-2">
                    {favExternalError ? (
                      <p className="text-rose-600 text-xs p-4">الرابط غير صالح أو تعذر تحميل الصورة.</p>
                    ) : (
                      <img
                        src={favExternalPreview}
                        alt="معاينة الفافيكون"
                        className="size-16 object-contain"
                        onError={() => setFavExternalError('الرابط غير صالح أو تعذر تحميل الصورة.')}
                      />
                    )}
                  </div>
                )}
              </div>

              {/* Info note about cache busting */}
              <div className="rounded-md border border-blue-200 bg-blue-50 p-3 text-xs text-blue-800">
                <strong>ملاحظة:</strong> بعد تغيير الفافيكون، قد يحتاج المتصفح لعدة دقائق أو إعادة تحميل قسري (Ctrl+Shift+R) لعرض الأيقونة الجديدة. النظام يضيف تلقائياً معامل عشوائي للرابط (cache busting) لتسريع التحديث.
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* ==================== VARIANT LOGOS ==================== */}
        <TabsContent value="variants" className="space-y-4 mt-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">شعارات إضافية (اختياري)</CardTitle>
              <CardDescription>شعارات لخلفيات فاتحة/داكنة، أو للجوال.</CardDescription>
            </CardHeader>
            <CardContent className="grid gap-4 sm:grid-cols-2">
              {([
                { key: 'logo_light_url' as const, label: 'شعار خلفية فاتحة', hint: 'يستعمل على الترويسة الفاتحة' },
                { key: 'logo_dark_url' as const, label: 'شعار خلفية داكنة', hint: 'يستعمل على الترويسة الداكنة' },
                { key: 'logo_mobile_url' as const, label: 'شعار الجوال', hint: 'مخصص لحجم الجوال' },
              ]).map((f) => (
                <div key={f.key} className="space-y-1.5">
                  <Label htmlFor={f.key}>{f.label}</Label>
                  <Input
                    id={f.key}
                    value={settings[f.key] ?? ''}
                    onChange={(e) => setSettings((s) => ({ ...s, [f.key]: e.target.value }))}
                    placeholder="https://…"
                    dir="ltr"
                    className="text-left"
                  />
                  {f.hint && <p className="text-xs text-muted-foreground">{f.hint}</p>}
                </div>
              ))}
              <div className="sm:col-span-2 flex justify-end">
                <Button onClick={saveVariants} disabled={saving} size="sm" className="bg-zinc-900 hover:bg-zinc-800">
                  {saving ? <Loader2 className="mr-1.5 size-4 animate-spin" /> : <Save className="mr-1.5 size-4" />} حفظ
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* ==================== COLORS ==================== */}
        <TabsContent value="colors" className="space-y-4 mt-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">الألوان</CardTitle>
            </CardHeader>
            <CardContent className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-1.5">
                <Label htmlFor="primary_color">اللون الأساسي (Hex)</Label>
                <div className="flex items-center gap-2">
                  <Input
                    id="primary_color"
                    value={settings.primary_color ?? ''}
                    onChange={(e) => setSettings((s) => ({ ...s, primary_color: e.target.value }))}
                    placeholder="#B23A0E"
                    dir="ltr"
                    className="text-left"
                  />
                  <div
                    className="size-10 rounded-md border"
                    style={{
                      backgroundColor:
                        settings.primary_color && isValidHex(settings.primary_color)
                          ? settings.primary_color
                          : '#B23A0E',
                    }}
                  />
                </div>
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="accent_color">لون التمييز (Hex)</Label>
                <div className="flex items-center gap-2">
                  <Input
                    id="accent_color"
                    value={settings.accent_color ?? ''}
                    onChange={(e) => setSettings((s) => ({ ...s, accent_color: e.target.value }))}
                    placeholder="#9A6A1E"
                    dir="ltr"
                    className="text-left"
                  />
                  <div
                    className="size-10 rounded-md border"
                    style={{
                      backgroundColor:
                        settings.accent_color && isValidHex(settings.accent_color)
                          ? settings.accent_color
                          : '#9A6A1E',
                    }}
                  />
                </div>
              </div>
              <div className="sm:col-span-2 flex justify-end">
                <Button onClick={saveColors} disabled={saving} size="sm" className="bg-zinc-900 hover:bg-zinc-800">
                  {saving ? <Loader2 className="mr-1.5 size-4 animate-spin" /> : <Save className="mr-1.5 size-4" />} حفظ الألوان
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

function clamp(n: number, min: number, max: number): number {
  if (Number.isNaN(n)) return min
  return Math.max(min, Math.min(max, n))
}
