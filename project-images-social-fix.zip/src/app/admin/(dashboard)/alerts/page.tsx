'use client'

import * as React from 'react'
import Link from 'next/link'
import {
  AlertTriangle, AlertCircle, Info, Loader2, RefreshCw, Bell,
  CheckCircle2, Package, ShoppingCart, Star, Plug, Search,
} from 'lucide-react'
import { toast } from 'sonner'

import { PageHeader, Spinner } from '@/components/admin/page-header'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'

interface Alert {
  id: string
  severity: 'critical' | 'warning' | 'info'
  category: string
  title: string
  description: string
  actionUrl?: string
  actionLabel?: string
  createdAt: string
}

interface AlertsData {
  alerts: Alert[]
  summary: {
    total: number
    critical: number
    warning: number
    info: number
  }
}

const SEVERITY_CONFIG = {
  critical: {
    icon: AlertCircle,
    color: 'text-rose-600',
    bg: 'bg-rose-50',
    border: 'border-rose-200',
    badge: 'bg-rose-100 text-rose-700',
    label: 'حرج',
  },
  warning: {
    icon: AlertTriangle,
    color: 'text-amber-600',
    bg: 'bg-amber-50',
    border: 'border-amber-200',
    badge: 'bg-amber-100 text-amber-700',
    label: 'تحذير',
  },
  info: {
    icon: Info,
    color: 'text-blue-600',
    bg: 'bg-blue-50',
    border: 'border-blue-200',
    badge: 'bg-blue-100 text-blue-700',
    label: 'معلومة',
  },
}

const CATEGORY_ICONS: Record<string, any> = {
  inventory: Package,
  orders: ShoppingCart,
  reviews: Star,
  integration: Plug,
  seo: Search,
}

export default function AlertsPage() {
  const [data, setData] = React.useState<AlertsData | null>(null)
  const [loading, setLoading] = React.useState(true)
  const [refreshing, setRefreshing] = React.useState(false)

  async function load() {
    setRefreshing(true)
    try {
      const res = await fetch('/api/admin/alerts', { credentials: 'include' })
      const json = await res.json()
      if (json.ok) setData(json)
    } catch {
      toast.error('خطأ في الشبكة')
    } finally {
      setLoading(false)
      setRefreshing(false)
    }
  }

  React.useEffect(() => { load() }, [])

  if (loading || !data) {
    return (
      <div className="space-y-6">
        <PageHeader title="مركز التنبيهات" description="تنبيهات حقيقية من النظام" breadcrumb={[{ label: 'الإدارة', href: '/admin/dashboard' }, { label: 'التنبيهات' }]} />
        <Spinner />
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <PageHeader
        title="مركز التنبيهات"
        description="تنبيهات حقيقية من قاعدة البيانات وحالة النظام"
        breadcrumb={[{ label: 'الإدارة', href: '/admin/dashboard' }, { label: 'التنبيهات' }]}
        actions={
          <Button variant="outline" size="icon" onClick={load} disabled={refreshing}>
            {refreshing ? <Loader2 className="size-4 animate-spin" /> : <RefreshCw className="size-4" />}
          </Button>
        }
      />

      {/* Summary cards */}
      <div className="grid gap-4 sm:grid-cols-3">
        <Card className={data.summary.critical > 0 ? 'border-rose-300 bg-rose-50/50' : ''}>
          <CardContent className="p-4 flex items-center justify-between">
            <div>
              <p className="text-xs text-muted-foreground">حرج</p>
              <p className="mt-1 font-display text-2xl font-bold text-rose-600">{data.summary.critical}</p>
            </div>
            <AlertCircle className="size-6 text-rose-600/40" />
          </CardContent>
        </Card>
        <Card className={data.summary.warning > 0 ? 'border-amber-300 bg-amber-50/50' : ''}>
          <CardContent className="p-4 flex items-center justify-between">
            <div>
              <p className="text-xs text-muted-foreground">تحذير</p>
              <p className="mt-1 font-display text-2xl font-bold text-amber-600">{data.summary.warning}</p>
            </div>
            <AlertTriangle className="size-6 text-amber-600/40" />
          </CardContent>
        </Card>
        <Card className={data.summary.info > 0 ? 'border-blue-300 bg-blue-50/50' : ''}>
          <CardContent className="p-4 flex items-center justify-between">
            <div>
              <p className="text-xs text-muted-foreground">معلومة</p>
              <p className="mt-1 font-display text-2xl font-bold text-blue-600">{data.summary.info}</p>
            </div>
            <Info className="size-6 text-blue-600/40" />
          </CardContent>
        </Card>
      </div>

      {/* Alerts list */}
      {data.alerts.length === 0 ? (
        <Card>
          <CardContent className="py-12 text-center">
            <CheckCircle2 className="size-12 text-emerald-600 mx-auto" />
            <p className="mt-3 font-medium text-emerald-700">لا توجد تنبيهات</p>
            <p className="mt-1 text-sm text-muted-foreground">كل شيء يعمل بشكل طبيعي.</p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-3">
          {data.alerts.map((alert) => {
            const config = SEVERITY_CONFIG[alert.severity]
            const Icon = config.icon
            const CategoryIcon = CATEGORY_ICONS[alert.category] || Bell
            return (
              <Card key={alert.id} className={`${config.border} ${config.bg}`}>
                <CardContent className="p-4">
                  <div className="flex items-start gap-3">
                    <div className={`grid size-9 flex-shrink-0 place-items-center rounded-lg ${config.bg} ${config.color}`}>
                      <Icon className="size-4" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex flex-wrap items-center gap-2">
                        <p className="font-medium text-sm text-foreground">{alert.title}</p>
                        <Badge variant="outline" className={config.badge}>{config.label}</Badge>
                        <Badge variant="ghost" className="text-xs gap-1">
                          <CategoryIcon className="size-3" />
                          {alert.category}
                        </Badge>
                      </div>
                      <p className="mt-1 text-sm text-muted-foreground">{alert.description}</p>
                      {alert.actionUrl && alert.actionLabel && (
                        <Link
                          href={alert.actionUrl}
                          className={`mt-2 inline-flex items-center gap-1 text-sm font-medium ${config.color} hover:underline`}
                        >
                          {alert.actionLabel} →
                        </Link>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            )
          })}
        </div>
      )}

      <p className="text-xs text-muted-foreground text-center">
        آخر تحديث: {new Date().toLocaleString('ar-MA')}
      </p>
    </div>
  )
}
