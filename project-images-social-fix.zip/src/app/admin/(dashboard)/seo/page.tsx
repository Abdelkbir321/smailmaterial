'use client'

import * as React from 'react'
import { Loader2, Save, RefreshCw, ExternalLink, Search, Plus, Trash2, AlertTriangle, CheckCircle2, Link2, Globe, FileText, Menu, Eye, ShieldCheck, KeyRound, Info } from 'lucide-react'
import { toast } from 'sonner'

import { PageHeader, Spinner } from '@/components/admin/page-header'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Switch } from '@/components/ui/switch'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Badge } from '@/components/ui/badge'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'

interface Redirect {
  id: string
  fromPath: string
  toPath: string
  statusCode: number
  isActive: boolean
  createdAt: string
  updatedAt: string
}

interface SitemapStatus {
  ok: boolean
  siteUrl: string
  sitemapUrl: string
  robotsUrl: string
  counts: {
    productsPublished: number
    productsDraft: number
    productsArchived: number
    productsNoindex: number
    categoriesVisible: number
    categoriesHidden: number
    brandsVisible: number
    pagesVisible: number
  }
  redirects: { active: number; total: number }
  totalUrls: number
  lastContentUpdate: string | null
}

interface Settings {
  seo_title?: string
  seo_description?: string
  seo_keywords?: string
  og_default_image?: string
  og_default_title?: string
  site_url?: string
  robots_extra_disallow?: string
  hreflang_enabled?: string
  // Google Search Console verification
  gsc_verification_token?: string
  gsc_verification_file_content?: string
  // Site identity defaults (also editable in /admin/visual-identity, but
  // surfaced here for a single-source-of-truth workflow)
  site_name?: string
  site_tagline?: string
  site_description?: string
}

interface Conflict {
  type: string
  id: string
  name: string
  url: string
}

export default function AdminSeoPage() {
  const [loading, setLoading] = React.useState(true)
  const [savingSettings, setSavingSettings] = React.useState(false)
  const [revalidating, setRevalidating] = React.useState(false)
  const [settings, setSettings] = React.useState<Settings>({})
  const [status, setStatus] = React.useState<SitemapStatus | null>(null)
  const [redirects, setRedirects] = React.useState<Redirect[]>([])

  // New redirect form
  const [newFrom, setNewFrom] = React.useState('')
  const [newTo, setNewTo] = React.useState('')
  const [newStatus, setNewStatus] = React.useState<301 | 302>(301)

  // Slug-check
  const [slugInput, setSlugInput] = React.useState('')
  const [slugConflicts, setSlugConflicts] = React.useState<Conflict[] | null>(null)
  const [slugChecking, setSlugChecking] = React.useState(false)

  // OG preview
  const [ogType, setOgType] = React.useState<'home' | 'product' | 'category' | 'brand' | 'page'>('product')
  const [ogSlug, setOgSlug] = React.useState('')
  const [ogTitle, setOgTitle] = React.useState('')
  const [ogDescription, setOgDescription] = React.useState('')
  const [ogImage, setOgImage] = React.useState('')
  const [ogPreview, setOgPreview] = React.useState<any>(null)
  const [ogLoading, setOgLoading] = React.useState(false)

  async function loadAll() {
    setLoading(true)
    try {
      const [setRes, statusRes, redRes] = await Promise.all([
        fetch('/api/admin/settings', { credentials: 'include' }),
        fetch('/api/admin/seo/sitemap-status', { credentials: 'include' }),
        fetch('/api/admin/redirects', { credentials: 'include' }),
      ])
      const setJson = await setRes.json()
      const statusJson = await statusRes.json()
      const redJson = await redRes.json()
      if (setJson.ok) {
        const s: Settings = {}
        for (const k of ['seo_title', 'seo_description', 'seo_keywords', 'og_default_image', 'og_default_title', 'site_url', 'robots_extra_disallow', 'hreflang_enabled', 'gsc_verification_token', 'gsc_verification_file_content', 'site_name', 'site_tagline', 'site_description']) {
          if (setJson.settings?.[k] !== undefined) s[k as keyof Settings] = setJson.settings[k]
        }
        setSettings(s)
      }
      if (statusJson.ok) setStatus(statusJson)
      if (redJson.ok) setRedirects(redJson.redirects || [])
    } catch {
      toast.error('خطأ في الشبكة')
    } finally {
      setLoading(false)
    }
  }

  React.useEffect(() => {
    loadAll()
  }, [])

  async function saveSettingsKeys() {
    setSavingSettings(true)
    try {
      const res = await fetch('/api/admin/settings', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ settings }),
        credentials: 'include',
      })
      const json = await res.json()
      if (!res.ok || !json.ok) {
        toast.error(json.error || 'فشل الحفظ')
        return
      }
      toast.success('تم حفظ إعدادات SEO')
    } catch {
      toast.error('خطأ في الشبكة')
    } finally {
      setSavingSettings(false)
    }
  }

  async function revalidateNow() {
    setRevalidating(true)
    try {
      const res = await fetch('/api/admin/seo/revalidate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({}),
        credentials: 'include',
      })
      const json = await res.json()
      if (!res.ok || !json.ok) {
        toast.error(json.error || 'فشل التحديث')
        return
      }
      toast.success('تم تحديث Sitemap وrobots.txt وRedirects')
      // Re-fetch status
      const s = await fetch('/api/admin/seo/sitemap-status', { credentials: 'include' })
      const sj = await s.json()
      if (sj.ok) setStatus(sj)
    } catch {
      toast.error('خطأ في الشبكة')
    } finally {
      setRevalidating(false)
    }
  }

  async function checkSlug() {
    if (!slugInput.trim()) return
    setSlugChecking(true)
    setSlugConflicts(null)
    try {
      const res = await fetch(`/api/admin/seo/slug-check?slug=${encodeURIComponent(slugInput.trim())}`, { credentials: 'include' })
      const json = await res.json()
      if (!res.ok || !json.ok) {
        toast.error(json.error || 'فشل الفحص')
        return
      }
      setSlugConflicts(json.conflicts || [])
      if ((json.conflicts || []).length === 0) toast.success('الـ Slug متاح')
    } catch {
      toast.error('خطأ في الشبكة')
    } finally {
      setSlugChecking(false)
    }
  }

  async function createRedirect() {
    if (!newFrom.trim() || !newTo.trim()) {
      toast.error('الرابط المصدر والوجهة مطلوبان')
      return
    }
    try {
      const res = await fetch('/api/admin/redirects', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          fromPath: newFrom.trim().startsWith('/') ? newFrom.trim() : `/${newFrom.trim()}`,
          toPath: newTo.trim(),
          statusCode: newStatus,
          isActive: true,
        }),
        credentials: 'include',
      })
      const json = await res.json()
      if (!res.ok || !json.ok) {
        toast.error(json.error || 'فشل الإنشاء')
        return
      }
      toast.success('تم إنشاء التوجيه')
      setNewFrom('')
      setNewTo('')
      // Refresh
      const r = await fetch('/api/admin/redirects', { credentials: 'include' })
      const rj = await r.json()
      if (rj.ok) setRedirects(rj.redirects || [])
    } catch {
      toast.error('خطأ في الشبكة')
    }
  }

  async function toggleRedirect(id: string, active: boolean) {
    try {
      const res = await fetch(`/api/admin/redirects/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ isActive: active }),
        credentials: 'include',
      })
      const json = await res.json()
      if (!res.ok || !json.ok) {
        toast.error(json.error || 'فشل التحديث')
        return
      }
      setRedirects((prev) => prev.map((r) => r.id === id ? { ...r, isActive: active } : r))
      toast.success(active ? 'تم تفعيل التوجيه' : 'تم تعطيل التوجيه')
    } catch {
      toast.error('خطأ في الشبكة')
    }
  }

  async function deleteRedirect(id: string) {
    if (!confirm('متأكد من حذف هذا التوجيه؟')) return
    try {
      const res = await fetch(`/api/admin/redirects/${id}`, {
        method: 'DELETE',
        credentials: 'include',
      })
      const json = await res.json()
      if (!res.ok || !json.ok) {
        toast.error(json.error || 'فشل الحذف')
        return
      }
      setRedirects((prev) => prev.filter((r) => r.id !== id))
      toast.success('تم حذف التوجيه')
    } catch {
      toast.error('خطأ في الشبكة')
    }
  }

  async function previewOg() {
    setOgLoading(true)
    setOgPreview(null)
    try {
      const res = await fetch('/api/admin/seo/og-preview', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ type: ogType, slug: ogSlug, title: ogTitle, description: ogDescription, image: ogImage }),
        credentials: 'include',
      })
      const json = await res.json()
      if (!res.ok || !json.ok) {
        toast.error(json.error || 'فشلت المعاينة')
        return
      }
      setOgPreview(json)
    } catch {
      toast.error('خطأ في الشبكة')
    } finally {
      setOgLoading(false)
    }
  }

  if (loading) {
    return (
      <>
        <PageHeader title="SEO والروابط" description="إعدادات تحسين محركات البحث، التوجيهات، وحالة Sitemap" />
        <Spinner />
      </>
    )
  }

  return (
    <>
      <PageHeader
        title="SEO والروابط"
        description="إعدادات تحسين محركات البحث، التوجيهات 301/302، وحالة Sitemap"
        actions={
          <Button onClick={revalidateNow} disabled={revalidating} variant="outline">
            {revalidating ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <RefreshCw className="mr-2 h-4 w-4" />}
            تحديث Sitemap فوراً
          </Button>
        }
      />

      <Tabs defaultValue="general" className="mt-6">
        <TabsList className="grid w-full grid-cols-2 md:grid-cols-6">
          <TabsTrigger value="general">عام</TabsTrigger>
          <TabsTrigger value="domain">الدومين والنشر</TabsTrigger>
          <TabsTrigger value="redirects">التوجيهات</TabsTrigger>
          <TabsTrigger value="slugs">فحص Slugs</TabsTrigger>
          <TabsTrigger value="preview">معاينة SEO</TabsTrigger>
          <TabsTrigger value="status">حالة Sitemap</TabsTrigger>
        </TabsList>

        {/* GENERAL */}
        <TabsContent value="general" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2"><Globe className="h-4 w-4" /> الدومين الرسمي</CardTitle>
              <CardDescription>يُستعمل لكل الروابط المطلقة، Canonical، Sitemap، و Open Graph. تغييره ممنوع إلا على Super-Admin.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              <div>
                <Label htmlFor="site_url">رابط الموقع الرسمي</Label>
                <Input
                  id="site_url"
                  value={settings.site_url || ''}
                  onChange={(e) => setSettings({ ...settings, site_url: e.target.value })}
                  placeholder="https://example.com"
                  dir="ltr"
                />
                <p className="mt-1 text-xs text-zinc-500">مثال: https://mon-magasin.ma — يجب أن يبدأ بـ https://</p>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2"><FileText className="h-4 w-4" /> بيانات SEO الافتراضية</CardTitle>
              <CardDescription>تُستعمل في الصفحات التي لا تملك عنواناً مخصصاً.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              <div>
                <Label htmlFor="seo_title">عنوان SEO العام</Label>
                <Input
                  id="seo_title"
                  value={settings.seo_title || ''}
                  onChange={(e) => setSettings({ ...settings, seo_title: e.target.value })}
                  maxLength={200}
                  dir="ltr"
                />
                <p className="mt-1 text-xs text-zinc-500">{(settings.seo_title || '').length} / 200</p>
              </div>
              <div>
                <Label htmlFor="seo_description">وصف SEO العام</Label>
                <Textarea
                  id="seo_description"
                  value={settings.seo_description || ''}
                  onChange={(e) => setSettings({ ...settings, seo_description: e.target.value })}
                  rows={3}
                  maxLength={300}
                  dir="ltr"
                />
                <p className="mt-1 text-xs text-zinc-500">{(settings.seo_description || '').length} / 300</p>
              </div>
              <div>
                <Label htmlFor="og_default_image">صورة OG الافتراضية (رابط مطلق)</Label>
                <Input
                  id="og_default_image"
                  value={settings.og_default_image || ''}
                  onChange={(e) => setSettings({ ...settings, og_default_image: e.target.value })}
                  placeholder="https://example.com/og-default.jpg"
                  dir="ltr"
                />
              </div>
              <Button onClick={saveSettingsKeys} disabled={savingSettings}>
                {savingSettings ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Save className="mr-2 h-4 w-4" />}
                حفظ الإعدادات
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        {/* DOMAIN & PUBLISH */}
        <TabsContent value="domain" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2"><Globe className="h-4 w-4" /> الدومين الرسمي (Production Domain)</CardTitle>
              <CardDescription>المصدر الوحيد للحقيقة — يُستعمل لجميع الروابط المطلقة (Sitemap، Canonical، Open Graph، Structured Data).</CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              <div>
                <Label htmlFor="site_url">رابط الموقع الرسمي</Label>
                <Input
                  id="site_url"
                  value={settings.site_url || ''}
                  onChange={(e) => setSettings({ ...settings, site_url: e.target.value })}
                  placeholder="https://example.com"
                  dir="ltr"
                />
                <p className="mt-1 text-xs text-zinc-500">مثال: https://mon-magasin.ma — يجب أن يبدأ بـ https:// ولا يحتوي على مسار أو query.</p>
              </div>
              <div className="rounded-md border border-amber-300 bg-amber-50 p-3 text-xs text-amber-800">
                <div className="mb-1 flex items-center gap-1.5 font-medium"><AlertTriangle className="h-3.5 w-3.5" /> تنبيهات مهمة</div>
                <ul className="list-disc space-y-0.5 pl-5">
                  <li>تغيير الدومين هنا لا يغيّر DNS ولا SSL — خاصك تدير دلك فـ Netlify أو مزود الدومين.</li>
                  <li>Netlify Preview Deployments ما كتدخلش فـ Sitemap الرسمي — غير الدومين المعتمد هنا هو اللي كيتستعمل.</li>
                  <li>هاد الإعداد ممنوع إلا على Super-Admin.</li>
                  <li>إذا تركتيه فارغ، Sitemap وrobots.txt ما كيعرضوش روابط بدومين خاطئ.</li>
                </ul>
              </div>
              <Button onClick={saveSettingsKeys} disabled={savingSettings}>
                {savingSettings ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Save className="mr-2 h-4 w-4" />}
                حفظ الدومين الرسمي
              </Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2"><Info className="h-4 w-4" /> أولوية الإعدادات</CardTitle>
              <CardDescription>كيفاش كنحددو الدومين الرسمي ملي كاين أزيد من مصدر.</CardDescription>
            </CardHeader>
            <CardContent>
              <ol className="list-decimal space-y-1.5 pl-5 text-sm text-zinc-700">
                <li><strong>قاعدة البيانات (site_settings.site_url)</strong> — الأولوية القصوى. يتدار من هاد اللوحة. ممنوع إلا على Super-Admin.</li>
                <li><strong>NEXT_PUBLIC_SITE_URL</strong> — Environment Variable. كيتستعمل غير ملي ما كاينش قيمة فالـ DB. مفيد فـ Netlify preview deployments.</li>
                <li><strong>localhost</strong> — غير فـ Development. ما كيتستعملش فالإنتاج أبداً.</li>
              </ol>
              <p className="mt-3 text-xs text-zinc-500">إذا كان الدومين فالـ DB غير صالح (HTTP فالإنتاج، أو فيه path/query)، كنرجعو للمتغير البيئي. إلا ما كانش حتى واحد صالح، ما كنخترعوش دومين.</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2"><KeyRound className="h-4 w-4" /> Google Search Console — التحقق من الملكية</CardTitle>
              <CardDescription>طريقتان: ملف HTML أو Meta Tag. استعمل واحدة فقط.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="gsc_token">طريقة 1: Meta Tag Verification</Label>
                <Input
                  id="gsc_token"
                  value={settings.gsc_verification_token || ''}
                  onChange={(e) => setSettings({ ...settings, gsc_verification_token: e.target.value })}
                  placeholder="google-site-verification=googleXXXXXXXX.html"
                  dir="ltr"
                />
                <p className="mt-1 text-xs text-zinc-500">انسخ القيمة اللي كتعطيها Google كاملة (مثل: <code dir="ltr">google-site-verification=google1234567890abcdef.html</code>). كتضاف كـ meta tag فالـ HTML.</p>
              </div>
              <div>
                <Label htmlFor="gsc_file">طريقة 2: HTML File Verification</Label>
                <Textarea
                  id="gsc_file"
                  value={settings.gsc_verification_file_content || ''}
                  onChange={(e) => setSettings({ ...settings, gsc_verification_file_content: e.target.value })}
                  placeholder="google-site-verification: google1234567890abcdef.html"
                  rows={2}
                  dir="ltr"
                />
                <p className="mt-1 text-xs text-zinc-500">إذا اخترتي طريقة الملف، انسخ المحتوى اللي كتعطيه Google فالملف (يبدأ بـ <code dir="ltr">google-site-verification: google...</code>). كيتخدم على <code dir="ltr">/googleXXXXXXXX.html</code> تلقائياً.</p>
              </div>
              <div className="rounded-md border border-blue-300 bg-blue-50 p-3 text-xs text-blue-800">
                <div className="mb-1 flex items-center gap-1.5 font-medium"><ShieldCheck className="h-3.5 w-3.5" /> خطوات التحقق</div>
                <ol className="list-decimal space-y-0.5 pl-5">
                  <li>سجّل فـ <a href="https://search.google.com/search-console" target="_blank" rel="noopener noreferrer" className="underline">Google Search Console</a>.</li>
                  <li>أضف Property جديد من نوع "URL prefix" بدومينك الرسمي.</li>
                  <li>اختر طريقة التحقق (HTML file أو Meta tag).</li>
                  <li>الصق القيمة فالحقل المناسب هنا واضغط Save.</li>
                  <li>اضغط "Verify" فـ Google — خاصها تشوف الملف أو الـ meta tag على الدومين الرسمي بعد النشر.</li>
                </ol>
              </div>
              <Button onClick={saveSettingsKeys} disabled={savingSettings}>
                {savingSettings ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Save className="mr-2 h-4 w-4" />}
                حفظ إعدادات التحقق
              </Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2"><FileText className="h-4 w-4" /> هوية الموقع الافتراضية</CardTitle>
              <CardDescription>تُستعمل فالصفحات اللي ما عندهاش عنوان خاص. للوغو والألوان، استعمل صفحة «الهوية البصرية».</CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              <div>
                <Label htmlFor="site_name">اسم المتجر</Label>
                <Input
                  id="site_name"
                  value={settings.site_name || ''}
                  onChange={(e) => setSettings({ ...settings, site_name: e.target.value })}
                  maxLength={120}
                  dir="ltr"
                />
              </div>
              <div>
                <Label htmlFor="site_tagline">الشعار النصي (Tagline)</Label>
                <Input
                  id="site_tagline"
                  value={settings.site_tagline || ''}
                  onChange={(e) => setSettings({ ...settings, site_tagline: e.target.value })}
                  maxLength={200}
                  dir="ltr"
                />
              </div>
              <div>
                <Label htmlFor="site_description">الوصف العام</Label>
                <Textarea
                  id="site_description"
                  value={settings.site_description || ''}
                  onChange={(e) => setSettings({ ...settings, site_description: e.target.value })}
                  rows={3}
                  maxLength={500}
                  dir="ltr"
                />
              </div>
              <Button onClick={saveSettingsKeys} disabled={savingSettings}>
                {savingSettings ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Save className="mr-2 h-4 w-4" />}
                حفظ الهوية
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        {/* REDIRECTS */}
        <TabsContent value="redirects" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2"><Plus className="h-4 w-4" /> إضافة توجيه جديد</CardTitle>
              <CardDescription>عند تغيير slug منتج، أنشئ توجيه 301 من الرابط القديم إلى الجديد للحفاظ على ترتيب البحث.</CardDescription>
            </CardHeader>
            <CardContent className="grid gap-3 md:grid-cols-2">
              <div>
                <Label htmlFor="newFrom">الرابط المصدر (fromPath)</Label>
                <Input
                  id="newFrom"
                  value={newFrom}
                  onChange={(e) => setNewFrom(e.target.value)}
                  placeholder="/old-product-slug"
                  dir="ltr"
                />
              </div>
              <div>
                <Label htmlFor="newTo">الوجهة (toPath)</Label>
                <Input
                  id="newTo"
                  value={newTo}
                  onChange={(e) => setNewTo(e.target.value)}
                  placeholder="/produits/new-product-slug"
                  dir="ltr"
                />
              </div>
              <div>
                <Label>نوع التوجيه</Label>
                <Select value={String(newStatus)} onValueChange={(v) => setNewStatus(Number(v) as 301 | 302)}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="301">301 — دائم (Permanent)</SelectItem>
                    <SelectItem value="302">302 — مؤقت (Temporary)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="flex items-end">
                <Button onClick={createRedirect}>
                  <Plus className="mr-2 h-4 w-4" /> إنشاء
                </Button>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2"><Link2 className="h-4 w-4" /> التوجيهات الموجودة ({redirects.length})</CardTitle>
              <CardDescription>التحقق من الحلقات (loops) يتم تلقائياً عند الإنشاء. لا يمكن تغيير fromPath بعد الإنشاء.</CardDescription>
            </CardHeader>
            <CardContent>
              {redirects.length === 0 ? (
                <p className="text-sm text-zinc-500">لا توجد توجيهات.</p>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>المصدر</TableHead>
                      <TableHead>الوجهة</TableHead>
                      <TableHead>الكود</TableHead>
                      <TableHead>الحالة</TableHead>
                      <TableHead></TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {redirects.map((r) => (
                      <TableRow key={r.id}>
                        <TableCell className="font-mono text-xs" dir="ltr">{r.fromPath}</TableCell>
                        <TableCell className="font-mono text-xs" dir="ltr">{r.toPath}</TableCell>
                        <TableCell>
                          <Badge variant={r.statusCode === 301 ? 'default' : 'secondary'}>{r.statusCode}</Badge>
                        </TableCell>
                        <TableCell>
                          <Switch checked={r.isActive} onCheckedChange={(v) => toggleRedirect(r.id, v)} />
                        </TableCell>
                        <TableCell>
                          <Button size="icon" variant="ghost" onClick={() => deleteRedirect(r.id)}>
                            <Trash2 className="h-4 w-4 text-red-500" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* SLUGS */}
        <TabsContent value="slugs" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2"><Search className="h-4 w-4" /> فحص تعارض الـ Slug</CardTitle>
              <CardDescription>تحقق ما إذا كان slug معين مستعملاً في منتج، قسم، ماركة، صفحة، أو توجيه.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex gap-2">
                <Input
                  value={slugInput}
                  onChange={(e) => setSlugInput(e.target.value)}
                  placeholder="mon-slug"
                  dir="ltr"
                  onKeyDown={(e) => e.key === 'Enter' && checkSlug()}
                />
                <Button onClick={checkSlug} disabled={slugChecking}>
                  {slugChecking ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Search className="mr-2 h-4 w-4" />}
                  فحص
                </Button>
              </div>
              {slugConflicts && (
                <div className="space-y-2">
                  {slugConflicts.length === 0 ? (
                    <div className="flex items-center gap-2 text-green-600 text-sm">
                      <CheckCircle2 className="h-4 w-4" /> الـ Slug متاح — لا توجد تعارضات.
                    </div>
                  ) : (
                    <>
                      <div className="flex items-center gap-2 text-amber-600 text-sm">
                        <AlertTriangle className="h-4 w-4" /> وُجدت {slugConflicts.length} تعارضات:
                      </div>
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead>النوع</TableHead>
                            <TableHead>الاسم</TableHead>
                            <TableHead>الرابط</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {slugConflicts.map((c, i) => (
                            <TableRow key={i}>
                              <TableCell><Badge variant="outline">{c.type}</Badge></TableCell>
                              <TableCell>{c.name}</TableCell>
                              <TableCell className="font-mono text-xs" dir="ltr">{c.url}</TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </>
                  )}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* PREVIEW */}
        <TabsContent value="preview" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2"><Eye className="h-4 w-4" /> معاينة نتائج البحث والمشاركة</CardTitle>
              <CardDescription>شاهد كيف ستظهر الصفحة في نتائج Google وعند مشاركتها على فيسبوك/واتساب.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="grid gap-3 md:grid-cols-2">
                <div>
                  <Label>نوع الصفحة</Label>
                  <Select value={ogType} onValueChange={(v) => setOgType(v as any)}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="home">الصفحة الرئيسية</SelectItem>
                      <SelectItem value="product">منتج</SelectItem>
                      <SelectItem value="category">قسم</SelectItem>
                      <SelectItem value="brand">ماركة</SelectItem>
                      <SelectItem value="page">صفحة</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="ogSlug">Slug (اختياري)</Label>
                  <Input id="ogSlug" value={ogSlug} onChange={(e) => setOgSlug(e.target.value)} dir="ltr" placeholder="mon-produit" />
                </div>
                <div>
                  <Label htmlFor="ogTitle">العنوان</Label>
                  <Input id="ogTitle" value={ogTitle} onChange={(e) => setOgTitle(e.target.value)} dir="ltr" maxLength={200} />
                </div>
                <div>
                  <Label htmlFor="ogImage">رابط الصورة</Label>
                  <Input id="ogImage" value={ogImage} onChange={(e) => setOgImage(e.target.value)} dir="ltr" placeholder="https://..." />
                </div>
              </div>
              <div>
                <Label htmlFor="ogDescription">الوصف</Label>
                <Textarea id="ogDescription" value={ogDescription} onChange={(e) => setOgDescription(e.target.value)} rows={3} maxLength={300} dir="ltr" />
              </div>
              <Button onClick={previewOg} disabled={ogLoading}>
                {ogLoading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Eye className="mr-2 h-4 w-4" />}
                توليد المعاينة
              </Button>

              {ogPreview && (
                <div className="space-y-4 pt-4">
                  {ogPreview.warnings?.length > 0 && (
                    <div className="rounded-md border border-amber-300 bg-amber-50 p-3 text-xs">
                      <div className="flex items-center gap-2 font-medium text-amber-700"><AlertTriangle className="h-3.5 w-3.5" /> تحذيرات</div>
                      <ul className="mt-1 list-disc pl-5 text-amber-700">
                        {ogPreview.warnings.map((w: string, i: number) => <li key={i}>{w}</li>)}
                      </ul>
                    </div>
                  )}
                  {/* Google snippet preview */}
                  <div>
                    <p className="mb-2 text-xs font-medium text-zinc-500">معاينة نتيجة Google</p>
                    <div className="rounded-md border p-3 bg-white">
                      <div className="text-xs text-zinc-700" dir="ltr">{ogPreview.preview.url}</div>
                      <div className="mt-1 text-base text-blue-700" dir="ltr">{ogPreview.preview.title || '(لا يوجد عنوان)'}</div>
                      <div className="mt-0.5 text-xs text-zinc-600" dir="ltr">{ogPreview.preview.description || '(لا يوجد وصف)'}</div>
                    </div>
                  </div>
                  {/* Facebook card preview */}
                  <div>
                    <p className="mb-2 text-xs font-medium text-zinc-500">معاينة بطاقة فيسبوك</p>
                    <div className="overflow-hidden rounded-md border bg-white">
                      <div className="aspect-[1.91/1] bg-zinc-100 grid place-items-center text-zinc-400 text-xs">
                        {ogPreview.preview.image ? (
                          // eslint-disable-next-line @next/next/no-img-element
                          <img src={ogPreview.preview.image} alt="" className="h-full w-full object-cover" />
                        ) : 'لا توجد صورة'}
                      </div>
                      <div className="p-3">
                        <div className="text-xs uppercase text-zinc-500" dir="ltr">{new URL(ogPreview.preview.url).hostname}</div>
                        <div className="mt-0.5 text-sm font-semibold text-zinc-900" dir="ltr">{ogPreview.preview.title || '(لا يوجد عنوان)'}</div>
                        <div className="mt-0.5 text-xs text-zinc-600" dir="ltr">{ogPreview.preview.description || '(لا يوجد وصف)'}</div>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* STATUS */}
        <TabsContent value="status" className="space-y-4">
          {status ? (
            <>
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2"><FileText className="h-4 w-4" /> حالة Sitemap</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="grid gap-2 text-sm sm:grid-cols-2">
                    <div className="flex items-center justify-between rounded-md border p-2">
                      <span className="text-zinc-600">رابط Sitemap:</span>
                      <a href={status.sitemapUrl} target="_blank" rel="noopener noreferrer" className="flex items-center gap-1 font-mono text-xs text-blue-600 hover:underline" dir="ltr">
                        {status.sitemapUrl} <ExternalLink className="h-3 w-3" />
                      </a>
                    </div>
                    <div className="flex items-center justify-between rounded-md border p-2">
                      <span className="text-zinc-600">رابط robots.txt:</span>
                      <a href={status.robotsUrl} target="_blank" rel="noopener noreferrer" className="flex items-center gap-1 font-mono text-xs text-blue-600 hover:underline" dir="ltr">
                        {status.robotsUrl} <ExternalLink className="h-3 w-3" />
                      </a>
                    </div>
                    <div className="flex items-center justify-between rounded-md border p-2">
                      <span className="text-zinc-600">إجمالي الروابط:</span>
                      <Badge>{status.totalUrls}</Badge>
                    </div>
                    <div className="flex items-center justify-between rounded-md border p-2">
                      <span className="text-zinc-600">آخر تحديث للمحتوى:</span>
                      <span className="text-xs">{status.lastContentUpdate ? new Date(status.lastContentUpdate).toLocaleString('ar-MA') : '—'}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>تفصيل المحتوى المُفهرس</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid gap-2 text-sm sm:grid-cols-2 md:grid-cols-3">
                    <Stat label="منتجات منشورة" value={status.counts.productsPublished} color="green" />
                    <Stat label="منتجات مسودة" value={status.counts.productsDraft} color="amber" />
                    <Stat label="منتجات مؤرشفة" value={status.counts.productsArchived} color="zinc" />
                    <Stat label="منتجات noindex" value={status.counts.productsNoindex} color="zinc" />
                    <Stat label="أقسام ظاهرة" value={status.counts.categoriesVisible} color="green" />
                    <Stat label="أقسام مخفية" value={status.counts.categoriesHidden} color="zinc" />
                    <Stat label="ماركات ظاهرة" value={status.counts.brandsVisible} color="green" />
                    <Stat label="صفحات ظاهرة" value={status.counts.pagesVisible} color="green" />
                    <Stat label="توجيهات نشطة" value={status.redirects.active} color="blue" />
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2"><Menu className="h-4 w-4" /> خطوات ربط Google Search Console</CardTitle>
                </CardHeader>
                <CardContent className="space-y-2 text-sm text-zinc-700">
                  <ol className="list-decimal space-y-2 pl-5">
                    <li>افتح <a href="https://search.google.com/search-console" target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:underline">Google Search Console</a> وسجّل الدخول بحساب Google.</li>
                    <li>أضف خاصية جديدة من نوع «URL prefix» وأدخل رابط موقعك الكامل (مثال: <code dir="ltr">https://mon-magasin.ma</code>).</li>
                    <li>تحقق من الملكية عبر ملف HTML أو Google Analytics أو علامة Meta — اختر الطريقة المناسبة لإعدادك.</li>
                    <li>من القائمة اليسرى، اضغط «Sitemaps» وأدخل المسار <code dir="ltr">sitemap.xml</code> ثم اضغط «Submit».</li>
                    <li>انتظر بضع دقائق حتى يبدأ Google بمعالجة الـ Sitemap. ستظهر حالة الفهرسة تحت «Coverage».</li>
                    <li>راقب الأخطاء دورياً (404, soft 404, أخطاء فهرسة) من نفس اللوحة.</li>
                  </ol>
                </CardContent>
              </Card>
            </>
          ) : (
            <Spinner />
          )}
        </TabsContent>
      </Tabs>
    </>
  )
}

function Stat({ label, value, color }: { label: string; value: number; color: string }) {
  const colors: Record<string, string> = {
    green: 'bg-green-50 text-green-700 border-green-200',
    amber: 'bg-amber-50 text-amber-700 border-amber-200',
    zinc: 'bg-zinc-50 text-zinc-700 border-zinc-200',
    blue: 'bg-blue-50 text-blue-700 border-blue-200',
  }
  return (
    <div className={`flex items-center justify-between rounded-md border p-2 ${colors[color] || colors.zinc}`}>
      <span className="text-xs">{label}</span>
      <Badge variant="outline">{value}</Badge>
    </div>
  )
}
