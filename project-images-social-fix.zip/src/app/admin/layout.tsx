/**
 * Admin root layout
 * Wraps EVERY admin route (login + dashboard) in an RTL Arabic container.
 * The root <html lang="fr"> stays LTR for the French storefront — we only
 * override the dir/lang on a wrapper div, so the admin inherits proper RTL
 * text direction without affecting the storefront.
 */
export const dynamic = 'force-dynamic'

export default function AdminRootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <div
      dir="rtl"
      lang="ar"
      className="min-h-screen bg-zinc-50 text-zinc-900 font-sans antialiased"
    >
      {children}
    </div>
  )
}
