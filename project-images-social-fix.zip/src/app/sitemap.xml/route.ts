import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { unstable_cache } from 'next/cache'
import { getProductionDomain } from '@/services/settings'

/**
 * Static Route Handler for /sitemap.xml
 * =====================================
 *
 * WHY THIS EXISTS (instead of using Next.js's sitemap.ts metadata convention):
 *
 * Next.js's built-in sitemap.ts generates /sitemap.xml as an ISR route with
 * headers that confuse Google Search Console:
 *
 *   1. `Vary: rsc, next-router-state-tree, next-router-prefetch, ...`
 *      — Google's sitemap fetcher doesn't send these Next.js-internal headers,
 *        and the Vary header causes Google to think the response varies by
 *        request headers it doesn't understand → "Couldn't fetch".
 *
 *   2. `Cache-Control: public, max-age=0, must-revalidate`
 *      — max-age=0 forces Google to revalidate on EVERY request. Combined
 *        with the Vary header, this causes intermittent fetch failures.
 *
 *   3. `Content-Type: application/xml` (without charset=utf-8)
 *      — Google expects `application/xml; charset=utf-8` or `text/xml; charset=utf-8`.
 *        The netlify.toml header is overridden by Next.js's generated header.
 *
 *   4. `netlify-vary: cookie=__prerender_bypass|__next_preview_data`
 *      — Cookie-based variation means Google could get a different response
 *        if it has any cookies cached.
 *
 * This Route Handler returns the SAME XML content but with clean headers:
 *   - Content-Type: application/xml; charset=utf-8
 *   - Cache-Control: public, max-age=3600, s-maxage=3600
 *   - No Vary header (or minimal Vary: Accept-Encoding)
 *   - No cookie-based variation
 *
 * Google Search Console will be able to fetch this reliably.
 */

export const revalidate = 3600
export const dynamic = 'force-static'

const STATIC_ROUTES: Array<{
  path: string
  changeFrequency: string
  priority: number
}> = [
  { path: '/', changeFrequency: 'daily', priority: 1 },
  { path: '/produits', changeFrequency: 'daily', priority: 0.9 },
  { path: '/categories', changeFrequency: 'weekly', priority: 0.7 },
  { path: '/aide', changeFrequency: 'monthly', priority: 0.5 },
  { path: '/contact', changeFrequency: 'monthly', priority: 0.5 },
  { path: '/page/a-propos', changeFrequency: 'monthly', priority: 0.5 },
  { path: '/page/faq', changeFrequency: 'monthly', priority: 0.4 },
  { path: '/page/livraison-retours', changeFrequency: 'monthly', priority: 0.4 },
  { path: '/page/conditions-generales', changeFrequency: 'yearly', priority: 0.3 },
  { path: '/page/politique-confidentialite', changeFrequency: 'yearly', priority: 0.3 },
]

interface SitemapEntry {
  url: string
  lastModified: Date
  changeFrequency?: string
  priority?: number
}

const buildSitemapEntries = unstable_cache(
  async (): Promise<SitemapEntry[]> => {
    const siteUrl = await getProductionDomain()
    if (!siteUrl) return []

    const staticRoutes: SitemapEntry[] = STATIC_ROUTES.map((r) => ({
      url: `${siteUrl}${r.path}`,
      lastModified: new Date(),
      changeFrequency: r.changeFrequency,
      priority: r.priority,
    }))

    try {
      // ─── Dynamic routes ─────────────────────────────────────────
      // NOTE: we only include routes that ACTUALLY EXIST in the storefront.
      // Before this fix, the sitemap included `/brands/[slug]` URLs, but
      // there is NO `/brands/[slug]` page in the app — that route returns
      // 404, which Google flags as a sitemap error.
      //
      // Brands are filterable via `/categories?brand=[slug]` or
      // `/produits?brand=[slug]`, but those are query-param URLs that
      // shouldn't be in the sitemap (Google indexes the base URL, the
      // filter variants get discovered via crawling).
      const [products, categories, pages] = await Promise.all([
        db.product.findMany({
          where: { status: 'PUBLISHED', noindex: false },
          select: { slug: true, updatedAt: true, publishedAt: true },
        }),
        db.category.findMany({
          where: { isVisible: true },
          select: { slug: true, updatedAt: true },
        }),
        db.page.findMany({
          where: { isVisible: true },
          select: { slug: true, updatedAt: true, publishedAt: true },
        }),
      ])

      const productRoutes: SitemapEntry[] = products.map((p) => ({
        url: `${siteUrl}/produits/${p.slug}`,
        lastModified: p.publishedAt ?? p.updatedAt,
        changeFrequency: 'weekly',
        priority: 0.8,
      }))
      const categoryRoutes: SitemapEntry[] = categories.map((c) => ({
        url: `${siteUrl}/categories/${c.slug}`,
        lastModified: c.updatedAt,
        changeFrequency: 'weekly',
        priority: 0.6,
      }))
      const pageRoutes: SitemapEntry[] = pages.map((p) => ({
        url: `${siteUrl}/page/${p.slug}`,
        lastModified: p.publishedAt ?? p.updatedAt,
        changeFrequency: 'monthly',
        priority: 0.4,
      }))

      const all = [...staticRoutes, ...productRoutes, ...categoryRoutes, ...pageRoutes]
      const seen = new Set<string>()
      return all.filter((entry) => {
        if (seen.has(entry.url)) return false
        seen.add(entry.url)
        return true
      })
    } catch {
      return staticRoutes
    }
  },
  ['sitemap-route-handler'],
  { revalidate: 3600, tags: ['sitemap', 'catalog'] },
)

function escapeXml(unsafe: string): string {
  return unsafe
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&apos;')
}

function toIsoDate(d: Date | null | undefined): string {
  // Format: YYYY-MM-DDTHH:mm:ss.sssZ
  // Handle null/undefined by falling back to "now" — this prevents the
  // "toISOString is not a function" crash when a product/page has no
  // publishedAt or updatedAt (rare but possible).
  if (!d || !(d instanceof Date) || isNaN(d.getTime())) {
    return new Date().toISOString()
  }
  return d.toISOString()
}

export async function GET(_req: NextRequest) {
  const entries = await buildSitemapEntries()

  const xml = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
${entries
  .map(
    (entry) => `  <url>
    <loc>${escapeXml(entry.url)}</loc>
    <lastmod>${toIsoDate(entry.lastModified)}</lastmod>
    <changefreq>${entry.changeFrequency || 'monthly'}</changefreq>
    <priority>${entry.priority ?? 0.5}</priority>
  </url>`,
  )
  .join('\n')}
</urlset>`

  return new Response(xml, {
    status: 200,
    headers: {
      'Content-Type': 'application/xml; charset=utf-8',
      'Cache-Control': 'public, max-age=3600, s-maxage=3600',
      'X-Content-Type-Options': 'nosniff',
    },
  })
}
