'use client'

import { useState, useCallback } from 'react'
import Link from 'next/link'
import { ShoppingCart, Check, Loader2, ImageIcon } from 'lucide-react'
import type { ProductCard } from '@/types'
import { formatPrice, discountPercent } from '@/lib/format'
import { useCart } from '@/lib/cart-store'
import { Button } from '@/components/ui/button'
import { cn } from '@/lib/utils'

/**
 * ProductCard — professional tool-store design.
 *
 * DESIGN PRINCIPLES
 * -----------------
 * - Clean, rectangular, unified cards (no glassmorphism, no excessive shadows)
 * - Large product image with object-contain (tools never cropped)
 * - Mobile-first: 2 columns on phone, readable text, easy-to-tap buttons
 * - White/neutral background, subtle border, minimal shadow on hover only
 * - Brand → name → price hierarchy, aligned across all cards
 * - Add-to-cart: shopping-cart icon (not "+"), full-width on mobile
 *
 * PRICE DISPLAY
 * -------------
 * - Current price: bold, prominent (text-base sm:text-lg)
 * - Old price (compareAtPrice): shown ONLY when it exists and is valid
 *   (compare > price). Strikethrough, neutral-400, readable size.
 * - On mobile: prices stack vertically (old above, current below) to
 *   prevent overlap in narrow cards.
 * - On desktop: prices side-by-side with clear gap.
 * - Discount % shown as a small pill, separate from prices.
 *
 * CLICK NAVIGATION
 * ----------------
 * The <Link> wraps the entire card. The Add-to-Cart button is a SIBLING
 * (z-30) with preventDefault + stopPropagation.
 */

type AddState = 'idle' | 'loading' | 'success'

export function ProductCard({ product }: { product: ProductCard }) {
  const add = useCart((s) => s.add)
  const openCart = useCart((s) => s.open)
  const [addState, setAddState] = useState<AddState>('idle')
  const [imgError, setImgError] = useState(false)

  const currency = { code: product.currencyCode, symbol: 'DH', locale: 'fr-MA' }
  const price = Number(product.price)
  const compare = product.compareAtPrice ? Number(product.compareAtPrice) : null
  const discount = discountPercent(price, compare)
  const outOfStock =
    product.trackInventory && !product.allowBackorder && product.stockQuantity <= 0
  const lowStock =
    product.trackInventory && !outOfStock && product.stockQuantity <= 5

  const handleAdd = useCallback(
    async (e: React.MouseEvent) => {
      e.preventDefault()
      e.stopPropagation()
      if (outOfStock || addState !== 'idle') return
      setAddState('loading')
      try {
        add({
          productId: product.id,
          slug: product.slug,
          name: product.name,
          sku: product.sku,
          price,
          image: product.mainImage?.secureUrl ?? product.mainImage?.url ?? null,
          maxStock: product.trackInventory ? product.stockQuantity : 999,
        })
        setAddState('success')
        openCart()
        setTimeout(() => setAddState('idle'), 1200)
      } catch {
        setAddState('idle')
      }
    },
    [add, openCart, outOfStock, addState, product, price],
  )

  const imgSrc = product.mainImage?.secureUrl || product.mainImage?.url

  return (
    <article className="group relative">
      <Link
        href={`/produits/${product.slug}`}
        className="relative flex h-full flex-col overflow-hidden rounded-xl border border-neutral-200 bg-white transition-all duration-200 hover:border-neutral-300 hover:shadow-md focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-neutral-900 focus-visible:ring-offset-2"
        aria-label={product.name}
      >
        {/* === IMAGE AREA === */}
        <div className="relative aspect-square overflow-hidden bg-neutral-50">
          {imgSrc && !imgError ? (
            <img
              src={imgSrc}
              alt={product.mainImage?.altText || product.name}
              className="h-full w-full object-contain p-4 transition-transform duration-300 ease-out group-hover:scale-[1.03] sm:p-5"
              loading="lazy"
              decoding="async"
              draggable={false}
              onError={() => setImgError(true)}
            />
          ) : (
            <div className="grid h-full w-full place-items-center text-neutral-300">
              <ImageIcon className="h-10 w-10" strokeWidth={1.2} />
            </div>
          )}

          {/* Badges — top-left */}
          <div
            className="pointer-events-none absolute left-2 top-2 z-20 flex flex-col gap-1"
            aria-hidden="true"
          >
            {discount && (
              <span className="rounded-md bg-red-600 px-1.5 py-0.5 text-[10px] font-bold text-white">
                −{discount}%
              </span>
            )}
            {product.isNewArrival && !outOfStock && (
              <span className="rounded-md bg-green-600 px-1.5 py-0.5 text-[10px] font-bold text-white">
                Nouveau
              </span>
            )}
            {product.isBestSeller && !outOfStock && (
              <span className="rounded-md bg-amber-600 px-1.5 py-0.5 text-[10px] font-bold text-white">
                Top
              </span>
            )}
          </div>

          {/* Out-of-stock overlay */}
          {outOfStock && (
            <div className="pointer-events-none absolute inset-0 z-20 grid place-items-center bg-white/80">
              <span className="rounded-md border border-neutral-300 bg-white px-3 py-1 text-xs font-semibold text-neutral-700">
                Rupture de stock
              </span>
            </div>
          )}
        </div>

        {/* === BODY === */}
        <div className="flex flex-1 flex-col p-3 sm:p-4">
          {/* Brand */}
          {product.brand && (
            <span className="mb-1 text-[10px] font-semibold uppercase tracking-wide text-neutral-500">
              {product.brand.name}
            </span>
          )}

          {/* Product name */}
          <h3 className="line-clamp-2 min-h-[2.5rem] font-semibold leading-snug text-neutral-900 transition-colors group-hover:text-neutral-700"
            style={{ fontSize: 'var(--text-sm)' }}
          >
            {product.name}
          </h3>

          {/* Short description */}
          {product.shortDescription && (
            <p className="mt-1 line-clamp-1 text-neutral-500" style={{ fontSize: 'var(--text-xs)' }}>
              {product.shortDescription}
            </p>
          )}

          {/* Low stock warning */}
          {lowStock && !outOfStock && (
            <p className="mt-1.5 text-[11px] font-medium text-amber-600">
              Plus que {product.stockQuantity} en stock
            </p>
          )}

          {/* === PRICE AREA === */}
          <div className="mt-auto pt-3">
            {compare ? (
              /* Product WITH old price — stack vertically on mobile, side-by-side on desktop */
              <div className="flex flex-col gap-0.5 sm:flex-row sm:items-baseline sm:gap-2">
                {/* Old price (strikethrough) — on top on mobile, left on desktop */}
                <span className="text-xs font-medium text-neutral-400 line-through decoration-1 sm:text-sm">
                  {formatPrice(compare, currency)}
                </span>
                {/* Current price — prominent */}
                <span className="price-display text-base font-bold tracking-tight text-neutral-900 sm:text-lg">
                  {formatPrice(price, currency)}
                </span>
              </div>
            ) : (
              /* Product WITHOUT old price — current price only */
              <div>
                <span className="price-display text-base font-bold tracking-tight text-neutral-900 sm:text-lg">
                  {formatPrice(price, currency)}
                </span>
              </div>
            )}
            <p className="mt-0.5 text-[10px] font-medium text-neutral-400">
              {product.currencyCode} · COD
            </p>
          </div>

          {/* === ADD TO CART BUTTON (inside card, full-width) === */}
          <Button
            onClick={handleAdd}
            disabled={outOfStock || addState === 'loading'}
            variant={outOfStock ? 'secondary' : 'default'}
            aria-label={outOfStock ? 'Indisponible' : `Ajouter ${product.name} au panier`}
            aria-disabled={outOfStock}
            className={cn(
              'mt-3 flex h-9 w-full items-center justify-center gap-1.5 rounded-lg p-0 text-xs font-semibold transition-all sm:h-10 sm:text-sm',
              outOfStock
                ? 'cursor-not-allowed bg-neutral-100 text-neutral-400'
                : 'bg-neutral-900 text-white hover:bg-neutral-800',
              addState === 'success' && 'bg-green-600 text-white hover:bg-green-600',
            )}
          >
            {outOfStock ? (
              <span>Indisponible</span>
            ) : addState === 'loading' ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : addState === 'success' ? (
              <>
                <Check className="h-4 w-4" />
                <span>Ajouté</span>
              </>
            ) : (
              <>
                <ShoppingCart className="h-4 w-4" />
                <span>Ajouter</span>
              </>
            )}
          </Button>
        </div>
      </Link>
    </article>
  )
}

/** Skeleton card for loading states */
export function ProductCardSkeleton() {
  return (
    <div className="overflow-hidden rounded-xl border border-neutral-200 bg-white">
      <div className="skeleton-shimmer aspect-square w-full" />
      <div className="p-4">
        <div className="skeleton-shimmer mb-2 h-2.5 w-1/3" />
        <div className="skeleton-shimmer mb-1 h-4 w-3/4" />
        <div className="skeleton-shimmer mb-3 h-4 w-1/2" />
        <div className="skeleton-shimmer h-6 w-2/3" />
      </div>
    </div>
  )
}
