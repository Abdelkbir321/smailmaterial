'use client'

import { useEffect, useRef, useState } from 'react'
import Link from 'next/link'
import { ShoppingCart, Search, Menu, Phone, ChevronRight, MessageCircle, Wrench } from 'lucide-react'
import { useCart } from '@/lib/cart-store'
import { siteConfig } from '@/config/site'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Sheet, SheetContent, SheetTrigger, SheetTitle } from '@/components/ui/sheet'
import { cn } from '@/lib/utils'
import { useRouter } from 'next/navigation'
import { Logo } from '@/components/storefront/logo'
import type { LogoMobile, LogoMotion, LogoSize, LogoVisual } from '@/lib/logo-config'

export function StoreHeader({
  categories,
  logoUrl,
  siteName,
  supportPhone,
  whatsapp,
  logoSize,
  logoMotion,
  logoVisual,
  logoMobile,
  announcementText,
  logoSubtitle,
  searchPlaceholder,
  catalogueButton,
  navHome,
  navProducts,
  navAllCategories,
}: {
  categories: Array<{ slug: string; name: string; nameAr?: string | null }>
  logoUrl?: string | null
  siteName?: string | null
  supportPhone?: string | null
  whatsapp?: string | null
  logoSize?: LogoSize | null
  logoMotion?: LogoMotion | null
  logoVisual?: LogoVisual | null
  logoMobile?: LogoMobile | null
  announcementText?: string | null
  logoSubtitle?: string | null
  searchPlaceholder?: string | null
  catalogueButton?: string | null
  navHome?: string | null
  navProducts?: string | null
  navAllCategories?: string | null
}) {
  const { count, open: openCart } = useCart()
  const [clicks, setClicks] = useState(0)
  const [scrolled, setScrolled] = useState(false)
  const clickTimer = useRef<ReturnType<typeof setTimeout> | null>(null)
  const router = useRouter()
  const [searchQ, setSearchQ] = useState('')
  const [mobileOpen, setMobileOpen] = useState(false)
  const name = siteName || siteConfig.name
  const phone = supportPhone || ''
  const phoneHref = phone.replace(/[\s()-]/g, '')
  const waNumber = (whatsapp || '').replace(/[^\d]/g, '')

  // Detect scroll — header shrinks subtly when scrolled (depth cue)
  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12)
    onScroll()
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  const onLogoClick = () => {
    const next = clicks + 1
    setClicks(next)
    if (clickTimer.current) clearTimeout(clickTimer.current)
    clickTimer.current = setTimeout(() => setClicks(0), 2000)
    if (next >= siteConfig.adminLogoClicks) {
      setClicks(0)
      router.push('/admin/login')
    }
  }

  const submitSearch = (e: React.FormEvent) => {
    e.preventDefault()
    if (searchQ.trim()) router.push(`/recherche?q=${encodeURIComponent(searchQ.trim())}`)
  }

  return (
    <header
      className={cn(
        'sticky top-0 z-40 border-b transition-all duration-300',
        scrolled
          ? 'border-border bg-background/85 backdrop-blur-md shadow-[var(--shadow-sm)]'
          : 'border-transparent bg-background',
      )}
    >
      {/* Top announcement bar — slim, dark, brass accents */}
      <div className="border-b border-border-strong/30 bg-secondary text-secondary-foreground">
        <div className="mx-auto flex max-w-7xl items-center justify-between gap-4 px-4 py-2 text-xs">
          <span className="truncate font-medium tracking-tight">
            {announcementText || 'Livraison 24–72h partout au Maroc · Paiement à la livraison'}
          </span>
          <div className="flex items-center gap-4">
            {phone && (
              <a
                href={`tel:${phoneHref}`}
                className="hidden items-center gap-1.5 transition-colors hover:text-accent sm:flex"
                dir="ltr"
              >
                <Phone className="h-3 w-3" /> {phone}
              </a>
            )}
            {waNumber && (
              <a
                href={`https://wa.me/${waNumber}`}
                target="_blank"
                rel="noopener noreferrer"
                className="hidden items-center gap-1.5 transition-colors hover:text-accent sm:flex"
                aria-label="WhatsApp"
              >
                <MessageCircle className="h-3 w-3" /> WhatsApp
              </a>
            )}
          </div>
        </div>
      </div>

      {/* Main header */}
      <div className="mx-auto flex max-w-7xl items-center gap-3 px-4 py-3.5">
        {/* Mobile menu */}
        <Sheet open={mobileOpen} onOpenChange={setMobileOpen}>
          <SheetTrigger asChild>
            <Button
              variant="ghost"
              size="icon"
              className="lg:hidden"
              aria-label="Menu"
            >
              <Menu className="h-5 w-5" />
            </Button>
          </SheetTrigger>
          <SheetContent side="left" className="w-80 max-w-[85vw]">
            <SheetTitle className="px-4 text-base font-semibold">
              Navigation
            </SheetTitle>
            <nav className="mt-2 flex flex-col">
              <Link
                href="/"
                className="border-b border-border px-4 py-3 text-sm transition-colors hover:bg-muted"
                onClick={() => setMobileOpen(false)}
              >
                Accueil
              </Link>
              <Link
                href="/produits"
                className="border-b border-border px-4 py-3 text-sm transition-colors hover:bg-muted"
                onClick={() => setMobileOpen(false)}
              >
                Tous les produits
              </Link>
              {categories.slice(0, 8).map((c) => (
                <Link
                  key={c.slug}
                  href={`/categories/${c.slug}`}
                  className="flex items-center justify-between border-b border-border px-4 py-3 text-sm transition-colors hover:bg-muted"
                  onClick={() => setMobileOpen(false)}
                >
                  <span>{c.name}</span>
                  <ChevronRight className="h-4 w-4 opacity-40" />
                </Link>
              ))}
              <Link
                href="/categories"
                className="px-4 py-3 text-sm text-muted-foreground"
                onClick={() => setMobileOpen(false)}
              >
                Tout voir →
              </Link>
            </nav>
          </SheetContent>
        </Sheet>

        {/* Logo — uses the Logo component which applies admin-configured size + motion */}
        <button
          onClick={onLogoClick}
          aria-label={name}
          title={name}
          className="group flex select-none items-center gap-3 outline-none"
        >
          <div className="relative grid place-items-center transition-transform duration-300 group-hover:scale-105">
            <Logo
              logoUrl={logoUrl ?? null}
              alt={name}
              size={logoSize ?? null}
              motion={logoMotion ?? null}
              visual={logoVisual ?? null}
              mobile={logoMobile ?? null}
              className="relative z-10"
            />
          </div>
          <div className="hidden flex-col leading-tight sm:flex">
            <span className="block font-display text-base font-bold tracking-tight text-foreground">
              {name}
            </span>
            <span className="block text-[10px] font-medium uppercase tracking-[0.12em] text-muted-foreground">
              {logoSubtitle || 'Outillage · Maroc'}
            </span>
          </div>
        </button>

        {/* Search (desktop) */}
        <form
          onSubmit={submitSearch}
          className="mx-4 hidden flex-1 max-w-xl md:block"
        >
          <div className="group relative">
            <Search className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground transition-colors group-focus-within:text-primary" />
            <Input
              value={searchQ}
              onChange={(e) => setSearchQ(e.target.value)}
              placeholder={searchPlaceholder || 'Rechercher un outil, une marque, une référence…'}
              className="h-11 rounded-full border-border bg-card pl-10 pr-4 text-sm shadow-[var(--shadow-xs)] transition-shadow focus-visible:shadow-[var(--shadow-sm)]"
              aria-label="Recherche"
            />
          </div>
        </form>

        <div className="ml-auto flex items-center gap-1.5">
          <Button
            variant="ghost"
            size="sm"
            className="hidden rounded-full px-4 font-medium sm:flex"
            asChild
          >
            <Link href="/produits">
              <Wrench className="mr-1.5 h-4 w-4" /> {catalogueButton || 'Catalogue'}
            </Link>
          </Button>
          <Button
            variant="ghost"
            size="icon"
            className="relative rounded-full"
            onClick={openCart}
            aria-label="Panier"
          >
            <ShoppingCart className="h-5 w-5" />
            {count() > 0 && (
              <span className="absolute -right-0.5 -top-0.5 grid h-5 min-w-5 place-items-center rounded-full bg-primary px-1 text-[10px] font-bold text-primary-foreground shadow-[var(--shadow-sm)]">
                {count()}
              </span>
            )}
          </Button>
        </div>
      </div>

      {/* Mobile search */}
      <form
        onSubmit={submitSearch}
        className="border-t border-border px-4 py-2.5 md:hidden"
      >
        <div className="relative">
          <Search className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            value={searchQ}
            onChange={(e) => setSearchQ(e.target.value)}
            placeholder={searchPlaceholder ? searchPlaceholder.slice(0, 20) + '…' : 'Rechercher…'}
            className="h-10 rounded-full border-border bg-card pl-10"
            aria-label="Recherche"
          />
        </div>
      </form>

      {/* Desktop category nav — refined, hairline */}
      <nav className="hidden border-t border-border bg-card/40 lg:block">
        <div className="mx-auto flex max-w-7xl items-center gap-1 px-4 py-2 text-sm">
          <Link
            href="/"
            className="rounded-full px-3.5 py-1.5 font-medium text-muted-foreground transition-colors hover:bg-muted hover:text-foreground"
          >
            {navHome || 'Accueil'}
          </Link>
          <Link
            href="/produits"
            className="rounded-full px-3.5 py-1.5 font-medium text-muted-foreground transition-colors hover:bg-muted hover:text-foreground"
          >
            {navProducts || 'Produits'}
          </Link>
          <div className="mx-2 h-4 w-px bg-border" />
          {categories.slice(0, 6).map((c) => (
            <Link
              key={c.slug}
              href={`/categories/${c.slug}`}
              className="rounded-full px-3.5 py-1.5 font-medium text-muted-foreground transition-colors hover:bg-muted hover:text-foreground"
            >
              {c.name}
            </Link>
          ))}
          <Link
            href="/categories"
            className="ml-auto rounded-full px-3.5 py-1.5 text-xs font-medium uppercase tracking-wide text-muted-foreground transition-colors hover:text-foreground"
          >
            {navAllCategories || 'Tout voir →'}
          </Link>
        </div>
      </nav>
    </header>
  )
}
