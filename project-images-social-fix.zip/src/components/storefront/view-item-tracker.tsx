'use client'

import { useEffect } from 'react'
import { trackEvent } from '@/lib/track'
import { ga4Events } from '@/components/analytics/google-analytics'

/**
 * Fires a `view_item` analytics event when a product detail page loads.
 * Only fires once per mount (no re-fires on re-render).
 *
 * Fires BOTH:
 *   - In-house analytics (AnalyticsEvent table → powers the admin dashboard)
 *   - GA4 `view_item` event (when GA4 is configured — no-op otherwise)
 */
export function ViewItemTracker({
  productSlug,
  productName,
  price,
  productId,
  currency = 'MAD',
}: {
  productSlug: string
  productName: string
  price: number
  productId?: string
  currency?: string
}) {
  useEffect(() => {
    // In-house analytics (always fires — powers the admin dashboard)
    trackEvent('view_item', {
      slug: productSlug,
      name: productName,
      price,
    })
    // GA4 e-commerce event (no-op when GA4 is not configured)
    if (productId) {
      ga4Events.viewItem({ id: productId, name: productName, price, currency })
    }
  }, [productSlug, productName, price, productId, currency])

  return null
}
