/**
 * Social icon helper — maps platform names to lucide-react icons.
 * Used by header, footer, and contact page.
 *
 * This file exports:
 *   - `getSocialIcon(platform)` — returns the LucideIcon for a platform
 *   - `getSocialLabel(platform)` — returns the human-readable label
 *   - `<SocialIcons links={...} />` — a ready-to-use React component that
 *     renders a row of social icon links. Used by both the Footer and the
 *     Contact page so they share the SAME visual style AND the SAME data
 *     source (SocialLink table via getSocialLinks()).
 */

import * as React from 'react'
import {
  Facebook,
  Instagram,
  Youtube,
  Twitter,
  Linkedin,
  MessageCircle,
  Send,
  Music,
  Image as ImageIcon,
  Link as LinkIcon,
} from 'lucide-react'
import type { LucideIcon } from 'lucide-react'

const PLATFORM_ICONS: Record<string, LucideIcon> = {
  facebook: Facebook,
  instagram: Instagram,
  youtube: Youtube,
  x: Twitter,
  twitter: Twitter,
  linkedin: Linkedin,
  whatsapp: MessageCircle,
  telegram: Send,
  tiktok: Music,
  pinterest: ImageIcon,
  custom: LinkIcon,
}

export function getSocialIcon(platform: string): LucideIcon {
  return PLATFORM_ICONS[platform.toLowerCase()] || LinkIcon
}

export function getSocialLabel(platform: string): string {
  const labels: Record<string, string> = {
    facebook: 'Facebook',
    instagram: 'Instagram',
    youtube: 'YouTube',
    x: 'X',
    twitter: 'Twitter',
    linkedin: 'LinkedIn',
    whatsapp: 'WhatsApp',
    telegram: 'Telegram',
    tiktok: 'TikTok',
    pinterest: 'Pinterest',
    custom: 'Link',
  }
  return labels[platform.toLowerCase()] || platform
}

export interface SocialLinkItem {
  id: string
  platform: string
  label: string | null
  url: string
  iconKey: string
}

/**
 * Reusable social icons row.
 *
 * Used by:
 *   - Footer (store-footer.tsx) — `size="sm"`
 *   - Contact page (contact/page.tsx) — `size="lg"`
 *
 * Both use the SAME `SocialLink` table data (via getSocialLinks()), so when
 * the admin changes a social link in /admin/settings → Social tab, BOTH
 * locations update automatically. No more sync issues.
 */
export function SocialIcons({
  links,
  size = 'sm',
  className = '',
}: {
  links: SocialLinkItem[]
  size?: 'sm' | 'lg'
  className?: string
}) {
  if (!links || links.length === 0) return null
  const sizeClass = size === 'lg' ? 'size-11' : 'size-9'
  const iconClass = size === 'lg' ? 'h-4 w-4' : 'h-3.5 w-3.5'
  return (
    <div className={`flex flex-wrap gap-2 ${className}`}>
      {links.map((link) => {
        const Icon = getSocialIcon(link.iconKey || link.platform)
        const label = link.label || getSocialLabel(link.platform)
        return (
          <a
            key={link.id}
            href={link.url}
            target="_blank"
            rel="noopener noreferrer"
            aria-label={label}
            title={label}
            className={`grid ${sizeClass} place-items-center rounded-full border border-border bg-card text-foreground transition-all hover:border-accent hover:bg-accent hover:text-accent-foreground hover:shadow-[var(--shadow-xs)]`}
          >
            <Icon className={iconClass} />
          </a>
        )
      })}
    </div>
  )
}
