'use client'

import { useState } from 'react'
import { ShoppingCart, Minus, Plus } from 'lucide-react'
import { useCart } from '@/lib/cart-store'
import { Button } from '@/components/ui/button'
import { toast } from 'sonner'
import Link from 'next/link'

export interface AddToCartProduct {
  id: string
  slug: string
  name: string
  sku: string
  price: number
  currencyCode: string
  stockQuantity: number
  lowStockThreshold: number
  trackInventory: boolean
  allowBackorder: boolean
  images: Array<{ secureUrl: string; url: string; altText?: string | null; isMain?: boolean }>
}

/**
 * AddToCartSection — quantity selector + primary + secondary CTA.
 *
 * DESIGN INTENT
 * -------------
 * - Quantity selector is a refined pill, not a chunky block
 * - Primary CTA is a large rounded button with the brand color
 * - "Order now" secondary is a darker button (warm charcoal) — direct
 *   shortcut to checkout for impatient buyers
 * - Disabled state when out of stock is visually clear (opacity + cursor)
 */
export function AddToCartSection({ product }: { product: AddToCartProduct }) {
  const add = useCart((s) => s.add)
  const openCart = useCart((s) => s.open)
  const [qty, setQty] = useState(1)

  const outOfStock =
    product.trackInventory && !product.allowBackorder && product.stockQuantity <= 0
  const maxQty = product.trackInventory ? Math.max(1, product.stockQuantity) : 99
  const price = Number(product.price)

  const handleAdd = () => {
    if (outOfStock) return
    add(
      {
        productId: product.id,
        slug: product.slug,
        name: product.name,
        sku: product.sku,
        price,
        image: product.images[0]?.secureUrl ?? product.images[0]?.url ?? null,
        maxStock: product.trackInventory ? product.stockQuantity : 999,
      },
      qty,
    )
    // Track add_to_cart event
    import('@/lib/track').then(({ trackEvent }) => {
      trackEvent('add_to_cart', {
        productId: product.id,
        productSlug: product.slug,
        productName: product.name,
        price,
        quantity: qty,
      })
    })
    toast.success('Ajouté au panier', { description: `${qty} × ${product.name}` })
  }

  return (
    <div className="space-y-3">
      {/* Quantity + Add to cart */}
      <div className="flex items-stretch gap-3">
        <div className="flex items-center rounded-full border border-border bg-card p-1 shadow-[var(--shadow-xs)]">
          <button
            onClick={() => setQty(Math.max(1, qty - 1))}
            className="grid size-9 place-items-center rounded-full text-foreground transition-colors hover:bg-muted disabled:opacity-40"
            aria-label="Diminuer la quantité"
            disabled={qty <= 1}
          >
            <Minus className="h-4 w-4" />
          </button>
          <span className="w-10 text-center font-mono text-sm font-semibold tabular-nums">
            {qty}
          </span>
          <button
            onClick={() => setQty(Math.min(maxQty, qty + 1))}
            className="grid size-9 place-items-center rounded-full text-foreground transition-colors hover:bg-muted disabled:opacity-40"
            aria-label="Augmenter la quantité"
            disabled={qty >= maxQty}
          >
            <Plus className="h-4 w-4" />
          </button>
        </div>
        <Button
          onClick={handleAdd}
          disabled={outOfStock}
          size="lg"
          className="btn-primary-cta flex-1 rounded-full h-12 text-base font-semibold"
        >
          <ShoppingCart className="mr-2 h-5 w-5" />
          {outOfStock ? 'Indisponible' : 'Ajouter au panier'}
        </Button>
      </div>

      {/* Direct checkout shortcut */}
      <Button
        asChild
        size="lg"
        className="btn-secondary-cta w-full rounded-full h-12 text-base font-semibold"
        onClick={() => {
          if (!outOfStock) {
            handleAdd()
            openCart()
          }
        }}
      >
        <Link href="/checkout" aria-disabled={outOfStock}>
          Commander maintenant
        </Link>
      </Button>
    </div>
  )
}
