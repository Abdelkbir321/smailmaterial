'use client'

import { useEffect, useRef } from 'react'
import { usePathname, useSearchParams } from 'next/navigation'

/**
 * Analytics Tracker
 * =================
 *
 * Automatically fires `page_view` events on route changes.
 * Uses `sendBeacon` for reliable delivery even during page unload.
 *
 * Features:
 *  - Dedup: won't fire the same page_view twice for the same path
 *  - Bot exclusion: admin pages are not tracked
 *  - UTM extraction: UTM params from URL are sent to the server
 *  - Referrer capture: document.referrer on first visit
 *  - No PII: no cookies beyond session ID, no fingerprinting
 */

const TRACKED_PATHS = /^\/(produits|categories|cart|checkout|contact|aide|recherche|confirmation|page|$)/

export function AnalyticsTracker() {
  const pathname = usePathname()
  const searchParams = useSearchParams()
  const lastPathRef = useRef<string | null>(null)

  useEffect(() => {
    // Don't track admin pages
    if (!pathname || pathname.startsWith('/admin') || pathname.startsWith('/api')) return

    // Only track storefront paths
    if (!TRACKED_PATHS.test(pathname)) return

    // Dedup — don't fire if path hasn't changed
    if (lastPathRef.current === pathname) return
    lastPathRef.current = pathname

    // Build the full URL
    const search = searchParams?.toString() || ''
    const pageUrl = typeof window !== 'undefined' ? window.location.href : ''
    const pagePath = pathname + (search ? `?${search}` : '')

    // Fire the event
    const eventData = {
      event: 'page_view',
      pageUrl,
      pagePath,
      referrer: typeof document !== 'undefined' ? document.referrer || null : null,
    }

    // Use sendBeacon for reliability, fallback to fetch
    if (typeof navigator !== 'undefined' && navigator.sendBeacon) {
      const blob = new Blob([JSON.stringify(eventData)], { type: 'application/json' })
      navigator.sendBeacon('/api/track', blob)
    } else {
      fetch('/api/track', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(eventData),
        keepalive: true,
      }).catch(() => {})
    }
  }, [pathname, searchParams])

  return null
}
