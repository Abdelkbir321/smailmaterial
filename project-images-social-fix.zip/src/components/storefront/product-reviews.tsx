'use client'

import * as React from 'react'
import { Star, BadgeCheck } from 'lucide-react'
import { ReviewForm } from './review-form'

interface Review {
  id: string
  customerName: string
  rating: number
  title: string | null
  body: string
  isVerified: boolean
  adminReply: string | null
  createdAt: string
}

interface ProductReviewsProps {
  productId: string
  productName: string
  /** Initial APPROVED reviews (server-rendered for SEO + fast first paint). */
  initialReviews: Review[]
  /** Initial aggregate (server-rendered). */
  initialAggregate: { ratingValue: number; reviewCount: number }
}

/**
 * Client component that displays the product's reviews + a submission form.
 *
 * The reviews are server-rendered initially (for SEO + fast first paint),
 * then this component takes over and allows:
 *   - Refreshing the list after a new review is submitted
 *   - Submitting a new review via the ReviewForm
 *
 * The aggregate rating + review count are also refreshed after submission
 * so the UI stays in sync with the server.
 */
export function ProductReviews({ productId, productName, initialReviews, initialAggregate }: ProductReviewsProps) {
  const [reviews, setReviews] = React.useState<Review[]>(initialReviews)
  const [aggregate, setAggregate] = React.useState(initialAggregate)

  async function refresh() {
    try {
      const res = await fetch(`/api/reviews?productId=${productId}`)
      const json = await res.json()
      if (json.ok) {
        setReviews(json.reviews || [])
        setAggregate(json.aggregate || { ratingValue: 0, reviewCount: 0 })
      }
    } catch {
      // silent — the initial server-rendered data is still showing
    }
  }

  return (
    <div className="mt-12 border-t border-border pt-8 sm:mt-16 sm:pt-12">
      {/* Header */}
      <div className="mb-6 flex flex-wrap items-center justify-between gap-3">
        <div>
          <span className="section-label">آراء العملاء</span>
          <h2 className="mt-3 font-display font-bold tracking-tight" style={{ fontSize: 'var(--text-xl)' }}>
            تقييمات المنتج
          </h2>
        </div>
        {aggregate.reviewCount > 0 && (
          <div className="flex items-center gap-2 text-sm">
            <span className="flex">
              {Array.from({ length: 5 }).map((_, i) => (
                <Star
                  key={i}
                  className={i < Math.round(aggregate.ratingValue)
                    ? 'size-4 text-amber-500 fill-amber-500'
                    : 'size-4 text-muted-foreground/30'}
                />
              ))}
            </span>
            <span className="font-medium">{aggregate.ratingValue.toFixed(1)}</span>
            <span className="text-muted-foreground">({aggregate.reviewCount} تقييم)</span>
          </div>
        )}
      </div>

      {/* Reviews list */}
      {reviews.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-border bg-card/40 p-8 text-center">
          <p className="font-medium text-sm">لا توجد تقييمات بعد</p>
          <p className="mt-1 text-xs text-muted-foreground">كن أول من يقيّم هذا المنتج.</p>
        </div>
      ) : (
        <div className="grid gap-4 sm:grid-cols-2">
          {reviews.map((r) => (
            <div key={r.id} className="rounded-2xl border border-border bg-card p-5">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="flex">
                    {Array.from({ length: 5 }).map((_, i) => (
                      <Star
                        key={i}
                        className={i < r.rating
                          ? 'size-3.5 text-amber-500 fill-amber-500'
                          : 'size-3.5 text-muted-foreground/30'}
                      />
                    ))}
                  </span>
                  <span className="font-display text-sm font-semibold">{r.customerName}</span>
                  {r.isVerified && (
                    <span className="inline-flex items-center gap-0.5 rounded-full bg-blue-50 px-1.5 py-0.5 text-[10px] font-medium text-blue-700">
                      <BadgeCheck className="size-3" /> شراء موثّق
                    </span>
                  )}
                </div>
                <span className="text-xs text-muted-foreground">
                  {new Date(r.createdAt).toLocaleDateString('ar-MA')}
                </span>
              </div>
              {r.title && <p className="mt-2 font-display text-sm font-semibold">{r.title}</p>}
              <p className="mt-1.5 text-sm leading-relaxed text-muted-foreground">{r.body}</p>
              {r.adminReply && (
                <div className="mt-3 rounded-md bg-muted/60 p-2 text-xs">
                  <p className="font-medium text-foreground mb-0.5">رد الإدارة:</p>
                  <p className="text-muted-foreground">{r.adminReply}</p>
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      {/* Submission form */}
      <div className="mt-8 rounded-2xl border border-border bg-card/50 p-5 sm:p-6">
        <h3 className="font-display font-bold tracking-tight mb-4" style={{ fontSize: 'var(--text-base)' }}>
          أضف تقييمك
        </h3>
        <ReviewForm
          productId={productId}
          productName={productName}
          onSubmitted={refresh}
        />
      </div>
    </div>
  )
}
