'use client'

import * as React from 'react'
import { Star, Loader2, Send, BadgeCheck, CheckCircle2 } from 'lucide-react'
import { toast } from 'sonner'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Label } from '@/components/ui/label'

interface ReviewFormProps {
  productId: string
  productName: string
  /** Called after a successful submission — parent can refresh the review list. */
  onSubmitted?: () => void
}

/**
 * Customer-facing review submission form.
 *
 * Features:
 *  - Star rating picker (1-5, defaults to 5)
 *  - Name (required, 2-60 chars)
 *  - Title (optional, max 120)
 *  - Body (required, 10-2000 chars) with live character counter
 *  - Optional phone number for Verified Purchase verification
 *  - Honeypot field (hidden `website` input) — bots fill it, humans don't
 *  - Client-side validation mirrors the server-side Zod schema
 *
 * The form is intentionally compact — it lives at the bottom of the product
 * page, below the existing reviews list. After submission, we show a success
 * message explaining whether the review is pending or auto-published.
 */
export function ReviewForm({ productId, productName, onSubmitted }: ReviewFormProps) {
  const [rating, setRating] = React.useState(5)
  const [hoverRating, setHoverRating] = React.useState(0)
  const [name, setName] = React.useState('')
  const [title, setTitle] = React.useState('')
  const [body, setBody] = React.useState('')
  const [phone, setPhone] = React.useState('')
  const [website, setWebsite] = React.useState('') // honeypot
  const [submitting, setSubmitting] = React.useState(false)
  const [errors, setErrors] = React.useState<Record<string, string>>({})
  const [success, setSuccess] = React.useState<{ status: string; isVerified: boolean } | null>(null)

  function validate(): boolean {
    const next: Record<string, string> = {}
    if (!name.trim() || name.trim().length < 2) next.name = 'الاسم قصير جداً'
    if (name.trim().length > 60) next.name = 'الاسم طويل جداً'
    if (rating < 1 || rating > 5) next.rating = 'اختر تقييماً من 1 إلى 5'
    if (!body.trim() || body.trim().length < 10) next.body = 'التعليق قصير جداً (10 أحرف على الأقل)'
    if (body.trim().length > 2000) next.body = 'التعليق طويل جداً'
    setErrors(next)
    return Object.keys(next).length === 0
  }

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault()
    // Honeypot — silent. The server will also check, but we skip the
    // network call entirely when the bot fills the field.
    if (website) {
      setSuccess({ status: 'PENDING', isVerified: false })
      return
    }
    if (!validate()) return
    setSubmitting(true)
    setErrors({})
    try {
      const res = await fetch('/api/reviews', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          productId,
          customerName: name.trim(),
          rating,
          title: title.trim() || undefined,
          body: body.trim(),
          orderPhone: phone.trim() || undefined,
          website, // honeypot — should be empty
        }),
      })
      const data = await res.json()
      if (!res.ok || !data.ok) {
        if (data.fieldErrors) {
          setErrors(data.fieldErrors)
        }
        toast.error(data.error || 'فشل إرسال التقييم')
        return
      }
      setSuccess({ status: data.status, isVerified: data.isVerified })
      // Reset form
      setName('')
      setTitle('')
      setBody('')
      setPhone('')
      setRating(5)
      onSubmitted?.()
    } catch {
      toast.error('خطأ في الشبكة')
    } finally {
      setSubmitting(false)
    }
  }

  if (success) {
    return (
      <div className="rounded-2xl border border-emerald-200 bg-emerald-50 p-5 text-center">
        <CheckCircle2 className="mx-auto size-10 text-emerald-600" />
        <p className="mt-3 font-medium text-emerald-800">
          {success.status === 'PENDING'
            ? 'شكراً! تقييمك في انتظار المراجعة.'
            : 'شكراً! تم نشر تقييمك.'}
        </p>
        {success.isVerified && (
          <p className="mt-1 text-sm text-emerald-700 flex items-center justify-center gap-1">
            <BadgeCheck className="size-4" /> تم تأكيد شرائك لهذا المنتج
          </p>
        )}
        <Button
          variant="outline"
          className="mt-4"
          onClick={() => setSuccess(null)}
        >
          إرسال تقييم آخر
        </Button>
      </div>
    )
  }

  return (
    <form onSubmit={onSubmit} className="space-y-4">
      <div>
        <Label>التقييم *</Label>
        <div className="mt-1.5 flex items-center gap-1">
          {Array.from({ length: 5 }).map((_, i) => {
            const val = i + 1
            const active = (hoverRating || rating) >= val
            return (
              <button
                key={i}
                type="button"
                onClick={() => setRating(val)}
                onMouseEnter={() => setHoverRating(val)}
                onMouseLeave={() => setHoverRating(0)}
                className="p-1 transition-transform hover:scale-110"
                aria-label={`${val} نجوم`}
              >
                <Star
                  className={active ? 'size-6 text-amber-500 fill-amber-500' : 'size-6 text-muted-foreground/30'}
                />
              </button>
            )
          })}
          <span className="ml-2 text-sm text-muted-foreground">
            {rating} / 5
          </span>
        </div>
        {errors.rating && <p className="text-xs text-destructive mt-1">{errors.rating}</p>}
      </div>

      <div className="grid gap-4 sm:grid-cols-2">
        <div className="space-y-1.5">
          <Label htmlFor="review-name">الاسم *</Label>
          <Input
            id="review-name"
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="اسمك"
            maxLength={60}
          />
          {errors.name && <p className="text-xs text-destructive">{errors.name}</p>}
        </div>
        <div className="space-y-1.5">
          <Label htmlFor="review-phone">رقم الهاتف (اختياري)</Label>
          <Input
            id="review-phone"
            type="tel"
            value={phone}
            onChange={(e) => setPhone(e.target.value)}
            placeholder="للتأكد من شراء موثّق"
            maxLength={30}
            dir="ltr"
            className="text-left"
          />
          <p className="text-xs text-muted-foreground">
            إن طابقت أرقام طلب مُسلّم، نُظهر شارة «شراء موثّق».
          </p>
        </div>
      </div>

      <div className="space-y-1.5">
        <Label htmlFor="review-title">العنوان (اختياري)</Label>
        <Input
          id="review-title"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          placeholder="ملخّص قصير"
          maxLength={120}
        />
      </div>

      <div className="space-y-1.5">
        <Label htmlFor="review-body">التعليق *</Label>
        <Textarea
          id="review-body"
          value={body}
          onChange={(e) => setBody(e.target.value)}
          placeholder={`شاركنا رأيك في ${productName}…`}
          rows={4}
          maxLength={2000}
        />
        <div className="flex justify-between text-xs text-muted-foreground">
          <span>{errors.body && <span className="text-destructive">{errors.body}</span>}</span>
          <span>{body.length} / 2000</span>
        </div>
      </div>

      {/* Honeypot — hidden from humans via CSS. Bots fill it. */}
      <div className="hidden" aria-hidden="true">
        <label>
          Website
          <input
            type="text"
            tabIndex={-1}
            autoComplete="off"
            value={website}
            onChange={(e) => setWebsite(e.target.value)}
          />
        </label>
      </div>

      <Button
        type="submit"
        disabled={submitting}
        className="bg-zinc-900 hover:bg-zinc-800"
      >
        {submitting ? (
          <>
            <Loader2 className="size-4 animate-spin" /> جارٍ الإرسال…
          </>
        ) : (
          <>
            <Send className="size-4" /> إرسال التقييم
          </>
        )}
      </Button>
    </form>
  )
}
