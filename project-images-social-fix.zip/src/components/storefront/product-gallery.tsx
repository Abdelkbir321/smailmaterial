'use client'

import { useState, useRef, useEffect, useCallback } from 'react'
import { cn } from '@/lib/utils'
import { ZoomIn, ChevronLeft, ChevronRight, X, Play, Video as VideoIcon } from 'lucide-react'

export interface GalleryImage {
  secureUrl: string
  url: string
  altText?: string | null
  isMain?: boolean
}

export interface GalleryVideo {
  id: string
  url: string
  sourceType: string // direct | youtube | vimeo | external
  embedId: string | null
  title: string | null
}

export function ProductGallery({
  images,
  videos = [],
  name,
}: {
  images: GalleryImage[]
  videos?: GalleryVideo[]
  name: string
}) {
  const ordered = [...images].sort((a, b) => (b.isMain ? 1 : 0) - (a.isMain ? 1 : 0))

  // Combined media items: images first, then videos
  type MediaItem = { type: 'image'; data: GalleryImage } | { type: 'video'; data: GalleryVideo }
  const mediaItems: MediaItem[] = [
    ...ordered.map((img) => ({ type: 'image' as const, data: img })),
    ...videos.map((vid) => ({ type: 'video' as const, data: vid })),
  ]

  const [active, setActive] = useState(0)
  const [zoom, setZoom] = useState(false)
  const [pos, setPos] = useState({ x: 50, y: 50 })
  const [fullscreen, setFullscreen] = useState(false)
  const imgRef = useRef<HTMLDivElement>(null)
  const touchStartX = useRef<number | null>(null)

  const next = useCallback(() => {
    setActive((a) => (a + 1) % mediaItems.length)
  }, [mediaItems.length])

  const prev = useCallback(() => {
    setActive((a) => (a - 1 + mediaItems.length) % mediaItems.length)
  }, [mediaItems.length])

  // Keyboard navigation
  useEffect(() => {
    if (!fullscreen) return
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setFullscreen(false)
      if (e.key === 'ArrowRight') next()
      if (e.key === 'ArrowLeft') prev()
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [fullscreen, next, prev])

  // Reset active when media changes
  useEffect(() => {
    setActive(0)
  }, [mediaItems.length])

  // Touch swipe
  const onTouchStart = (e: React.TouchEvent) => {
    touchStartX.current = e.touches[0].clientX
  }
  const onTouchEnd = (e: React.TouchEvent) => {
    if (touchStartX.current === null) return
    const diff = touchStartX.current - e.changedTouches[0].clientX
    if (Math.abs(diff) > 50) {
      if (diff > 0) next()
      else prev()
    }
    touchStartX.current = null
  }

  if (mediaItems.length === 0) {
    return (
      <div className="aspect-square w-full overflow-hidden rounded-3xl border border-border bg-muted/30 grid place-items-center text-muted-foreground/60">
        <span className="text-sm">Pas d'image</span>
      </div>
    )
  }

  const current = mediaItems[active]
  const hasMultiple = mediaItems.length > 1

  const onMove = (e: React.MouseEvent) => {
    if (!imgRef.current || current.type !== 'image') return
    const rect = imgRef.current.getBoundingClientRect()
    const x = ((e.clientX - rect.left) / rect.width) * 100
    const y = ((e.clientY - rect.top) / rect.height) * 100
    setPos({ x: Math.max(0, Math.min(100, x)), y: Math.max(0, Math.min(100, y)) })
  }

  // Build embed URL for YouTube/Vimeo
  const getEmbedUrl = (video: GalleryVideo): string | null => {
    if (video.sourceType === 'youtube' && video.embedId) {
      return `https://www.youtube.com/embed/${video.embedId}?rel=0&modestbranding=1`
    }
    if (video.sourceType === 'vimeo' && video.embedId) {
      return `https://player.vimeo.com/video/${video.embedId}`
    }
    return null
  }

  return (
    <>
      <div className="flex flex-col gap-3">
        {/* Main media display */}
        <div
          ref={imgRef}
          className="group relative aspect-square w-full overflow-hidden rounded-3xl border border-border bg-muted/30 shadow-[var(--shadow-sm)]"
          onMouseEnter={() => current.type === 'image' && setZoom(true)}
          onMouseLeave={() => setZoom(false)}
          onMouseMove={onMove}
          onTouchStart={onTouchStart}
          onTouchEnd={onTouchEnd}
        >
          {current.type === 'image' ? (
            <img
              src={current.data.secureUrl || current.data.url}
              alt={current.data.altText || name}
              className="h-full w-full object-cover transition-transform duration-300 ease-out"
              style={zoom ? { transformOrigin: `${pos.x}% ${pos.y}%`, transform: 'scale(1.8)' } : undefined}
              onClick={() => setFullscreen(true)}
            />
          ) : (
            <div className="h-full w-full bg-black">
              {/* Video player */}
              {current.data.sourceType === 'direct' ? (
                <video
                  src={current.data.url}
                  controls
                  className="h-full w-full object-contain"
                  preload="metadata"
                >
                  <source src={current.data.url} />
                  متصفحك لا يدعم تشغيل الفيديو.
                </video>
              ) : getEmbedUrl(current.data) ? (
                <iframe
                  src={getEmbedUrl(current.data)}
                  className="h-full w-full"
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                  allowFullScreen
                  title={current.data.title || name}
                />
              ) : (
                <div className="flex h-full flex-col items-center justify-center gap-3 p-6 text-center">
                  <VideoIcon className="h-12 w-12 text-muted-foreground" strokeWidth={1.2} />
                  <p className="text-sm text-muted-foreground">
                    هذا الرابط لا يمكن تشغيله مباشرة في المتصفح.
                  </p>
                  <a
                    href={current.data.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-xs text-primary underline"
                  >
                    فتح الرابط
                  </a>
                </div>
              )}
            </div>
          )}

          {/* Video badge */}
          {current.type === 'video' && (
            <div className="pointer-events-none absolute left-3 top-3">
              <span className="inline-flex items-center gap-1 rounded-full bg-black/70 px-2.5 py-1 text-[10px] font-bold text-white backdrop-blur">
                <Play className="h-3 w-3 fill-white" />
                فيديو
              </span>
            </div>
          )}

          {/* Zoom affordance (images only) */}
          {current.type === 'image' && (
            <div className="pointer-events-none absolute right-3 top-3 translate-y-[-4px] opacity-0 transition-all duration-200 group-hover:translate-y-0 group-hover:opacity-100">
              <button
                onClick={(e) => {
                  e.stopPropagation()
                  setFullscreen(true)
                }}
                className="grid size-8 place-items-center rounded-full bg-card/95 shadow-[var(--shadow-sm)] backdrop-blur transition-colors hover:bg-card"
                aria-label="تكبير الصورة"
              >
                <ZoomIn className="h-3.5 w-3.5 text-foreground" />
              </button>
            </div>
          )}

          {/* Navigation arrows */}
          {hasMultiple && (
            <>
              <button
                onClick={prev}
                className="absolute left-2 top-1/2 -translate-y-1/2 grid size-9 place-items-center rounded-full bg-card/90 shadow-[var(--shadow-sm)] backdrop-blur transition-all hover:bg-card opacity-0 group-hover:opacity-100"
                aria-label="السابق"
              >
                <ChevronLeft className="h-4 w-4" />
              </button>
              <button
                onClick={next}
                className="absolute right-2 top-1/2 -translate-y-1/2 grid size-9 place-items-center rounded-full bg-card/90 shadow-[var(--shadow-sm)] backdrop-blur transition-all hover:bg-card opacity-0 group-hover:opacity-100"
                aria-label="التالي"
              >
                <ChevronRight className="h-4 w-4" />
              </button>
            </>
          )}

          {/* Counter */}
          {hasMultiple && (
            <div className="pointer-events-none absolute bottom-3 left-1/2 -translate-x-1/2">
              <span className="rounded-full bg-black/60 px-2.5 py-0.5 text-[10px] font-medium text-white backdrop-blur">
                {active + 1} / {mediaItems.length}
              </span>
            </div>
          )}
        </div>

        {/* Thumbnails */}
        {hasMultiple && (
          <div className="grid grid-cols-5 gap-2 sm:grid-cols-6">
            {mediaItems.map((item, i) => (
              <button
                key={i}
                onClick={() => setActive(i)}
                className={cn(
                  'relative aspect-square overflow-hidden rounded-xl border bg-muted/30 transition-all duration-200',
                  i === active
                    ? 'border-primary shadow-[var(--shadow-xs)]'
                    : 'border-border hover:border-border-strong',
                )}
                aria-label={item.type === 'video' ? `فيديو ${i + 1}` : `صورة ${i + 1}`}
                aria-pressed={i === active}
              >
                {item.type === 'image' ? (
                  <img
                    src={item.data.secureUrl || item.data.url}
                    alt=""
                    className="h-full w-full object-cover"
                    loading="lazy"
                  />
                ) : (
                  <div className="flex h-full w-full items-center justify-center bg-zinc-900">
                    {item.data.sourceType === 'direct' ? (
                      <video src={item.data.url} className="h-full w-full object-cover" preload="metadata" muted />
                    ) : (
                      <Play className="h-5 w-5 text-white" fill="white" />
                    )}
                    <span className="absolute bottom-0.5 right-0.5 rounded bg-black/60 p-0.5">
                      <Play className="h-2.5 w-2.5 text-white" fill="white" />
                    </span>
                  </div>
                )}
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Fullscreen modal */}
      {fullscreen && current.type === 'image' && (
        <div
          className="fixed inset-0 z-[100] flex items-center justify-center bg-black/90 backdrop-blur-sm"
          onClick={() => setFullscreen(false)}
        >
          <button
            className="absolute right-4 top-4 grid size-10 place-items-center rounded-full bg-white/10 text-white transition-colors hover:bg-white/20"
            onClick={() => setFullscreen(false)}
            aria-label="إغلاق"
          >
            <X className="h-5 w-5" />
          </button>

          {hasMultiple && (
            <>
              <button
                className="absolute left-4 top-1/2 -translate-y-1/2 grid size-12 place-items-center rounded-full bg-white/10 text-white transition-colors hover:bg-white/20"
                onClick={(e) => {
                  e.stopPropagation()
                  prev()
                }}
                aria-label="السابق"
              >
                <ChevronLeft className="h-6 w-6" />
              </button>
              <button
                className="absolute right-4 top-1/2 -translate-y-1/2 grid size-12 place-items-center rounded-full bg-white/10 text-white transition-colors hover:bg-white/20"
                onClick={(e) => {
                  e.stopPropagation()
                  next()
                }}
                aria-label="التالي"
              >
                <ChevronRight className="h-6 w-6" />
              </button>
            </>
          )}

          <img
            src={current.data.secureUrl || current.data.url}
            alt={current.data.altText || name}
            className="max-h-[90vh] max-w-[90vw] object-contain"
            onClick={(e) => e.stopPropagation()}
          />

          {hasMultiple && (
            <div className="absolute bottom-4 left-1/2 -translate-x-1/2">
              <span className="rounded-full bg-white/10 px-3 py-1 text-xs font-medium text-white backdrop-blur">
                {active + 1} / {mediaItems.length}
              </span>
            </div>
          )}
        </div>
      )}
    </>
  )
}

/** Gallery skeleton */
export function ProductGallerySkeleton() {
  return (
    <div className="flex flex-col gap-3">
      <div className="skeleton-shimmer aspect-square w-full rounded-3xl" />
      <div className="grid grid-cols-5 gap-2">
        {Array.from({ length: 4 }).map((_, i) => (
          <div key={i} className="skeleton-shimmer aspect-square rounded-xl" />
        ))}
      </div>
    </div>
  )
}
