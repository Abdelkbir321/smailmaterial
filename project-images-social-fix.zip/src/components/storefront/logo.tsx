'use client'

import { useEffect, useRef } from 'react'
import { cn } from '@/lib/utils'
// IMPORTANT: import from @/lib/logo-config (NOT @/services/branding)
// because branding.ts is a server-side file with DB imports — importing
// it into a client component would drag the DB code into the client bundle.
import {
  DEFAULT_LOGO_MOBILE,
  DEFAULT_LOGO_MOTION,
  DEFAULT_LOGO_SIZE,
  DEFAULT_LOGO_VISUAL,
  type LogoMobile,
  type LogoMotion,
  type LogoSize,
  type LogoVisual,
} from '@/lib/logo-config'

/**
 * Logo — reusable component that renders the brand logo with admin-configured
 * size, motion, visual effects, and mobile-specific settings.
 *
 * ==========================================================================
 * EXPANDED FEATURES (this version)
 * --------------------------------------------------------------------------
 * - 7 motion types: breathe, float, rotate (2D), pulse, rotate3d, tilt, none
 * - 3D rotation with configurable X/Y/Z axes + perspective
 * - 3D tilt with direction control (horizontal/vertical/both)
 * - Visual effects: shadow, glow, border, background, border-radius, padding
 * - Mobile: independent animation disable, separate size, custom breakpoint
 * - Reduced-motion: always respected (animation skipped)
 * - "Black borders": if the logo image has black borders baked into the PNG,
 *   the admin can use background + padding + border-radius to create a clean
 *   container that visually crops/masks them. If the borders are part of the
 *   image itself, CSS cannot remove them — the admin must replace the image.
 * ==========================================================================
 */

interface LogoProps {
  /** Logo URL (admin-configured via Cloudinary or external URL). If null, uses /logo.svg */
  logoUrl: string | null
  /** Alt text for the image (typically the site name) */
  alt: string
  /** Size settings (null = use defaults 36×36) */
  size?: LogoSize | null
  /** Motion settings (null = use defaults: breathe, speed 1, intensity 0.5) */
  motion?: LogoMotion | null
  /** Visual effect settings (null = use defaults: no shadow/glow/border) */
  visual?: LogoVisual | null
  /** Mobile-specific settings (null = use defaults) */
  mobile?: LogoMobile | null
  /** Additional CSS classes (e.g. for layout context) */
  className?: string
  /** When true, the image fills its container (object-contain). Default: true */
  contain?: boolean
}

export function Logo({
  logoUrl,
  alt,
  size,
  motion,
  visual,
  mobile,
  className,
  contain = true,
}: LogoProps) {
  // Merge with defaults
  const finalSize = size ?? DEFAULT_LOGO_SIZE
  const finalMotion = motion ?? DEFAULT_LOGO_MOTION
  const finalVisual = visual ?? DEFAULT_LOGO_VISUAL
  const finalMobile = mobile ?? DEFAULT_LOGO_MOBILE

  const src = logoUrl || '/logo.svg'

  // Compute the container style (background, border, shadow, glow, radius, padding)
  const containerStyle = buildContainerStyle(finalVisual, finalSize)

  return (
    <div
      className={cn('relative grid place-items-center', className)}
      style={containerStyle}
    >
      <LogoImage
        src={src}
        alt={alt}
        size={finalSize}
        motion={finalMotion}
        visual={finalVisual}
        mobile={finalMobile}
      />
    </div>
  )
}

/**
 * Build the container's CSS style from the visual settings.
 * This applies shadow, glow, border, background, border-radius, padding.
 */
function buildContainerStyle(visual: LogoVisual, size: LogoSize): React.CSSProperties {
  const shadows: string[] = []

  // Drop shadow
  if (visual.shadow) {
    shadows.push(
      `${visual.shadow.offsetX}px ${visual.shadow.offsetY}px ${visual.shadow.blur}px ${visual.shadow.color}`,
    )
  }

  // Glow (colored box-shadow)
  if (visual.glow) {
    shadows.push(
      `0 0 ${visual.glow.blur}px ${visual.glow.color}`,
    )
  }

  const style: React.CSSProperties = {
    borderRadius: `${visual.borderRadius}px`,
    padding: `${visual.padding}px`,
    boxShadow: shadows.length > 0 ? shadows.join(', ') : undefined,
  }

  // Border
  if (visual.border && visual.border.width > 0) {
    style.border = `${visual.border.width}px ${visual.border.style} ${visual.border.color}`
  }

  // Background
  if (visual.background && visual.background.color !== 'transparent') {
    const opacity = visual.background.opacity
    if (opacity < 1) {
      // Convert hex to rgba for opacity
      const rgba = hexToRgba(visual.background.color, opacity)
      style.backgroundColor = rgba
    } else {
      style.backgroundColor = visual.background.color
    }
  }

  return style
}

/** Convert hex color to rgba string with given opacity. */
function hexToRgba(hex: string, opacity: number): string {
  const cleaned = hex.replace('#', '')
  const full = cleaned.length === 3
    ? cleaned.split('').map((c) => c + c).join('')
    : cleaned
  const r = parseInt(full.slice(0, 2), 16) || 0
  const g = parseInt(full.slice(2, 4), 16) || 0
  const b = parseInt(full.slice(4, 6), 16) || 0
  return `rgba(${r}, ${g}, ${b}, ${opacity})`
}

/**
 * Inner component that applies the animation via the Web Animations API.
 */
function LogoImage({
  src,
  alt,
  size,
  motion,
  visual,
  mobile,
}: {
  src: string
  alt: string
  size: LogoSize
  motion: LogoMotion
  visual: LogoVisual
  mobile: LogoMobile
}) {
  const ref = useAnimationRef(motion, mobile)

  const style: React.CSSProperties = {
    width: `${size.width}px`,
    height: `${size.height}px`,
    objectFit: 'contain',
    display: 'block',
  }

  return (
    <img
      ref={ref}
      src={src}
      alt={alt}
      style={style}
      draggable={false}
      onError={(e) => {
        const img = e.currentTarget as HTMLImageElement
        img.style.visibility = 'hidden'
      }}
    />
  )
}

/**
 * Hook that returns a ref to attach to the <img>. On mount, it starts the
 * animation based on the motion settings (skipped if reduced-motion is set
 * or if mobile animation is disabled on a mobile screen).
 */
function useAnimationRef(motion: LogoMotion, mobile: LogoMobile) {
  const ref = useRef<HTMLImageElement | null>(null)

  useEffect(() => {
    const el = ref.current
    if (!el) return

    // Reduced motion — render static, no animation
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return

    // 'none' = no animation
    if (motion.type === 'none') return

    // Mobile: check if animation is disabled on mobile screens
    const isMobile = window.innerWidth < mobile.breakpoint
    if (isMobile && mobile.disableAnimation) return

    const keyframes = getKeyframes(motion)
    if (!keyframes) return

    const baseDuration: Record<LogoMotion['type'], number> = {
      breathe: 2500,
      float: 2000,
      rotate: 8000,
      pulse: 1500,
      rotate3d: 6000,
      tilt: 4000,
      none: 0,
    }
    const duration = baseDuration[motion.type] / motion.speed

    // For 3D animations, set perspective on the parent + transform-style
    if (motion.type === 'rotate3d' || motion.type === 'tilt') {
      const perspective = motion.perspective ?? 600
      if (el.parentElement) {
        el.parentElement.style.perspective = `${perspective}px`
      }
      el.style.transformStyle = 'preserve-3d'
    }

    const animation = el.animate(keyframes, {
      duration,
      iterations: Infinity,
      easing: motion.type === 'rotate' || motion.type === 'rotate3d' ? 'linear' : 'ease-in-out',
    })

    return () => animation.cancel()
  }, [motion, mobile])

  return ref
}

/**
 * Build the Web Animations API keyframes for the given motion settings.
 */
function getKeyframes(motion: LogoMotion): Keyframe[] | null {
  const i = motion.intensity

  switch (motion.type) {
    case 'breathe':
      return [
        { opacity: 1 - 0.3 * i, offset: 0 },
        { opacity: 1, offset: 0.5 },
        { opacity: 1 - 0.3 * i, offset: 1 },
      ]

    case 'float': {
      const floatDelta = 4 * i
      return [
        { transform: 'translateY(0px)', offset: 0 },
        { transform: `translateY(-${floatDelta}px)`, offset: 0.5 },
        { transform: 'translateY(0px)', offset: 1 },
      ]
    }

    case 'rotate':
      return [
        { transform: 'rotate(0deg)', offset: 0 },
        { transform: 'rotate(360deg)', offset: 1 },
      ]

    case 'pulse': {
      const pulseMax = 1 + 0.05 * i
      return [
        { transform: 'scale(1)', offset: 0 },
        { transform: `scale(${pulseMax})`, offset: 0.5 },
        { transform: 'scale(1)', offset: 1 },
      ]
    }

    case 'rotate3d': {
      // 3D rotation around configured axes.
      // rotateX/Y/Z are the TOTAL rotation in degrees per cycle.
      const rx = motion.rotateX ?? 0
      const ry = motion.rotateY ?? 0
      const rz = motion.rotateZ ?? 360
      return [
        { transform: `rotateX(0deg) rotateY(0deg) rotateZ(0deg)`, offset: 0 },
        { transform: `rotateX(${rx}deg) rotateY(${ry}deg) rotateZ(${rz}deg)`, offset: 1 },
      ]
    }

    case 'tilt': {
      // 3D tilt — oscillates rotateX + rotateY.
      // intensity scales the max tilt angle.
      const maxAngle = 15 * i // 4.5° / 7.5° / 12°
      const dir = motion.tiltDirection ?? 'both'
      const rx = dir === 'horizontal' ? 0 : maxAngle
      const ry = dir === 'vertical' ? 0 : maxAngle
      return [
        { transform: `rotateX(${-rx}deg) rotateY(${-ry}deg)`, offset: 0 },
        { transform: `rotateX(${rx}deg) rotateY(${ry}deg)`, offset: 0.5 },
        { transform: `rotateX(${-rx}deg) rotateY(${-ry}deg)`, offset: 1 },
      ]
    }

    case 'none':
      return null

    default:
      return null
  }
}
