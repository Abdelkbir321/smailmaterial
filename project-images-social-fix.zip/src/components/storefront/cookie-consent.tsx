'use client'

import * as React from 'react'
import Link from 'next/link'
import { Cookie, X } from 'lucide-react'
import { Button } from '@/components/ui/button'

const STORAGE_KEY = 'cookie-consent-v1'
const CONSENT_EXPIRY_DAYS = 180

/**
 * Minimal cookie consent banner.
 *
 * Shows once (until the user accepts or declines). The choice is stored in
 * localStorage with a 6-month expiry — we don't use a cookie for this to
 * avoid the chicken-and-egg problem of needing consent to set a consent cookie.
 *
 * The banner mentions only the cookies we actually use (cart + first-party
 * analytics). No third-party trackers, no ad cookies. See the privacy policy
 * at /page/politique-confidentialite for the full list.
 *
 * Accepting OR declining both work — the site functions identically in both
 * cases. The only difference is that "accept" allows the analytics tracker
 * to send events; "decline" disables it (the tracker checks localStorage).
 */
export function CookieConsent() {
  const [visible, setVisible] = React.useState(false)

  React.useEffect(() => {
    // Only show on the client (after hydration) to avoid SSR mismatch.
    try {
      const stored = localStorage.getItem(STORAGE_KEY)
      if (stored) {
        const parsed = JSON.parse(stored) as { choice: 'accept' | 'decline'; ts: number }
        const ageDays = (Date.now() - parsed.ts) / (1000 * 60 * 60 * 24)
        if (ageDays < CONSENT_EXPIRY_DAYS) {
          // Still valid — apply the choice and don't show the banner
          if (parsed.choice === 'decline') {
            // Signal to the analytics tracker to not send events
            window.dispatchEvent(new CustomEvent('cookie-consent-declined'))
          }
          return
        }
      }
      // No stored choice or expired — show the banner
      setVisible(true)
    } catch {
      // localStorage unavailable (private browsing, etc.) — don't show
    }
  }, [])

  function choose(choice: 'accept' | 'decline') {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify({ choice, ts: Date.now() }))
    } catch {
      // ignore
    }
    if (choice === 'decline') {
      window.dispatchEvent(new CustomEvent('cookie-consent-declined'))
    } else {
      window.dispatchEvent(new CustomEvent('cookie-consent-accepted'))
    }
    setVisible(false)
  }

  if (!visible) return null

  return (
    <div
      role="dialog"
      aria-label="Consentement aux cookies"
      aria-live="polite"
      className="fixed inset-x-0 bottom-0 z-50 p-4 sm:p-6"
    >
      <div className="mx-auto max-w-3xl rounded-2xl border border-border bg-card p-4 shadow-[var(--shadow-lg)] sm:p-5">
        <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:gap-4">
          <div className="flex items-start gap-3 flex-1">
            <div className="grid size-9 flex-shrink-0 place-items-center rounded-full bg-muted text-primary">
              <Cookie className="size-4" />
            </div>
            <div className="text-sm">
              <p className="font-medium text-foreground">
                Nous utilisons des cookies essentiels et d'analyse.
              </p>
              <p className="mt-1 text-muted-foreground">
                Panier (localStorage) et statistiques de visite anonymes.
                Pas de publicité, pas de tracking tiers.{' '}
                <Link href="/page/politique-confidentialite" className="text-primary hover:underline">
                  En savoir plus
                </Link>
              </p>
            </div>
          </div>
          <div className="flex flex-shrink-0 gap-2 sm:flex-col">
            <Button
              size="sm"
              onClick={() => choose('accept')}
              className="bg-zinc-900 hover:bg-zinc-800"
            >
              Accepter
            </Button>
            <Button
              size="sm"
              variant="outline"
              onClick={() => choose('decline')}
            >
              Refuser
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}
