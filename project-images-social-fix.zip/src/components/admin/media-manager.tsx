'use client'

import * as React from 'react'
import { toast } from 'sonner'
import {
  Loader2, Plus, Trash2, Star, ImageIcon, Upload, X, ArrowUp, ArrowDown,
  Globe, Link as LinkIcon, Video as VideoIcon, Play, GripVertical,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Separator } from '@/components/ui/separator'

export interface MediaImage {
  id: string
  url: string
  secureUrl?: string
  altText: string | null
  isMain: boolean
  sourceType?: string
  publicId?: string | null
  sortOrder: number
}

export interface MediaVideo {
  id: string
  url: string
  sourceType: string
  embedId: string | null
  title: string | null
  sortOrder: number
}

interface MediaManagerProps {
  productId: string
  initialImages: MediaImage[]
  initialVideos: MediaVideo[]
  onImagesChange: (images: MediaImage[]) => void
}

export function MediaManager({ productId, initialImages, initialVideos, onImagesChange }: MediaManagerProps) {
  const [images, setImages] = React.useState<MediaImage[]>(initialImages)
  const [videos, setVideos] = React.useState<MediaVideo[]>(initialVideos)
  const [uploading, setUploading] = React.useState(false)
  const [savingMedia, setSavingMedia] = React.useState(false)
  const [bulkImageUrls, setBulkImageUrls] = React.useState('')
  const [bulkVideoUrls, setBulkVideoUrls] = React.useState('')
  const [addingBulk, setAddingBulk] = React.useState(false)
  const fileRef = React.useRef<HTMLInputElement>(null)

  // Drag state
  const [dragIndex, setDragIndex] = React.useState<number | null>(null)
  const [dragType, setDragType] = React.useState<'image' | 'video' | null>(null)

  // Notify parent when images change
  React.useEffect(() => {
    onImagesChange(images)
  }, [images, onImagesChange])

  // Sync when initialImages change (e.g. after server fetch)
  React.useEffect(() => {
    setImages(initialImages)
  }, [initialImages])
  React.useEffect(() => {
    setVideos(initialVideos)
  }, [initialVideos])

  // Fetch videos on mount (initialVideos may be empty — fetch from server)
  React.useEffect(() => {
    refreshMedia()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [productId])

  // --- File upload ---
  async function uploadFiles(files: FileList | null) {
    if (!files || files.length === 0) return
    setUploading(true)
    try {
      for (const file of Array.from(files)) {
        const formData = new FormData()
        formData.append('file', file)
        formData.append('productId', productId)
        if (images.length === 0) formData.append('isMain', 'true')
        const res = await fetch('/api/admin/upload', {
          method: 'POST',
          body: formData,
          credentials: 'include',
        })
        const json = await res.json()
        if (!res.ok || !json.ok) {
          toast.error(json.error || 'فشل الرفع')
          continue
        }
        const im = json.image
        if (im) {
          setImages((prev) => {
            const next = [...prev]
            if (im.isMain) next.forEach((i) => (i.isMain = false))
            next.push({
              id: im.id,
              url: im.secureUrl || im.url,
              secureUrl: im.secureUrl,
              altText: im.altText || '',
              isMain: im.isMain ?? false,
              sourceType: im.sourceType,
              publicId: im.publicId,
              sortOrder: next.length,
            })
            return next
          })
        }
      }
      toast.success('تم رفع الصور')
    } finally {
      setUploading(false)
      if (fileRef.current) fileRef.current.value = ''
    }
  }

  // --- Bulk add images from URLs ---
  async function addBulkImages() {
    const urls = bulkImageUrls
      .split('\n')
      .map((u) => u.trim())
      .filter((u) => u.length > 0)

    if (urls.length === 0) {
      toast.error('أدخل رابط واحد على الأقل')
      return
    }

    setAddingBulk(true)
    try {
      const res = await fetch(`/api/admin/products/${productId}/media`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          addImages: urls.map((url) => ({ url, altText: '' })),
        }),
        credentials: 'include',
      })
      const json = await res.json()
      if (!res.ok || !json.ok) {
        toast.error(json.error || 'فشل الإضافة')
        return
      }

      // Fetch updated images
      await refreshMedia()

      const added = json.addedImages || 0
      const errs = json.errors || []
      if (added > 0) {
        toast.success(`تمت إضافة ${added} صورة`)
      }
      if (errs.length > 0) {
        toast.error(`${errs.length} رابط غير صالح`)
      }
      setBulkImageUrls('')
    } catch {
      toast.error('خطأ في الشبكة')
    } finally {
      setAddingBulk(false)
    }
  }

  // --- Bulk add videos from URLs ---
  async function addBulkVideos() {
    const lines = bulkVideoUrls
      .split('\n')
      .map((l) => l.trim())
      .filter((l) => l.length > 0)

    if (lines.length === 0) {
      toast.error('أدخل رابط فيديو واحد على الأقل')
      return
    }

    // Parse: each line can be "url" or "url | title"
    const videosToAdd = lines.map((line) => {
      const [url, ...titleParts] = line.split('|')
      return {
        url: url.trim(),
        title: titleParts.join('|').trim() || '',
      }
    }).filter((v) => v.url.length > 0)

    setAddingBulk(true)
    try {
      const res = await fetch(`/api/admin/products/${productId}/media`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ addVideos: videosToAdd }),
        credentials: 'include',
      })
      const json = await res.json()
      if (!res.ok || !json.ok) {
        toast.error(json.error || 'فشل الإضافة')
        return
      }

      await refreshMedia()

      const added = json.addedVideos || 0
      const errs = json.errors || []
      if (added > 0) {
        toast.success(`تمت إضافة ${added} فيديو`)
      }
      if (errs.length > 0) {
        toast.error(`${errs.length} رابط فيديو غير صالح`)
      }
      setBulkVideoUrls('')
    } catch {
      toast.error('خطأ في الشبكة')
    } finally {
      setAddingBulk(false)
    }
  }

  // --- Refresh media from server ---
  async function refreshMedia() {
    try {
      const res = await fetch(`/api/admin/products/${productId}/media`, { credentials: 'include' })
      const json = await res.json()
      if (json.ok) {
        setImages(json.images.map((im: any) => ({
          id: im.id,
          url: im.secureUrl || im.url,
          secureUrl: im.secureUrl,
          altText: im.altText || '',
          isMain: im.isMain ?? false,
          sourceType: im.sourceType,
          publicId: im.publicId,
          sortOrder: im.sortOrder ?? 0,
        })))
        setVideos(json.videos.map((v: any) => ({
          id: v.id,
          url: v.url,
          sourceType: v.sourceType,
          embedId: v.embedId,
          title: v.title,
          sortOrder: v.sortOrder ?? 0,
        })))
      }
    } catch {}
  }

  // --- Set main image ---
  async function setMainImage(id: string) {
    // Optimistic update
    setImages((prev) => prev.map((i) => ({ ...i, isMain: i.id === id })))
    // Persist
    const reordered = images.map((i, idx) => ({
      id: i.id,
      sortOrder: idx,
      isMain: i.id === id,
    }))
    try {
      await fetch(`/api/admin/products/${productId}/media`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ reorderImages: reordered }),
        credentials: 'include',
      })
      toast.success('تم تعيين الصورة الرئيسية')
    } catch {
      toast.error('فشل الحفظ')
    }
  }

  // --- Delete image ---
  async function deleteImage(id: string) {
    if (!confirm('هل تريد حذف هذه الصورة؟')) return
    setImages((prev) => prev.filter((i) => i.id !== id))
    try {
      await fetch(`/api/admin/products/${productId}/media`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ deleteImage: id }),
        credentials: 'include',
      })
      toast.success('تم حذف الصورة')
      await refreshMedia()
    } catch {
      toast.error('فشل الحذف')
    }
  }

  // --- Delete video ---
  async function deleteVideo(id: string) {
    if (!confirm('هل تريد حذف هذا الفيديو؟')) return
    setVideos((prev) => prev.filter((v) => v.id !== id))
    try {
      await fetch(`/api/admin/products/${productId}/media`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ deleteVideo: id }),
        credentials: 'include',
      })
      toast.success('تم حذف الفيديو')
    } catch {
      toast.error('فشل الحذف')
    }
  }

  // --- Update video title ---
  async function updateVideoTitle(id: string, title: string) {
    setVideos((prev) => prev.map((v) => (v.id === id ? { ...v, title } : v)))
  }

  async function saveVideoTitle(id: string) {
    const video = videos.find((v) => v.id === id)
    if (!video) return
    try {
      await fetch(`/api/admin/products/${productId}/media`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ updateVideoTitle: { id, title: video.title || '' } }),
        credentials: 'include',
      })
      toast.success('تم حفظ العنوان')
    } catch {
      toast.error('فشل الحفظ')
    }
  }

  // --- Save image order ---
  async function saveImageOrder() {
    setSavingMedia(true)
    const reordered = images.map((i, idx) => ({
      id: i.id,
      sortOrder: idx,
      isMain: i.isMain,
    }))
    try {
      await fetch(`/api/admin/products/${productId}/media`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ reorderImages: reordered }),
        credentials: 'include',
      })
      toast.success('تم حفظ ترتيب الصور')
    } catch {
      toast.error('فشل الحفظ')
    } finally {
      setSavingMedia(false)
    }
  }

  // --- Drag and drop handlers ---
  function onDragStart(index: number, type: 'image' | 'video') {
    setDragIndex(index)
    setDragType(type)
  }

  function onDragOver(e: React.DragEvent, index: number, type: 'image' | 'video') {
    e.preventDefault()
    if (dragIndex === null || dragType !== type) return
    if (index === dragIndex) return

    if (type === 'image') {
      setImages((prev) => {
        const next = [...prev]
        const [moved] = next.splice(dragIndex, 1)
        next.splice(index, 0, moved)
        return next
      })
    } else {
      setVideos((prev) => {
        const next = [...prev]
        const [moved] = next.splice(dragIndex, 1)
        next.splice(index, 0, moved)
        return next
      })
    }
    setDragIndex(index)
  }

  function onDragEnd() {
    setDragIndex(null)
    setDragType(null)
  }

  function sourceBadge(sourceType?: string) {
    if (sourceType === 'cloudinary') {
      return <span className="bg-emerald-600 text-white text-[10px] font-medium px-1.5 py-0.5 rounded">Cloudinary</span>
    }
    if (sourceType === 'external') {
      return <span className="bg-orange-500 text-white text-[10px] font-medium px-1.5 py-0.5 rounded">رابط خارجي</span>
    }
    return null
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-base">صور وفيديوهات المنتج</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* === File upload dropzone === */}
        <div
          onDragOver={(e) => e.preventDefault()}
          onDrop={(e) => {
            e.preventDefault()
            uploadFiles(e.dataTransfer.files)
          }}
          className="border-2 border-dashed rounded-lg p-6 text-center cursor-pointer hover:bg-muted/50 transition-colors"
          onClick={() => fileRef.current?.click()}
        >
          <input
            ref={fileRef}
            type="file"
            accept="image/*"
            multiple
            className="hidden"
            onChange={(e) => uploadFiles(e.target.files)}
          />
          {uploading ? (
            <div className="flex flex-col items-center gap-2 text-muted-foreground">
              <Loader2 className="size-6 animate-spin" />
              <p className="text-sm">جارٍ الرفع…</p>
            </div>
          ) : (
            <div className="flex flex-col items-center gap-2 text-muted-foreground">
              <Upload className="size-6" />
              <p className="text-sm font-medium">اسحب الصور هنا، أو اضغط لتصفح الملفات</p>
              <p className="text-xs">PNG، JPG، WEBP — حد أقصى 25 ميغابايت</p>
            </div>
          )}
        </div>

        {/* === Bulk image URLs === */}
        <Separator />
        <div className="space-y-2">
          <div className="flex items-center gap-2 text-sm font-medium">
            <LinkIcon className="size-4" />
            إضافة صور متعددة بالروابط (رابط واحد في كل سطر)
          </div>
          <Textarea
            placeholder={'https://example.com/image1.jpg\nhttps://example.com/image2.jpg\nhttps://res.cloudinary.com/...'}
            value={bulkImageUrls}
            onChange={(e) => setBulkImageUrls(e.target.value)}
            rows={4}
            dir="ltr"
            className="text-left font-mono text-xs"
          />
          <div className="flex items-center justify-between">
            <p className="text-xs text-muted-foreground">
              يتم التحقق من كل رابط على الخادم. الصور غير الصالحة يتم تجاهلها.
            </p>
            <Button
              type="button"
              size="sm"
              onClick={addBulkImages}
              disabled={addingBulk || !bulkImageUrls.trim()}
              className="bg-zinc-900 hover:bg-zinc-800"
            >
              {addingBulk ? <Loader2 className="size-4 animate-spin" /> : <Plus className="size-4" />}
              إضافة الصور
            </Button>
          </div>
        </div>

        {/* === Existing images === */}
        <Separator />
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-sm font-medium">
              <ImageIcon className="size-4" />
              الصور الحالية ({images.length})
            </div>
            {images.length > 1 && (
              <Button size="sm" variant="outline" onClick={saveImageOrder} disabled={savingMedia}>
                {savingMedia ? <Loader2 className="size-4 animate-spin" /> : null}
                حفظ الترتيب
              </Button>
            )}
          </div>
          <p className="text-xs text-muted-foreground">
            اسحب الصور لإعادة الترتيب. اضغط نجمة لتعيين الصورة الرئيسية.
          </p>
          {images.length > 0 ? (
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-4">
              {images.map((im, i) => (
                <div
                  key={im.id}
                  draggable
                  onDragStart={() => onDragStart(i, 'image')}
                  onDragOver={(e) => onDragOver(e, i, 'image')}
                  onDragEnd={onDragEnd}
                  className={`group relative border rounded-lg overflow-hidden bg-muted cursor-move transition-opacity ${dragIndex === i ? 'opacity-40' : ''}`}
                >
                  <div className="aspect-square relative bg-muted">
                    <img
                      src={im.secureUrl || im.url}
                      alt={im.altText || ''}
                      className="size-full object-cover"
                      onError={(e) => {
                        // When the image fails to load (broken URL, 404, hotlink
                        // protection), replace it with the placeholder so the
                        // admin sees a clear "broken image" state instead of a
                        // blank box or a text URL.
                        const target = e.currentTarget
                        if (target.src !== '/products/placeholder.svg') {
                          target.src = '/products/placeholder.svg'
                        }
                      }}
                    />
                    <div className="absolute top-1 right-1 flex flex-col gap-1">
                      {im.isMain && (
                        <span className="bg-emerald-600 text-white text-[10px] font-medium px-1.5 py-0.5 rounded flex items-center gap-0.5">
                          <Star className="size-2.5 fill-white" /> رئيسية
                        </span>
                      )}
                      {sourceBadge(im.sourceType)}
                    </div>
                    <div className="absolute top-1 left-1 opacity-50">
                      <GripVertical className="size-3 text-white drop-shadow" />
                    </div>
                  </div>
                  <div className="p-1.5 space-y-1">
                    <Input
                      placeholder="نص بديل"
                      value={im.altText || ''}
                      onChange={(e) => {
                        const v = e.target.value
                        setImages((prev) => prev.map((x) => (x.id === im.id ? { ...x, altText: v } : x)))
                      }}
                      className="h-6 text-xs"
                    />
                    <div className="flex items-center gap-0.5">
                      {!im.isMain && (
                        <Button
                          size="icon"
                          variant="ghost"
                          className="size-6"
                          onClick={() => setMainImage(im.id)}
                          title="تعيين كصورة رئيسية"
                        >
                          <Star className="size-3" />
                        </Button>
                      )}
                      <Button
                        size="icon"
                        variant="ghost"
                        className="mr-auto size-6 text-rose-600"
                        onClick={() => deleteImage(im.id)}
                        title="حذف"
                      >
                        <X className="size-3" />
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center text-muted-foreground text-sm flex items-center justify-center gap-2 py-6">
              <ImageIcon className="size-4" />
              لا توجد صور. ارفعها أو أضف روابط أعلاه.
            </div>
          )}
        </div>

        {/* === Videos section === */}
        <Separator />
        <div className="space-y-2">
          <div className="flex items-center gap-2 text-sm font-medium">
            <VideoIcon className="size-4" />
            الفيديوهات ({videos.length})
          </div>

          {/* Bulk video URLs */}
          <div className="space-y-2 rounded-lg border border-border p-3 bg-muted/20">
            <Label className="text-xs">إضافة فيديوهات (رابط واحد في كل سطر)</Label>
            <Textarea
              placeholder={'https://example.com/video.mp4\nhttps://youtube.com/watch?v=XXXXX | طريقة الاستعمال\nhttps://vimeo.com/123456'}
              value={bulkVideoUrls}
              onChange={(e) => setBulkVideoUrls(e.target.value)}
              rows={3}
              dir="ltr"
              className="text-left font-mono text-xs"
            />
            <p className="text-xs text-muted-foreground">
              يدعم: روابط مباشرة (.mp4, .webm), YouTube, Vimeo. أضف عنوان بعد الرابط بـ | (اختياري).
            </p>
            <Button
              type="button"
              size="sm"
              onClick={addBulkVideos}
              disabled={addingBulk || !bulkVideoUrls.trim()}
              className="bg-zinc-900 hover:bg-zinc-800"
            >
              {addingBulk ? <Loader2 className="size-4 animate-spin" /> : <Plus className="size-4" />}
              إضافة الفيديوهات
            </Button>
          </div>

          {/* Existing videos */}
          {videos.length > 0 ? (
            <div className="space-y-2">
              {videos.map((vid, i) => (
                <div
                  key={vid.id}
                  draggable
                  onDragStart={() => onDragStart(i, 'video')}
                  onDragOver={(e) => onDragOver(e, i, 'video')}
                  onDragEnd={onDragEnd}
                  className={`flex gap-3 rounded-lg border border-border p-3 bg-card cursor-move transition-opacity ${dragIndex === i ? 'opacity-40' : ''}`}
                >
                  {/* Video preview */}
                  <div className="relative size-20 shrink-0 overflow-hidden rounded-lg bg-black">
                    {vid.sourceType === 'direct' ? (
                      <video src={vid.url} className="h-full w-full object-cover" preload="metadata" muted />
                    ) : (
                      <div className="flex h-full w-full items-center justify-center">
                        <Play className="h-6 w-6 text-white" fill="white" />
                      </div>
                    )}
                    <span className="absolute bottom-0.5 right-0.5 rounded bg-black/60 px-1 text-[8px] text-white">
                      {vid.sourceType}
                    </span>
                  </div>

                  {/* Video info */}
                  <div className="flex-1 space-y-1">
                    <Input
                      placeholder="عنوان الفيديو (اختياري) — مثال: طريقة الاستعمال"
                      value={vid.title || ''}
                      onChange={(e) => updateVideoTitle(vid.id, e.target.value)}
                      className="h-7 text-xs"
                    />
                    <p className="truncate text-[10px] text-muted-foreground font-mono" dir="ltr">
                      {vid.url}
                    </p>
                    <div className="flex gap-1">
                      <Button
                        size="sm"
                        variant="outline"
                        className="h-6 text-xs"
                        onClick={() => saveVideoTitle(vid.id)}
                      >
                        حفظ العنوان
                      </Button>
                      <Button
                        size="icon"
                        variant="ghost"
                        className="size-6 text-rose-600"
                        onClick={() => deleteVideo(vid.id)}
                      >
                        <Trash2 className="size-3" />
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-center text-muted-foreground text-sm py-4">
              لا توجد فيديوهات. أضف روابط أعلاه.
            </p>
          )}
        </div>
      </CardContent>
    </Card>
  )
}
