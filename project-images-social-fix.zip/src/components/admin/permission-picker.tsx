'use client'

import * as React from 'react'
import { Lock, CheckCheck, X as XIcon } from 'lucide-react'

import { Switch } from '@/components/ui/switch'
import { Button } from '@/components/ui/button'
import { cn } from '@/lib/utils'

/** The action labels are shown in Arabic next to each toggle. */
const ACTION_LABEL: Record<string, string> = {
  view: 'عرض',
  create: 'إنشاء',
  edit: 'تعديل',
  delete: 'حذف',
  publish: 'نشر',
  manage_settings: 'إدارة الإعدادات',
}

export interface PermissionSection {
  key: string
  label?: string
  labelAr?: string
  actions: string[]
}

export type PermissionMap = Record<string, string[]>

const SENSITIVE_SECTIONS = new Set(['admin_users', 'permissions', 'security'])

interface PermissionPickerProps {
  sections: PermissionSection[]
  value: PermissionMap
  onChange: (next: PermissionMap) => void
  disabled?: boolean
}

/**
 * Controlled permission picker. Renders a grid of 21 sections, each with
 * a row of switches for every allowed action. Selecting/deselecting an
 * action mutates `value[section]` and emits the new map via `onChange`.
 */
export function PermissionPicker({
  sections,
  value,
  onChange,
  disabled,
}: PermissionPickerProps) {
  const isOn = (section: string, action: string) => {
    const acts = value[section]
    return Array.isArray(acts) && acts.includes(action)
  }

  function toggle(section: string, action: string, on: boolean) {
    const prev = value[section] ?? []
    const set = new Set(prev)
    if (on) set.add(action)
    else set.delete(action)
    const next = { ...value }
    if (set.size === 0) {
      delete next[section]
    } else {
      next[section] = Array.from(set)
    }
    onChange(next)
  }

  function selectAll() {
    const next: PermissionMap = {}
    for (const s of sections) {
      next[s.key] = [...s.actions]
    }
    onChange(next)
  }

  function clearAll() {
    onChange({})
  }

  function selectSection(section: PermissionSection) {
    onChange({ ...value, [section.key]: [...section.actions] })
  }

  function clearSection(sectionKey: string) {
    const next = { ...value }
    delete next[sectionKey]
    onChange(next)
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center gap-2 sticky top-0 bg-background/95 backdrop-blur py-1 z-10">
        <Button
          type="button"
          variant="outline"
          size="sm"
          onClick={selectAll}
          disabled={disabled}
        >
          <CheckCheck className="size-4" />
          تحديد الكل
        </Button>
        <Button
          type="button"
          variant="outline"
          size="sm"
          onClick={clearAll}
          disabled={disabled}
        >
          <XIcon className="size-4" />
          إلغاء الكل
        </Button>
        <span className="text-muted-foreground text-xs mr-auto">
          {sections.length} قسم — الصلاحيات تُطبّق على الدور، لا على المسؤول وحده.
        </span>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        {sections.map((section) => {
          const sensitive = SENSITIVE_SECTIONS.has(section.key)
          const granted = value[section.key] ?? []
          const grantedCount = granted.length
          return (
            <div
              key={section.key}
              className={cn(
                'rounded-lg border bg-card p-3 shadow-sm',
                sensitive && 'border-amber-300 bg-amber-50/40',
              )}
            >
              <div className="flex items-start justify-between gap-2 mb-2">
                <div className="flex flex-col">
                  <div className="flex items-center gap-1.5">
                    {sensitive && (
                      <Lock className="size-3.5 text-amber-600" />
                    )}
                    <span className="font-medium text-sm">
                      {section.labelAr || section.label || section.key}
                    </span>
                  </div>
                  <span
                    className="text-muted-foreground text-[10px] font-mono"
                    dir="ltr"
                  >
                    {section.key}
                  </span>
                </div>
                <div className="flex items-center gap-1">
                  <span
                    className={cn(
                      'text-[10px] px-1.5 py-0.5 rounded font-medium tabular-nums',
                      grantedCount > 0
                        ? 'bg-emerald-100 text-emerald-700'
                        : 'bg-zinc-100 text-zinc-500',
                    )}
                  >
                    {grantedCount}/{section.actions.length}
                  </span>
                  {grantedCount > 0 ? (
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      className="h-7 px-2 text-[11px]"
                      onClick={() => clearSection(section.key)}
                      disabled={disabled}
                    >
                      مسح
                    </Button>
                  ) : (
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      className="h-7 px-2 text-[11px]"
                      onClick={() => selectSection(section)}
                      disabled={disabled}
                    >
                      الكل
                    </Button>
                  )}
                </div>
              </div>

              {sensitive && (
                <p className="text-amber-700 text-[11px] mb-2 flex items-center gap-1">
                  <Lock className="size-3" />
                  صلاحيات حساسة
                </p>
              )}

              <div className="flex flex-wrap gap-3 pt-1">
                {section.actions.map((action) => {
                  const on = isOn(section.key, action)
                  return (
                    <label
                      key={action}
                      className={cn(
                        'flex items-center gap-1.5 rounded-md border px-2 py-1 cursor-pointer select-none',
                        on
                          ? 'border-emerald-300 bg-emerald-50'
                          : 'border-zinc-200 bg-background',
                        disabled && 'opacity-60 pointer-events-none',
                      )}
                    >
                      <Switch
                        checked={on}
                        onCheckedChange={(v) => toggle(section.key, action, v)}
                        disabled={disabled}
                      />
                      <span className="text-xs">{ACTION_LABEL[action] ?? action}</span>
                    </label>
                  )
                })}
              </div>
            </div>
          )
        })}
      </div>
    </div>
  )
}
