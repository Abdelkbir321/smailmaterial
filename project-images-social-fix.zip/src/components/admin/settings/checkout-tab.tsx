'use client'

import * as React from 'react'
import { Save, Loader2, Truck, RotateCcw, Star } from 'lucide-react'
import { toast } from 'sonner'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Label } from '@/components/ui/label'
import { Switch } from '@/components/ui/switch'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import type { CheckoutTexts, ShippingReturnSettings } from '@/services/site-settings'

interface CheckoutTabProps {
  initial: CheckoutTexts
  initialShipping: ShippingReturnSettings
}

type Lang = 'fr' | 'ar' | 'en'

const LANG_LABELS: Record<Lang, string> = { fr: 'Français', ar: 'العربية', en: 'English' }

const SECTIONS: Array<{ key: keyof CheckoutTexts; label: string; type: 'input' | 'textarea' }> = [
  { key: 'pageTitle', label: 'عنوان الصفحة', type: 'input' },
  { key: 'pageSubtitle', label: 'العنوان الفرعي للصفحة', type: 'input' },
  { key: 'buyerInfoTitle', label: 'عنوان قسم معلومات المشتري', type: 'input' },
  { key: 'buyerInfoHelper', label: 'نص توضيحي للمشتري', type: 'input' },
  { key: 'paymentTitle', label: 'عنوان قسم الدفع', type: 'input' },
  { key: 'paymentDescription', label: 'وصف الدفع', type: 'textarea' },
  { key: 'submitButton', label: 'نص زر التأكيد', type: 'input' },
  { key: 'submitHelper', label: 'نص مساعدة الزر', type: 'input' },
  { key: 'cartTitle', label: 'عنوان السلة', type: 'input' },
  { key: 'subtotalLabel', label: 'المجموع الفرعي', type: 'input' },
  { key: 'shippingLabel', label: 'التوصيل', type: 'input' },
  { key: 'totalLabel', label: 'المجموع', type: 'input' },
  { key: 'freeShippingLabel', label: 'توصيل مجاني', type: 'input' },
  { key: 'trustCod', label: 'شارة الدفع عند الاستلام', type: 'input' },
  { key: 'trustShipping', label: 'شارة التوصيل', type: 'input' },
  { key: 'trustPrivacy', label: 'شارة الخصوصية', type: 'input' },
  { key: 'successMessage', label: 'رسالة النجاح', type: 'input' },
  { key: 'errorMessage', label: 'رسالة الخطأ', type: 'input' },
  { key: 'processingMessage', label: 'رسالة المعالجة', type: 'input' },
]

export function CheckoutTab({ initial, initialShipping }: CheckoutTabProps) {
  const [texts, setTexts] = React.useState<CheckoutTexts>(initial)
  const [shipping, setShipping] = React.useState<ShippingReturnSettings>(initialShipping)
  const [savingTexts, setSavingTexts] = React.useState(false)
  const [savingShipping, setSavingShipping] = React.useState(false)
  const [lang, setLang] = React.useState<Lang>('fr')

  const update = (key: keyof CheckoutTexts, value: string) => {
    setTexts({ ...texts, [key]: { ...texts[key], [lang]: value } })
  }

  const saveTexts = async () => {
    setSavingTexts(true)
    try {
      const res = await fetch('/api/admin/settings', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ settings: { checkout_texts: JSON.stringify(texts) } }),
      })
      if (res.ok) {
        toast.success('تم حفظ نصوص الدفع')
      } else {
        toast.error('فشل الحفظ')
      }
    } catch {
      toast.error('خطأ في الشبكة')
    } finally {
      setSavingTexts(false)
    }
  }

  const saveShipping = async () => {
    setSavingShipping(true)
    try {
      const res = await fetch('/api/admin/settings', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ settings: { shipping_return_settings: JSON.stringify(shipping) } }),
      })
      if (res.ok) {
        toast.success('تم حفظ إعدادات الشحن والإرجاع')
      } else {
        toast.error('فشل الحفظ')
      }
    } catch {
      toast.error('خطأ في الشبكة')
    } finally {
      setSavingShipping(false)
    }
  }

  return (
    <div className="space-y-4">
      {/* ─── Shipping & Return Policy ─── */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Truck className="size-4" /> سياسة الشحن والإرجاع
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-xs text-muted-foreground">
            هذه القيم تُستعمل في البيانات المنظمة (Product Schema) وفي صفحة
            «التوصيل والإرجاع». أي تغيير هنا ينعكس تلقائياً على جميع صفحات المنتجات.
          </p>
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-1.5">
              <Label htmlFor="shipping-rate">تكلفة التوصيل (الحد الأدنى)</Label>
              <Input
                id="shipping-rate"
                type="number"
                min={0}
                value={shipping.shippingRate}
                onChange={(e) => setShipping({ ...shipping, shippingRate: Number(e.target.value) || 0 })}
                dir="ltr"
                className="text-left"
              />
              <p className="text-xs text-muted-foreground">0 = توصيل مجاني</p>
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="shipping-currency">العملة</Label>
              <Input
                id="shipping-currency"
                value={shipping.shippingCurrency}
                onChange={(e) => setShipping({ ...shipping, shippingCurrency: e.target.value.toUpperCase().slice(0, 3) })}
                dir="ltr"
                className="text-left"
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="free-shipping">حد التوصيل المجاني</Label>
              <Input
                id="free-shipping"
                type="number"
                min={0}
                value={shipping.freeShippingThreshold}
                onChange={(e) => setShipping({ ...shipping, freeShippingThreshold: Number(e.target.value) || 0 })}
                dir="ltr"
                className="text-left"
              />
              <p className="text-xs text-muted-foreground">0 = لا يوجد توصيل مجاني</p>
            </div>
            <div className="grid grid-cols-2 gap-2">
              <div className="space-y-1.5">
                <Label htmlFor="min-days">أقل أيام</Label>
                <Input
                  id="min-days"
                  type="number"
                  min={0}
                  max={30}
                  value={shipping.deliveryTimeMinDays}
                  onChange={(e) => setShipping({ ...shipping, deliveryTimeMinDays: Number(e.target.value) || 0 })}
                  dir="ltr"
                  className="text-left"
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="max-days">أكثر أيام</Label>
                <Input
                  id="max-days"
                  type="number"
                  min={0}
                  max={60}
                  value={shipping.deliveryTimeMaxDays}
                  onChange={(e) => setShipping({ ...shipping, deliveryTimeMaxDays: Number(e.target.value) || 0 })}
                  dir="ltr"
                  className="text-left"
                />
              </div>
            </div>
          </div>

          <div className="space-y-3 rounded-lg border p-3">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium">السماح بالإرجاع</p>
                <p className="text-xs text-muted-foreground">يظهر `hasMerchantReturnPolicy` في الـ Schema</p>
              </div>
              <Switch
                checked={shipping.returnsEnabled}
                onCheckedChange={(v) => setShipping({ ...shipping, returnsEnabled: v })}
              />
            </div>
            {shipping.returnsEnabled && (
              <div className="space-y-1.5">
                <Label htmlFor="return-days">مدة الإرجاع (أيام)</Label>
                <Input
                  id="return-days"
                  type="number"
                  min={1}
                  max={90}
                  value={shipping.returnPolicyDays}
                  onChange={(e) => setShipping({ ...shipping, returnPolicyDays: Number(e.target.value) || 0 })}
                  dir="ltr"
                  className="text-left"
                />
              </div>
            )}
            {shipping.returnsEnabled && (
              <div className="grid grid-cols-2 gap-2">
                <div className="space-y-1.5">
                  <Label htmlFor="return-fees">مصاريف إرجاع الشحن</Label>
                  <Input
                    id="return-fees"
                    type="number"
                    min={0}
                    value={shipping.returnShippingFeesAmount}
                    onChange={(e) => setShipping({ ...shipping, returnShippingFeesAmount: Number(e.target.value) || 0 })}
                    dir="ltr"
                    className="text-left"
                  />
                  <p className="text-xs text-muted-foreground">0 = إرجاع مجاني</p>
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="return-fees-currency">عملة مصاريف الإرجاع</Label>
                  <Input
                    id="return-fees-currency"
                    value={shipping.returnShippingFeesCurrency}
                    onChange={(e) => setShipping({ ...shipping, returnShippingFeesCurrency: e.target.value.toUpperCase().slice(0, 3) })}
                    dir="ltr"
                    className="text-left"
                  />
                </div>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* ─── Brand fallback setting ─── */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <ShieldCheck className="size-4" /> العلامة التجارية الاحتياطية
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex items-center justify-between rounded-lg border p-3">
            <div>
              <p className="text-sm font-medium">استعمال اسم المتجر كعلامة تجارية للمنتجات بدون علامة</p>
              <p className="text-xs text-muted-foreground">
                يساعد في إزالة تحذير Google "Missing brand". اسم المتجر هو معرّف شرعي (التاجر)، وليس علامة مصنّع وهمية.
              </p>
            </div>
            <Switch
              checked={shipping.useStoreNameAsFallbackBrand}
              onCheckedChange={(v) => setShipping({ ...shipping, useStoreNameAsFallbackBrand: v })}
            />
          </div>
        </CardContent>
      </Card>

      {/* ─── Reviews settings ─── */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Star className="size-4" /> إعدادات التقييمات
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex items-center justify-between rounded-lg border p-3">
            <div>
              <p className="text-sm font-medium">تفعيل التقييمات</p>
              <p className="text-xs text-muted-foreground">السماح للعملاء بإرسال تقييمات</p>
            </div>
            <Switch
              checked={shipping.reviewsEnabled}
              onCheckedChange={(v) => setShipping({ ...shipping, reviewsEnabled: v })}
            />
          </div>
          <div className="flex items-center justify-between rounded-lg border p-3">
            <div>
              <p className="text-sm font-medium">يتطلب موافقة يدوية</p>
              <p className="text-xs text-muted-foreground">التقييمات تبقى «في الانتظار» حتى الموافقة</p>
            </div>
            <Switch
              checked={shipping.reviewsRequireApproval}
              onCheckedChange={(v) => setShipping({ ...shipping, reviewsRequireApproval: v })}
            />
          </div>
          <div className="flex items-center justify-between rounded-lg border p-3">
            <div>
              <p className="text-sm font-medium">شارة «شراء موثّق»</p>
              <p className="text-xs text-muted-foreground">تظهر عند تأكيد طلب مُسلّم بنفس الهاتف</p>
            </div>
            <Switch
              checked={shipping.reviewsShowVerifiedBadge}
              onCheckedChange={(v) => setShipping({ ...shipping, reviewsShowVerifiedBadge: v })}
            />
          </div>
        </CardContent>
      </Card>

      {/* ─── Checkout texts ─── */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <span>نصوص صفحة إتمام الطلب (Checkout)</span>
            <Tabs value={lang} onValueChange={(v) => setLang(v as Lang)}>
              <TabsList>
                <TabsTrigger value="fr">FR</TabsTrigger>
                <TabsTrigger value="ar">AR</TabsTrigger>
                <TabsTrigger value="en">EN</TabsTrigger>
              </TabsList>
            </Tabs>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {SECTIONS.map((section) => (
            <div key={section.key}>
              <Label>{section.label}</Label>
              {section.type === 'input' ? (
                <Input
                  value={texts[section.key][lang]}
                  onChange={(e) => update(section.key, e.target.value)}
                  dir={lang === 'ar' ? 'rtl' : 'ltr'}
                />
              ) : (
                <Textarea
                  value={texts[section.key][lang]}
                  onChange={(e) => update(section.key, e.target.value)}
                  dir={lang === 'ar' ? 'rtl' : 'ltr'}
                  rows={2}
                />
              )}
            </div>
          ))}
        </CardContent>
      </Card>

      <div className="flex flex-wrap justify-end gap-2">
        <Button onClick={saveShipping} disabled={savingShipping} variant="outline">
          {savingShipping ? <Loader2 className="ml-2 h-4 w-4 animate-spin" /> : <RotateCcw className="ml-2 h-4 w-4" />}
          حفظ الشحن والتقييمات
        </Button>
        <Button onClick={saveTexts} disabled={savingTexts}>
          {savingTexts ? <Loader2 className="ml-2 h-4 w-4 animate-spin" /> : <Save className="ml-2 h-4 w-4" />}
          حفظ نصوص الدفع
        </Button>
      </div>
    </div>
  )
}
