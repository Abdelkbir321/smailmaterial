'use client'

import * as React from 'react'
import { Save, Loader2 } from 'lucide-react'
import { toast } from 'sonner'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Switch } from '@/components/ui/switch'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import type { DesignSettings } from '@/services/site-settings'

interface DesignTabProps {
  initial: DesignSettings
}

export function DesignTab({ initial }: DesignTabProps) {
  const [settings, setSettings] = React.useState<DesignSettings>(initial)
  const [saving, setSaving] = React.useState(false)

  const save = async () => {
    setSaving(true)
    try {
      const res = await fetch('/api/admin/settings', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ settings: { design_settings: JSON.stringify(settings) } }),
      })
      if (res.ok) {
        toast.success('تم حفظ إعدادات التصميم')
      } else {
        toast.error('فشل الحفظ')
      }
    } catch {
      toast.error('خطأ في الشبكة')
    } finally {
      setSaving(false)
    }
  }

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle>الألوان</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
            <ColorField label="اللون الأساسي" value={settings.primaryColor} onChange={(v) => setSettings({ ...settings, primaryColor: v })} />
            <ColorField label="لون التمرير (hover)" value={settings.primaryHoverColor} onChange={(v) => setSettings({ ...settings, primaryHoverColor: v })} />
            <ColorField label="لون التمييز" value={settings.accentColor} onChange={(v) => setSettings({ ...settings, accentColor: v })} />
            <ColorField label="لون الخلفية" value={settings.backgroundColor} onChange={(v) => setSettings({ ...settings, backgroundColor: v })} />
            <ColorField label="خلفية ثانوية" value={settings.backgroundSubtleColor} onChange={(v) => setSettings({ ...settings, backgroundSubtleColor: v })} />
            <ColorField label="لون النص" value={settings.textColor} onChange={(v) => setSettings({ ...settings, textColor: v })} />
            <ColorField label="لون البطاقات" value={settings.cardColor} onChange={(v) => setSettings({ ...settings, cardColor: v })} />
            <ColorField label="لون الحدود" value={settings.borderColor} onChange={(v) => setSettings({ ...settings, borderColor: v })} />
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>الأشكال والأحجام</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 gap-4 md:grid-cols-4">
            <div>
              <Label>نوع الزوايا (px)</Label>
              <Input
                type="number"
                min="0"
                max="50"
                value={settings.borderRadius}
                onChange={(e) => setSettings({ ...settings, borderRadius: parseInt(e.target.value) || 0 })}
              />
              <p className="text-xs text-muted-foreground mt-1">0 = مربعة، 50 = دائرية</p>
            </div>
            <div>
              <Label>حجم الأزرار — افقي (px)</Label>
              <Input
                type="number"
                min="4"
                max="32"
                value={settings.buttonPaddingX}
                onChange={(e) => setSettings({ ...settings, buttonPaddingX: parseInt(e.target.value) || 16 })}
              />
            </div>
            <div>
              <Label>حجم الأزرار — عمودي (px)</Label>
              <Input
                type="number"
                min="2"
                max="20"
                value={settings.buttonPaddingY}
                onChange={(e) => setSettings({ ...settings, buttonPaddingY: parseInt(e.target.value) || 8 })}
              />
            </div>
            <div>
              <Label>حجم خط الأزرار (rem)</Label>
              <Input
                type="number"
                step="0.05"
                min="0.5"
                max="1.5"
                value={settings.buttonFontSize}
                onChange={(e) => setSettings({ ...settings, buttonFontSize: parseFloat(e.target.value) || 0.875 })}
              />
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>التخطيط (Layout)</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
            <div>
              <Label>عرض المحتوى الأقصى (px)</Label>
              <Input
                type="number"
                min="800"
                max="1920"
                value={settings.contentMaxWidth}
                onChange={(e) => setSettings({ ...settings, contentMaxWidth: parseInt(e.target.value) || 1280 })}
              />
            </div>
            <div>
              <Label>تباعد الأقسام (px)</Label>
              <Input
                type="number"
                min="24"
                max="160"
                value={settings.sectionSpacing}
                onChange={(e) => setSettings({ ...settings, sectionSpacing: parseInt(e.target.value) || 64 })}
              />
            </div>
            <div>
              <Label>نمط بطاقات المنتجات</Label>
              <Select value={settings.productCardStyle} onValueChange={(v) => setSettings({ ...settings, productCardStyle: v as DesignSettings['productCardStyle'] })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="classic">كلاسيكي</SelectItem>
                  <SelectItem value="compact">مضغوط</SelectItem>
                  <SelectItem value="minimal">بسيط</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>إظهار/إخفاء العناصر</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
            <ToggleField label="شريط الإعلان العلوي" checked={settings.showAnnouncementBar} onChange={(v) => setSettings({ ...settings, showAnnouncementBar: v })} />
            <ToggleField label="قسم الـ Hero" checked={settings.showHeroSection} onChange={(v) => setSettings({ ...settings, showHeroSection: v })} />
            <ToggleField label="منتجات مميزة" checked={settings.showFeaturedProducts} onChange={(v) => setSettings({ ...settings, showFeaturedProducts: v })} />
            <ToggleField label="الأكثر مبيعاً" checked={settings.showBestSellers} onChange={(v) => setSettings({ ...settings, showBestSellers: v })} />
            <ToggleField label="وصل حديثاً" checked={settings.showNewArrivals} onChange={(v) => setSettings({ ...settings, showNewArrivals: v })} />
            <ToggleField label="قسم الماركات" checked={settings.showBrandsSection} onChange={(v) => setSettings({ ...settings, showBrandsSection: v })} />
            <ToggleField label="قسم الأسئلة الشائعة" checked={settings.showFaqSection} onChange={(v) => setSettings({ ...settings, showFaqSection: v })} />
          </div>
        </CardContent>
      </Card>

      <div className="flex justify-end">
        <Button onClick={save} disabled={saving}>
          {saving ? <Loader2 className="ml-2 h-4 w-4 animate-spin" /> : <Save className="ml-2 h-4 w-4" />}
          حفظ إعدادات التصميم
        </Button>
      </div>
    </div>
  )
}

function ColorField({ label, value, onChange }: { label: string; value: string; onChange: (v: string) => void }) {
  return (
    <div>
      <Label>{label}</Label>
      <div className="flex gap-2 items-center">
        <input
          type="color"
          value={value}
          onChange={(e) => onChange(e.target.value)}
          className="h-9 w-12 rounded border border-border cursor-pointer"
        />
        <Input
          value={value}
          onChange={(e) => onChange(e.target.value)}
          dir="ltr"
          className="flex-1"
        />
      </div>
    </div>
  )
}

function ToggleField({ label, checked, onChange }: { label: string; checked: boolean; onChange: (v: boolean) => void }) {
  return (
    <label className="flex items-center justify-between rounded-lg border border-border p-3 cursor-pointer hover:bg-muted/50">
      <span className="text-sm font-medium">{label}</span>
      <Switch checked={checked} onCheckedChange={onChange} />
    </label>
  )
}
