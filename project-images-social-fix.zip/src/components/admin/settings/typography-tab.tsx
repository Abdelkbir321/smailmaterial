'use client'

import * as React from 'react'
import { Save, Loader2 } from 'lucide-react'
import { toast } from 'sonner'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import {
  ARABIC_FONTS,
  LATIN_FONTS,
  HEADING_FONTS,
  type TypographySettings,
} from '@/services/site-settings'

interface TypographyTabProps {
  initial: TypographySettings
}

export function TypographyTab({ initial }: TypographyTabProps) {
  const [settings, setSettings] = React.useState<TypographySettings>(initial)
  const [saving, setSaving] = React.useState(false)

  const save = async () => {
    setSaving(true)
    try {
      // Build Google Fonts URL from selected fonts
      const fontsToLoad: string[] = []
      const arabicFont = ARABIC_FONTS.find((f) => f.value === settings.bodyFontArabic)
      const latinFont = LATIN_FONTS.find((f) => f.value === settings.bodyFontLatin)
      const headingFont = HEADING_FONTS.find((f) => f.value === settings.headingFont)
      const buttonFont = LATIN_FONTS.find((f) => f.value === settings.buttonFont)

      if (arabicFont?.google) fontsToLoad.push(arabicFont.google)
      if (latinFont?.google) fontsToLoad.push(latinFont.google)
      if (headingFont?.google && headingFont.google !== latinFont?.google) fontsToLoad.push(headingFont.google)
      if (buttonFont?.google && !fontsToLoad.includes(buttonFont.google)) fontsToLoad.push(buttonFont.google)

      const googleFontsUrl = fontsToLoad.length > 0
        ? `https://fonts.googleapis.com/css2?${fontsToLoad.map((f) => `family=${f}`).join('&')}&display=swap`
        : ''

      const toSave = { ...settings, googleFontsUrl }

      const res = await fetch('/api/admin/settings', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ settings: { typography: JSON.stringify(toSave) } }),
      })
      if (res.ok) {
        toast.success('تم حفظ إعدادات الخطوط')
        setSettings(toSave)
      } else {
        toast.error('فشل الحفظ')
      }
    } catch {
      toast.error('خطأ في الشبكة')
    } finally {
      setSaving(false)
    }
  }

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle>الخطوط</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
            <div>
              <Label>الخط الأساسي للنصوص العربية</Label>
              <Select value={settings.bodyFontArabic} onValueChange={(v) => setSettings({ ...settings, bodyFontArabic: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {ARABIC_FONTS.map((f) => (
                    <SelectItem key={f.value} value={f.value}>{f.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <p className="mt-1 text-sm" style={{ fontFamily: settings.bodyFontArabic }}>
                مثال: هذا نص تجريبي للخط العربي
              </p>
            </div>
            <div>
              <Label>الخط الأساسي للنصوص الفرنسية/الإنجليزية</Label>
              <Select value={settings.bodyFontLatin} onValueChange={(v) => setSettings({ ...settings, bodyFontLatin: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {LATIN_FONTS.map((f) => (
                    <SelectItem key={f.value} value={f.value}>{f.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <p className="mt-1 text-sm" style={{ fontFamily: settings.bodyFontLatin }}>
                Sample text in Latin font
              </p>
            </div>
            <div>
              <Label>خط العناوين</Label>
              <Select value={settings.headingFont} onValueChange={(v) => setSettings({ ...settings, headingFont: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {HEADING_FONTS.map((f) => (
                    <SelectItem key={f.value} value={f.value}>{f.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <p className="mt-1 text-xl font-bold" style={{ fontFamily: settings.headingFont }}>
                عنوان تجريبي
              </p>
            </div>
            <div>
              <Label>خط الأزرار</Label>
              <Select value={settings.buttonFont} onValueChange={(v) => setSettings({ ...settings, buttonFont: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {LATIN_FONTS.map((f) => (
                    <SelectItem key={f.value} value={f.value}>{f.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Button className="mt-2" size="sm" style={{ fontFamily: settings.buttonFont }}>
                زر تجريبي
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>الأحجام والأوزان</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
            <div>
              <Label>حجم النص الأساسي (rem)</Label>
              <Input
                type="number"
                step="0.05"
                min="0.5"
                max="2"
                value={settings.bodyFontSize}
                onChange={(e) => setSettings({ ...settings, bodyFontSize: parseFloat(e.target.value) || 1 })}
              />
            </div>
            <div>
              <Label>حجم العناوين (rem)</Label>
              <Input
                type="number"
                step="0.1"
                min="1"
                max="4"
                value={settings.headingFontSize}
                onChange={(e) => setSettings({ ...settings, headingFontSize: parseFloat(e.target.value) || 2 })}
              />
            </div>
            <div>
              <Label>حجم النص الصغير (rem)</Label>
              <Input
                type="number"
                step="0.05"
                min="0.5"
                max="1"
                value={settings.smallTextSize}
                onChange={(e) => setSettings({ ...settings, smallTextSize: parseFloat(e.target.value) || 0.875 })}
              />
            </div>
            <div>
              <Label>وزن الخط الأساسي</Label>
              <Select value={String(settings.bodyFontWeight)} onValueChange={(v) => setSettings({ ...settings, bodyFontWeight: parseInt(v) })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {[300, 400, 500, 600, 700].map((w) => (
                    <SelectItem key={w} value={String(w)}>{w}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>وزن العناوين</Label>
              <Select value={String(settings.headingFontWeight)} onValueChange={(v) => setSettings({ ...settings, headingFontWeight: parseInt(v) })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {[400, 500, 600, 700, 800].map((w) => (
                    <SelectItem key={w} value={String(w)}>{w}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>ارتفاع السطر (body)</Label>
              <Input
                type="number"
                step="0.05"
                min="1"
                max="2.5"
                value={settings.bodyLineHeight}
                onChange={(e) => setSettings({ ...settings, bodyLineHeight: parseFloat(e.target.value) || 1.6 })}
              />
            </div>
            <div>
              <Label>ارتفاع سطر العناوين</Label>
              <Input
                type="number"
                step="0.05"
                min="0.8"
                max="2"
                value={settings.headingLineHeight}
                onChange={(e) => setSettings({ ...settings, headingLineHeight: parseFloat(e.target.value) || 1.2 })}
              />
            </div>
            <div>
              <Label>تباعد أحرف النص (em)</Label>
              <Input
                type="number"
                step="0.01"
                min="-0.05"
                max="0.2"
                value={settings.bodyLetterSpacing}
                onChange={(e) => setSettings({ ...settings, bodyLetterSpacing: parseFloat(e.target.value) || 0 })}
              />
            </div>
            <div>
              <Label>تباعد أحرف العناوين (em)</Label>
              <Input
                type="number"
                step="0.01"
                min="-0.1"
                max="0.2"
                value={settings.headingLetterSpacing}
                onChange={(e) => setSettings({ ...settings, headingLetterSpacing: parseFloat(e.target.value) || -0.02 })}
              />
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="flex justify-end">
        <Button onClick={save} disabled={saving}>
          {saving ? <Loader2 className="ml-2 h-4 w-4 animate-spin" /> : <Save className="ml-2 h-4 w-4" />}
          حفظ إعدادات الخطوط
        </Button>
      </div>
    </div>
  )
}
