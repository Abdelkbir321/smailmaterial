'use client'

import * as React from 'react'
import { Save, Loader2 } from 'lucide-react'
import { toast } from 'sonner'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Label } from '@/components/ui/label'
import { Switch } from '@/components/ui/switch'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'

interface GeneralTabProps {
  initial: Record<string, string>
  featureFlags: Record<string, boolean>
}

const GENERAL_FIELDS: Array<{ key: string; label: string; type?: 'input' | 'textarea' }> = [
  { key: 'site_name', label: 'اسم الموقع' },
  { key: 'site_tagline', label: 'الشعار النصي' },
  { key: 'site_description', label: 'الوصف', type: 'textarea' },
  { key: 'support_phone', label: 'هاتف الدعم' },
  { key: 'whatsapp', label: 'واتساب' },
  { key: 'support_email', label: 'بريد الدعم' },
  { key: 'address', label: 'العنوان' },
  { key: 'announcement_bar', label: 'شريط الإعلان' },
]

const FEATURE_FLAGS: Array<{ key: string; label: string }> = [
  { key: 'reviews', label: 'آراء العملاء' },
  { key: 'coupons', label: 'أكواد الخصم' },
  { key: 'wishlist', label: 'قائمة الرغبات' },
  { key: 'online_payments', label: 'الدفع عبر الإنترنت' },
  { key: 'cod', label: 'الدفع عند الاستلام (COD)' },
  { key: 'multi_country', label: 'متعدد الدول' },
  { key: 'maintenance_mode', label: 'وضع الصيانة' },
  { key: 'ai_assistant', label: 'المساعد الذكي' },
]

export function GeneralTab({ initial, featureFlags: initialFlags }: GeneralTabProps) {
  const [settings, setSettings] = React.useState<Record<string, string>>(initial)
  const [flags, setFlags] = React.useState<Record<string, boolean>>(initialFlags)
  const [saving, setSaving] = React.useState(false)

  const save = async () => {
    setSaving(true)
    try {
      const res = await fetch('/api/admin/settings', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ settings, featureFlags: flags }),
      })
      if (res.ok) {
        toast.success('تم حفظ الإعدادات')
      } else {
        const data = await res.json().catch(() => ({}))
        toast.error(data.error || 'فشل الحفظ')
      }
    } catch {
      toast.error('خطأ في الشبكة')
    } finally {
      setSaving(false)
    }
  }

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle>المعلومات العامة</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {GENERAL_FIELDS.map((field) => (
            <div key={field.key}>
              <Label>{field.label}</Label>
              {field.type === 'textarea' ? (
                <Textarea
                  value={settings[field.key] || ''}
                  onChange={(e) => setSettings({ ...settings, [field.key]: e.target.value })}
                  rows={3}
                />
              ) : (
                <Input
                  value={settings[field.key] || ''}
                  onChange={(e) => setSettings({ ...settings, [field.key]: e.target.value })}
                />
              )}
            </div>
          ))}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>الميزات (Feature Flags)</CardTitle>
        </CardHeader>
        <CardContent className="space-y-2">
          {FEATURE_FLAGS.map((flag) => (
            <label key={flag.key} className="flex items-center justify-between rounded-lg border border-border p-3 cursor-pointer hover:bg-muted/50">
              <span className="text-sm font-medium">{flag.label}</span>
              <Switch
                checked={flags[flag.key] ?? false}
                onCheckedChange={(v) => setFlags({ ...flags, [flag.key]: v })}
              />
            </label>
          ))}
        </CardContent>
      </Card>

      <div className="flex justify-end">
        <Button onClick={save} disabled={saving} size="lg">
          {saving ? <Loader2 className="ml-2 h-4 w-4 animate-spin" /> : <Save className="ml-2 h-4 w-4" />}
          حفظ الإعدادات العامة
        </Button>
      </div>
    </div>
  )
}
