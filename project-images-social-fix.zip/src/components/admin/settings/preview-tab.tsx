'use client'

import * as React from 'react'
import Link from 'next/link'
import { ExternalLink, RefreshCw } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { toast } from 'sonner'

export function PreviewTab() {
  const [revalidating, setRevalidating] = React.useState(false)

  const revalidate = async () => {
    setRevalidating(true)
    try {
      const res = await fetch('/api/admin/seo/revalidate', { method: 'POST' })
      if (res.ok) {
        toast.success('تم تحديث الكاش — التغييرات ظاهرة الآن')
      } else {
        toast.error('فشل التحديث')
      }
    } catch {
      toast.error('خطأ في الشبكة')
    } finally {
      setRevalidating(false)
    }
  }

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle>المعاينة والنشر</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="rounded-lg border border-border p-4 space-y-2">
            <h3 className="font-semibold">كيف تعمل التغييرات؟</h3>
            <p className="text-sm text-muted-foreground">
              جميع التغييرات المحفوظة في الأقسام السابقة تظهر فوراً في الواجهة العامة بفضل آلية Cache Revalidation.
              لا حاجة لإعادة بناء المشروع أو نشر نسخة جديدة.
            </p>
          </div>

          <div className="rounded-lg border border-border p-4 space-y-3">
            <h3 className="font-semibold">روابط سريعة</h3>
            <div className="flex flex-wrap gap-2">
              <Link href="/" target="_blank">
                <Button variant="outline" size="sm">
                  <ExternalLink className="ml-1 h-4 w-4" /> الصفحة الرئيسية
                </Button>
              </Link>
              <Link href="/produits" target="_blank">
                <Button variant="outline" size="sm">
                  <ExternalLink className="ml-1 h-4 w-4" /> صفحة المنتجات
                </Button>
              </Link>
              <Link href="/checkout" target="_blank">
                <Button variant="outline" size="sm">
                  <ExternalLink className="ml-1 h-4 w-4" /> صفحة الدفع
                </Button>
              </Link>
              <Link href="/contact" target="_blank">
                <Button variant="outline" size="sm">
                  <ExternalLink className="ml-1 h-4 w-4" /> صفحة التواصل
                </Button>
              </Link>
            </div>
          </div>

          <div className="rounded-lg border border-primary/30 bg-primary/5 p-4 space-y-3">
            <h3 className="font-semibold">تحديث الكاش يدوياً</h3>
            <p className="text-sm text-muted-foreground">
              إذا لم تظهر التغييرات فوراً، اضغط الزر أدناه لفرض تحديث الكاش.
            </p>
            <Button onClick={revalidate} disabled={revalidating}>
              <RefreshCw className={`ml-2 h-4 w-4 ${revalidating ? 'animate-spin' : ''}`} />
              {revalidating ? 'جاري التحديث...' : 'تحديث الكاش الآن'}
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
