'use client'

import * as React from 'react'
import { toast } from 'sonner'
import { PageHeader, Spinner } from '@/components/admin/page-header'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Settings, Share2, FileText, ShoppingCart, Type, Palette, LayoutPanelTop, Eye } from 'lucide-react'
import { SocialTab } from './social-tab'
import { TypographyTab } from './typography-tab'
import { DesignTab } from './design-tab'
import { CheckoutTab } from './checkout-tab'
import { HeaderFooterTab } from './header-footer-tab'
import { GeneralTab } from './general-tab'
import { PreviewTab } from './preview-tab'
import type {
  SocialLinkRow,
  TypographySettings,
  DesignSettings,
  CheckoutTexts,
  HeaderTexts,
  FooterTexts,
  ShippingReturnSettings,
} from '@/services/site-settings'

interface SettingsTabsProps {
  socialLinks: SocialLinkRow[]
  typography: TypographySettings
  design: DesignSettings
  checkoutTexts: CheckoutTexts
  headerTexts: HeaderTexts
  footerTexts: FooterTexts
  generalSettings: Record<string, string>
  featureFlags: Record<string, boolean>
  shippingReturn: ShippingReturnSettings
}

export function SettingsTabs(props: SettingsTabsProps) {
  return (
    <div className="space-y-6">
      <PageHeader
        title="إعدادات الموقع"
        description="تحكم كامل في تصميم ونصوص وإعدادات المتجر من مكان واحد"
        icon={Settings}
      />

      <Tabs defaultValue="general" className="w-full">
        <TabsList className="flex w-full flex-wrap h-auto gap-1 bg-muted/50 p-1">
          <TabsTrigger value="general" className="gap-1.5">
            <Settings className="h-4 w-4" /> الإعدادات العامة
          </TabsTrigger>
          <TabsTrigger value="social" className="gap-1.5">
            <Share2 className="h-4 w-4" /> التواصل الاجتماعي
          </TabsTrigger>
          <TabsTrigger value="checkout" className="gap-1.5">
            <ShoppingCart className="h-4 w-4" /> Checkout والدفع
          </TabsTrigger>
          <TabsTrigger value="typography" className="gap-1.5">
            <Type className="h-4 w-4" /> الخطوط والطباعة
          </TabsTrigger>
          <TabsTrigger value="design" className="gap-1.5">
            <Palette className="h-4 w-4" /> الألوان والتصميم
          </TabsTrigger>
          <TabsTrigger value="header-footer" className="gap-1.5">
            <LayoutPanelTop className="h-4 w-4" /> الهيدر والفوتر
          </TabsTrigger>
          <TabsTrigger value="preview" className="gap-1.5">
            <Eye className="h-4 w-4" /> المعاينة والنشر
          </TabsTrigger>
        </TabsList>

        <TabsContent value="general" className="mt-4">
          <GeneralTab initial={props.generalSettings} featureFlags={props.featureFlags} />
        </TabsContent>

        <TabsContent value="social" className="mt-4">
          <SocialTab initialLinks={props.socialLinks} />
        </TabsContent>

        <TabsContent value="checkout" className="mt-4">
          <CheckoutTab initial={props.checkoutTexts} initialShipping={props.shippingReturn} />
        </TabsContent>

        <TabsContent value="typography" className="mt-4">
          <TypographyTab initial={props.typography} />
        </TabsContent>

        <TabsContent value="design" className="mt-4">
          <DesignTab initial={props.design} />
        </TabsContent>

        <TabsContent value="header-footer" className="mt-4">
          <HeaderFooterTab initialHeader={props.headerTexts} initialFooter={props.footerTexts} />
        </TabsContent>

        <TabsContent value="preview" className="mt-4">
          <PreviewTab />
        </TabsContent>
      </Tabs>
    </div>
  )
}
