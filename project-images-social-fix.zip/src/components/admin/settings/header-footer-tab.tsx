'use client'

import * as React from 'react'
import { Save, Loader2 } from 'lucide-react'
import { toast } from 'sonner'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Label } from '@/components/ui/label'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import type { HeaderTexts, FooterTexts } from '@/services/site-settings'

interface HeaderFooterTabProps {
  initialHeader: HeaderTexts
  initialFooter: FooterTexts
}

type Lang = 'fr' | 'ar' | 'en'

const HEADER_FIELDS: Array<{ key: keyof HeaderTexts; label: string }> = [
  { key: 'announcementText', label: 'نص شريط الإعلان' },
  { key: 'logoSubtitle', label: 'نص بجانب الشعار' },
  { key: 'searchPlaceholder', label: 'نص البحث' },
  { key: 'catalogueButton', label: 'زر الكتالوج' },
  { key: 'navHome', label: 'رابط الرئيسية' },
  { key: 'navProducts', label: 'رابط المنتجات' },
  { key: 'navAllCategories', label: 'رابط عرض الكل' },
]

const FOOTER_FIELDS: Array<{ key: keyof FooterTexts; label: string; type?: 'input' | 'textarea' }> = [
  { key: 'aboutTitle', label: 'عنوان "حول"' },
  { key: 'shippingTitle', label: 'عنوان التوصيل' },
  { key: 'shippingDesc', label: 'وصف التوصيل' },
  { key: 'paymentTitle', label: 'عنوان الدفع' },
  { key: 'paymentDesc', label: 'وصف الدفع' },
  { key: 'supportTitle', label: 'عنوان الدعم' },
  { key: 'supportDesc', label: 'وصف الدعم' },
  { key: 'workingHours', label: 'ساعات العمل' },
  { key: 'catalogTitle', label: 'عنوان الكتالوج' },
  { key: 'allProducts', label: 'جميع المنتجات' },
  { key: 'categoriesTitle', label: 'عنوان الفئات' },
  { key: 'featuredProducts', label: 'منتجات مميزة' },
  { key: 'bestSellers', label: 'الأكثر مبيعاً' },
  { key: 'newArrivals', label: 'وصل حديثاً' },
  { key: 'helpTitle', label: 'عنوان المساعدة' },
  { key: 'helpCenter', label: 'مركز المساعدة' },
  { key: 'contactUs', label: 'اتصل بنا' },
  { key: 'faq', label: 'الأسئلة الشائعة' },
  { key: 'shippingReturns', label: 'التوصيل والإرجاع' },
  { key: 'terms', label: 'الشروط والأحكام' },
  { key: 'brandsTitle', label: 'عنوان الماركات' },
  { key: 'brandsList', label: 'قائمة الماركات' },
  { key: 'copyright', label: 'حقوق النشر' },
  { key: 'codBadge', label: 'شارة الدفع عند الاستلام' },
  { key: 'shippingBadge', label: 'شارة التوصيل' },
]

export function HeaderFooterTab({ initialHeader, initialFooter }: HeaderFooterTabProps) {
  const [header, setHeader] = React.useState<HeaderTexts>(initialHeader)
  const [footer, setFooter] = React.useState<FooterTexts>(initialFooter)
  const [saving, setSaving] = React.useState(false)
  const [lang, setLang] = React.useState<Lang>('fr')

  const updateHeader = (key: keyof HeaderTexts, value: string) => {
    setHeader({ ...header, [key]: { ...header[key], [lang]: value } })
  }

  const updateFooter = (key: keyof FooterTexts, value: string) => {
    setFooter({ ...footer, [key]: { ...footer[key], [lang]: value } })
  }

  const save = async () => {
    setSaving(true)
    try {
      const res = await fetch('/api/admin/settings', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          settings: {
            header_texts: JSON.stringify(header),
            footer_texts: JSON.stringify(footer),
          },
        }),
      })
      if (res.ok) {
        toast.success('تم حفظ نصوص الهيدر والفوتر')
      } else {
        toast.error('فشل الحفظ')
      }
    } catch {
      toast.error('خطأ في الشبكة')
    } finally {
      setSaving(false)
    }
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold">نصوص الهيدر والفوتر</h3>
        <Tabs value={lang} onValueChange={(v) => setLang(v as Lang)}>
          <TabsList>
            <TabsTrigger value="fr">FR</TabsTrigger>
            <TabsTrigger value="ar">AR</TabsTrigger>
            <TabsTrigger value="en">EN</TabsTrigger>
          </TabsList>
        </Tabs>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>نصوص الهيدر</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {HEADER_FIELDS.map((field) => (
            <div key={field.key}>
              <Label>{field.label}</Label>
              <Input
                value={header[field.key][lang]}
                onChange={(e) => updateHeader(field.key, e.target.value)}
                dir={lang === 'ar' ? 'rtl' : 'ltr'}
              />
            </div>
          ))}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>نصوص الفوتر</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {FOOTER_FIELDS.map((field) => (
            <div key={field.key}>
              <Label>{field.label}</Label>
              <Input
                value={footer[field.key][lang]}
                onChange={(e) => updateFooter(field.key, e.target.value)}
                dir={lang === 'ar' ? 'rtl' : 'ltr'}
              />
            </div>
          ))}
        </CardContent>
      </Card>

      <div className="flex justify-end">
        <Button onClick={save} disabled={saving}>
          {saving ? <Loader2 className="ml-2 h-4 w-4 animate-spin" /> : <Save className="ml-2 h-4 w-4" />}
          حفظ النصوص
        </Button>
      </div>
    </div>
  )
}
