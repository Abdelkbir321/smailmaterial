'use client'

import * as React from 'react'
import { Plus, Trash2, GripVertical, Eye, EyeOff, ExternalLink } from 'lucide-react'
import { toast } from 'sonner'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Switch } from '@/components/ui/switch'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import type { SocialLinkRow } from '@/services/site-settings'

const PLATFORMS = [
  { value: 'facebook', label: 'Facebook', icon: 'Facebook' },
  { value: 'instagram', label: 'Instagram', icon: 'Instagram' },
  { value: 'tiktok', label: 'TikTok', icon: 'Music' },
  { value: 'youtube', label: 'YouTube', icon: 'Youtube' },
  { value: 'whatsapp', label: 'WhatsApp', icon: 'MessageCircle' },
  { value: 'telegram', label: 'Telegram', icon: 'Send' },
  { value: 'pinterest', label: 'Pinterest', icon: 'Image' },
  { value: 'linkedin', label: 'LinkedIn', icon: 'Linkedin' },
  { value: 'x', label: 'X (Twitter)', icon: 'Twitter' },
  { value: 'custom', label: 'مخصص', icon: 'Link' },
]

export function SocialTab({ initialLinks }: { initialLinks: SocialLinkRow[] }) {
  const [links, setLinks] = React.useState<SocialLinkRow[]>(initialLinks)
  const [saving, setSaving] = React.useState<string | null>(null)
  const [adding, setAdding] = React.useState(false)
  const [newLink, setNewLink] = React.useState({
    platform: 'facebook',
    label: '',
    url: '',
    showInHeader: false,
    showInFooter: true,
    showInContact: false,
  })

  const createLink = async () => {
    if (!newLink.url) {
      toast.error('الرابط مطلوب')
      return
    }
    try {
      new URL(newLink.url)
    } catch {
      toast.error('رابط غير صالح')
      return
    }
    setAdding(false)
    const res = await fetch('/api/admin/social-links', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        platform: newLink.platform,
        label: newLink.label || null,
        url: newLink.url,
        order: links.length,
        showInHeader: newLink.showInHeader,
        showInFooter: newLink.showInFooter,
        showInContact: newLink.showInContact,
      }),
    })
    if (res.ok) {
      const data = await res.json()
      setLinks([...links, data.link])
      setNewLink({ platform: 'facebook', label: '', url: '', showInHeader: false, showInFooter: true, showInContact: false })
      toast.success('تمت إضافة الحساب')
    } else {
      toast.error('فشل الإضافة')
    }
  }

  const updateLink = async (id: string, field: string, value: string | boolean | number) => {
    setLinks(links.map((l) => (l.id === id ? { ...l, [field]: value } : l)))
  }

  const saveLink = async (id: string) => {
    const link = links.find((l) => l.id === id)
    if (!link) return
    setSaving(id)
    try {
      const res = await fetch(`/api/admin/social-links/${id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(link),
      })
      if (res.ok) {
        toast.success('تم الحفظ')
      } else {
        toast.error('فشل الحفظ')
      }
    } catch {
      toast.error('خطأ في الشبكة')
    } finally {
      setSaving(null)
    }
  }

  const deleteLink = async (id: string) => {
    if (!confirm('هل أنت متأكد من حذف هذا الحساب؟')) return
    const res = await fetch(`/api/admin/social-links/${id}`, { method: 'DELETE' })
    if (res.ok) {
      setLinks(links.filter((l) => l.id !== id))
      toast.success('تم الحذف')
    } else {
      toast.error('فشل الحذف')
    }
  }

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <span>حسابات التواصل الاجتماعي</span>
            <Button size="sm" onClick={() => setAdding(!adding)}>
              <Plus className="ml-1 h-4 w-4" /> إضافة حساب
            </Button>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {adding && (
            <Card className="border-primary/30 bg-primary/5">
              <CardContent className="pt-4 space-y-3">
                <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
                  <div>
                    <Label>المنصة</Label>
                    <Select value={newLink.platform} onValueChange={(v) => setNewLink({ ...newLink, platform: v })}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        {PLATFORMS.map((p) => (
                          <SelectItem key={p.value} value={p.value}>{p.label}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label>رابط الحساب *</Label>
                    <Input
                      placeholder="https://facebook.com/votre-page"
                      value={newLink.url}
                      onChange={(e) => setNewLink({ ...newLink, url: e.target.value })}
                      dir="ltr"
                    />
                  </div>
                  <div>
                    <Label>نص اختياري</Label>
                    <Input
                      placeholder="تابعنا"
                      value={newLink.label}
                      onChange={(e) => setNewLink({ ...newLink, label: e.target.value })}
                    />
                  </div>
                  <div className="flex items-end gap-4">
                    <label className="flex items-center gap-2 text-sm">
                      <Switch checked={newLink.showInHeader} onCheckedChange={(v) => setNewLink({ ...newLink, showInHeader: v })} />
                      الهيدر
                    </label>
                    <label className="flex items-center gap-2 text-sm">
                      <Switch checked={newLink.showInFooter} onCheckedChange={(v) => setNewLink({ ...newLink, showInFooter: v })} />
                      الفوتر
                    </label>
                    <label className="flex items-center gap-2 text-sm">
                      <Switch checked={newLink.showInContact} onCheckedChange={(v) => setNewLink({ ...newLink, showInContact: v })} />
                      صفحة التواصل
                    </label>
                  </div>
                </div>
                <div className="flex gap-2">
                  <Button onClick={createLink} size="sm">حفظ</Button>
                  <Button onClick={() => setAdding(false)} variant="outline" size="sm">إلغاء</Button>
                </div>
              </CardContent>
            </Card>
          )}

          {links.length === 0 && !adding && (
            <p className="text-center text-muted-foreground py-8">لا توجد حسابات. اضغط "إضافة حساب" لإنشاء أول واحد.</p>
          )}

          {links.map((link, idx) => (
            <Card key={link.id} className="border-border">
              <CardContent className="pt-4">
                <div className="grid grid-cols-1 gap-3 md:grid-cols-12 items-start">
                  <div className="md:col-span-1 flex items-center gap-1">
                    <GripVertical className="h-4 w-4 text-muted-foreground" />
                    <Input
                      type="number"
                      value={link.order}
                      onChange={(e) => updateLink(link.id, 'order', parseInt(e.target.value) || 0)}
                      className="w-16"
                    />
                  </div>
                  <div className="md:col-span-2">
                    <Select value={link.platform} onValueChange={(v) => updateLink(link.id, 'platform', v)}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        {PLATFORMS.map((p) => (
                          <SelectItem key={p.value} value={p.value}>{p.label}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="md:col-span-4">
                    <Input
                      placeholder="https://..."
                      value={link.url}
                      onChange={(e) => updateLink(link.id, 'url', e.target.value)}
                      dir="ltr"
                    />
                  </div>
                  <div className="md:col-span-2">
                    <Input
                      placeholder="نص اختياري"
                      value={link.label || ''}
                      onChange={(e) => updateLink(link.id, 'label', e.target.value)}
                    />
                  </div>
                  <div className="md:col-span-3 flex items-center gap-2 flex-wrap">
                    <label className="flex items-center gap-1 text-xs" title="الهيدر">
                      <Switch checked={link.showInHeader} onCheckedChange={(v) => updateLink(link.id, 'showInHeader', v)} />
                      هيدر
                    </label>
                    <label className="flex items-center gap-1 text-xs" title="الفوتر">
                      <Switch checked={link.showInFooter} onCheckedChange={(v) => updateLink(link.id, 'showInFooter', v)} />
                      فوتر
                    </label>
                    <label className="flex items-center gap-1 text-xs" title="صفحة التواصل">
                      <Switch checked={link.showInContact} onCheckedChange={(v) => updateLink(link.id, 'showInContact', v)} />
                      تواصل
                    </label>
                    <label className="flex items-center gap-1 text-xs" title="مفعّل">
                      <Switch checked={link.isEnabled} onCheckedChange={(v) => updateLink(link.id, 'isEnabled', v)} />
                      {link.isEnabled ? <Eye className="h-3 w-3" /> : <EyeOff className="h-3 w-3" />}
                    </label>
                  </div>
                </div>
                <div className="mt-3 flex items-center gap-2 justify-end">
                  <a
                    href={link.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-xs text-muted-foreground hover:text-foreground flex items-center gap-1"
                  >
                    <ExternalLink className="h-3 w-3" /> فتح
                  </a>
                  <Button size="sm" variant="outline" onClick={() => saveLink(link.id)} disabled={saving === link.id}>
                    {saving === link.id ? 'جاري...' : 'حفظ'}
                  </Button>
                  <Button size="sm" variant="destructive" onClick={() => deleteLink(link.id)}>
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </CardContent>
      </Card>
    </div>
  )
}
