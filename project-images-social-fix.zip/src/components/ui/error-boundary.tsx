'use client'

import React, { Component, type ReactNode } from 'react'

/**
 * ErrorBoundary — catches React render errors in the wrapped subtree.
 *
 * WHY THIS EXISTS
 * --------------
 * The homepage has a 3D scene powered by @react-three/fiber. R3F v8
 * declared `react: ">=18 <19"` as its peer dependency — it's NOT
 * compatible with React 19. When the <Canvas> tries to mount in the
 * browser, R3F v8 calls into React 19 reconciler APIs that have
 * changed → throws an uncaught error → React renders the
 * "Application error: a client-side exception has occurred" page on
 * Netlify, and the whole site appears broken.
 *
 * THE FIX
 * --------
 * We wrap the 3D scene (and any other "optional" client component
 * that might fail) in this Error Boundary. If the 3D fails for ANY
 * reason — R3F version mismatch, WebGL not supported, chunk failed
 * to load, etc. — the boundary catches the error and renders the
 * `fallback` prop instead. The page itself never crashes.
 *
 * The fallback for the HeroScene is the static "Z logo + accent
 * dots" composition — visually identical to what the 3D scene would
 * render, just without animation. So users with incompatible setups
 * see a polished visual, not a broken page.
 *
 * USAGE
 * -----
 *   <ErrorBoundary fallback={<StaticFallback />}>
 *     <HeroSceneCanvas />
 *   </ErrorBoundary>
 *
 * The boundary is intentionally silent in production — it logs the
 * error to the console (for developer debugging) but never shows
 * an error UI to the user. The fallback is rendered instead.
 */
interface Props {
  children: ReactNode
  fallback: ReactNode
}

interface State {
  hasError: boolean
}

export class ErrorBoundary extends Component<Props, State> {
  constructor(props: Props) {
    super(props)
    this.state = { hasError: false }
  }

  static getDerivedStateFromError(_error: Error): State {
    // Update state so the next render shows the fallback UI.
    return { hasError: true }
  }

  componentDidCatch(error: Error, errorInfo: React.ErrorInfo) {
    // Log the error to the console so developers can debug it.
    // We don't send it to any external monitoring service — keep it
    // local. The error name + component stack is enough to diagnose.
    if (process.env.NODE_ENV !== 'production') {
      // eslint-disable-next-line no-console
      console.error('[ErrorBoundary] caught error:', error?.name, error?.message)
      // eslint-disable-next-line no-console
      console.error('[ErrorBoundary] component stack:', errorInfo?.componentStack)
    }
  }

  render() {
    if (this.state.hasError) {
      return this.props.fallback
    }
    return this.props.children
  }
}
