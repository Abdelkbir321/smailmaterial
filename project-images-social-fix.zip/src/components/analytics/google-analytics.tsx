import Script from 'next/script'

/**
 * Google Analytics 4 (GA4) integration.
 *
 * This component is rendered ONCE in the root layout. It only loads the
 * gtag.js script when GA4_MEASUREMENT_ID is configured (starts with "G-").
 * When the env var is not set, this component renders nothing — no fake
 * tracking, no placeholder.
 *
 * PRIVACY COMPLIANCE:
 *   - gtag.js is loaded with `anonymize_ip: true` (Google's recommended
 *     setting for GDPR/CCPA — the IP is truncated before being sent to GA4).
 *   - We DO NOT send PII (names, phones, addresses) to GA4. E-commerce
 *     events use only transaction_id, value, currency, items[] (with
 *     technical IDs — never customer names).
 *   - The cookie consent banner (CookieConsent component) fires a
 *     `cookie-consent-declined` event that disables gtag via
 *     `window.gtag('consent', 'update', { analytics_storage: 'denied' })`.
 *
 * SETUP:
 *   1. Create a GA4 property at https://analytics.google.com/
 *   2. Copy the Measurement ID (format: G-XXXXXXXXXX)
 *   3. Add it to Netlify env vars: GA4_MEASUREMENT_ID=G-XXXXXXXXXX
 *   4. Redeploy — this component will start loading gtag.js automatically.
 */

const GA4_MEASUREMENT_ID = process.env.GA4_MEASUREMENT_ID

export function GoogleAnalytics() {
  // Only render when the measurement ID is configured AND valid (starts with G-)
  if (!GA4_MEASUREMENT_ID || !GA4_MEASUREMENT_ID.startsWith('G-')) {
    return null
  }

  return (
    <>
      <Script
        src={`https://www.googletagmanager.com/gtag/js?id=${GA4_MEASUREMENT_ID}`}
        strategy="afterInteractive"
      />
      <Script id="ga4-init" strategy="afterInteractive">
        {`
          window.dataLayer = window.dataLayer || [];
          function gtag(){dataLayer.push(arguments);}
          gtag('js', new Date());
          gtag('config', '${GA4_MEASUREMENT_ID}', {
            anonymize_ip: true,
            cookie_flags: 'SameSite=None;Secure',
          });
          // Respect cookie consent — if the user declined, disable analytics storage.
          window.addEventListener('cookie-consent-declined', function() {
            gtag('consent', 'update', { analytics_storage: 'denied' });
          });
          window.addEventListener('cookie-consent-accepted', function() {
            gtag('consent', 'update', { analytics_storage: 'granted' });
          });
        `}
      </Script>
    </>
  )
}

/**
 * Helper to send GA4 events from client components.
 * Safe to call even when GA4 is not configured — it's a no-op.
 */
export function trackGA4Event(eventName: string, params?: Record<string, unknown>) {
  if (typeof window === 'undefined') return
  if (!GA4_MEASUREMENT_ID || !GA4_MEASUREMENT_ID.startsWith('G-')) return
  const w = window as unknown as { gtag?: (...args: unknown[]) => void }
  if (typeof w.gtag === 'function') {
    w.gtag('event', eventName, params)
  }
}

/**
 * GA4 e-commerce events for the storefront.
 * These complement the in-house analytics — both run in parallel.
 */
export const ga4Events = {
  viewItem: (product: { id: string; name: string; price: number; currency: string }) => {
    trackGA4Event('view_item', {
      currency: product.currency,
      value: product.price,
      items: [{
        item_id: product.id,
        item_name: product.name,
        price: product.price,
      }],
    })
  },
  viewItemList: (products: Array<{ id: string; name: string; price: number }>, listName: string) => {
    trackGA4Event('view_item_list', {
      item_list_name: listName,
      items: products.map((p, i) => ({
        item_id: p.id,
        item_name: p.name,
        price: p.price,
        index: i,
      })),
    })
  },
  addToCart: (product: { id: string; name: string; price: number; currency: string; quantity: number }) => {
    trackGA4Event('add_to_cart', {
      currency: product.currency,
      value: product.price * product.quantity,
      items: [{
        item_id: product.id,
        item_name: product.name,
        price: product.price,
        quantity: product.quantity,
      }],
    })
  },
  beginCheckout: (cartValue: number, currency: string, itemCount: number) => {
    trackGA4Event('begin_checkout', {
      currency,
      value: cartValue,
      itemCount,
    })
  },
  /**
   * Purchase event — ONLY call this when an order is ACTUALLY placed
   * (the server confirmed it). For COD, this means the order was created
   * successfully — NOT that the customer paid.
   */
  purchase: (order: {
    transactionId: string
    value: number
    currency: string
    items: Array<{ item_id: string; item_name: string; price: number; quantity: number }>
  }) => {
    trackGA4Event('purchase', {
      transaction_id: order.transactionId,
      value: order.value,
      currency: order.currency,
      items: order.items,
    })
  },
  search: (query: string) => {
    trackGA4Event('search', { search_term: query })
  },
}
