import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // IMPORTANT: Do NOT use output: "standalone" in next.config.ts.
  // The @netlify/plugin-nextjs plugin sets NEXT_PRIVATE_STANDALONE=true
  // internally and handles SSR/ISR natively via serverless functions.
  typescript: {
    ignoreBuildErrors: true,
  },
  reactStrictMode: false,
  // Exclude sharp from the serverless function bundle.
  // On Netlify, image optimization is handled by Netlify's Image CDN
  // (configured by @netlify/plugin-nextjs), not by the local sharp library.
  // sharp + libvips is ~18MB and would push the function bundle over
  // Netlify's 50MB zipped limit, causing the function to fail to deploy.
  serverExternalPackages: ["sharp"],
  // Security headers applied to ALL routes.
  async headers() {
    return [
      {
        source: "/(.*)",
        headers: [
          { key: "X-Content-Type-Options", value: "nosniff" },
          { key: "X-Frame-Options", value: "SAMEORIGIN" },
          { key: "Referrer-Policy", value: "strict-origin-when-cross-origin" },
          { key: "Permissions-Policy", value: "camera=(), microphone=(), geolocation=(), interest-cohort=()" },
          {
            key: "Strict-Transport-Security",
            value: "max-age=63072000; includeSubDomains; preload",
          },
          {
            key: "Content-Security-Policy",
            value: [
              "default-src 'self'",
              "img-src 'self' https: data: blob:",
              "media-src 'self' https:",
              "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com",
              "font-src 'self' data: https://fonts.gstatic.com",
              "script-src 'self' 'unsafe-inline' 'unsafe-eval'",
              "connect-src 'self' https:",
              "frame-ancestors 'self'",
              "base-uri 'self'",
              "form-action 'self' https:",
              "object-src 'none'",
            ].join("; "),
          },
          { key: "X-DNS-Prefetch-Control", value: "on" },
        ],
      },
      {
        source: "/_next/static/:path*",
        headers: [
          { key: "Cache-Control", value: "public, max-age=31536000, immutable" },
          { key: "X-Content-Type-Options", value: "nosniff" },
        ],
      },
    ];
  },
};

export default nextConfig;
