import ZAI from 'z-ai-web-dev-sdk'
import fs from 'node:fs'
import path from 'node:path'

/**
 * Generate real, professional product images for all seeded products.
 * Saves to public/products/<slug>.png (1024x1024, studio product photography).
 * Re-run safely — skips files that already exist.
 */
const PRODUCTS = [
  { slug: 'visseuse-impact-20v-ingco', prompt: 'Professional product photography of a cordless impact driver power tool, 20V, brushless, with battery pack, bright clean white background, studio lighting, sharp detail, e-commerce product shot, high quality' },
  { slug: 'perceuse-sans-fil-18v', prompt: 'Professional product photography of a cordless drill driver 18V with battery and chuck, modern design, clean white background, studio lighting, e-commerce product shot, high quality' },
  { slug: 'meuleuse-115mm-total-tools', prompt: 'Professional product photography of an angle grinder power tool 115mm with cutting disc, industrial design, clean white background, studio lighting, e-commerce product shot, high quality' },
  { slug: 'telemetre-laser-40m-ingco', prompt: 'Professional product photography of a handheld laser distance meter 40m measuring tool, digital display, yellow and black, clean white background, studio lighting, e-commerce product shot, high quality' },
  { slug: 'casque-anti-bruit-wurth', prompt: 'Professional product photography of protective earmuffs hearing protection safety headphones, blue and white, clean white background, studio lighting, e-commerce product shot, high quality' },
  { slug: 'gants-mecaniciens-crown', prompt: 'Professional product photography of mechanic work gloves, protective gloves, black and orange, clean white background, studio lighting, e-commerce product shot, high quality' },
  { slug: 'poste-souder-inverter-200a-total-tools', prompt: 'Professional product photography of an inverter arc welder machine 200A, industrial welding equipment with cables, red and black, clean white background, studio lighting, e-commerce product shot, high quality' },
  { slug: 'set-embouts-32p-wurth', prompt: 'Professional product photography of a 32-piece screwdriver bit set with case, chrome vanadium bits, organized kit, clean white background, studio lighting, e-commerce product shot, high quality' },
  { slug: 'niveau-laser-rotatif-total-tools', prompt: 'Professional product photography of a rotary laser level construction measuring tool with tripod mount, green laser, clean white background, studio lighting, e-commerce product shot, high quality' },
  { slug: 'marteau-perforateur-sds-crown', prompt: 'Professional product photography of an SDS rotary hammer drill power tool with chisel, heavy duty, blue and black, clean white background, studio lighting, e-commerce product shot, high quality' },
]

async function main() {
  const outDir = path.join(process.cwd(), 'public', 'products')
  if (!fs.existsSync(outDir)) fs.mkdirSync(outDir, { recursive: true })

  const zai = await ZAI.create()
  let ok = 0, fail = 0, skip = 0
  for (const p of PRODUCTS) {
    const outFile = path.join(outDir, `${p.slug}.png`)
    if (fs.existsSync(outFile) && fs.statSync(outFile).size > 5000) {
      console.log(`  skip (exists): ${p.slug}`)
      skip++
      continue
    }
    try {
      console.log(`  generating: ${p.slug} ...`)
      const res = await zai.images.generations.create({ prompt: p.prompt, size: '1024x1024' })
      const b64 = res.data?.[0]?.base64
      if (!b64) throw new Error('no base64 in response')
      fs.writeFileSync(outFile, Buffer.from(b64, 'base64'))
      console.log(`  OK ${p.slug} (${(fs.statSync(outFile).size / 1024).toFixed(0)} KB)`)
      ok++
    } catch (e) {
      console.error(`  FAIL ${p.slug}: ${(e as Error).message}`)
      fail++
    }
  }
  console.log(`\nDone: ${ok} generated, ${skip} skipped, ${fail} failed`)
}

main().catch((e) => { console.error(e); process.exit(1) })
