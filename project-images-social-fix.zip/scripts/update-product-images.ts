import { db } from '../src/lib/db'

/**
 * Update all seeded products' images to use the REAL generated product photos
 * in /public/products/<slug>.png (instead of placehold.co placeholders).
 * Idempotent — safe to re-run.
 */
async function main() {
  const products = await db.product.findMany({ select: { id: true, slug: true }, where: { status: 'PUBLISHED' } })
  let updated = 0
  for (const p of products) {
    const localUrl = `/products/${p.slug}.png`
    // Update existing images for this product to point to the real local file
    const existing = await db.productImage.findMany({ where: { productId: p.id } })
    if (existing.length === 0) {
      // Create the image row
      await db.productImage.create({
        data: {
          productId: p.id,
          sourceType: 'external',
          publicId: `local/${p.slug}`,
          externalUrl: localUrl,
          secureUrl: localUrl,
          url: localUrl,
          width: 1024,
          height: 1024,
          format: 'png',
          altText: p.slug.replace(/-/g, ' '),
          sortOrder: 0,
          isMain: true,
        },
      })
    } else {
      // Point first image to the real file, mark isMain
      await db.productImage.update({
        where: { id: existing[0].id },
        data: { sourceType: 'external', externalUrl: localUrl, secureUrl: localUrl, url: localUrl, isMain: true, altText: p.slug.replace(/-/g, ' ') },
      })
      // Remove any extra placeholder images
      if (existing.length > 1) {
        await db.productImage.deleteMany({ where: { productId: p.id, NOT: { id: existing[0].id } } })
      }
    }
    updated++
    console.log(`  ✓ ${p.slug} → ${localUrl}`)
  }
  console.log(`\n✅ Updated ${updated} products with real images`)
}

main()
  .catch((e) => { console.error(e); process.exit(1) })
  .finally(() => db.$disconnect())
